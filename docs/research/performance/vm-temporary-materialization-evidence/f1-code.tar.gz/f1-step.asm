
/home/kan/Документы/develop/open-bsl-materialization.UpSJarfM/f1-target/release/bsl-cli:     file format elf64-x86-64


Disassembly of section .text:

0000000000c0f920 <_RNvCsbxgXiyEKxkX_6bsl_vm4step>:
  c0f920:	push   rbp
  c0f921:	push   r15
  c0f923:	push   r14
  c0f925:	push   r13
  c0f927:	push   r12
  c0f929:	push   rbx
  c0f92a:	sub    rsp,0x5e8
  c0f931:	mov    rbx,QWORD PTR [rsi+0x10]
  c0f935:	mov    r10,rbx
  c0f938:	sub    r10,0x1
  c0f93c:	jb     c19766 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e46>
  c0f942:	lea    r11,[rsi+0x8]
  c0f946:	mov    rax,QWORD PTR [r11]
  c0f949:	imul   r15,r10,0x78
  c0f94d:	mov    r14,QWORD PTR [rax+r15*1+0x50]
  c0f952:	mov    r12,QWORD PTR [rcx+0x28]
  c0f956:	cmp    r14,r12
  c0f959:	jae    c0fa06 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xe6>
  c0f95f:	mov    QWORD PTR [rsp+0x350],r8
  c0f967:	mov    r8,r10
  c0f96a:	mov    r10,QWORD PTR [rsp+0x620]
  c0f972:	mov    QWORD PTR [rsp+0x18],r15
  c0f977:	mov    r15,QWORD PTR [rax+r15*1+0x58]
  c0f97c:	mov    rbp,QWORD PTR [rcx+0x20]
  c0f980:	imul   r13,r14,0xc8
  c0f987:	mov    rax,QWORD PTR [rbp+r13*1+0x10]
  c0f98c:	mov    QWORD PTR [rsp+0x1d8],rax
  c0f994:	cmp    r15,rax
  c0f997:	jae    c0fa21 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x101>
  c0f99d:	add    r13,rbp
  c0f9a0:	mov    rax,QWORD PTR [r13+0xb0]
  c0f9a7:	mov    QWORD PTR [rsp+0x1c0],r13
  c0f9af:	mov    r13,QWORD PTR [r13+0xb8]
  c0f9b6:	mov    QWORD PTR [rsp+0x578],r13
  c0f9be:	cmp    r15,r13
  c0f9c1:	mov    QWORD PTR [rsp+0x10],rdi
  c0f9c6:	mov    QWORD PTR [rsp+0x198],r11
  c0f9ce:	mov    QWORD PTR [rsp+0x20],rdx
  c0f9d3:	mov    QWORD PTR [rsp+0x1b8],r9
  c0f9db:	mov    QWORD PTR [rsp+0x3b0],r12
  c0f9e3:	mov    QWORD PTR [rsp+0x568],rax
  c0f9eb:	jae    c0fac8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a8>
  c0f9f1:	mov    r13,r15
  c0f9f4:	movzx  r15d,BYTE PTR [rax+r15*1]
  c0f9f9:	cmp    r15b,0x1
  c0f9fd:	adc    r15b,0xff
  c0fa01:	jmp    c0face <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ae>
  c0fa06:	mov    BYTE PTR [rdi],0x1f
  c0fa09:	lea    rax,[rip+0xffffffffff6b6883]        # 2c6293 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x18d2>
  c0fa10:	mov    QWORD PTR [rdi+0x8],rax
  c0fa14:	mov    QWORD PTR [rdi+0x10],0x3a
  c0fa1c:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c0fa21:	mov    rbx,rdi
  c0fa24:	mov    DWORD PTR [rsp+0x70],0x2
  c0fa2c:	mov    r8,QWORD PTR [r10]
  c0fa2f:	mov    rcx,r9
  c0fa32:	mov    r9,QWORD PTR [r10+0x10]
  c0fa36:	sub    rsp,0x8
  c0fa3a:	lea    rax,[rsp+0x78]
  c0fa3f:	lea    rdi,[rsp+0x108]
  c0fa47:	push   rax
  c0fa48:	call   c0dae0 <_RNvCsbxgXiyEKxkX_6bsl_vm20do_return_with_value>
  c0fa4d:	add    rsp,0x10
  c0fa51:	movzx  eax,BYTE PTR [rsp+0x100]
  c0fa59:	cmp    al,0xff
  c0fa5b:	je     c1739e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a7e>
  c0fa61:	mov    ecx,DWORD PTR [rsp+0x101]
  c0fa68:	mov    edx,DWORD PTR [rsp+0x104]
  c0fa6f:	mov    DWORD PTR [rbx+0x4],edx
  c0fa72:	mov    DWORD PTR [rbx+0x1],ecx
  c0fa75:	mov    ecx,DWORD PTR [rsp+0x108]
  c0fa7c:	movups xmm0,XMMWORD PTR [rsp+0x10c]
  c0fa84:	movaps XMMWORD PTR [rsp+0x3c0],xmm0
  c0fa8c:	mov    edx,DWORD PTR [rsp+0x11c]
  c0fa93:	mov    DWORD PTR [rsp+0x3d0],edx
  c0fa9a:	movups xmm0,XMMWORD PTR [rsp+0x120]
  c0faa2:	movups XMMWORD PTR [rbx+0x20],xmm0
  c0faa6:	mov    edx,DWORD PTR [rsp+0x3d0]
  c0faad:	mov    DWORD PTR [rbx+0x1c],edx
  c0fab0:	movdqa xmm0,XMMWORD PTR [rsp+0x3c0]
  c0fab9:	movdqu XMMWORD PTR [rbx+0xc],xmm0
  c0fabe:	mov    BYTE PTR [rbx],al
  c0fac0:	mov    DWORD PTR [rbx+0x8],ecx
  c0fac3:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c0fac8:	mov    r13,r15
  c0facb:	xor    r15d,r15d
  c0face:	mov    r10,r8
  c0fad1:	mov    r9,QWORD PTR [rsp+0x620]
  c0fad9:	mov    QWORD PTR [rsp+0x3a8],rbp
  c0fae1:	mov    QWORD PTR [rsp+0x580],rbx
  c0fae9:	mov    rax,QWORD PTR [rsp+0x658]
  c0faf1:	mov    QWORD PTR [rsp+0x4e0],rax
  c0faf9:	mov    QWORD PTR [rsp+0x8],rsi
  c0fafe:	lea    rax,[rsi+0x10]
  c0fb02:	mov    QWORD PTR [rsp+0x1a8],rax
  c0fb0a:	mov    rax,QWORD PTR [rsp+0x638]
  c0fb12:	lea    rdx,[rax+0x100]
  c0fb19:	lea    rsi,[rax+0x110]
  c0fb20:	mov    QWORD PTR [rsp+0x3b8],r14
  c0fb28:	lea    rdi,[r14+r14*2]
  c0fb2c:	shl    rdi,0x3
  c0fb30:	mov    r8,QWORD PTR [rsp+0x350]
  c0fb38:	add    rdi,QWORD PTR [r8+0x8]
  c0fb3c:	mov    QWORD PTR [rsp+0x190],rdi
  c0fb44:	mov    QWORD PTR [rsp+0x398],rsi
  c0fb4c:	movq   xmm0,rsi
  c0fb51:	mov    QWORD PTR [rsp+0x3a0],rdx
  c0fb59:	movq   xmm1,rdx
  c0fb5e:	punpcklqdq xmm1,xmm0
  c0fb62:	movdqa XMMWORD PTR [rsp+0x520],xmm1
  c0fb6b:	lea    rdx,[rax+0x58]
  c0fb6f:	mov    QWORD PTR [rsp+0x390],rdx
  c0fb77:	lea    rdx,[rax+0x48]
  c0fb7b:	mov    QWORD PTR [rsp+0x388],rdx
  c0fb83:	lea    rdx,[rax+0x68]
  c0fb87:	mov    QWORD PTR [rsp+0x380],rdx
  c0fb8f:	lea    rdx,[rax+0xf0]
  c0fb96:	mov    QWORD PTR [rsp+0x378],rdx
  c0fb9e:	lea    rdx,[rax+0x118]
  c0fba5:	mov    QWORD PTR [rsp+0x370],rdx
  c0fbad:	mov    rdx,QWORD PTR [rcx+0x38]
  c0fbb1:	mov    QWORD PTR [rsp+0x4b8],rdx
  c0fbb9:	mov    rdx,QWORD PTR [rcx+0x40]
  c0fbbd:	mov    QWORD PTR [rsp+0x4c0],rdx
  c0fbc5:	mov    rdx,QWORD PTR [r8+0x10]
  c0fbc9:	mov    QWORD PTR [rsp+0x4c8],rdx
  c0fbd1:	lea    rax,[rax+0xb8]
  c0fbd8:	mov    QWORD PTR [rsp+0x4b0],rax
  c0fbe0:	mov    rax,QWORD PTR [r9]
  c0fbe3:	mov    QWORD PTR [rsp+0x4e8],rax
  c0fbeb:	mov    rax,QWORD PTR [r9+0x8]
  c0fbef:	mov    QWORD PTR [rsp+0x570],rax
  c0fbf7:	mov    QWORD PTR [rsp+0x1b0],rcx
  c0fbff:	mov    rax,QWORD PTR [rcx+0x88]
  c0fc06:	mov    QWORD PTR [rsp+0x4d0],rax
  c0fc0e:	mov    QWORD PTR [rsp+0x4d8],rax
  c0fc16:	mov    QWORD PTR [rsp],r10
  c0fc1a:	mov    rax,QWORD PTR [rsp+0x1c0]
  c0fc22:	jmp    c0fc60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x340>
  c0fc24:	mov    rcx,QWORD PTR [rsp+0x568]
  c0fc2c:	movzx  r15d,BYTE PTR [rcx+rax*1]
  c0fc31:	cmp    r15b,0x1
  c0fc35:	adc    r15b,0xff
  c0fc39:	mov    r13,rax
  c0fc3c:	mov    rax,QWORD PTR [rsp+0x1c0]
  c0fc44:	cmp    r13,QWORD PTR [rsp+0x1d8]
  c0fc4c:	jae    c1973d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e1d>
  c0fc52:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  c0fc60:	mov    rcx,QWORD PTR [rax+0x8]
  c0fc64:	movzx  edx,BYTE PTR [rcx+r13*8]
  c0fc69:	mov    r10,rax
  c0fc6c:	movzx  r14d,BYTE PTR [rcx+r13*8+0x1]
  c0fc72:	movzx  r12d,r14b
  c0fc76:	movzx  ebp,WORD PTR [rcx+r13*8+0x2]
  c0fc7c:	mov    eax,ebp
  c0fc7e:	shr    eax,0x8
  c0fc81:	mov    ebx,DWORD PTR [rcx+r13*8+0x4]
  c0fc86:	lea    rsi,[rip+0xffffffffff6b5a7f]        # 2c570c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xd4b>
  c0fc8d:	movsxd rdx,DWORD PTR [rsi+rdx*4]
  c0fc91:	add    rdx,rsi
  c0fc94:	jmp    rdx
  c0fc96:	mov    rsi,QWORD PTR [rcx+r13*8]
  c0fc9a:	lea    rdi,[rsp+0x100]
  c0fca2:	mov    r12,QWORD PTR [rsp+0x8]
  c0fca7:	mov    rdx,r12
  c0fcaa:	mov    rcx,QWORD PTR [rsp+0x20]
  c0fcaf:	mov    r8,QWORD PTR [rsp+0x1b0]
  c0fcb7:	mov    r9,QWORD PTR [rsp+0x350]
  c0fcbf:	push   r10
  c0fcc1:	push   QWORD PTR [rsp+0x3c0]
  c0fcc8:	push   QWORD PTR [rsp+0x10]
  c0fccc:	push   QWORD PTR [rsp+0x4f8]
  c0fcd3:	push   QWORD PTR [rsp+0x670]
  c0fcda:	push   QWORD PTR [rsp+0x598]
  c0fce1:	push   QWORD PTR [rsp+0x518]
  c0fce8:	push   QWORD PTR [rsp+0x1f0]
  c0fcef:	push   QWORD PTR [rsp+0x670]
  c0fcf6:	push   QWORD PTR [rsp+0x688]
  c0fcfd:	push   QWORD PTR [rsp+0x688]
  c0fd04:	push   QWORD PTR [rsp+0x680]
  c0fd0b:	call   c1ab40 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold>
  c0fd10:	add    rsp,0x60
  c0fd14:	cmp    BYTE PTR [rsp+0x100],0xff
  c0fd1c:	jne    c19588 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c68>
  c0fd22:	mov    rbx,QWORD PTR [rsp+0x10]
  c0fd27:	lea    rbp,[r12+0x8]
  c0fd2c:	mov    r14,QWORD PTR [rsp+0x18]
  c0fd31:	test   r15b,r15b
  c0fd34:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c0fd3a:	cmp    BYTE PTR [rsp+0x648],0x0
  c0fd42:	je     c1738f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a6f>
  c0fd48:	lea    rax,[r12+0x10]
  c0fd4d:	mov    rcx,QWORD PTR [rsp+0x580]
  c0fd55:	cmp    QWORD PTR [rax],rcx
  c0fd58:	jne    c1738f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a6f>
  c0fd5e:	mov    rax,QWORD PTR [rbp+0x0]
  c0fd62:	mov    rax,QWORD PTR [rax+r14*1+0x58]
  c0fd67:	inc    r13
  c0fd6a:	cmp    rax,r13
  c0fd6d:	jne    c1738f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a6f>
  c0fd73:	cmp    rax,QWORD PTR [rsp+0x1d8]
  c0fd7b:	jae    c1738f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a6f>
  c0fd81:	cmp    rax,QWORD PTR [rsp+0x578]
  c0fd89:	jb     c0fc24 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x304>
  c0fd8f:	xor    r15d,r15d
  c0fd92:	mov    r13,rax
  c0fd95:	mov    rax,QWORD PTR [rsp+0x1c0]
  c0fd9d:	cmp    r13,QWORD PTR [rsp+0x1d8]
  c0fda5:	jb     c0fc60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x340>
  c0fdab:	jmp    c1973d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e1d>
  c0fdb0:	mov    rcx,QWORD PTR [rsp+0x8]
  c0fdb5:	lea    rax,[rcx+0x10]
  c0fdb9:	mov    rsi,QWORD PTR [rax]
  c0fdbc:	cmp    QWORD PTR [rsp],rsi
  c0fdc0:	jae    c19931 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa011>
  c0fdc6:	lea    rax,[rcx+0x8]
  c0fdca:	mov    rsi,QWORD PTR [rax]
  c0fdcd:	mov    rdi,QWORD PTR [rsp+0x18]
  c0fdd2:	lea    rdx,[rsi+rdi*1]
  c0fdd6:	movzx  ecx,bpl
  c0fdda:	mov    rax,rcx
  c0fddd:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c0fde2:	mov    r14,QWORD PTR [rsp+0x10]
  c0fde7:	jae    c10bcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12ac>
  c0fded:	mov    rax,QWORD PTR [rdx+0x28]
  c0fdf1:	shl    ecx,0x4
  c0fdf4:	mov    rax,QWORD PTR [rax+rcx*1]
  c0fdf8:	jmp    c10bd0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12b0>
  c0fdfd:	mov    r12,QWORD PTR [rsp+0x8]
  c0fe02:	lea    rax,[r12+0x10]
  c0fe07:	mov    rsi,QWORD PTR [rax]
  c0fe0a:	cmp    QWORD PTR [rsp],rsi
  c0fe0e:	jae    c198ca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9faa>
  c0fe14:	lea    rdx,[r12+0x8]
  c0fe19:	mov    rax,QWORD PTR [rdx]
  c0fe1c:	movsx  rcx,bp
  c0fe20:	mov    rbp,rdx
  c0fe23:	mov    r14,QWORD PTR [rsp+0x18]
  c0fe28:	mov    QWORD PTR [rax+r14*1+0x58],rcx
  c0fe2d:	mov    rbx,QWORD PTR [rsp+0x10]
  c0fe32:	test   r15b,r15b
  c0fe35:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c0fe3b:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c0fe40:	mov    eax,ebx
  c0fe42:	shr    eax,0x10
  c0fe45:	cmp    QWORD PTR [r10+0x40],rax
  c0fe49:	jbe    c175e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7cc6>
  c0fe4f:	movzx  edx,bx
  c0fe52:	mov    rcx,QWORD PTR [rsp+0x3b0]
  c0fe5a:	cmp    rcx,rdx
  c0fe5d:	jbe    c178ca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7faa>
  c0fe63:	lea    rbx,[rax+rax*2]
  c0fe67:	shl    ebx,0x3
  c0fe6a:	mov    QWORD PTR [rsp+0x4a8],rdx
  c0fe72:	imul   rax,rdx,0xc8
  c0fe79:	mov    rcx,QWORD PTR [rsp+0x3a8]
  c0fe81:	lea    rdx,[rcx+rax*1]
  c0fe85:	mov    QWORD PTR [rsp+0x1e0],rdx
  c0fe8d:	mov    rdx,QWORD PTR [rsp+0x1c0]
  c0fe95:	add    rbx,QWORD PTR [rdx+0x38]
  c0fe99:	cmp    BYTE PTR [rcx+rax*1+0xc1],0x0
  c0fea1:	jne    c17ba2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8282>
  c0fea7:	mov    rcx,QWORD PTR [rsp+0x8]
  c0feac:	lea    rax,[rcx+0x10]
  c0feb0:	mov    rsi,QWORD PTR [rax]
  c0feb3:	cmp    rsi,0x3e7
  c0feba:	ja     c181ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x888c>
  c0fec0:	cmp    QWORD PTR [rsp],rsi
  c0fec4:	jae    c19c7d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa35d>
  c0feca:	mov    edi,r15d
  c0fecd:	lea    rax,[rcx+0x8]
  c0fed1:	mov    rax,QWORD PTR [rax]
  c0fed4:	mov    rcx,QWORD PTR [rsp+0x18]
  c0fed9:	inc    QWORD PTR [rax+rcx*1+0x58]
  c0fede:	mov    rcx,QWORD PTR [rbx+0x10]
  c0fee2:	mov    r12,rcx
  c0fee5:	shl    r12,0x4
  c0fee9:	movabs rax,0xfffffffffffffff
  c0fef3:	mov    r15,rcx
  c0fef6:	cmp    rcx,rax
  c0fef9:	seta   al
  c0fefc:	movabs rcx,0x7ffffffffffffff8
  c0ff06:	cmp    r12,rcx
  c0ff09:	seta   cl
  c0ff0c:	or     cl,al
  c0ff0e:	jne    c17404 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ae4>
  c0ff14:	test   r12,r12
  c0ff17:	mov    QWORD PTR [rsp+0x1a0],r13
  c0ff1f:	mov    DWORD PTR [rsp+0x2c],edi
  c0ff23:	je     c11bc9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x22a9>
  c0ff29:	call   QWORD PTR [rip+0x23d831]        # e4d760 <_DYNAMIC+0x300>
  c0ff2f:	mov    r13d,0x8
  c0ff35:	mov    esi,0x8
  c0ff3a:	mov    rdi,r12
  c0ff3d:	call   QWORD PTR [rip+0x23d825]        # e4d768 <_DYNAMIC+0x308>
  c0ff43:	test   rax,rax
  c0ff46:	je     c1740f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7aef>
  c0ff4c:	mov    rcx,r15
  c0ff4f:	mov    r13,QWORD PTR [rsp+0x1a0]
  c0ff57:	jmp    c11bd0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x22b0>
  c0ff5c:	mov    rdx,QWORD PTR [rsp+0x8]
  c0ff61:	lea    rcx,[rdx+0x10]
  c0ff65:	mov    rsi,QWORD PTR [rcx]
  c0ff68:	cmp    QWORD PTR [rsp],rsi
  c0ff6c:	jae    c1986c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f4c>
  c0ff72:	lea    rcx,[rdx+0x8]
  c0ff76:	mov    rdi,QWORD PTR [rcx]
  c0ff79:	mov    r10,QWORD PTR [rsp+0x18]
  c0ff7e:	lea    rsi,[rdi+r10*1]
  c0ff82:	movzx  edx,bpl
  c0ff86:	mov    rcx,rdx
  c0ff89:	sub    rcx,QWORD PTR [rdi+r10*1+0x30]
  c0ff8e:	mov    r14,QWORD PTR [rsp+0x10]
  c0ff93:	jae    c10c2e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x130e>
  c0ff99:	mov    rcx,QWORD PTR [rsi+0x28]
  c0ff9d:	shl    edx,0x4
  c0ffa0:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c0ffa4:	jmp    c10c32 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1312>
  c0ffa9:	mov    rdx,QWORD PTR [rsp+0x8]
  c0ffae:	lea    rcx,[rdx+0x8]
  c0ffb2:	mov    rsi,QWORD PTR [rcx]
  c0ffb5:	lea    rbx,[rdx+0x10]
  c0ffb9:	mov    rdx,QWORD PTR [rbx]
  c0ffbc:	mov    rdi,QWORD PTR [rsp+0x20]
  c0ffc1:	mov    rcx,QWORD PTR [rdi+0x8]
  c0ffc5:	mov    r8,QWORD PTR [rdi+0x10]
  c0ffc9:	sub    rsp,0x8
  c0ffcd:	movzx  eax,al
  c0ffd0:	movzx  r10d,bpl
  c0ffd4:	lea    rdi,[rsp+0x108]
  c0ffdc:	mov    r14,QWORD PTR [rsp+0x8]
  c0ffe1:	mov    r9,r14
  c0ffe4:	push   rax
  c0ffe5:	push   r10
  c0ffe7:	push   r12
  c0ffe9:	call   c1a7e0 <_RNvCsbxgXiyEKxkX_6bsl_vm6add_op>
  c0ffee:	add    rsp,0x20
  c0fff2:	cmp    BYTE PTR [rsp+0x100],0xff
  c0fffa:	jne    c19588 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c68>
  c10000:	mov    rsi,QWORD PTR [rbx]
  c10003:	cmp    r14,rsi
  c10006:	mov    rbx,QWORD PTR [rsp+0x10]
  c1000b:	jb     c10a12 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x10f2>
  c10011:	jmp    c199f9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0d9>
  c10016:	mov    rcx,QWORD PTR [rsp+0x8]
  c1001b:	lea    rax,[rcx+0x10]
  c1001f:	mov    rsi,QWORD PTR [rax]
  c10022:	cmp    QWORD PTR [rsp],rsi
  c10026:	jae    c198e8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fc8>
  c1002c:	lea    rax,[rcx+0x8]
  c10030:	mov    rcx,QWORD PTR [rax]
  c10033:	mov    r14,QWORD PTR [rsp+0x18]
  c10038:	lea    rax,[rcx+r14*1]
  c1003c:	cmp    QWORD PTR [rcx+r14*1+0x30],r12
  c10041:	mov    rbx,QWORD PTR [rsp+0x10]
  c10046:	jbe    c1005c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x73c>
  c10048:	mov    rcx,QWORD PTR [rax+0x28]
  c1004c:	shl    r12d,0x4
  c10050:	cmp    BYTE PTR [rcx+r12*1+0x8],0x0
  c10056:	je     c11acc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21ac>
  c1005c:	movsx  rcx,bp
  c10060:	mov    QWORD PTR [rax+0x58],rcx
  c10064:	jmp    c11ad0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21b0>
  c10069:	mov    rdx,QWORD PTR [rsp+0x8]
  c1006e:	lea    rcx,[rdx+0x8]
  c10072:	mov    rsi,QWORD PTR [rcx]
  c10075:	lea    rbx,[rdx+0x10]
  c10079:	mov    rdx,QWORD PTR [rbx]
  c1007c:	mov    rdi,QWORD PTR [rsp+0x20]
  c10081:	mov    rcx,QWORD PTR [rdi+0x8]
  c10085:	mov    r8,QWORD PTR [rdi+0x10]
  c10089:	sub    rsp,0x8
  c1008d:	movzx  eax,al
  c10090:	movzx  r10d,bpl
  c10094:	lea    rdi,[rsp+0x108]
  c1009c:	mov    r14,QWORD PTR [rsp+0x8]
  c100a1:	mov    r9,r14
  c100a4:	push   rax
  c100a5:	push   r10
  c100a7:	push   r12
  c100a9:	call   c082a0 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3remEB2_>
  c100ae:	add    rsp,0x20
  c100b2:	cmp    BYTE PTR [rsp+0x100],0xff
  c100ba:	jne    c19588 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c68>
  c100c0:	mov    rsi,QWORD PTR [rbx]
  c100c3:	cmp    r14,rsi
  c100c6:	mov    rbx,QWORD PTR [rsp+0x10]
  c100cb:	jb     c10a12 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x10f2>
  c100d1:	jmp    c19995 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa075>
  c100d6:	mov    rdi,QWORD PTR [rsp+0x8]
  c100db:	lea    rcx,[rdi+0x10]
  c100df:	mov    rsi,QWORD PTR [rcx]
  c100e2:	cmp    QWORD PTR [rsp],rsi
  c100e6:	jae    c198f9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fd9>
  c100ec:	mov    rcx,QWORD PTR [rsp+0x20]
  c100f1:	mov    rsi,QWORD PTR [rcx+0x8]
  c100f5:	mov    rdx,QWORD PTR [rcx+0x10]
  c100f9:	lea    rcx,[rdi+0x8]
  c100fd:	mov    rcx,QWORD PTR [rcx]
  c10100:	add    rcx,QWORD PTR [rsp+0x18]
  c10105:	movzx  r8d,bpl
  c10109:	movzx  r9d,al
  c1010d:	lea    rdi,[rsp+0x100]
  c10115:	call   c24480 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs4load>
  c1011a:	mov    eax,DWORD PTR [rsp+0x100]
  c10121:	cmp    eax,0xffffffff
  c10124:	mov    r14,QWORD PTR [rsp+0x10]
  c10129:	je     c17862 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f42>
  c1012f:	lea    rsi,[rsp+0x104]
  c10137:	mov    ecx,DWORD PTR [rsi+0x30]
  c1013a:	mov    DWORD PTR [rsp+0x60],ecx
  c1013e:	movups xmm0,XMMWORD PTR [rsi]
  c10141:	movups xmm1,XMMWORD PTR [rsi+0x10]
  c10145:	movups xmm2,XMMWORD PTR [rsi+0x20]
  c10149:	movaps XMMWORD PTR [rsp+0x50],xmm2
  c1014e:	movaps XMMWORD PTR [rsp+0x40],xmm1
  c10153:	movaps XMMWORD PTR [rsp+0x30],xmm0
  c10158:	mov    rcx,QWORD PTR [rsi+0x44]
  c1015c:	lea    rdx,[rsp+0x74]
  c10161:	mov    QWORD PTR [rdx+0x44],rcx
  c10165:	movups xmm0,XMMWORD PTR [rsi+0x34]
  c10169:	movups XMMWORD PTR [rdx+0x34],xmm0
  c1016d:	mov    ecx,DWORD PTR [rsp+0x60]
  c10171:	mov    DWORD PTR [rdx+0x30],ecx
  c10174:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c1017a:	movdqa xmm1,XMMWORD PTR [rsp+0x40]
  c10180:	movaps xmm2,XMMWORD PTR [rsp+0x50]
  c10185:	movups XMMWORD PTR [rdx+0x20],xmm2
  c10189:	movdqu XMMWORD PTR [rdx+0x10],xmm1
  c1018e:	movdqu XMMWORD PTR [rdx],xmm0
  c10192:	mov    DWORD PTR [rsp+0x70],eax
  c10196:	cmp    bl,0x2c
  c10199:	jne    c11608 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ce8>
  c1019f:	xor    esi,esi
  c101a1:	mov    rax,QWORD PTR [rsp+0x628]
  c101a9:	cmp    DWORD PTR [rax],0xffffffff
  c101ac:	cmovne rsi,rax
  c101b0:	lea    rdi,[rsp+0x100]
  c101b8:	call   c0d980 <_RNvCsbxgXiyEKxkX_6bsl_vm18current_error_info>
  c101bd:	mov    rax,QWORD PTR [rsp+0x8]
  c101c2:	lea    rbp,[rax+0x8]
  c101c6:	jmp    c11650 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1d30>
  c101cb:	mov    rdx,QWORD PTR [rsp+0x8]
  c101d0:	lea    rcx,[rdx+0x8]
  c101d4:	mov    rsi,QWORD PTR [rcx]
  c101d7:	lea    rbx,[rdx+0x10]
  c101db:	mov    rdx,QWORD PTR [rbx]
  c101de:	mov    rdi,QWORD PTR [rsp+0x20]
  c101e3:	mov    rcx,QWORD PTR [rdi+0x8]
  c101e7:	mov    r8,QWORD PTR [rdi+0x10]
  c101eb:	sub    rsp,0x8
  c101ef:	movzx  eax,al
  c101f2:	movzx  r10d,bpl
  c101f6:	lea    rdi,[rsp+0x108]
  c101fe:	mov    r14,QWORD PTR [rsp+0x8]
  c10203:	mov    r9,r14
  c10206:	push   rax
  c10207:	push   r10
  c10209:	push   r12
  c1020b:	call   c06f20 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3divEB2_>
  c10210:	add    rsp,0x20
  c10214:	cmp    BYTE PTR [rsp+0x100],0xff
  c1021c:	jne    c19588 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c68>
  c10222:	mov    rsi,QWORD PTR [rbx]
  c10225:	cmp    r14,rsi
  c10228:	mov    rbx,QWORD PTR [rsp+0x10]
  c1022d:	jb     c10a12 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x10f2>
  c10233:	jmp    c19a6e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa14e>
  c10238:	mov    rdx,QWORD PTR [rsp+0x8]
  c1023d:	lea    rcx,[rdx+0x10]
  c10241:	mov    rsi,QWORD PTR [rcx]
  c10244:	mov    rdi,QWORD PTR [rsp]
  c10248:	cmp    rdi,rsi
  c1024b:	jae    c19942 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa022>
  c10251:	lea    rcx,[rdx+0x8]
  c10255:	mov    rbx,QWORD PTR [rcx]
  c10258:	movzx  edx,bpl
  c1025c:	mov    rcx,QWORD PTR [rsp+0x18]
  c10261:	mov    r9,QWORD PTR [rbx+rcx*1+0x30]
  c10266:	add    rbx,rcx
  c10269:	mov    rcx,rdx
  c1026c:	sub    rcx,r9
  c1026f:	mov    QWORD PTR [rsp+0x1a0],r13
  c10277:	mov    DWORD PTR [rsp+0x2c],r15d
  c1027c:	jae    c10c8a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x136a>
  c10282:	mov    rcx,QWORD PTR [rbx+0x28]
  c10286:	shl    edx,0x4
  c10289:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1028d:	jmp    c10c8e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x136e>
  c10292:	mov    rdx,QWORD PTR [rsp+0x8]
  c10297:	lea    rcx,[rdx+0x10]
  c1029b:	mov    rsi,QWORD PTR [rcx]
  c1029e:	mov    rdi,QWORD PTR [rsp]
  c102a2:	cmp    rdi,rsi
  c102a5:	jae    c19816 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ef6>
  c102ab:	lea    rcx,[rdx+0x8]
  c102af:	mov    rbx,QWORD PTR [rcx]
  c102b2:	movzx  edx,bpl
  c102b6:	mov    rcx,QWORD PTR [rsp+0x18]
  c102bb:	mov    r14,QWORD PTR [rbx+rcx*1+0x30]
  c102c0:	add    rbx,rcx
  c102c3:	mov    rcx,rdx
  c102c6:	sub    rcx,r14
  c102c9:	jae    c10d01 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13e1>
  c102cf:	mov    rcx,QWORD PTR [rbx+0x28]
  c102d3:	shl    edx,0x4
  c102d6:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c102da:	jmp    c10d05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13e5>
  c102df:	mov    rdx,QWORD PTR [rsp+0x8]
  c102e4:	lea    rcx,[rdx+0x10]
  c102e8:	mov    rsi,QWORD PTR [rcx]
  c102eb:	mov    rdi,QWORD PTR [rsp]
  c102ef:	cmp    rdi,rsi
  c102f2:	jae    c198bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f9d>
  c102f8:	lea    rcx,[rdx+0x8]
  c102fc:	mov    rbx,QWORD PTR [rcx]
  c102ff:	movzx  edx,bpl
  c10303:	mov    rcx,QWORD PTR [rsp+0x18]
  c10308:	mov    r14,QWORD PTR [rbx+rcx*1+0x30]
  c1030d:	add    rbx,rcx
  c10310:	mov    rcx,rdx
  c10313:	sub    rcx,r14
  c10316:	jae    c10d85 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1465>
  c1031c:	mov    rcx,QWORD PTR [rbx+0x28]
  c10320:	shl    edx,0x4
  c10323:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c10327:	jmp    c10d89 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1469>
  c1032c:	mov    rdx,QWORD PTR [rsp+0x8]
  c10331:	lea    rcx,[rdx+0x10]
  c10335:	mov    rsi,QWORD PTR [rcx]
  c10338:	cmp    QWORD PTR [rsp],rsi
  c1033c:	jae    c1994f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa02f>
  c10342:	lea    rcx,[rdx+0x8]
  c10346:	mov    rsi,QWORD PTR [rcx]
  c10349:	mov    r14,QWORD PTR [rsp+0x18]
  c1034e:	lea    rdx,[rsi+r14*1]
  c10352:	mov    rcx,r12
  c10355:	sub    rcx,QWORD PTR [rsi+r14*1+0x30]
  c1035a:	mov    rbx,QWORD PTR [rsp+0x10]
  c1035f:	jae    c10e09 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14e9>
  c10365:	mov    rcx,QWORD PTR [rdx+0x28]
  c10369:	shl    r12d,0x4
  c1036d:	mov    rcx,QWORD PTR [rcx+r12*1]
  c10371:	jmp    c10e0d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14ed>
  c10376:	mov    rcx,QWORD PTR [rsp+0x8]
  c1037b:	lea    rax,[rcx+0x10]
  c1037f:	mov    rsi,QWORD PTR [rax]
  c10382:	mov    rdi,QWORD PTR [rsp]
  c10386:	cmp    rdi,rsi
  c10389:	jae    c1990a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fea>
  c1038f:	lea    rax,[rcx+0x8]
  c10393:	mov    rdx,QWORD PTR [rax]
  c10396:	mov    rsi,QWORD PTR [rsp+0x18]
  c1039b:	lea    rcx,[rdx+rsi*1]
  c1039f:	mov    rax,r12
  c103a2:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c103a7:	mov    rbx,QWORD PTR [rsp+0x10]
  c103ac:	jae    c10e61 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1541>
  c103b2:	mov    rax,QWORD PTR [rcx+0x28]
  c103b6:	shl    r12d,0x4
  c103ba:	mov    rax,QWORD PTR [rax+r12*1]
  c103be:	jmp    c10e65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1545>
  c103c3:	mov    rdx,QWORD PTR [rsp+0x8]
  c103c8:	lea    rcx,[rdx+0x8]
  c103cc:	mov    rsi,QWORD PTR [rcx]
  c103cf:	lea    rbx,[rdx+0x10]
  c103d3:	mov    rdx,QWORD PTR [rbx]
  c103d6:	mov    rdi,QWORD PTR [rsp+0x20]
  c103db:	mov    rcx,QWORD PTR [rdi+0x8]
  c103df:	mov    r8,QWORD PTR [rdi+0x10]
  c103e3:	sub    rsp,0x8
  c103e7:	movzx  eax,al
  c103ea:	movzx  r10d,bpl
  c103ee:	lea    rdi,[rsp+0x108]
  c103f6:	mov    r14,QWORD PTR [rsp+0x8]
  c103fb:	mov    r9,r14
  c103fe:	push   rax
  c103ff:	push   r10
  c10401:	push   r12
  c10403:	call   c08c60 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3subEB2_>
  c10408:	add    rsp,0x20
  c1040c:	cmp    BYTE PTR [rsp+0x100],0xff
  c10414:	jne    c19588 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c68>
  c1041a:	mov    rsi,QWORD PTR [rbx]
  c1041d:	cmp    r14,rsi
  c10420:	mov    rbx,QWORD PTR [rsp+0x10]
  c10425:	jb     c10a12 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x10f2>
  c1042b:	jmp    c19a7f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa15f>
  c10430:	cmp    QWORD PTR [r10+0x28],rbp
  c10434:	jbe    c17606 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ce6>
  c1043a:	mov    rcx,QWORD PTR [r10+0x20]
  c1043e:	lea    rdx,[rbp*2+0x0]
  c10446:	add    rdx,rbp
  c10449:	mov    eax,DWORD PTR [rcx+rdx*8]
  c1044c:	mov    esi,eax
  c1044e:	sub    esi,0x2
  c10451:	mov    edi,0x3
  c10456:	cmovae edi,esi
  c10459:	lea    rcx,[rcx+rdx*8]
  c1045d:	lea    rdx,[rip+0xffffffffff6b5870]        # 2c5cd4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1313>
  c10464:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c10468:	add    rsi,rdx
  c1046b:	jmp    rsi
  c1046d:	mov    rax,QWORD PTR [rcx+0x10]
  c10471:	mov    QWORD PTR [rsp+0x80],rax
  c10479:	movdqu xmm0,XMMWORD PTR [rcx]
  c1047d:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c10483:	mov    rax,QWORD PTR [rsp+0x8]
  c10488:	lea    rbp,[rax+0x8]
  c1048c:	mov    r9,QWORD PTR [rsp+0x20]
  c10491:	lea    r8,[rax+0x10]
  c10495:	mov    rdi,QWORD PTR [rsp]
  c10499:	mov    r10,QWORD PTR [rsp+0x18]
  c1049e:	jmp    c15d67 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6447>
  c104a3:	mov    rcx,QWORD PTR [rsp+0x8]
  c104a8:	lea    rax,[rcx+0x10]
  c104ac:	mov    rsi,QWORD PTR [rax]
  c104af:	mov    rdi,QWORD PTR [rsp]
  c104b3:	cmp    rdi,rsi
  c104b6:	jae    c1985f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f3f>
  c104bc:	lea    rbp,[rcx+0x8]
  c104c0:	mov    rdx,QWORD PTR [rbp+0x0]
  c104c4:	mov    rsi,QWORD PTR [rsp+0x18]
  c104c9:	lea    rcx,[rdx+rsi*1]
  c104cd:	mov    rax,r12
  c104d0:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c104d5:	mov    rbx,QWORD PTR [rsp+0x10]
  c104da:	jae    c10ef9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15d9>
  c104e0:	mov    rax,QWORD PTR [rcx+0x28]
  c104e4:	shl    r12d,0x4
  c104e8:	mov    rax,QWORD PTR [rax+r12*1]
  c104ec:	jmp    c10efd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15dd>
  c104f1:	cmp    QWORD PTR [rsp+0x4d0],rbp
  c104f9:	jbe    c1745e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b3e>
  c104ff:	mov    rcx,QWORD PTR [rsp+0x8]
  c10504:	lea    rax,[rcx+0x10]
  c10508:	mov    rsi,QWORD PTR [rax]
  c1050b:	mov    rdi,QWORD PTR [rsp]
  c1050f:	cmp    rdi,rsi
  c10512:	mov    rbx,QWORD PTR [rsp+0x10]
  c10517:	jae    c199ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0cc>
  c1051d:	lea    rax,[rcx+0x8]
  c10521:	mov    rdx,QWORD PTR [rax]
  c10524:	mov    rsi,QWORD PTR [rsp+0x18]
  c10529:	lea    rcx,[rdx+rsi*1]
  c1052d:	mov    rax,r12
  c10530:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c10535:	mov    rdx,QWORD PTR [rsp+0x20]
  c1053a:	mov    r9,QWORD PTR [rsp+0x540]
  c10542:	jae    c116df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1dbf>
  c10548:	mov    rax,QWORD PTR [rcx+0x28]
  c1054c:	shl    r12d,0x4
  c10550:	mov    rax,QWORD PTR [rax+r12*1]
  c10554:	jmp    c116e3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1dc3>
  c10559:	mov    rdx,QWORD PTR [rsp+0x8]
  c1055e:	lea    rcx,[rdx+0x10]
  c10562:	mov    rsi,QWORD PTR [rcx]
  c10565:	mov    rdi,QWORD PTR [rsp]
  c10569:	cmp    rdi,rsi
  c1056c:	jae    c19823 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f03>
  c10572:	lea    rcx,[rdx+0x8]
  c10576:	mov    rbx,QWORD PTR [rcx]
  c10579:	movzx  edx,bpl
  c1057d:	mov    rcx,QWORD PTR [rsp+0x18]
  c10582:	mov    rbp,QWORD PTR [rbx+rcx*1+0x30]
  c10587:	add    rbx,rcx
  c1058a:	mov    rcx,rdx
  c1058d:	sub    rcx,rbp
  c10590:	jae    c10f80 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1660>
  c10596:	mov    rcx,QWORD PTR [rbx+0x28]
  c1059a:	shl    edx,0x4
  c1059d:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c105a1:	jmp    c10f84 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1664>
  c105a6:	mov    rcx,QWORD PTR [rsp+0x8]
  c105ab:	lea    rax,[rcx+0x10]
  c105af:	mov    rsi,QWORD PTR [rax]
  c105b2:	mov    rdi,QWORD PTR [rsp]
  c105b6:	cmp    rdi,rsi
  c105b9:	jae    c19852 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f32>
  c105bf:	lea    rbp,[rcx+0x8]
  c105c3:	mov    rdx,QWORD PTR [rbp+0x0]
  c105c7:	mov    rsi,QWORD PTR [rsp+0x18]
  c105cc:	lea    rcx,[rdx+rsi*1]
  c105d0:	mov    rax,r12
  c105d3:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c105d8:	mov    rbx,QWORD PTR [rsp+0x10]
  c105dd:	jae    c10ff9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16d9>
  c105e3:	mov    rax,QWORD PTR [rcx+0x28]
  c105e7:	shl    r12d,0x4
  c105eb:	mov    rax,QWORD PTR [rax+r12*1]
  c105ef:	jmp    c10ffd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16dd>
  c105f4:	mov    rcx,QWORD PTR [rsp+0x8]
  c105f9:	lea    rax,[rcx+0x10]
  c105fd:	mov    rsi,QWORD PTR [rax]
  c10600:	cmp    QWORD PTR [rsp],rsi
  c10604:	jae    c1989b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f7b>
  c1060a:	lea    rax,[rcx+0x8]
  c1060e:	mov    rdx,QWORD PTR [rax]
  c10611:	mov    r14,QWORD PTR [rsp+0x18]
  c10616:	lea    rcx,[rdx+r14*1]
  c1061a:	mov    rax,r12
  c1061d:	sub    rax,QWORD PTR [rdx+r14*1+0x30]
  c10622:	jae    c11080 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1760>
  c10628:	mov    rax,QWORD PTR [rcx+0x28]
  c1062c:	shl    r12d,0x4
  c10630:	mov    rax,QWORD PTR [rax+r12*1]
  c10634:	jmp    c11084 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1764>
  c10639:	mov    rax,QWORD PTR [rsp+0x8]
  c1063e:	lea    r9,[rax+0x10]
  c10642:	mov    rsi,QWORD PTR [r9]
  c10645:	mov    rdi,QWORD PTR [rsp]
  c10649:	cmp    rdi,rsi
  c1064c:	jae    c198db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fbb>
  c10652:	add    rax,0x8
  c10656:	mov    rsi,QWORD PTR [rax]
  c10659:	mov    r11,QWORD PTR [rsp+0x18]
  c1065e:	lea    rdx,[rsi+r11*1]
  c10662:	movzx  ecx,bpl
  c10666:	mov    rax,rcx
  c10669:	sub    rax,QWORD PTR [rsi+r11*1+0x30]
  c1066e:	mov    rbx,QWORD PTR [rsp+0x10]
  c10673:	jae    c110d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x17b6>
  c10679:	mov    rax,QWORD PTR [rdx+0x28]
  c1067d:	shl    ecx,0x4
  c10680:	mov    rax,QWORD PTR [rax+rcx*1]
  c10684:	jmp    c110da <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x17ba>
  c10689:	cmp    QWORD PTR [rsp+0x4d0],rbp
  c10691:	jbe    c1745e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b3e>
  c10697:	mov    rax,QWORD PTR [rsp+0x1b8]
  c1069f:	cmp    QWORD PTR [rax+0x10],rbp
  c106a3:	mov    rbx,QWORD PTR [rsp+0x10]
  c106a8:	jbe    c178ea <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7fca>
  c106ae:	mov    rax,QWORD PTR [rax+0x8]
  c106b2:	lea    rdx,[rbp*2+0x0]
  c106ba:	add    rdx,rbp
  c106bd:	mov    ecx,DWORD PTR [rax+rdx*8]
  c106c0:	lea    esi,[rcx-0x2]
  c106c3:	cmp    rcx,0x2
  c106c7:	mov    edi,0x3
  c106cc:	cmovae edi,esi
  c106cf:	lea    rax,[rax+rdx*8]
  c106d3:	lea    rdx,[rip+0xffffffffff6b564a]        # 2c5d24 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1363>
  c106da:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c106de:	add    rsi,rdx
  c106e1:	jmp    rsi
  c106e3:	mov    r9,QWORD PTR [rax]
  c106e6:	mov    r10,QWORD PTR [rax+0x8]
  c106ea:	mov    rsi,QWORD PTR [rax+0x10]
  c106ee:	mov    rax,QWORD PTR [rsp+0x8]
  c106f3:	lea    rbp,[rax+0x8]
  c106f7:	mov    r8,QWORD PTR [rsp+0x20]
  c106fc:	lea    rdx,[rax+0x10]
  c10700:	mov    rdi,QWORD PTR [rsp]
  c10704:	mov    r11,QWORD PTR [rsp+0x18]
  c10709:	jmp    c16060 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6740>
  c1070e:	mov    rdx,QWORD PTR [rsp+0x8]
  c10713:	lea    rcx,[rdx+0x8]
  c10717:	mov    rsi,QWORD PTR [rcx]
  c1071a:	lea    rbx,[rdx+0x10]
  c1071e:	mov    rdx,QWORD PTR [rbx]
  c10721:	mov    rdi,QWORD PTR [rsp+0x20]
  c10726:	mov    rcx,QWORD PTR [rdi+0x8]
  c1072a:	mov    r8,QWORD PTR [rdi+0x10]
  c1072e:	sub    rsp,0x8
  c10732:	movzx  eax,al
  c10735:	movzx  r10d,bpl
  c10739:	lea    rdi,[rsp+0x108]
  c10741:	mov    r14,QWORD PTR [rsp+0x8]
  c10746:	mov    r9,r14
  c10749:	push   rax
  c1074a:	push   r10
  c1074c:	push   r12
  c1074e:	call   c078e0 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3mulEB2_>
  c10753:	add    rsp,0x20
  c10757:	cmp    BYTE PTR [rsp+0x100],0xff
  c1075f:	jne    c19588 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c68>
  c10765:	mov    rsi,QWORD PTR [rbx]
  c10768:	cmp    r14,rsi
  c1076b:	mov    rbx,QWORD PTR [rsp+0x10]
  c10770:	jb     c10a12 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x10f2>
  c10776:	jmp    c19972 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa052>
  c1077b:	mov    rcx,QWORD PTR [rsp+0x8]
  c10780:	lea    rax,[rcx+0x10]
  c10784:	mov    rsi,QWORD PTR [rax]
  c10787:	cmp    QWORD PTR [rsp],rsi
  c1078b:	jae    c1988a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f6a>
  c10791:	lea    rax,[rcx+0x8]
  c10795:	mov    r9,QWORD PTR [rax]
  c10798:	mov    r14,QWORD PTR [rsp+0x18]
  c1079d:	mov    rax,QWORD PTR [r9+r14*1+0x30]
  c107a2:	add    r9,r14
  c107a5:	mov    rcx,r12
  c107a8:	sub    rcx,rax
  c107ab:	jae    c11132 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1812>
  c107b1:	mov    rcx,QWORD PTR [r9+0x28]
  c107b5:	shl    r12d,0x4
  c107b9:	mov    rcx,QWORD PTR [rcx+r12*1]
  c107bd:	jmp    c11136 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1816>
  c107c2:	mov    rcx,QWORD PTR [rsp+0x8]
  c107c7:	lea    r11,[rcx+0x10]
  c107cb:	mov    rsi,QWORD PTR [r11]
  c107ce:	mov    rdi,QWORD PTR [rsp]
  c107d2:	cmp    rdi,rsi
  c107d5:	jae    c19917 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ff7>
  c107db:	add    rcx,0x8
  c107df:	mov    r8,QWORD PTR [rcx]
  c107e2:	mov    r9,QWORD PTR [rsp+0x18]
  c107e7:	lea    rsi,[r8+r9*1]
  c107eb:	movzx  edx,bpl
  c107ef:	mov    rcx,rdx
  c107f2:	sub    rcx,QWORD PTR [r8+r9*1+0x30]
  c107f7:	mov    r9,QWORD PTR [rsp+0x10]
  c107fc:	jae    c111a5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1885>
  c10802:	mov    rcx,QWORD PTR [rsi+0x28]
  c10806:	shl    edx,0x4
  c10809:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1080d:	jmp    c111a9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1889>
  c10812:	mov    rcx,QWORD PTR [rsp+0x8]
  c10817:	lea    rax,[rcx+0x10]
  c1081b:	mov    rsi,QWORD PTR [rax]
  c1081e:	cmp    QWORD PTR [rsp],rsi
  c10822:	jae    c19805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ee5>
  c10828:	lea    rax,[rcx+0x8]
  c1082c:	mov    rdx,QWORD PTR [rax]
  c1082f:	mov    r14,QWORD PTR [rsp+0x18]
  c10834:	lea    rcx,[rdx+r14*1]
  c10838:	mov    rax,r12
  c1083b:	sub    rax,QWORD PTR [rdx+r14*1+0x30]
  c10840:	mov    r8,QWORD PTR [rsp+0x10]
  c10845:	jae    c11202 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x18e2>
  c1084b:	mov    rax,QWORD PTR [rcx+0x28]
  c1084f:	shl    r12d,0x4
  c10853:	mov    rax,QWORD PTR [rax+r12*1]
  c10857:	jmp    c11206 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x18e6>
  c1085c:	mov    rdx,QWORD PTR [rsp+0x8]
  c10861:	lea    rcx,[rdx+0x10]
  c10865:	mov    rsi,QWORD PTR [rcx]
  c10868:	mov    rdi,QWORD PTR [rsp]
  c1086c:	cmp    rdi,rsi
  c1086f:	jae    c19924 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa004>
  c10875:	lea    rcx,[rdx+0x8]
  c10879:	mov    rdi,QWORD PTR [rcx]
  c1087c:	mov    r8,QWORD PTR [rsp+0x18]
  c10881:	lea    rsi,[rdi+r8*1]
  c10885:	movzx  edx,bpl
  c10889:	mov    rcx,rdx
  c1088c:	sub    rcx,QWORD PTR [rdi+r8*1+0x30]
  c10891:	mov    rbx,QWORD PTR [rsp+0x10]
  c10896:	jae    c1125d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x193d>
  c1089c:	mov    rcx,QWORD PTR [rsi+0x28]
  c108a0:	shl    edx,0x4
  c108a3:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c108a7:	jmp    c11261 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1941>
  c108ac:	mov    rcx,QWORD PTR [rsp+0x8]
  c108b1:	lea    rax,[rcx+0x10]
  c108b5:	mov    rsi,QWORD PTR [rax]
  c108b8:	mov    rdi,QWORD PTR [rsp]
  c108bc:	cmp    rdi,rsi
  c108bf:	jae    c197f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ed8>
  c108c5:	lea    rax,[rcx+0x8]
  c108c9:	mov    rsi,QWORD PTR [rax]
  c108cc:	mov    rdi,QWORD PTR [rsp+0x18]
  c108d1:	lea    rdx,[rsi+rdi*1]
  c108d5:	movzx  ecx,bpl
  c108d9:	mov    rax,rcx
  c108dc:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c108e1:	mov    rbx,QWORD PTR [rsp+0x10]
  c108e6:	jae    c112b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1999>
  c108ec:	mov    rax,QWORD PTR [rdx+0x28]
  c108f0:	shl    ecx,0x4
  c108f3:	mov    rax,QWORD PTR [rax+rcx*1]
  c108f7:	jmp    c112bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x199d>
  c108fc:	mov    DWORD PTR [rsp+0x2c],r15d
  c10901:	mov    rcx,QWORD PTR [rsp+0x8]
  c10906:	lea    rax,[rcx+0x10]
  c1090a:	mov    rsi,QWORD PTR [rax]
  c1090d:	cmp    QWORD PTR [rsp],rsi
  c10911:	jae    c19841 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f21>
  c10917:	lea    rax,[rcx+0x8]
  c1091b:	mov    rdx,QWORD PTR [rax]
  c1091e:	mov    r14,QWORD PTR [rsp+0x18]
  c10923:	mov    rax,QWORD PTR [rdx+r14*1+0x50]
  c10928:	cmp    rax,QWORD PTR [rsp+0x3b0]
  c10930:	mov    r15,QWORD PTR [rsp+0x10]
  c10935:	jae    c17493 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b73>
  c1093b:	add    rdx,r14
  c1093e:	mov    rcx,r12
  c10941:	sub    rcx,QWORD PTR [rdx+0x30]
  c10945:	jae    c117dd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ebd>
  c1094b:	mov    rcx,QWORD PTR [rdx+0x28]
  c1094f:	shl    r12d,0x4
  c10953:	mov    rcx,QWORD PTR [rcx+r12*1]
  c10957:	jmp    c117e1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ec1>
  c1095c:	mov    rcx,QWORD PTR [rsp+0x8]
  c10961:	lea    rax,[rcx+0x10]
  c10965:	mov    rsi,QWORD PTR [rax]
  c10968:	mov    rdi,QWORD PTR [rsp]
  c1096c:	cmp    rdi,rsi
  c1096f:	jae    c1987d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f5d>
  c10975:	lea    rax,[rcx+0x8]
  c10979:	mov    rsi,QWORD PTR [rax]
  c1097c:	mov    rdi,QWORD PTR [rsp+0x18]
  c10981:	lea    rdx,[rsi+rdi*1]
  c10985:	movzx  ecx,bpl
  c10989:	mov    rax,rcx
  c1098c:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c10991:	mov    rbx,QWORD PTR [rsp+0x10]
  c10996:	jae    c11313 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19f3>
  c1099c:	mov    rax,QWORD PTR [rdx+0x28]
  c109a0:	shl    ecx,0x4
  c109a3:	mov    rax,QWORD PTR [rax+rcx*1]
  c109a7:	jmp    c11317 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19f7>
  c109ac:	mov    rcx,QWORD PTR [rsp+0x8]
  c109b1:	lea    rax,[rcx+0x8]
  c109b5:	mov    rdx,QWORD PTR [rax]
  c109b8:	lea    r14,[rcx+0x10]
  c109bc:	mov    rcx,QWORD PTR [r14]
  c109bf:	mov    rax,QWORD PTR [rsp+0x20]
  c109c4:	mov    r8,QWORD PTR [rax+0x8]
  c109c8:	mov    r9,QWORD PTR [rax+0x10]
  c109cc:	movzx  eax,bpl
  c109d0:	lea    rdi,[rsp+0x100]
  c109d8:	mov    rsi,QWORD PTR [rsp+0x1b0]
  c109e0:	push   rbx
  c109e1:	push   rax
  c109e2:	push   r12
  c109e4:	mov    rbx,QWORD PTR [rsp+0x18]
  c109e9:	push   rbx
  c109ea:	call   c0c820 <_RNvCsbxgXiyEKxkX_6bsl_vm12add_const_op>
  c109ef:	add    rsp,0x20
  c109f3:	cmp    BYTE PTR [rsp+0x100],0xff
  c109fb:	jne    c19588 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c68>
  c10a01:	mov    rsi,QWORD PTR [r14]
  c10a04:	cmp    rbx,rsi
  c10a07:	mov    rbx,QWORD PTR [rsp+0x10]
  c10a0c:	jae    c199db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0bb>
  c10a12:	mov    r12,QWORD PTR [rsp+0x8]
  c10a17:	lea    rbp,[r12+0x8]
  c10a1c:	mov    rax,QWORD PTR [rbp+0x0]
  c10a20:	mov    r14,QWORD PTR [rsp+0x18]
  c10a25:	inc    QWORD PTR [rax+r14*1+0x58]
  c10a2a:	test   r15b,r15b
  c10a2d:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c10a33:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c10a38:	mov    rcx,QWORD PTR [rsp+0x8]
  c10a3d:	lea    rax,[rcx+0x10]
  c10a41:	mov    rsi,QWORD PTR [rax]
  c10a44:	mov    rdi,QWORD PTR [rsp]
  c10a48:	cmp    rdi,rsi
  c10a4b:	jae    c197de <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ebe>
  c10a51:	lea    rax,[rcx+0x8]
  c10a55:	mov    rsi,QWORD PTR [rax]
  c10a58:	mov    rdi,QWORD PTR [rsp+0x18]
  c10a5d:	lea    rdx,[rsi+rdi*1]
  c10a61:	movzx  ecx,bpl
  c10a65:	mov    rax,rcx
  c10a68:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c10a6d:	mov    rbx,QWORD PTR [rsp+0x10]
  c10a72:	jae    c1136d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a4d>
  c10a78:	mov    rax,QWORD PTR [rdx+0x28]
  c10a7c:	shl    ecx,0x4
  c10a7f:	mov    rax,QWORD PTR [rax+rcx*1]
  c10a83:	jmp    c11371 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a51>
  c10a88:	mov    rcx,QWORD PTR [rsp+0x8]
  c10a8d:	lea    r11,[rcx+0x10]
  c10a91:	mov    rsi,QWORD PTR [r11]
  c10a94:	mov    rdi,QWORD PTR [rsp]
  c10a98:	cmp    rdi,rsi
  c10a9b:	jae    c197eb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ecb>
  c10aa1:	add    rcx,0x8
  c10aa5:	mov    r8,QWORD PTR [rcx]
  c10aa8:	mov    r9,QWORD PTR [rsp+0x18]
  c10aad:	lea    rsi,[r8+r9*1]
  c10ab1:	movzx  edx,bpl
  c10ab5:	mov    rcx,rdx
  c10ab8:	sub    rcx,QWORD PTR [r8+r9*1+0x30]
  c10abd:	mov    r9,QWORD PTR [rsp+0x10]
  c10ac2:	jae    c113c7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1aa7>
  c10ac8:	mov    rcx,QWORD PTR [rsi+0x28]
  c10acc:	shl    edx,0x4
  c10acf:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c10ad3:	jmp    c113cb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1aab>
  c10ad8:	mov    rcx,QWORD PTR [rsp+0x8]
  c10add:	lea    rax,[rcx+0x10]
  c10ae1:	mov    rsi,QWORD PTR [rax]
  c10ae4:	cmp    QWORD PTR [rsp],rsi
  c10ae8:	jae    c198ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f8c>
  c10aee:	mov    r14d,r15d
  c10af1:	lea    rax,[rcx+0x8]
  c10af5:	mov    rax,QWORD PTR [rax]
  c10af8:	mov    rdx,QWORD PTR [rsp+0x18]
  c10afd:	mov    rcx,QWORD PTR [rax+rdx*1+0x30]
  c10b02:	add    rax,rdx
  c10b05:	mov    r15,r12
  c10b08:	sub    r15,rcx
  c10b0b:	jae    c11424 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1b04>
  c10b11:	mov    rdx,QWORD PTR [rax+0x28]
  c10b15:	shl    r12d,0x4
  c10b19:	mov    r15,QWORD PTR [rdx+r12*1]
  c10b1d:	jmp    c11428 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1b08>
  c10b22:	mov    rcx,QWORD PTR [rsp+0x8]
  c10b27:	lea    rax,[rcx+0x10]
  c10b2b:	mov    rsi,QWORD PTR [rax]
  c10b2e:	cmp    QWORD PTR [rsp],rsi
  c10b32:	jae    c197cd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ead>
  c10b38:	lea    rax,[rcx+0x8]
  c10b3c:	mov    rdx,QWORD PTR [rax]
  c10b3f:	mov    r14,QWORD PTR [rsp+0x18]
  c10b44:	lea    rcx,[rdx+r14*1]
  c10b48:	mov    rax,r12
  c10b4b:	sub    rax,QWORD PTR [rdx+r14*1+0x30]
  c10b50:	mov    r8,QWORD PTR [rsp+0x10]
  c10b55:	jae    c115ad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1c8d>
  c10b5b:	mov    rax,QWORD PTR [rcx+0x28]
  c10b5f:	shl    r12d,0x4
  c10b63:	mov    rax,QWORD PTR [rax+r12*1]
  c10b67:	jmp    c115b1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1c91>
  c10b6c:	mov    DWORD PTR [rsp+0x2c],r15d
  c10b71:	mov    rcx,QWORD PTR [rsp+0x8]
  c10b76:	lea    rax,[rcx+0x10]
  c10b7a:	mov    rsi,QWORD PTR [rax]
  c10b7d:	cmp    QWORD PTR [rsp],rsi
  c10b81:	jae    c19830 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f10>
  c10b87:	lea    rax,[rcx+0x8]
  c10b8b:	mov    rdx,QWORD PTR [rax]
  c10b8e:	mov    r14,QWORD PTR [rsp+0x18]
  c10b93:	mov    rax,QWORD PTR [rdx+r14*1+0x50]
  c10b98:	cmp    rax,QWORD PTR [rsp+0x3b0]
  c10ba0:	mov    r15,QWORD PTR [rsp+0x10]
  c10ba5:	jae    c17493 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b73>
  c10bab:	add    rdx,r14
  c10bae:	mov    rcx,r12
  c10bb1:	sub    rcx,QWORD PTR [rdx+0x30]
  c10bb5:	jae    c11835 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f15>
  c10bbb:	mov    rcx,QWORD PTR [rdx+0x28]
  c10bbf:	shl    r12d,0x4
  c10bc3:	mov    rcx,QWORD PTR [rcx+r12*1]
  c10bc7:	jmp    c11839 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f19>
  c10bcc:	add    rax,QWORD PTR [rdx+0x60]
  c10bd0:	mov    rcx,QWORD PTR [rsp+0x20]
  c10bd5:	cmp    rax,QWORD PTR [rcx+0x10]
  c10bd9:	mov    rdx,QWORD PTR [rsp+0x8]
  c10bde:	lea    rbp,[rdx+0x8]
  c10be2:	jae    c1763a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7d1a>
  c10be8:	mov    rdx,QWORD PTR [rcx+0x8]
  c10bec:	lea    rax,[rax+rax*2]
  c10bf0:	mov    ecx,DWORD PTR [rdx+rax*8]
  c10bf3:	lea    esi,[rcx-0x2]
  c10bf6:	cmp    rcx,0x2
  c10bfa:	mov    edi,0x3
  c10bff:	cmovae edi,esi
  c10c02:	lea    rax,[rdx+rax*8]
  c10c06:	lea    rdx,[rip+0xffffffffff6b4cb7]        # 2c58c4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf03>
  c10c0d:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c10c11:	add    rsi,rdx
  c10c14:	jmp    rsi
  c10c16:	mov    rdx,QWORD PTR [rax]
  c10c19:	mov    rsi,QWORD PTR [rax+0x8]
  c10c1d:	mov    rcx,QWORD PTR [rax+0x10]
  c10c21:	mov    rax,QWORD PTR [rsp+0x190]
  c10c29:	jmp    c11de0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x24c0>
  c10c2e:	add    rcx,QWORD PTR [rsi+0x60]
  c10c32:	mov    rdx,QWORD PTR [rsp+0x20]
  c10c37:	cmp    rcx,QWORD PTR [rdx+0x10]
  c10c3b:	mov    rsi,QWORD PTR [rsp+0x8]
  c10c40:	lea    r9,[rsi+0x8]
  c10c44:	jae    c17612 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7cf2>
  c10c4a:	mov    rsi,QWORD PTR [rdx+0x8]
  c10c4e:	lea    rcx,[rcx+rcx*2]
  c10c52:	mov    edx,DWORD PTR [rsi+rcx*8]
  c10c55:	lea    edi,[rdx-0x2]
  c10c58:	cmp    rdx,0x2
  c10c5c:	mov    r8d,0x3
  c10c62:	cmovae r8d,edi
  c10c66:	lea    rcx,[rsi+rcx*8]
  c10c6a:	lea    rsi,[rip+0xffffffffff6b4b7b]        # 2c57ec <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe2b>
  c10c71:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c10c75:	add    rdi,rsi
  c10c78:	jmp    rdi
  c10c7a:	mov    rsi,QWORD PTR [rcx]
  c10c7d:	mov    rdi,QWORD PTR [rcx+0x8]
  c10c81:	mov    rcx,QWORD PTR [rcx+0x10]
  c10c85:	jmp    c122c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x29a0>
  c10c8a:	add    rcx,QWORD PTR [rbx+0x60]
  c10c8e:	mov    rdx,QWORD PTR [rsp+0x20]
  c10c93:	mov    r13,QWORD PTR [rdx+0x10]
  c10c97:	cmp    rcx,r13
  c10c9a:	jae    c177ca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7eaa>
  c10ca0:	mov    r14,QWORD PTR [rdx+0x8]
  c10ca4:	lea    rcx,[rcx+rcx*2]
  c10ca8:	mov    esi,DWORD PTR [r14+rcx*8]
  c10cac:	lea    edx,[rsi-0x2]
  c10caf:	cmp    rsi,0x2
  c10cb3:	mov    edi,0x3
  c10cb8:	cmovae edi,edx
  c10cbb:	lea    rdx,[r14+rcx*8]
  c10cbf:	lea    rcx,[rip+0xffffffffff6b4dde]        # 2c5aa4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x10e3>
  c10cc6:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10cca:	add    rdi,rcx
  c10ccd:	jmp    rdi
  c10ccf:	mov    rcx,QWORD PTR [rdx]
  c10cd2:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10cd7:	mov    QWORD PTR [rsp+0x30],rcx
  c10cdc:	movdqu XMMWORD PTR [rsp+0x38],xmm0
  c10ce2:	movzx  ecx,ax
  c10ce5:	mov    rax,rcx
  c10ce8:	sub    rax,r9
  c10ceb:	jae    c1188d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f6d>
  c10cf1:	mov    rax,QWORD PTR [rbx+0x28]
  c10cf5:	shl    ecx,0x4
  c10cf8:	mov    rax,QWORD PTR [rax+rcx*1]
  c10cfc:	jmp    c11891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f71>
  c10d01:	add    rcx,QWORD PTR [rbx+0x60]
  c10d05:	mov    rdx,QWORD PTR [rsp+0x20]
  c10d0a:	mov    rbp,QWORD PTR [rdx+0x10]
  c10d0e:	cmp    rcx,rbp
  c10d11:	jae    c1747e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b5e>
  c10d17:	mov    DWORD PTR [rsp+0x2c],r15d
  c10d1c:	mov    QWORD PTR [rsp+0x1a0],r13
  c10d24:	mov    r15,QWORD PTR [rdx+0x8]
  c10d28:	lea    rcx,[rcx+rcx*2]
  c10d2c:	mov    esi,DWORD PTR [r15+rcx*8]
  c10d30:	lea    edx,[rsi-0x2]
  c10d33:	cmp    rsi,0x2
  c10d37:	mov    edi,0x3
  c10d3c:	cmovae edi,edx
  c10d3f:	lea    rdx,[r15+rcx*8]
  c10d43:	lea    rcx,[rip+0xffffffffff6b4dfa]        # 2c5b44 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1183>
  c10d4a:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10d4e:	add    rdi,rcx
  c10d51:	jmp    rdi
  c10d53:	mov    rcx,QWORD PTR [rdx]
  c10d56:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10d5b:	mov    QWORD PTR [rsp+0x30],rcx
  c10d60:	movdqu XMMWORD PTR [rsp+0x38],xmm0
  c10d66:	movzx  ecx,ax
  c10d69:	mov    rax,rcx
  c10d6c:	sub    rax,r14
  c10d6f:	jae    c118d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1fb2>
  c10d75:	mov    rax,QWORD PTR [rbx+0x28]
  c10d79:	shl    ecx,0x4
  c10d7c:	mov    rax,QWORD PTR [rax+rcx*1]
  c10d80:	jmp    c118d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1fb6>
  c10d85:	add    rcx,QWORD PTR [rbx+0x60]
  c10d89:	mov    rdx,QWORD PTR [rsp+0x20]
  c10d8e:	mov    rbp,QWORD PTR [rdx+0x10]
  c10d92:	cmp    rcx,rbp
  c10d95:	jae    c1747e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b5e>
  c10d9b:	mov    DWORD PTR [rsp+0x2c],r15d
  c10da0:	mov    QWORD PTR [rsp+0x1a0],r13
  c10da8:	mov    r15,QWORD PTR [rdx+0x8]
  c10dac:	lea    rcx,[rcx+rcx*2]
  c10db0:	mov    esi,DWORD PTR [r15+rcx*8]
  c10db4:	lea    edx,[rsi-0x2]
  c10db7:	cmp    rsi,0x2
  c10dbb:	mov    edi,0x3
  c10dc0:	cmovae edi,edx
  c10dc3:	lea    rdx,[r15+rcx*8]
  c10dc7:	lea    rcx,[rip+0xffffffffff6b4d26]        # 2c5af4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1133>
  c10dce:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10dd2:	add    rdi,rcx
  c10dd5:	jmp    rdi
  c10dd7:	mov    rcx,QWORD PTR [rdx]
  c10dda:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10ddf:	mov    QWORD PTR [rsp+0x30],rcx
  c10de4:	movdqu XMMWORD PTR [rsp+0x38],xmm0
  c10dea:	movzx  ecx,ax
  c10ded:	mov    rax,rcx
  c10df0:	sub    rax,r14
  c10df3:	jae    c11917 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ff7>
  c10df9:	mov    rax,QWORD PTR [rbx+0x28]
  c10dfd:	shl    ecx,0x4
  c10e00:	mov    rax,QWORD PTR [rax+rcx*1]
  c10e04:	jmp    c1191b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ffb>
  c10e09:	add    rcx,QWORD PTR [rdx+0x60]
  c10e0d:	mov    rdx,QWORD PTR [rsp+0x20]
  c10e12:	cmp    rcx,QWORD PTR [rdx+0x10]
  c10e16:	mov    r12,QWORD PTR [rsp+0x8]
  c10e1b:	jae    c17662 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7d42>
  c10e21:	mov    rsi,QWORD PTR [rdx+0x8]
  c10e25:	lea    rcx,[rcx+rcx*2]
  c10e29:	mov    edx,DWORD PTR [rsi+rcx*8]
  c10e2c:	lea    edi,[rdx-0x2]
  c10e2f:	cmp    rdx,0x2
  c10e33:	mov    r8d,0x3
  c10e39:	cmovae r8d,edi
  c10e3d:	lea    rcx,[rsi+rcx*8]
  c10e41:	lea    rsi,[rip+0xffffffffff6b4aa4]        # 2c58ec <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf2b>
  c10e48:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c10e4c:	add    rdi,rsi
  c10e4f:	jmp    rdi
  c10e51:	mov    r8,QWORD PTR [rcx]
  c10e54:	mov    rsi,QWORD PTR [rcx+0x8]
  c10e58:	mov    rcx,QWORD PTR [rcx+0x10]
  c10e5c:	jmp    c12a81 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3161>
  c10e61:	add    rax,QWORD PTR [rcx+0x60]
  c10e65:	mov    rdx,QWORD PTR [rsp+0x20]
  c10e6a:	mov    rcx,QWORD PTR [rdx+0x8]
  c10e6e:	and    bpl,0x1
  c10e72:	mov    BYTE PTR [rsp+0x104],bpl
  c10e7a:	mov    DWORD PTR [rsp+0x100],0x4
  c10e85:	cmp    rax,QWORD PTR [rdx+0x10]
  c10e89:	mov    r12,QWORD PTR [rsp+0x8]
  c10e8e:	jae    c17689 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7d69>
  c10e94:	lea    rax,[rax+rax*2]
  c10e98:	lea    r14,[rcx+rax*8]
  c10e9c:	mov    eax,DWORD PTR [rcx+rax*8]
  c10e9f:	mov    edx,eax
  c10ea1:	sub    edx,0x2
  c10ea4:	mov    ecx,0x3
  c10ea9:	cmovae ecx,edx
  c10eac:	cmp    ecx,0x8
  c10eaf:	ja     c1396a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x404a>
  c10eb5:	mov    edx,0x1e7
  c10eba:	bt     edx,ecx
  c10ebd:	lea    rbp,[r12+0x8]
  c10ec2:	jae    c11ae8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21c8>
  c10ec8:	mov    rax,QWORD PTR [rsp+0x110]
  c10ed0:	mov    QWORD PTR [r14+0x10],rax
  c10ed4:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c10edd:	movdqu XMMWORD PTR [r14],xmm0
  c10ee2:	lea    rax,[r12+0x10]
  c10ee7:	mov    rsi,QWORD PTR [rax]
  c10eea:	cmp    QWORD PTR [rsp],rsi
  c10eee:	jb     c16140 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6820>
  c10ef4:	jmp    c19a5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa13d>
  c10ef9:	add    rax,QWORD PTR [rcx+0x60]
  c10efd:	mov    rdx,QWORD PTR [rsp+0x20]
  c10f02:	mov    rcx,QWORD PTR [rdx+0x8]
  c10f06:	mov    DWORD PTR [rsp+0x100],0x2
  c10f11:	cmp    rax,QWORD PTR [rdx+0x10]
  c10f15:	mov    r12,QWORD PTR [rsp+0x8]
  c10f1a:	jae    c17745 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e25>
  c10f20:	lea    rax,[rax+rax*2]
  c10f24:	lea    r14,[rcx+rax*8]
  c10f28:	mov    eax,DWORD PTR [rcx+rax*8]
  c10f2b:	mov    edx,eax
  c10f2d:	sub    edx,0x2
  c10f30:	mov    ecx,0x3
  c10f35:	cmovae ecx,edx
  c10f38:	cmp    ecx,0x8
  c10f3b:	ja     c13cc1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x43a1>
  c10f41:	mov    edx,0x1e7
  c10f46:	bt     edx,ecx
  c10f49:	jae    c11b15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21f5>
  c10f4f:	mov    rax,QWORD PTR [rsp+0x110]
  c10f57:	mov    QWORD PTR [r14+0x10],rax
  c10f5b:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c10f64:	movdqu XMMWORD PTR [r14],xmm0
  c10f69:	lea    rax,[r12+0x10]
  c10f6e:	mov    rsi,QWORD PTR [rax]
  c10f71:	cmp    QWORD PTR [rsp],rsi
  c10f75:	jb     c16140 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6820>
  c10f7b:	jmp    c19a0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0ea>
  c10f80:	add    rcx,QWORD PTR [rbx+0x60]
  c10f84:	mov    rdx,QWORD PTR [rsp+0x20]
  c10f89:	mov    r14,QWORD PTR [rdx+0x10]
  c10f8d:	cmp    rcx,r14
  c10f90:	jae    c17709 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7de9>
  c10f96:	mov    DWORD PTR [rsp+0x2c],r15d
  c10f9b:	mov    r15,QWORD PTR [rdx+0x8]
  c10f9f:	lea    rcx,[rcx+rcx*2]
  c10fa3:	mov    esi,DWORD PTR [r15+rcx*8]
  c10fa7:	lea    edx,[rsi-0x2]
  c10faa:	cmp    rsi,0x2
  c10fae:	mov    edi,0x3
  c10fb3:	cmovae edi,edx
  c10fb6:	lea    rdx,[r15+rcx*8]
  c10fba:	lea    rcx,[rip+0xffffffffff6b4bd3]        # 2c5b94 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x11d3>
  c10fc1:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10fc5:	add    rdi,rcx
  c10fc8:	jmp    rdi
  c10fca:	mov    rcx,QWORD PTR [rdx]
  c10fcd:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10fd2:	mov    QWORD PTR [rsp+0x30],rcx
  c10fd7:	movdqu XMMWORD PTR [rsp+0x38],xmm0
  c10fdd:	mov    rcx,rax
  c10fe0:	sub    rcx,rbp
  c10fe3:	jae    c1195c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x203c>
  c10fe9:	mov    rcx,QWORD PTR [rbx+0x28]
  c10fed:	shl    eax,0x4
  c10ff0:	mov    rcx,QWORD PTR [rcx+rax*1]
  c10ff4:	jmp    c11960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2040>
  c10ff9:	add    rax,QWORD PTR [rcx+0x60]
  c10ffd:	mov    rdx,QWORD PTR [rsp+0x20]
  c11002:	mov    rcx,QWORD PTR [rdx+0x8]
  c11006:	mov    DWORD PTR [rsp+0x100],0x3
  c11011:	cmp    rax,QWORD PTR [rdx+0x10]
  c11015:	mov    r12,QWORD PTR [rsp+0x8]
  c1101a:	jae    c17799 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e79>
  c11020:	lea    rax,[rax+rax*2]
  c11024:	lea    r14,[rcx+rax*8]
  c11028:	mov    eax,DWORD PTR [rcx+rax*8]
  c1102b:	mov    edx,eax
  c1102d:	sub    edx,0x2
  c11030:	mov    ecx,0x3
  c11035:	cmovae ecx,edx
  c11038:	cmp    ecx,0x8
  c1103b:	ja     c13cfa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x43da>
  c11041:	mov    edx,0x1e7
  c11046:	bt     edx,ecx
  c11049:	jae    c11b42 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2222>
  c1104f:	mov    rax,QWORD PTR [rsp+0x110]
  c11057:	mov    QWORD PTR [r14+0x10],rax
  c1105b:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c11064:	movdqu XMMWORD PTR [r14],xmm0
  c11069:	lea    rax,[r12+0x10]
  c1106e:	mov    rsi,QWORD PTR [rax]
  c11071:	cmp    QWORD PTR [rsp],rsi
  c11075:	jb     c16140 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6820>
  c1107b:	jmp    c199b8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa098>
  c11080:	add    rax,QWORD PTR [rcx+0x60]
  c11084:	mov    rcx,QWORD PTR [rsp+0x20]
  c11089:	cmp    rax,QWORD PTR [rcx+0x10]
  c1108d:	mov    r12,QWORD PTR [rsp+0x8]
  c11092:	jae    c1779e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e7e>
  c11098:	mov    rdx,QWORD PTR [rcx+0x8]
  c1109c:	lea    rax,[rax+rax*2]
  c110a0:	mov    ecx,DWORD PTR [rdx+rax*8]
  c110a3:	lea    esi,[rcx-0x2]
  c110a6:	cmp    rcx,0x2
  c110aa:	mov    edi,0x3
  c110af:	cmovae edi,esi
  c110b2:	lea    rax,[rdx+rax*8]
  c110b6:	lea    rdx,[rip+0xffffffffff6b478f]        # 2c584c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe8b>
  c110bd:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c110c1:	add    rsi,rdx
  c110c4:	jmp    rsi
  c110c6:	mov    rdi,QWORD PTR [rax]
  c110c9:	mov    rdx,QWORD PTR [rax+0x8]
  c110cd:	mov    rax,QWORD PTR [rax+0x10]
  c110d1:	jmp    c12d0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33ea>
  c110d6:	add    rax,QWORD PTR [rdx+0x60]
  c110da:	mov    r8,QWORD PTR [rsp+0x20]
  c110df:	cmp    rax,QWORD PTR [r8+0x10]
  c110e3:	mov    rcx,QWORD PTR [rsp+0x8]
  c110e8:	lea    rbp,[rcx+0x8]
  c110ec:	jae    c176dd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7dbd>
  c110f2:	mov    rdx,QWORD PTR [r8+0x8]
  c110f6:	lea    rax,[rax+rax*2]
  c110fa:	mov    ecx,DWORD PTR [rdx+rax*8]
  c110fd:	lea    esi,[rcx-0x2]
  c11100:	cmp    rcx,0x2
  c11104:	mov    r10d,0x3
  c1110a:	cmovae r10d,esi
  c1110e:	lea    rax,[rdx+rax*8]
  c11112:	lea    rdx,[rip+0xffffffffff6b4c33]        # 2c5d4c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x138b>
  c11119:	movsxd rsi,DWORD PTR [rdx+r10*4]
  c1111d:	add    rsi,rdx
  c11120:	jmp    rsi
  c11122:	mov    rsi,QWORD PTR [rax]
  c11125:	mov    rdx,QWORD PTR [rax+0x8]
  c11129:	mov    rax,QWORD PTR [rax+0x10]
  c1112d:	jmp    c12e3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x351e>
  c11132:	add    rcx,QWORD PTR [r9+0x60]
  c11136:	movzx  edx,bpl
  c1113a:	mov    r8,rdx
  c1113d:	sub    r8,rax
  c11140:	mov    r12,QWORD PTR [rsp+0x8]
  c11145:	jae    c11154 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1834>
  c11147:	mov    rax,QWORD PTR [r9+0x28]
  c1114b:	shl    edx,0x4
  c1114e:	mov    r8,QWORD PTR [rax+rdx*1]
  c11152:	jmp    c11158 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1838>
  c11154:	add    r8,QWORD PTR [r9+0x60]
  c11158:	lea    rbp,[r12+0x8]
  c1115d:	mov    rax,QWORD PTR [rsp+0x20]
  c11162:	mov    rsi,QWORD PTR [rax+0x8]
  c11166:	mov    rdx,QWORD PTR [rax+0x10]
  c1116a:	add    r9,0x58
  c1116e:	sub    rsp,0x8
  c11172:	lea    rdi,[rsp+0x108]
  c1117a:	push   rbx
  c1117b:	call   c0f6a0 <_RNvCsbxgXiyEKxkX_6bsl_vm24numeric_for_next_regular>
  c11180:	add    rsp,0x10
  c11184:	cmp    BYTE PTR [rsp+0x100],0xff
  c1118c:	jne    c17807 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ee7>
  c11192:	mov    rbx,QWORD PTR [rsp+0x10]
  c11197:	test   r15b,r15b
  c1119a:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c111a0:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c111a5:	add    rcx,QWORD PTR [rsi+0x60]
  c111a9:	mov    r10,QWORD PTR [rsp+0x20]
  c111ae:	cmp    rcx,QWORD PTR [r10+0x10]
  c111b2:	mov    rdx,QWORD PTR [rsp+0x8]
  c111b7:	lea    rbp,[rdx+0x8]
  c111bb:	jae    c178a2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f82>
  c111c1:	mov    rsi,QWORD PTR [r10+0x8]
  c111c5:	lea    rcx,[rcx+rcx*2]
  c111c9:	mov    edx,DWORD PTR [rsi+rcx*8]
  c111cc:	lea    ebx,[rdx-0x2]
  c111cf:	cmp    rdx,0x2
  c111d3:	mov    r8d,0x3
  c111d9:	cmovae r8d,ebx
  c111dd:	lea    rcx,[rsi+rcx*8]
  c111e1:	lea    rsi,[rip+0xffffffffff6b49fc]        # 2c5be4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1223>
  c111e8:	movsxd r8,DWORD PTR [rsi+r8*4]
  c111ec:	add    r8,rsi
  c111ef:	jmp    r8
  c111f2:	mov    rbx,QWORD PTR [rcx]
  c111f5:	mov    r14,QWORD PTR [rcx+0x8]
  c111f9:	mov    rsi,QWORD PTR [rcx+0x10]
  c111fd:	jmp    c12fe9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36c9>
  c11202:	add    rax,QWORD PTR [rcx+0x60]
  c11206:	mov    rcx,QWORD PTR [rsp+0x20]
  c1120b:	cmp    rax,QWORD PTR [rcx+0x10]
  c1120f:	mov    r12,QWORD PTR [rsp+0x8]
  c11214:	jae    c177df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ebf>
  c1121a:	mov    rdx,QWORD PTR [rcx+0x8]
  c1121e:	lea    rax,[rax+rax*2]
  c11222:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11225:	lea    esi,[rcx-0x2]
  c11228:	cmp    rcx,0x2
  c1122c:	mov    edi,0x3
  c11231:	cmovae edi,esi
  c11234:	lea    rax,[rdx+rax*8]
  c11238:	lea    rdx,[rip+0xffffffffff6b4815]        # 2c5a54 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1093>
  c1123f:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c11243:	add    rsi,rdx
  c11246:	mov    DWORD PTR [rsp+0x2c],r15d
  c1124b:	jmp    rsi
  c1124d:	mov    rdx,QWORD PTR [rax]
  c11250:	mov    rsi,QWORD PTR [rax+0x8]
  c11254:	mov    rax,QWORD PTR [rax+0x10]
  c11258:	jmp    c1321c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38fc>
  c1125d:	add    rcx,QWORD PTR [rsi+0x60]
  c11261:	mov    r14,QWORD PTR [rsp+0x20]
  c11266:	cmp    rcx,QWORD PTR [r14+0x10]
  c1126a:	mov    rdx,QWORD PTR [rsp+0x8]
  c1126f:	lea    rbp,[rdx+0x8]
  c11273:	jae    c17772 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e52>
  c11279:	mov    rsi,QWORD PTR [r14+0x8]
  c1127d:	lea    rcx,[rcx+rcx*2]
  c11281:	mov    edx,DWORD PTR [rsi+rcx*8]
  c11284:	lea    edi,[rdx-0x2]
  c11287:	cmp    rdx,0x2
  c1128b:	mov    r8d,0x3
  c11291:	cmovae r8d,edi
  c11295:	lea    rcx,[rsi+rcx*8]
  c11299:	lea    rsi,[rip+0xffffffffff6b46c4]        # 2c5964 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xfa3>
  c112a0:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c112a4:	add    rdi,rsi
  c112a7:	jmp    rdi
  c112a9:	mov    r8,QWORD PTR [rcx]
  c112ac:	mov    rdi,QWORD PTR [rcx+0x8]
  c112b0:	mov    rsi,QWORD PTR [rcx+0x10]
  c112b4:	jmp    c13315 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39f5>
  c112b9:	add    rax,QWORD PTR [rdx+0x60]
  c112bd:	mov    r14,QWORD PTR [rsp+0x20]
  c112c2:	cmp    rax,QWORD PTR [r14+0x10]
  c112c6:	mov    rcx,QWORD PTR [rsp+0x8]
  c112cb:	lea    rbp,[rcx+0x8]
  c112cf:	jae    c1768e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7d6e>
  c112d5:	mov    rdx,QWORD PTR [r14+0x8]
  c112d9:	lea    rax,[rax+rax*2]
  c112dd:	mov    ecx,DWORD PTR [rdx+rax*8]
  c112e0:	lea    esi,[rcx-0x2]
  c112e3:	cmp    rcx,0x2
  c112e7:	mov    edi,0x3
  c112ec:	cmovae edi,esi
  c112ef:	lea    rax,[rdx+rax*8]
  c112f3:	lea    rdx,[rip+0xffffffffff6b452a]        # 2c5824 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe63>
  c112fa:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c112fe:	add    rsi,rdx
  c11301:	jmp    rsi
  c11303:	mov    rdx,QWORD PTR [rax]
  c11306:	mov    rsi,QWORD PTR [rax+0x8]
  c1130a:	mov    rax,QWORD PTR [rax+0x10]
  c1130e:	jmp    c13473 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b53>
  c11313:	add    rax,QWORD PTR [rdx+0x60]
  c11317:	mov    r14,QWORD PTR [rsp+0x20]
  c1131c:	cmp    rax,QWORD PTR [r14+0x10]
  c11320:	mov    rcx,QWORD PTR [rsp+0x8]
  c11325:	lea    rbp,[rcx+0x8]
  c11329:	jae    c1771e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7dfe>
  c1132f:	mov    rdx,QWORD PTR [r14+0x8]
  c11333:	lea    rax,[rax+rax*2]
  c11337:	mov    ecx,DWORD PTR [rdx+rax*8]
  c1133a:	lea    esi,[rcx-0x2]
  c1133d:	cmp    rcx,0x2
  c11341:	mov    edi,0x3
  c11346:	cmovae edi,esi
  c11349:	lea    rax,[rdx+rax*8]
  c1134d:	lea    rdx,[rip+0xffffffffff6b4930]        # 2c5c84 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x12c3>
  c11354:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c11358:	add    rsi,rdx
  c1135b:	jmp    rsi
  c1135d:	mov    rdx,QWORD PTR [rax]
  c11360:	mov    rsi,QWORD PTR [rax+0x8]
  c11364:	mov    rax,QWORD PTR [rax+0x10]
  c11368:	jmp    c1379e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e7e>
  c1136d:	add    rax,QWORD PTR [rdx+0x60]
  c11371:	mov    r14,QWORD PTR [rsp+0x20]
  c11376:	cmp    rax,QWORD PTR [r14+0x10]
  c1137a:	mov    rcx,QWORD PTR [rsp+0x8]
  c1137f:	lea    rbp,[rcx+0x8]
  c11383:	jae    c1783b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f1b>
  c11389:	mov    rdx,QWORD PTR [r14+0x8]
  c1138d:	lea    rax,[rax+rax*2]
  c11391:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11394:	lea    esi,[rcx-0x2]
  c11397:	cmp    rcx,0x2
  c1139b:	mov    edi,0x3
  c113a0:	cmovae edi,esi
  c113a3:	lea    rax,[rdx+rax*8]
  c113a7:	lea    rdx,[rip+0xffffffffff6b48fe]        # 2c5cac <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x12eb>
  c113ae:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c113b2:	add    rsi,rdx
  c113b5:	jmp    rsi
  c113b7:	mov    rdx,QWORD PTR [rax]
  c113ba:	mov    rsi,QWORD PTR [rax+0x8]
  c113be:	mov    rax,QWORD PTR [rax+0x10]
  c113c2:	jmp    c13a30 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4110>
  c113c7:	add    rcx,QWORD PTR [rsi+0x60]
  c113cb:	mov    r10,QWORD PTR [rsp+0x20]
  c113d0:	cmp    rcx,QWORD PTR [r10+0x10]
  c113d4:	mov    rdx,QWORD PTR [rsp+0x8]
  c113d9:	lea    rbp,[rdx+0x8]
  c113dd:	jae    c1774a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e2a>
  c113e3:	mov    rsi,QWORD PTR [r10+0x8]
  c113e7:	lea    rcx,[rcx+rcx*2]
  c113eb:	mov    edx,DWORD PTR [rsi+rcx*8]
  c113ee:	lea    ebx,[rdx-0x2]
  c113f1:	cmp    rdx,0x2
  c113f5:	mov    r8d,0x3
  c113fb:	cmovae r8d,ebx
  c113ff:	lea    rcx,[rsi+rcx*8]
  c11403:	lea    rsi,[rip+0xffffffffff6b482a]        # 2c5c34 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1273>
  c1140a:	movsxd r8,DWORD PTR [rsi+r8*4]
  c1140e:	add    r8,rsi
  c11411:	jmp    r8
  c11414:	mov    rbx,QWORD PTR [rcx]
  c11417:	mov    r14,QWORD PTR [rcx+0x8]
  c1141b:	mov    rsi,QWORD PTR [rcx+0x10]
  c1141f:	jmp    c13c29 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4309>
  c11424:	add    r15,QWORD PTR [rax+0x60]
  c11428:	movzx  edx,bpl
  c1142c:	mov    rbp,rdx
  c1142f:	sub    rbp,rcx
  c11432:	mov    r12,QWORD PTR [rsp+0x8]
  c11437:	jae    c11446 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1b26>
  c11439:	mov    rcx,QWORD PTR [rax+0x28]
  c1143d:	shl    edx,0x4
  c11440:	mov    rbp,QWORD PTR [rcx+rdx*1]
  c11444:	jmp    c1144a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1b2a>
  c11446:	add    rbp,QWORD PTR [rax+0x60]
  c1144a:	mov    rsi,QWORD PTR [rax]
  c1144d:	mov    rdx,QWORD PTR [rax+0x8]
  c11451:	mov    r9,QWORD PTR [rax+0x10]
  c11455:	mov    rcx,QWORD PTR [rax+0x18]
  c11459:	mov    QWORD PTR [rax],0x0
  c11460:	cmp    rsi,0x1
  c11464:	jne    c11477 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1b57>
  c11466:	mov    rax,r13
  c11469:	cmp    rdx,r13
  c1146c:	je     c114fa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1bda>
  c11472:	jmp    c1889d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8f7d>
  c11477:	lea    rax,[r12+0x10]
  c1147c:	mov    rsi,QWORD PTR [rax]
  c1147f:	cmp    QWORD PTR [rsp],rsi
  c11483:	jae    c19ced <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3cd>
  c11489:	lea    rax,[r12+0x8]
  c1148e:	mov    rax,QWORD PTR [rax]
  c11491:	mov    rcx,QWORD PTR [rsp+0x20]
  c11496:	mov    rsi,QWORD PTR [rcx+0x8]
  c1149a:	mov    rdx,QWORD PTR [rcx+0x10]
  c1149e:	mov    rcx,QWORD PTR [rsp+0x18]
  c114a3:	lea    rax,[rax+rcx*1+0x58]
  c114a8:	lea    rdi,[rsp+0x100]
  c114b0:	mov    rcx,r15
  c114b3:	mov    r8,rbp
  c114b6:	mov    r9,r13
  c114b9:	push   rbx
  c114ba:	push   rax
  c114bb:	call   c0e560 <_RNvCsbxgXiyEKxkX_6bsl_vm21numeric_for_i64_start>
  c114c0:	add    rsp,0x10
  c114c4:	movzx  eax,BYTE PTR [rsp+0x100]
  c114cc:	cmp    al,0xff
  c114ce:	jne    c188bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8f9d>
  c114d4:	test   BYTE PTR [rsp+0x108],0x1
  c114dc:	je     c195c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ca6>
  c114e2:	mov    rax,QWORD PTR [rsp+0x110]
  c114ea:	mov    r9,QWORD PTR [rsp+0x118]
  c114f2:	mov    rcx,QWORD PTR [rsp+0x120]
  c114fa:	mov    rdx,r9
  c114fd:	inc    rdx
  c11500:	jo     c1952e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c0e>
  c11506:	cmp    rdx,rcx
  c11509:	jle    c119a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2081>
  c1150f:	mov    rsi,QWORD PTR [rsp+0x20]
  c11514:	mov    rax,QWORD PTR [rsi+0x8]
  c11518:	mov    rcx,rdx
  c1151b:	sar    rcx,0x3f
  c1151f:	mov    QWORD PTR [rsp+0x100],0x0
  c1152b:	mov    QWORD PTR [rsp+0x108],rdx
  c11533:	mov    QWORD PTR [rsp+0x110],rcx
  c1153b:	cmp    r15,QWORD PTR [rsi+0x10]
  c1153f:	lea    rbp,[r12+0x8]
  c11544:	jae    c18905 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8fe5>
  c1154a:	lea    rcx,[r15+r15*2]
  c1154e:	lea    r15,[rax+rcx*8]
  c11552:	mov    rdi,r15
  c11555:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1155a:	mov    rbx,QWORD PTR [rsp+0x10]
  c1155f:	mov    rax,QWORD PTR [rsp+0x110]
  c11567:	mov    QWORD PTR [r15+0x10],rax
  c1156b:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c11574:	movdqu XMMWORD PTR [r15],xmm0
  c11579:	lea    rax,[r12+0x10]
  c1157e:	mov    rsi,QWORD PTR [rax]
  c11581:	cmp    QWORD PTR [rsp],rsi
  c11585:	jae    c19d60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa440>
  c1158b:	mov    rax,QWORD PTR [rbp+0x0]
  c1158f:	mov    rcx,QWORD PTR [rsp+0x18]
  c11594:	inc    QWORD PTR [rax+rcx*1+0x58]
  c11599:	mov    r15d,r14d
  c1159c:	mov    r14,rcx
  c1159f:	test   r15b,r15b
  c115a2:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c115a8:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c115ad:	add    rax,QWORD PTR [rcx+0x60]
  c115b1:	mov    rcx,QWORD PTR [rsp+0x20]
  c115b6:	cmp    rax,QWORD PTR [rcx+0x10]
  c115ba:	mov    r12,QWORD PTR [rsp+0x8]
  c115bf:	jae    c176b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7d95>
  c115c5:	mov    rdx,QWORD PTR [rcx+0x8]
  c115c9:	lea    rax,[rax+rax*2]
  c115cd:	mov    ecx,DWORD PTR [rdx+rax*8]
  c115d0:	lea    esi,[rcx-0x2]
  c115d3:	cmp    rcx,0x2
  c115d7:	mov    edi,0x3
  c115dc:	cmovae edi,esi
  c115df:	lea    rax,[rdx+rax*8]
  c115e3:	lea    rdx,[rip+0xffffffffff6b4492]        # 2c5a7c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x10bb>
  c115ea:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c115ee:	add    rsi,rdx
  c115f1:	mov    DWORD PTR [rsp+0x2c],r15d
  c115f6:	jmp    rsi
  c115f8:	mov    rdx,QWORD PTR [rax]
  c115fb:	mov    rsi,QWORD PTR [rax+0x8]
  c115ff:	mov    rax,QWORD PTR [rax+0x10]
  c11603:	jmp    c13d44 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4424>
  c11608:	lea    rdi,[rsp+0x70]
  c1160d:	call   c24d20 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs8as_slice>
  c11612:	mov    rcx,QWORD PTR [rsp+0x8]
  c11617:	lea    rbp,[rcx+0x8]
  c1161b:	mov    r8,rdx
  c1161e:	mov    ecx,ebx
  c11620:	shr    ebx,0x8
  c11623:	sub    rsp,0x8
  c11627:	movzx  esi,cl
  c1162a:	movzx  edx,bl
  c1162d:	lea    rdi,[rsp+0x108]
  c11635:	mov    rcx,rax
  c11638:	mov    r9,QWORD PTR [rsp+0x638]
  c11640:	push   QWORD PTR [rsp+0x648]
  c11647:	call   c0eb80 <_RNvCsbxgXiyEKxkX_6bsl_vm24call_builtin_with_format>
  c1164c:	add    rsp,0x10
  c11650:	movzx  eax,BYTE PTR [rsp+0x100]
  c11658:	cmp    al,0xff
  c1165a:	jne    c17985 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8065>
  c11660:	lea    rcx,[rsp+0x104]
  c11668:	mov    rax,QWORD PTR [rcx+0x14]
  c1166c:	lea    rdx,[rsp+0x37]
  c11671:	mov    QWORD PTR [rdx+0x10],rax
  c11675:	movups xmm0,XMMWORD PTR [rcx+0x4]
  c11679:	movups XMMWORD PTR [rdx],xmm0
  c1167c:	movdqu xmm0,XMMWORD PTR [rdx]
  c11680:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c11689:	mov    rax,QWORD PTR [rdx+0x10]
  c1168d:	mov    QWORD PTR [rsp+0xd0],rax
  c11695:	mov    rax,QWORD PTR [rsp+0x8]
  c1169a:	add    rax,0x10
  c1169e:	mov    rsi,QWORD PTR [rax]
  c116a1:	mov    rdi,QWORD PTR [rsp]
  c116a5:	cmp    rdi,rsi
  c116a8:	mov    r8,QWORD PTR [rsp+0x20]
  c116ad:	mov    r9,QWORD PTR [rsp+0x18]
  c116b2:	jae    c19b03 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1e3>
  c116b8:	mov    rdx,QWORD PTR [rbp+0x0]
  c116bc:	lea    rcx,[rdx+r9*1]
  c116c0:	mov    rax,r12
  c116c3:	sub    rax,QWORD PTR [rdx+r9*1+0x30]
  c116c8:	jae    c11a0d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20ed>
  c116ce:	mov    rax,QWORD PTR [rcx+0x28]
  c116d2:	shl    r12d,0x4
  c116d6:	mov    rax,QWORD PTR [rax+r12*1]
  c116da:	jmp    c11a11 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20f1>
  c116df:	add    rax,QWORD PTR [rcx+0x60]
  c116e3:	mov    r8,QWORD PTR [rsp+0x1b8]
  c116eb:	cmp    rax,QWORD PTR [rdx+0x10]
  c116ef:	mov    r12,QWORD PTR [rsp+0x8]
  c116f4:	jae    c17916 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ff6>
  c116fa:	mov    rdx,QWORD PTR [rdx+0x8]
  c116fe:	lea    rax,[rax+rax*2]
  c11702:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11705:	lea    esi,[rcx-0x2]
  c11708:	cmp    rcx,0x2
  c1170c:	mov    edi,0x3
  c11711:	cmovae edi,esi
  c11714:	lea    rax,[rdx+rax*8]
  c11718:	lea    rdx,[rip+0xffffffffff6b45dd]        # 2c5cfc <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x133b>
  c1171f:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c11723:	add    rsi,rdx
  c11726:	jmp    rsi
  c11728:	mov    rdx,QWORD PTR [rax]
  c1172b:	mov    rcx,QWORD PTR [rax+0x8]
  c1172f:	mov    r9,QWORD PTR [rax+0x10]
  c11733:	mov    QWORD PTR [rsp+0x4f0],rdx
  c1173b:	mov    QWORD PTR [rsp+0x4f8],rcx
  c11743:	mov    QWORD PTR [rsp+0x500],r9
  c1174b:	cmp    QWORD PTR [r8+0x10],rbp
  c1174f:	jbe    c17edf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85bf>
  c11755:	mov    QWORD PTR [rsp+0x540],r9
  c1175d:	mov    QWORD PTR [rsp+0x418],rcx
  c11765:	mov    QWORD PTR [rsp+0x2b0],rdx
  c1176d:	mov    rax,QWORD PTR [r8+0x8]
  c11771:	lea    rcx,[rbp*2+0x0]
  c11779:	add    rcx,rbp
  c1177c:	lea    r14,[rax+rcx*8]
  c11780:	mov    eax,DWORD PTR [rax+rcx*8]
  c11783:	mov    edx,eax
  c11785:	sub    edx,0x2
  c11788:	mov    ecx,0x3
  c1178d:	cmovae ecx,edx
  c11790:	cmp    ecx,0x8
  c11793:	ja     c1557d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c5d>
  c11799:	mov    edx,0x1e7
  c1179e:	bt     edx,ecx
  c117a1:	lea    rbp,[r12+0x8]
  c117a6:	jae    c11b9c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x227c>
  c117ac:	mov    rax,QWORD PTR [rsp+0x500]
  c117b4:	mov    QWORD PTR [r14+0x10],rax
  c117b8:	movdqu xmm0,XMMWORD PTR [rsp+0x4f0]
  c117c1:	movdqu XMMWORD PTR [r14],xmm0
  c117c6:	lea    rax,[r12+0x10]
  c117cb:	mov    rsi,QWORD PTR [rax]
  c117ce:	cmp    QWORD PTR [rsp],rsi
  c117d2:	jb     c16140 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6820>
  c117d8:	jmp    c19b70 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa250>
  c117dd:	add    rcx,QWORD PTR [rdx+0x60]
  c117e1:	mov    r12,QWORD PTR [rsp+0x8]
  c117e6:	mov    rdx,QWORD PTR [rsp+0x20]
  c117eb:	cmp    rcx,QWORD PTR [rdx+0x10]
  c117ef:	jae    c1795d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x803d>
  c117f5:	mov    rsi,QWORD PTR [rdx+0x8]
  c117f9:	lea    rcx,[rcx+rcx*2]
  c117fd:	mov    edx,DWORD PTR [rsi+rcx*8]
  c11800:	lea    edi,[rdx-0x2]
  c11803:	cmp    rdx,0x2
  c11807:	mov    r8d,0x3
  c1180d:	cmovae r8d,edi
  c11811:	lea    rcx,[rsi+rcx*8]
  c11815:	lea    rsi,[rip+0xffffffffff6b4210]        # 2c5a2c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x106b>
  c1181c:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c11820:	add    rdi,rsi
  c11823:	jmp    rdi
  c11825:	mov    rsi,QWORD PTR [rcx]
  c11828:	mov    rdi,QWORD PTR [rcx+0x8]
  c1182c:	mov    rcx,QWORD PTR [rcx+0x10]
  c11830:	jmp    c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c11835:	add    rcx,QWORD PTR [rdx+0x60]
  c11839:	mov    r12,QWORD PTR [rsp+0x8]
  c1183e:	mov    rdx,QWORD PTR [rsp+0x20]
  c11843:	cmp    rcx,QWORD PTR [rdx+0x10]
  c11847:	jae    c17935 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8015>
  c1184d:	mov    rsi,QWORD PTR [rdx+0x8]
  c11851:	lea    rcx,[rcx+rcx*2]
  c11855:	mov    edx,DWORD PTR [rsi+rcx*8]
  c11858:	lea    edi,[rdx-0x2]
  c1185b:	cmp    rdx,0x2
  c1185f:	mov    r8d,0x3
  c11865:	cmovae r8d,edi
  c11869:	lea    rcx,[rsi+rcx*8]
  c1186d:	lea    rsi,[rip+0xffffffffff6b4190]        # 2c5a04 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1043>
  c11874:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c11878:	add    rdi,rsi
  c1187b:	jmp    rdi
  c1187d:	mov    rsi,QWORD PTR [rcx]
  c11880:	mov    rdi,QWORD PTR [rcx+0x8]
  c11884:	mov    rcx,QWORD PTR [rcx+0x10]
  c11888:	jmp    c142df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x49bf>
  c1188d:	add    rax,QWORD PTR [rbx+0x60]
  c11891:	cmp    rax,r13
  c11894:	jae    c179e1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80c1>
  c1189a:	lea    rax,[rax+rax*2]
  c1189e:	mov    edx,DWORD PTR [r14+rax*8]
  c118a2:	lea    ecx,[rdx-0x2]
  c118a5:	cmp    rdx,0x2
  c118a9:	mov    esi,0x3
  c118ae:	cmovae esi,ecx
  c118b1:	lea    rcx,[r14+rax*8]
  c118b5:	lea    rax,[rip+0xffffffffff6b4210]        # 2c5acc <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x110b>
  c118bc:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c118c0:	add    rsi,rax
  c118c3:	jmp    rsi
  c118c5:	mov    rax,QWORD PTR [rcx]
  c118c8:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c118cd:	jmp    c1621e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68fe>
  c118d2:	add    rax,QWORD PTR [rbx+0x60]
  c118d6:	cmp    rax,rbp
  c118d9:	jae    c179cc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80ac>
  c118df:	lea    rax,[rax+rax*2]
  c118e3:	mov    edx,DWORD PTR [r15+rax*8]
  c118e7:	lea    ecx,[rdx-0x2]
  c118ea:	cmp    rdx,0x2
  c118ee:	mov    esi,0x3
  c118f3:	cmovae esi,ecx
  c118f6:	lea    rcx,[r15+rax*8]
  c118fa:	lea    rax,[rip+0xffffffffff6b426b]        # 2c5b6c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x11ab>
  c11901:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c11905:	add    rsi,rax
  c11908:	jmp    rsi
  c1190a:	mov    rax,QWORD PTR [rcx]
  c1190d:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c11912:	jmp    c164b2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b92>
  c11917:	add    rax,QWORD PTR [rbx+0x60]
  c1191b:	cmp    rax,rbp
  c1191e:	jae    c17a38 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8118>
  c11924:	lea    rax,[rax+rax*2]
  c11928:	mov    edx,DWORD PTR [r15+rax*8]
  c1192c:	lea    ecx,[rdx-0x2]
  c1192f:	cmp    rdx,0x2
  c11933:	mov    esi,0x3
  c11938:	cmovae esi,ecx
  c1193b:	lea    rcx,[r15+rax*8]
  c1193f:	lea    rax,[rip+0xffffffffff6b41d6]        # 2c5b1c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x115b>
  c11946:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c1194a:	add    rsi,rax
  c1194d:	jmp    rsi
  c1194f:	mov    rax,QWORD PTR [rcx]
  c11952:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c11957:	jmp    c1676d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e4d>
  c1195c:	add    rcx,QWORD PTR [rbx+0x60]
  c11960:	cmp    rcx,r14
  c11963:	jae    c179f6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80d6>
  c11969:	lea    rax,[rcx+rcx*2]
  c1196d:	mov    edx,DWORD PTR [r15+rax*8]
  c11971:	lea    ecx,[rdx-0x2]
  c11974:	cmp    rdx,0x2
  c11978:	mov    esi,0x3
  c1197d:	cmovae esi,ecx
  c11980:	lea    rcx,[r15+rax*8]
  c11984:	lea    rax,[rip+0xffffffffff6b4231]        # 2c5bbc <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x11fb>
  c1198b:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c1198f:	add    rsi,rax
  c11992:	jmp    rsi
  c11994:	mov    rax,QWORD PTR [rcx]
  c11997:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c1199c:	jmp    c16a28 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7108>
  c119a1:	lea    r8,[r12+0x10]
  c119a6:	mov    rsi,QWORD PTR [r8]
  c119a9:	mov    rdi,QWORD PTR [rsp]
  c119ad:	cmp    rdi,rsi
  c119b0:	lea    rbp,[r12+0x8]
  c119b5:	jae    c19d0f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3ef>
  c119bb:	mov    rsi,QWORD PTR [rbp+0x0]
  c119bf:	mov    r9,QWORD PTR [rsp+0x18]
  c119c4:	mov    QWORD PTR [rsi+r9*1],0x1
  c119cc:	mov    QWORD PTR [rsi+r9*1+0x8],rax
  c119d1:	mov    QWORD PTR [rsi+r9*1+0x10],rdx
  c119d6:	mov    QWORD PTR [rsi+r9*1+0x18],rcx
  c119db:	mov    rsi,QWORD PTR [r8]
  c119de:	cmp    rdi,rsi
  c119e1:	jae    c19cfe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3de>
  c119e7:	mov    r15d,r14d
  c119ea:	mov    rax,QWORD PTR [rbp+0x0]
  c119ee:	movsx  rcx,bx
  c119f2:	mov    QWORD PTR [rax+r9*1+0x58],rcx
  c119f7:	mov    r14,r9
  c119fa:	mov    rbx,QWORD PTR [rsp+0x10]
  c119ff:	test   r15b,r15b
  c11a02:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c11a08:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c11a0d:	add    rax,QWORD PTR [rcx+0x60]
  c11a11:	mov    r12,QWORD PTR [rsp+0x8]
  c11a16:	mov    rcx,QWORD PTR [r8+0x8]
  c11a1a:	mov    rdx,QWORD PTR [rsp+0xd0]
  c11a22:	mov    QWORD PTR [rsp+0x110],rdx
  c11a2a:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c11a33:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c11a3c:	cmp    rax,QWORD PTR [r8+0x10]
  c11a40:	jae    c17e63 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8543>
  c11a46:	lea    rax,[rax+rax*2]
  c11a4a:	lea    r14,[rcx+rax*8]
  c11a4e:	mov    eax,DWORD PTR [rcx+rax*8]
  c11a51:	mov    edx,eax
  c11a53:	sub    edx,0x2
  c11a56:	mov    ecx,0x3
  c11a5b:	cmovae ecx,edx
  c11a5e:	cmp    ecx,0x8
  c11a61:	ja     c15545 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c25>
  c11a67:	mov    edx,0x1e7
  c11a6c:	bt     edx,ecx
  c11a6f:	jae    c11b6f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x224f>
  c11a75:	mov    rax,QWORD PTR [rsp+0xd0]
  c11a7d:	mov    QWORD PTR [r14+0x10],rax
  c11a81:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c11a8a:	movdqu XMMWORD PTR [r14],xmm0
  c11a8f:	lea    rax,[r12+0x10]
  c11a94:	mov    rsi,QWORD PTR [rax]
  c11a97:	cmp    QWORD PTR [rsp],rsi
  c11a9b:	jae    c19b48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa228>
  c11aa1:	mov    rax,QWORD PTR [rbp+0x0]
  c11aa5:	mov    r14,QWORD PTR [rsp+0x18]
  c11aaa:	inc    QWORD PTR [rax+r14*1+0x58]
  c11aaf:	lea    rdi,[rsp+0x70]
  c11ab4:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c11ab9:	mov    rbx,QWORD PTR [rsp+0x10]
  c11abe:	test   r15b,r15b
  c11ac1:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c11ac7:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c11acc:	inc    QWORD PTR [rax+0x58]
  c11ad0:	mov    r12,QWORD PTR [rsp+0x8]
  c11ad5:	lea    rbp,[r12+0x8]
  c11ada:	test   r15b,r15b
  c11add:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c11ae3:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c11ae8:	cmp    ecx,0x3
  c11aeb:	jne    c129a4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3084>
  c11af1:	test   eax,eax
  c11af3:	je     c10ec8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a8>
  c11af9:	mov    rax,QWORD PTR [r14+0x8]
  c11afd:	dec    QWORD PTR [rax]
  c11b00:	jne    c10ec8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a8>
  c11b06:	lea    rdi,[r14+0x8]
  c11b0a:	call   QWORD PTR [rip+0x23bb98]        # e4d6a8 <_DYNAMIC+0x248>
  c11b10:	jmp    c10ec8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a8>
  c11b15:	cmp    ecx,0x3
  c11b18:	jne    c12bfc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x32dc>
  c11b1e:	test   eax,eax
  c11b20:	je     c10f4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162f>
  c11b26:	mov    rax,QWORD PTR [r14+0x8]
  c11b2a:	dec    QWORD PTR [rax]
  c11b2d:	jne    c10f4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162f>
  c11b33:	lea    rdi,[r14+0x8]
  c11b37:	call   QWORD PTR [rip+0x23bb6b]        # e4d6a8 <_DYNAMIC+0x248>
  c11b3d:	jmp    c10f4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162f>
  c11b42:	cmp    ecx,0x3
  c11b45:	jne    c12c39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3319>
  c11b4b:	test   eax,eax
  c11b4d:	je     c1104f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x172f>
  c11b53:	mov    rax,QWORD PTR [r14+0x8]
  c11b57:	dec    QWORD PTR [rax]
  c11b5a:	jne    c1104f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x172f>
  c11b60:	lea    rdi,[r14+0x8]
  c11b64:	call   QWORD PTR [rip+0x23bb3e]        # e4d6a8 <_DYNAMIC+0x248>
  c11b6a:	jmp    c1104f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x172f>
  c11b6f:	cmp    ecx,0x3
  c11b72:	jne    c15529 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c09>
  c11b78:	test   eax,eax
  c11b7a:	je     c11a75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2155>
  c11b80:	mov    rax,QWORD PTR [r14+0x8]
  c11b84:	dec    QWORD PTR [rax]
  c11b87:	jne    c11a75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2155>
  c11b8d:	lea    rdi,[r14+0x8]
  c11b91:	call   QWORD PTR [rip+0x23bb11]        # e4d6a8 <_DYNAMIC+0x248>
  c11b97:	jmp    c11a75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2155>
  c11b9c:	cmp    ecx,0x3
  c11b9f:	jne    c15561 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c41>
  c11ba5:	test   eax,eax
  c11ba7:	je     c117ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e8c>
  c11bad:	mov    rax,QWORD PTR [r14+0x8]
  c11bb1:	dec    QWORD PTR [rax]
  c11bb4:	jne    c117ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e8c>
  c11bba:	lea    rdi,[r14+0x8]
  c11bbe:	call   QWORD PTR [rip+0x23bae4]        # e4d6a8 <_DYNAMIC+0x248>
  c11bc4:	jmp    c117ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e8c>
  c11bc9:	mov    eax,0x8
  c11bce:	xor    ecx,ecx
  c11bd0:	mov    QWORD PTR [rsp+0x30],rcx
  c11bd5:	mov    QWORD PTR [rsp+0x38],rax
  c11bda:	mov    QWORD PTR [rsp+0x40],0x0
  c11be3:	mov    QWORD PTR [rsp+0x70],0x0
  c11bec:	mov    QWORD PTR [rsp+0x78],0x8
  c11bf5:	mov    QWORD PTR [rsp+0x80],0x0
  c11c01:	test   r15,r15
  c11c04:	mov    r12,QWORD PTR [rsp+0x8]
  c11c09:	mov    QWORD PTR [rsp+0x538],rax
  c11c11:	je     c11c47 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2327>
  c11c13:	mov    r8,QWORD PTR [rbx+0x8]
  c11c17:	shl    r15,0x2
  c11c1b:	mov    QWORD PTR [rsp+0x550],r15
  c11c23:	xor    r11d,r11d
  c11c26:	movzx  eax,BYTE PTR [r8+r11*1]
  c11c2b:	lea    rcx,[rip+0xffffffffff6b3d82]        # 2c59b4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xff3>
  c11c32:	movsxd rax,DWORD PTR [rcx+rax*4]
  c11c36:	add    rax,rcx
  c11c39:	mov    rdx,QWORD PTR [rsp]
  c11c3d:	mov    QWORD PTR [rsp+0x548],r8
  c11c45:	jmp    rax
  c11c47:	mov    r14,QWORD PTR [rsp+0x18]
  c11c4c:	jmp    c16dd2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b2>
  c11c51:	mov    rax,QWORD PTR [rcx+0x8]
  c11c55:	inc    QWORD PTR [rax]
  c11c58:	mov    rcx,QWORD PTR [rsp+0x8]
  c11c5d:	lea    rbp,[rcx+0x8]
  c11c61:	lea    r8,[rcx+0x10]
  c11c65:	mov    rdi,QWORD PTR [rsp]
  c11c69:	mov    r10,QWORD PTR [rsp+0x18]
  c11c6e:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c11c74:	mov    QWORD PTR [rsp+0x78],rax
  c11c79:	mov    DWORD PTR [rsp+0x70],0xb
  c11c81:	jmp    c11d0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x23ea>
  c11c86:	mov    DWORD PTR [rsp+0x70],0x2
  c11c8e:	jmp    c10483 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xb63>
  c11c93:	mov    DWORD PTR [rsp+0x70],0x3
  c11c9b:	jmp    c10483 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xb63>
  c11ca0:	test   al,0x1
  c11ca2:	mov    rdx,QWORD PTR [rsp+0x8]
  c11ca7:	lea    rbp,[rdx+0x8]
  c11cab:	lea    r8,[rdx+0x10]
  c11caf:	mov    rdi,QWORD PTR [rsp]
  c11cb3:	mov    r10,QWORD PTR [rsp+0x18]
  c11cb8:	je     c15d42 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6422>
  c11cbe:	mov    rdx,QWORD PTR [rcx+0x8]
  c11cc2:	inc    QWORD PTR [rdx]
  c11cc5:	mov    r9,QWORD PTR [rsp+0x20]
  c11cca:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c11cd0:	mov    eax,0x1
  c11cd5:	jmp    c15d52 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6432>
  c11cda:	mov    rax,QWORD PTR [rcx+0x8]
  c11cde:	inc    QWORD PTR [rax]
  c11ce1:	mov    rcx,QWORD PTR [rsp+0x8]
  c11ce6:	lea    rbp,[rcx+0x8]
  c11cea:	lea    r8,[rcx+0x10]
  c11cee:	mov    rdi,QWORD PTR [rsp]
  c11cf2:	mov    r10,QWORD PTR [rsp+0x18]
  c11cf7:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c11cfd:	mov    QWORD PTR [rsp+0x78],rax
  c11d02:	mov    DWORD PTR [rsp+0x70],0x6
  c11d0a:	mov    r9,QWORD PTR [rsp+0x20]
  c11d0f:	jmp    c15d67 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6447>
  c11d14:	mov    rsi,QWORD PTR [rax+0x8]
  c11d18:	inc    QWORD PTR [rsi]
  c11d1b:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c11d21:	movabs rax,0xffffffff00000000
  c11d2b:	mov    rdx,QWORD PTR [rsp+0x320]
  c11d33:	and    rdx,rax
  c11d36:	or     rdx,0xb
  c11d3a:	jmp    c11dd0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x24b0>
  c11d3f:	movabs rax,0xffffffff00000000
  c11d49:	mov    rdx,QWORD PTR [rsp+0x320]
  c11d51:	and    rdx,rax
  c11d54:	or     rdx,0x2
  c11d58:	jmp    c11d73 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2453>
  c11d5a:	movabs rax,0xffffffff00000000
  c11d64:	mov    rdx,QWORD PTR [rsp+0x320]
  c11d6c:	and    rdx,rax
  c11d6f:	or     rdx,0x3
  c11d73:	mov    rax,QWORD PTR [rsp+0x190]
  c11d7b:	mov    rsi,QWORD PTR [rsp+0x470]
  c11d83:	jmp    c11dd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x24b8>
  c11d85:	test   cl,0x1
  c11d88:	je     c15e66 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6546>
  c11d8e:	mov    rsi,QWORD PTR [rax+0x8]
  c11d92:	inc    QWORD PTR [rsi]
  c11d95:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c11d9b:	mov    edx,0x1
  c11da0:	mov    rax,QWORD PTR [rsp+0x190]
  c11da8:	jmp    c11de0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x24c0>
  c11daa:	mov    rsi,QWORD PTR [rax+0x8]
  c11dae:	inc    QWORD PTR [rsi]
  c11db1:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c11db7:	movabs rax,0xffffffff00000000
  c11dc1:	mov    rdx,QWORD PTR [rsp+0x320]
  c11dc9:	and    rdx,rax
  c11dcc:	or     rdx,0x6
  c11dd0:	mov    rax,QWORD PTR [rsp+0x190]
  c11dd8:	mov    rcx,QWORD PTR [rsp+0x248]
  c11de0:	mov    QWORD PTR [rsp+0xe0],rdx
  c11de8:	mov    QWORD PTR [rsp+0xe8],rsi
  c11df0:	mov    QWORD PTR [rsp+0x248],rcx
  c11df8:	mov    QWORD PTR [rsp+0xf0],rcx
  c11e00:	cmp    edx,0xb
  c11e03:	mov    QWORD PTR [rsp+0x320],rdx
  c11e0b:	mov    QWORD PTR [rsp+0x470],rsi
  c11e13:	jne    c11f91 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2671>
  c11e19:	cmp    BYTE PTR [rsi+0x10],0xf
  c11e1d:	jne    c11f91 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2671>
  c11e23:	add    rsi,0x18
  c11e27:	mov    rax,QWORD PTR [rsp+0x378]
  c11e2f:	mov    rcx,QWORD PTR [rax]
  c11e32:	test   rcx,rcx
  c11e35:	cmovne rcx,rax
  c11e39:	mov    rdx,QWORD PTR [rsp+0x370]
  c11e41:	mov    rax,QWORD PTR [rdx]
  c11e44:	test   rax,rax
  c11e47:	cmovne rax,rdx
  c11e4b:	mov    rdx,QWORD PTR [rsp+0x398]
  c11e53:	movq   xmm0,QWORD PTR [rdx]
  c11e57:	mov    rdx,QWORD PTR [rsp+0x3a0]
  c11e5f:	movq   xmm1,QWORD PTR [rdx]
  c11e63:	punpcklqdq xmm1,xmm0
  c11e67:	mov    rdx,QWORD PTR [rsp+0x630]
  c11e6f:	mov    QWORD PTR [rsp+0x100],rdx
  c11e77:	mov    rdx,QWORD PTR [rip+0x23b902]        # e4d780 <_DYNAMIC+0x320>
  c11e7e:	mov    QWORD PTR [rsp+0x108],rdx
  c11e86:	mov    BYTE PTR [rsp+0x188],0x0
  c11e8e:	mov    rdx,QWORD PTR [rsp+0x640]
  c11e96:	movups xmm0,XMMWORD PTR [rdx]
  c11e99:	movups XMMWORD PTR [rsp+0x110],xmm0
  c11ea1:	movdqu xmm0,XMMWORD PTR [rdx+0x10]
  c11ea6:	movdqu XMMWORD PTR [rsp+0x120],xmm0
  c11eaf:	mov    rdx,QWORD PTR [rsp+0x388]
  c11eb7:	mov    QWORD PTR [rsp+0x130],rdx
  c11ebf:	mov    rdx,QWORD PTR [rsp+0x390]
  c11ec7:	mov    QWORD PTR [rsp+0x138],rdx
  c11ecf:	mov    rdx,QWORD PTR [rsp+0x380]
  c11ed7:	mov    QWORD PTR [rsp+0x140],rdx
  c11edf:	mov    QWORD PTR [rsp+0x148],rcx
  c11ee7:	mov    QWORD PTR [rsp+0x150],0x0
  c11ef3:	mov    QWORD PTR [rsp+0x160],0x0
  c11eff:	pxor   xmm0,xmm0
  c11f03:	pcmpeqd xmm0,xmm1
  c11f07:	pshufd xmm1,xmm0,0xb1
  c11f0c:	pand   xmm1,xmm0
  c11f10:	pandn  xmm1,XMMWORD PTR [rsp+0x520]
  c11f19:	movdqu XMMWORD PTR [rsp+0x170],xmm1
  c11f22:	mov    QWORD PTR [rsp+0x180],rax
  c11f2a:	lea    rdi,[rsp+0x70]
  c11f2f:	lea    r9,[rsp+0x100]
  c11f37:	mov    rdx,QWORD PTR [rsp+0x4b0]
  c11f3f:	mov    ecx,ebx
  c11f41:	mov    r8,QWORD PTR [rsp+0x1b0]
  c11f49:	call   c37aa0 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7linking18component_prop_get>
  c11f4e:	movzx  eax,BYTE PTR [rsp+0x70]
  c11f53:	cmp    al,0xff
  c11f55:	jne    c18d8f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x946f>
  c11f5b:	lea    rdx,[rsp+0x78]
  c11f60:	mov    rax,QWORD PTR [rdx+0x10]
  c11f64:	lea    rcx,[rsp+0x37]
  c11f69:	mov    QWORD PTR [rcx+0x10],rax
  c11f6d:	movups xmm0,XMMWORD PTR [rdx]
  c11f70:	movups XMMWORD PTR [rcx],xmm0
  c11f73:	movdqu xmm0,XMMWORD PTR [rcx]
  c11f77:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c11f80:	mov    rax,QWORD PTR [rcx+0x10]
  c11f84:	mov    QWORD PTR [rsp+0xd0],rax
  c11f8c:	jmp    c1209b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x277b>
  c11f91:	mov    rcx,QWORD PTR [rsp+0x4c8]
  c11f99:	cmp    QWORD PTR [rsp+0x3b8],rcx
  c11fa1:	jae    c185c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ca4>
  c11fa7:	cmp    r13,QWORD PTR [rax+0x10]
  c11fab:	jae    c185d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8cb2>
  c11fb1:	lea    rcx,[r13*2+0x0]
  c11fb9:	add    rcx,r13
  c11fbc:	shl    rcx,0x3
  c11fc0:	add    rcx,QWORD PTR [rax+0x8]
  c11fc4:	lea    rdi,[rsp+0x70]
  c11fc9:	lea    rsi,[rsp+0xe0]
  c11fd1:	mov    edx,ebx
  c11fd3:	call   QWORD PTR [rip+0x240c87]        # e52c60 <_DYNAMIC+0x5800>
  c11fd9:	movzx  eax,BYTE PTR [rsp+0x70]
  c11fde:	cmp    eax,0xff
  c11fe3:	je     c1207d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x275d>
  c11fe9:	cmp    eax,0x5
  c11fec:	jne    c18a2d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x910d>
  c11ff2:	cmp    QWORD PTR [rsp+0x4c0],rbx
  c11ffa:	jbe    c18a59 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9139>
  c12000:	lea    rax,[rbx+rbx*2]
  c12004:	mov    rcx,QWORD PTR [rsp+0x4b8]
  c1200c:	mov    rdx,QWORD PTR [rcx+rax*8+0x8]
  c12011:	mov    rcx,QWORD PTR [rcx+rax*8+0x10]
  c12016:	lea    rdi,[rsp+0x100]
  c1201e:	lea    rsi,[rsp+0xe0]
  c12026:	call   QWORD PTR [rip+0x240c3c]        # e52c68 <_DYNAMIC+0x5808>
  c1202c:	movzx  eax,BYTE PTR [rsp+0x100]
  c12034:	cmp    al,0xff
  c12036:	jne    c18a72 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9152>
  c1203c:	lea    rcx,[rsp+0x104]
  c12044:	mov    rax,QWORD PTR [rcx+0x14]
  c12048:	lea    rdx,[rsp+0x37]
  c1204d:	mov    QWORD PTR [rdx+0x10],rax
  c12051:	movups xmm0,XMMWORD PTR [rcx+0x4]
  c12055:	movups XMMWORD PTR [rdx],xmm0
  c12058:	movdqu xmm0,XMMWORD PTR [rdx]
  c1205c:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c12065:	mov    rax,QWORD PTR [rdx+0x10]
  c12069:	mov    QWORD PTR [rsp+0xd0],rax
  c12071:	lea    rdi,[rsp+0x70]
  c12076:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c1207b:	jmp    c1209b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x277b>
  c1207d:	lea    rcx,[rsp+0x78]
  c12082:	mov    rax,QWORD PTR [rcx+0x10]
  c12086:	mov    QWORD PTR [rsp+0xd0],rax
  c1208e:	movdqu xmm0,XMMWORD PTR [rcx]
  c12092:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c1209b:	mov    rax,QWORD PTR [rsp+0x8]
  c120a0:	add    rax,0x10
  c120a4:	mov    rsi,QWORD PTR [rax]
  c120a7:	mov    rdi,QWORD PTR [rsp]
  c120ab:	cmp    rdi,rsi
  c120ae:	mov    r8,QWORD PTR [rsp+0x20]
  c120b3:	mov    r9,QWORD PTR [rsp+0x18]
  c120b8:	jae    c19c0c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2ec>
  c120be:	mov    rdx,QWORD PTR [rbp+0x0]
  c120c2:	lea    rcx,[rdx+r9*1]
  c120c6:	mov    rax,r12
  c120c9:	sub    rax,QWORD PTR [rdx+r9*1+0x30]
  c120ce:	jae    c120de <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x27be>
  c120d0:	mov    rax,QWORD PTR [rcx+0x28]
  c120d4:	shl    r12d,0x4
  c120d8:	mov    rax,QWORD PTR [rax+r12*1]
  c120dc:	jmp    c120e2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x27c2>
  c120de:	add    rax,QWORD PTR [rcx+0x60]
  c120e2:	mov    r12,QWORD PTR [rsp+0x8]
  c120e7:	mov    rcx,QWORD PTR [r8+0x8]
  c120eb:	mov    rdx,QWORD PTR [rsp+0xd0]
  c120f3:	mov    QWORD PTR [rsp+0x110],rdx
  c120fb:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c12104:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c1210d:	cmp    rax,QWORD PTR [r8+0x10]
  c12111:	jae    c1852c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c0c>
  c12117:	lea    rax,[rax+rax*2]
  c1211b:	lea    r14,[rcx+rax*8]
  c1211f:	mov    eax,DWORD PTR [rcx+rax*8]
  c12122:	mov    edx,eax
  c12124:	sub    edx,0x2
  c12127:	mov    ecx,0x3
  c1212c:	cmovae ecx,edx
  c1212f:	cmp    ecx,0x8
  c12132:	ja     c15c0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62ea>
  c12138:	mov    edx,0x1e7
  c1213d:	bt     edx,ecx
  c12140:	jae    c121d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28b7>
  c12146:	mov    rax,QWORD PTR [rsp+0xd0]
  c1214e:	mov    QWORD PTR [r14+0x10],rax
  c12152:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c1215b:	movdqu XMMWORD PTR [r14],xmm0
  c12160:	lea    rax,[r12+0x10]
  c12165:	mov    rsi,QWORD PTR [rax]
  c12168:	cmp    QWORD PTR [rsp],rsi
  c1216c:	jae    c19cb5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa395>
  c12172:	mov    rax,QWORD PTR [rbp+0x0]
  c12176:	mov    r14,QWORD PTR [rsp+0x18]
  c1217b:	inc    QWORD PTR [rax+r14*1+0x58]
  c12180:	mov    eax,DWORD PTR [rsp+0xe0]
  c12187:	mov    edx,eax
  c12189:	sub    edx,0x2
  c1218c:	mov    ecx,0x3
  c12191:	cmovae ecx,edx
  c12194:	cmp    ecx,0x8
  c12197:	mov    rbx,QWORD PTR [rsp+0x10]
  c1219c:	ja     c15c39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6319>
  c121a2:	mov    edx,0x1e7
  c121a7:	bt     edx,ecx
  c121aa:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c121b0:	cmp    ecx,0x3
  c121b3:	jne    c15c26 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6306>
  c121b9:	test   eax,eax
  c121bb:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c121c1:	mov    rax,QWORD PTR [rsp+0xe8]
  c121c9:	dec    QWORD PTR [rax]
  c121cc:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c121d2:	jmp    c1510b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x57eb>
  c121d7:	cmp    ecx,0x3
  c121da:	jne    c15bee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62ce>
  c121e0:	test   eax,eax
  c121e2:	je     c12146 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2826>
  c121e8:	mov    rax,QWORD PTR [r14+0x8]
  c121ec:	dec    QWORD PTR [rax]
  c121ef:	jne    c12146 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2826>
  c121f5:	lea    rdi,[r14+0x8]
  c121f9:	call   QWORD PTR [rip+0x23b4a9]        # e4d6a8 <_DYNAMIC+0x248>
  c121ff:	jmp    c12146 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2826>
  c12204:	mov    rdi,QWORD PTR [rcx+0x8]
  c12208:	inc    QWORD PTR [rdi]
  c1220b:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12211:	movabs rcx,0xffffffff00000000
  c1221b:	mov    rsi,QWORD PTR [rsp+0x310]
  c12223:	and    rsi,rcx
  c12226:	or     rsi,0xb
  c1222a:	jmp    c122b8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2998>
  c1222f:	movabs rcx,0xffffffff00000000
  c12239:	mov    rsi,QWORD PTR [rsp+0x310]
  c12241:	and    rsi,rcx
  c12244:	or     rsi,0x2
  c12248:	mov    rdi,QWORD PTR [rsp+0x458]
  c12250:	jmp    c122b8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2998>
  c12252:	movabs rcx,0xffffffff00000000
  c1225c:	mov    rsi,QWORD PTR [rsp+0x310]
  c12264:	and    rsi,rcx
  c12267:	or     rsi,0x3
  c1226b:	mov    rdi,QWORD PTR [rsp+0x458]
  c12273:	jmp    c122b8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2998>
  c12275:	test   dl,0x1
  c12278:	je     c15e88 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6568>
  c1227e:	mov    rdi,QWORD PTR [rcx+0x8]
  c12282:	inc    QWORD PTR [rdi]
  c12285:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1228b:	mov    esi,0x1
  c12290:	jmp    c122c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x29a0>
  c12292:	mov    rdi,QWORD PTR [rcx+0x8]
  c12296:	inc    QWORD PTR [rdi]
  c12299:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1229f:	movabs rcx,0xffffffff00000000
  c122a9:	mov    rsi,QWORD PTR [rsp+0x310]
  c122b1:	and    rsi,rcx
  c122b4:	or     rsi,0x6
  c122b8:	mov    rcx,QWORD PTR [rsp+0x230]
  c122c0:	mov    QWORD PTR [rsp+0x310],rsi
  c122c8:	mov    QWORD PTR [rsp+0x358],rsi
  c122d0:	mov    QWORD PTR [rsp+0x458],rdi
  c122d8:	mov    QWORD PTR [rsp+0x360],rdi
  c122e0:	mov    QWORD PTR [rsp+0x230],rcx
  c122e8:	mov    QWORD PTR [rsp+0x368],rcx
  c122f0:	mov    rcx,QWORD PTR [rsp+0x8]
  c122f5:	add    rcx,0x10
  c122f9:	mov    rsi,QWORD PTR [rcx]
  c122fc:	cmp    QWORD PTR [rsp],rsi
  c12300:	jae    c19a31 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa111>
  c12306:	mov    rcx,QWORD PTR [rsp+0x20]
  c1230b:	mov    rsi,QWORD PTR [rcx+0x8]
  c1230f:	mov    rdx,QWORD PTR [rcx+0x10]
  c12313:	mov    rcx,QWORD PTR [r9]
  c12316:	add    rcx,r10
  c12319:	movzx  r8d,al
  c1231d:	movzx  r9d,bl
  c12321:	lea    rdi,[rsp+0x100]
  c12329:	call   c24480 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs4load>
  c1232e:	mov    eax,DWORD PTR [rsp+0x100]
  c12335:	cmp    eax,0xffffffff
  c12338:	je     c17b62 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8242>
  c1233e:	shr    ebx,0x8
  c12341:	lea    rsi,[rsp+0x104]
  c12349:	mov    ecx,DWORD PTR [rsi+0x30]
  c1234c:	mov    DWORD PTR [rsp+0x60],ecx
  c12350:	movups xmm0,XMMWORD PTR [rsi]
  c12353:	movups xmm1,XMMWORD PTR [rsi+0x10]
  c12357:	movups xmm2,XMMWORD PTR [rsi+0x20]
  c1235b:	movaps XMMWORD PTR [rsp+0x50],xmm2
  c12360:	movaps XMMWORD PTR [rsp+0x40],xmm1
  c12365:	movaps XMMWORD PTR [rsp+0x30],xmm0
  c1236a:	mov    rcx,QWORD PTR [rsi+0x44]
  c1236e:	lea    rdx,[rsp+0x74]
  c12373:	mov    QWORD PTR [rdx+0x44],rcx
  c12377:	movups xmm0,XMMWORD PTR [rsi+0x34]
  c1237b:	movups XMMWORD PTR [rdx+0x34],xmm0
  c1237f:	mov    ecx,DWORD PTR [rsp+0x60]
  c12383:	mov    DWORD PTR [rdx+0x30],ecx
  c12386:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c1238c:	movdqa xmm1,XMMWORD PTR [rsp+0x40]
  c12392:	movaps xmm2,XMMWORD PTR [rsp+0x50]
  c12397:	movups XMMWORD PTR [rdx+0x20],xmm2
  c1239b:	movdqu XMMWORD PTR [rdx+0x10],xmm1
  c123a0:	movdqu XMMWORD PTR [rdx],xmm0
  c123a4:	mov    DWORD PTR [rsp+0x70],eax
  c123a8:	cmp    DWORD PTR [rsp+0x358],0xb
  c123b0:	jne    c12565 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2c45>
  c123b6:	mov    rbp,QWORD PTR [rsp+0x360]
  c123be:	cmp    BYTE PTR [rbp+0x10],0xf
  c123c2:	jne    c12565 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2c45>
  c123c8:	mov    r14d,r15d
  c123cb:	mov    rax,QWORD PTR [rsp+0x378]
  c123d3:	mov    rcx,QWORD PTR [rax]
  c123d6:	test   rcx,rcx
  c123d9:	cmovne rcx,rax
  c123dd:	mov    rdx,QWORD PTR [rsp+0x370]
  c123e5:	mov    rax,QWORD PTR [rdx]
  c123e8:	test   rax,rax
  c123eb:	cmovne rax,rdx
  c123ef:	mov    rdx,QWORD PTR [rsp+0x398]
  c123f7:	movq   xmm0,QWORD PTR [rdx]
  c123fb:	mov    rdx,QWORD PTR [rsp+0x3a0]
  c12403:	movq   xmm1,QWORD PTR [rdx]
  c12407:	punpcklqdq xmm1,xmm0
  c1240b:	mov    rdx,QWORD PTR [rsp+0x630]
  c12413:	mov    QWORD PTR [rsp+0x100],rdx
  c1241b:	mov    rdx,QWORD PTR [rip+0x23b35e]        # e4d780 <_DYNAMIC+0x320>
  c12422:	mov    QWORD PTR [rsp+0x108],rdx
  c1242a:	mov    BYTE PTR [rsp+0x188],0x0
  c12432:	mov    rdx,QWORD PTR [rsp+0x640]
  c1243a:	movups xmm0,XMMWORD PTR [rdx]
  c1243d:	movups XMMWORD PTR [rsp+0x110],xmm0
  c12445:	movdqu xmm0,XMMWORD PTR [rdx+0x10]
  c1244a:	movdqu XMMWORD PTR [rsp+0x120],xmm0
  c12453:	mov    rdx,QWORD PTR [rsp+0x388]
  c1245b:	mov    QWORD PTR [rsp+0x130],rdx
  c12463:	mov    rdx,QWORD PTR [rsp+0x390]
  c1246b:	mov    QWORD PTR [rsp+0x138],rdx
  c12473:	mov    rdx,QWORD PTR [rsp+0x380]
  c1247b:	mov    QWORD PTR [rsp+0x140],rdx
  c12483:	mov    QWORD PTR [rsp+0x148],rcx
  c1248b:	mov    rcx,QWORD PTR [rsp+0x650]
  c12493:	mov    QWORD PTR [rsp+0x150],rcx
  c1249b:	lea    rcx,[rip+0x223dee]        # e36290 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x9f0>
  c124a2:	mov    QWORD PTR [rsp+0x158],rcx
  c124aa:	mov    QWORD PTR [rsp+0x160],0x0
  c124b6:	pxor   xmm0,xmm0
  c124ba:	pcmpeqd xmm0,xmm1
  c124be:	pshufd xmm1,xmm0,0xb1
  c124c3:	pand   xmm1,xmm0
  c124c7:	pandn  xmm1,XMMWORD PTR [rsp+0x520]
  c124d0:	movdqu XMMWORD PTR [rsp+0x170],xmm1
  c124d9:	mov    QWORD PTR [rsp+0x180],rax
  c124e1:	movzx  edi,bl
  c124e4:	call   QWORD PTR [rip+0x240786]        # e52c70 <_DYNAMIC+0x5810>
  c124ea:	mov    rbx,rax
  c124ed:	mov    r15,rdx
  c124f0:	lea    rdi,[rsp+0x70]
  c124f5:	call   c24d20 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs8as_slice>
  c124fa:	mov    r9,rdx
  c124fd:	add    rbp,0x18
  c12501:	sub    rsp,0x8
  c12505:	lea    rdi,[rsp+0x38]
  c1250a:	mov    rsi,rbp
  c1250d:	mov    rdx,rbx
  c12510:	mov    rcx,r15
  c12513:	mov    r8,rax
  c12516:	lea    rax,[rsp+0x108]
  c1251e:	push   rax
  c1251f:	call   QWORD PTR [rip+0x240753]        # e52c78 <_DYNAMIC+0x5818>
  c12525:	add    rsp,0x10
  c12529:	movzx  eax,BYTE PTR [rsp+0x30]
  c1252e:	cmp    al,0xff
  c12530:	mov    r15,QWORD PTR [rsp+0x18]
  c12535:	mov    rcx,QWORD PTR [rsp+0x8]
  c1253a:	lea    rbp,[rcx+0x8]
  c1253e:	jne    c18e52 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9532>
  c12544:	mov    rbx,rbp
  c12547:	lea    rcx,[rsp+0x37]
  c1254c:	mov    rax,QWORD PTR [rcx+0x11]
  c12550:	lea    rdx,[rsp+0xc7]
  c12558:	mov    QWORD PTR [rdx+0x10],rax
  c1255c:	movups xmm0,XMMWORD PTR [rcx+0x1]
  c12560:	jmp    c1264f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d2f>
  c12565:	sub    eax,0xc
  c12568:	mov    r8d,0x2
  c1256e:	cmovae r8d,eax
  c12572:	lea    rax,[rip+0xffffffffff6b329b]        # 2c5814 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe53>
  c12579:	movsxd rcx,DWORD PTR [rax+r8*4]
  c1257d:	add    rcx,rax
  c12580:	jmp    rcx
  c12582:	mov    r14d,r15d
  c12585:	mov    ecx,0x8
  c1258a:	jmp    c125cb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2cab>
  c1258c:	mov    r8,QWORD PTR [rsp+0xb8]
  c12594:	cmp    r8,0x4
  c12598:	jae    c19721 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e01>
  c1259e:	mov    r14d,r15d
  c125a1:	lea    rcx,[rsp+0x70]
  c125a6:	jmp    c125cb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2cab>
  c125a8:	mov    r14d,r15d
  c125ab:	mov    rcx,QWORD PTR [rsp+0x80]
  c125b3:	mov    r8,QWORD PTR [rsp+0x88]
  c125bb:	jmp    c125cb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2cab>
  c125bd:	mov    r14d,r15d
  c125c0:	mov    r8d,0x1
  c125c6:	lea    rcx,[rsp+0x78]
  c125cb:	mov    rdx,QWORD PTR [rsp+0x638]
  c125d3:	mov    rax,QWORD PTR [rdx+0x58]
  c125d7:	mov    r10,QWORD PTR [rdx+0x60]
  c125db:	mov    rdx,QWORD PTR [r10+0x10]
  c125df:	dec    rdx
  c125e2:	and    rdx,0xfffffffffffffff0
  c125e6:	add    rax,rdx
  c125e9:	add    rax,0x10
  c125ed:	movzx  esi,bl
  c125f0:	lea    rdi,[rsp+0x100]
  c125f8:	lea    rdx,[rsp+0x358]
  c12600:	mov    r9,QWORD PTR [rsp+0x630]
  c12608:	push   r10
  c1260a:	push   rax
  c1260b:	call   QWORD PTR [rip+0x24066f]        # e52c80 <_DYNAMIC+0x5820>
  c12611:	add    rsp,0x10
  c12615:	movzx  eax,BYTE PTR [rsp+0x100]
  c1261d:	cmp    al,0xff
  c1261f:	mov    r15,QWORD PTR [rsp+0x18]
  c12624:	mov    rcx,QWORD PTR [rsp+0x8]
  c12629:	lea    rbp,[rcx+0x8]
  c1262d:	jne    c1860c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8cec>
  c12633:	mov    rbx,rbp
  c12636:	lea    rcx,[rsp+0x104]
  c1263e:	mov    rax,QWORD PTR [rcx+0x14]
  c12642:	lea    rdx,[rsp+0x37]
  c12647:	mov    QWORD PTR [rdx+0x10],rax
  c1264b:	movups xmm0,XMMWORD PTR [rcx+0x4]
  c1264f:	movups XMMWORD PTR [rdx],xmm0
  c12652:	movdqu xmm0,XMMWORD PTR [rdx]
  c12656:	movdqa XMMWORD PTR [rsp+0xe0],xmm0
  c1265f:	mov    rax,QWORD PTR [rdx+0x10]
  c12663:	mov    QWORD PTR [rsp+0xf0],rax
  c1266b:	mov    rax,QWORD PTR [rsp+0x8]
  c12670:	add    rax,0x10
  c12674:	mov    rsi,QWORD PTR [rax]
  c12677:	mov    rdi,QWORD PTR [rsp]
  c1267b:	cmp    rdi,rsi
  c1267e:	mov    r8,QWORD PTR [rsp+0x20]
  c12683:	jae    c19b5e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa23e>
  c12689:	mov    ebp,r14d
  c1268c:	mov    rdx,QWORD PTR [rbx]
  c1268f:	lea    rcx,[rdx+r15*1]
  c12693:	mov    rax,r12
  c12696:	sub    rax,QWORD PTR [rdx+r15*1+0x30]
  c1269b:	jae    c126ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d8b>
  c1269d:	mov    rax,QWORD PTR [rcx+0x28]
  c126a1:	shl    r12d,0x4
  c126a5:	mov    rax,QWORD PTR [rax+r12*1]
  c126a9:	jmp    c126af <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d8f>
  c126ab:	add    rax,QWORD PTR [rcx+0x60]
  c126af:	mov    r12,QWORD PTR [rsp+0x8]
  c126b4:	mov    rcx,QWORD PTR [r8+0x8]
  c126b8:	mov    rdx,QWORD PTR [rsp+0xf0]
  c126c0:	mov    QWORD PTR [rsp+0x110],rdx
  c126c8:	movdqa xmm0,XMMWORD PTR [rsp+0xe0]
  c126d1:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c126da:	cmp    rax,QWORD PTR [r8+0x10]
  c126de:	jae    c184bf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b9f>
  c126e4:	lea    rax,[rax+rax*2]
  c126e8:	lea    r14,[rcx+rax*8]
  c126ec:	mov    eax,DWORD PTR [rcx+rax*8]
  c126ef:	mov    edx,eax
  c126f1:	sub    edx,0x2
  c126f4:	mov    ecx,0x3
  c126f9:	cmovae ecx,edx
  c126fc:	cmp    ecx,0x8
  c126ff:	ja     c15b01 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x61e1>
  c12705:	mov    edx,0x1e7
  c1270a:	bt     edx,ecx
  c1270d:	jae    c127d0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2eb0>
  c12713:	mov    rax,QWORD PTR [rsp+0xf0]
  c1271b:	mov    QWORD PTR [r14+0x10],rax
  c1271f:	movdqa xmm0,XMMWORD PTR [rsp+0xe0]
  c12728:	movdqu XMMWORD PTR [r14],xmm0
  c1272d:	lea    rax,[r12+0x10]
  c12732:	mov    rsi,QWORD PTR [rax]
  c12735:	cmp    QWORD PTR [rsp],rsi
  c12739:	jae    c19c8e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa36e>
  c1273f:	mov    rax,QWORD PTR [rbx]
  c12742:	mov    r14,r15
  c12745:	inc    QWORD PTR [rax+r15*1+0x58]
  c1274a:	lea    rdi,[rsp+0x70]
  c1274f:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c12754:	mov    rsi,QWORD PTR [rsp+0x10]
  c12759:	mov    r15d,ebp
  c1275c:	mov    eax,DWORD PTR [rsp+0x358]
  c12763:	mov    edx,eax
  c12765:	sub    edx,0x2
  c12768:	mov    ecx,0x3
  c1276d:	cmovae ecx,edx
  c12770:	cmp    ecx,0x8
  c12773:	ja     c15b3b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x621b>
  c12779:	mov    edx,0x1e7
  c1277e:	bt     edx,ecx
  c12781:	mov    r12,QWORD PTR [rsp+0x8]
  c12786:	mov    rbp,rbx
  c12789:	mov    rbx,rsi
  c1278c:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c12792:	cmp    ecx,0x3
  c12795:	jne    c15b1d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x61fd>
  c1279b:	test   eax,eax
  c1279d:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c127a3:	mov    rax,QWORD PTR [rsp+0x360]
  c127ab:	dec    QWORD PTR [rax]
  c127ae:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c127b4:	lea    rdi,[rsp+0x360]
  c127bc:	call   QWORD PTR [rip+0x23aee6]        # e4d6a8 <_DYNAMIC+0x248>
  c127c2:	test   r15b,r15b
  c127c5:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c127cb:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c127d0:	cmp    ecx,0x3
  c127d3:	jne    c15ae5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x61c5>
  c127d9:	test   eax,eax
  c127db:	je     c12713 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2df3>
  c127e1:	mov    rax,QWORD PTR [r14+0x8]
  c127e5:	dec    QWORD PTR [rax]
  c127e8:	jne    c12713 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2df3>
  c127ee:	lea    rdi,[r14+0x8]
  c127f2:	call   QWORD PTR [rip+0x23aeb0]        # e4d6a8 <_DYNAMIC+0x248>
  c127f8:	jmp    c12713 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2df3>
  c127fd:	mov    rcx,QWORD PTR [rdx+0x8]
  c12801:	inc    QWORD PTR [rcx]
  c12804:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1280a:	movq   xmm0,rcx
  c1280f:	mov    ecx,0xb
  c12814:	jmp    c10cd7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b7>
  c12819:	mov    ecx,0x2
  c1281e:	jmp    c10cd7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b7>
  c12823:	mov    ecx,0x3
  c12828:	jmp    c10cd7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b7>
  c1282d:	mov    rcx,QWORD PTR [rdx+0x8]
  c12831:	inc    QWORD PTR [rcx]
  c12834:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1283a:	movq   xmm0,rcx
  c1283f:	mov    ecx,0xb
  c12844:	jmp    c10d5b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x143b>
  c12849:	mov    ecx,0x2
  c1284e:	jmp    c10d5b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x143b>
  c12853:	mov    ecx,0x3
  c12858:	jmp    c10d5b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x143b>
  c1285d:	mov    rcx,QWORD PTR [rdx+0x8]
  c12861:	inc    QWORD PTR [rcx]
  c12864:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1286a:	movq   xmm0,rcx
  c1286f:	mov    ecx,0xb
  c12874:	jmp    c10ddf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14bf>
  c12879:	mov    ecx,0x2
  c1287e:	jmp    c10ddf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14bf>
  c12883:	mov    ecx,0x3
  c12888:	jmp    c10ddf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14bf>
  c1288d:	mov    rsi,QWORD PTR [rcx+0x8]
  c12891:	inc    QWORD PTR [rsi]
  c12894:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1289a:	movabs rcx,0xffffffff00000000
  c128a4:	mov    r8,QWORD PTR [rsp+0x2f8]
  c128ac:	and    r8,rcx
  c128af:	or     r8,0xb
  c128b3:	jmp    c12a79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3159>
  c128b8:	test   sil,0x1
  c128bc:	je     c15ea2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6582>
  c128c2:	mov    rdi,QWORD PTR [rdx+0x8]
  c128c6:	inc    QWORD PTR [rdi]
  c128c9:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c128cf:	mov    ecx,0x1
  c128d4:	jmp    c15eb4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6594>
  c128d9:	movabs rcx,0xffffffff00000000
  c128e3:	mov    r8,QWORD PTR [rsp+0x2f8]
  c128eb:	and    r8,rcx
  c128ee:	or     r8,0x2
  c128f2:	mov    rsi,QWORD PTR [rsp+0x478]
  c128fa:	jmp    c12a79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3159>
  c128ff:	movabs rcx,0xffffffff00000000
  c12909:	mov    r8,QWORD PTR [rsp+0x2f8]
  c12911:	and    r8,rcx
  c12914:	or     r8,0x3
  c12918:	mov    rsi,QWORD PTR [rsp+0x478]
  c12920:	jmp    c12a79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3159>
  c12925:	test   sil,0x1
  c12929:	je     c15ec7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x65a7>
  c1292f:	mov    rdi,QWORD PTR [rdx+0x8]
  c12933:	inc    QWORD PTR [rdi]
  c12936:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1293c:	mov    ecx,0x1
  c12941:	jmp    c15ed9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x65b9>
  c12946:	test   sil,0x1
  c1294a:	je     c15eec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x65cc>
  c12950:	mov    rdi,QWORD PTR [rdx+0x8]
  c12954:	inc    QWORD PTR [rdi]
  c12957:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1295d:	mov    ecx,0x1
  c12962:	jmp    c15efe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x65de>
  c12967:	test   dl,0x1
  c1296a:	je     c15f11 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x65f1>
  c12970:	mov    rsi,QWORD PTR [rcx+0x8]
  c12974:	inc    QWORD PTR [rsi]
  c12977:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1297d:	mov    r8d,0x1
  c12983:	jmp    c12a81 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3161>
  c12988:	mov    rcx,QWORD PTR [rdx+0x8]
  c1298c:	inc    QWORD PTR [rcx]
  c1298f:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12995:	movq   xmm0,rcx
  c1299a:	mov    ecx,0x6
  c1299f:	jmp    c10cd7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b7>
  c129a4:	mov    rax,QWORD PTR [r14+0x8]
  c129a8:	dec    QWORD PTR [rax]
  c129ab:	jne    c10ec8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a8>
  c129b1:	lea    rdi,[r14+0x8]
  c129b5:	call   QWORD PTR [rip+0x23acf5]        # e4d6b0 <_DYNAMIC+0x250>
  c129bb:	jmp    c10ec8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a8>
  c129c0:	mov    rcx,QWORD PTR [rdx+0x8]
  c129c4:	inc    QWORD PTR [rcx]
  c129c7:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c129cd:	movq   xmm0,rcx
  c129d2:	mov    ecx,0x6
  c129d7:	jmp    c10d5b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x143b>
  c129dc:	mov    rcx,QWORD PTR [rdx+0x8]
  c129e0:	inc    QWORD PTR [rcx]
  c129e3:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c129e9:	movq   xmm0,rcx
  c129ee:	mov    ecx,0xb
  c129f3:	jmp    c10fd2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16b2>
  c129f8:	mov    rcx,QWORD PTR [rdx+0x8]
  c129fc:	inc    QWORD PTR [rcx]
  c129ff:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12a05:	movq   xmm0,rcx
  c12a0a:	mov    ecx,0x6
  c12a0f:	jmp    c10ddf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14bf>
  c12a14:	mov    rdx,QWORD PTR [rax+0x8]
  c12a18:	inc    QWORD PTR [rdx]
  c12a1b:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12a21:	movabs rax,0xffffffff00000000
  c12a2b:	mov    rdi,QWORD PTR [rsp+0x2f0]
  c12a33:	and    rdi,rax
  c12a36:	or     rdi,0xb
  c12a3a:	jmp    c12d02 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33e2>
  c12a3f:	mov    ecx,0x2
  c12a44:	jmp    c10fd2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16b2>
  c12a49:	mov    ecx,0x3
  c12a4e:	jmp    c10fd2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16b2>
  c12a53:	mov    rsi,QWORD PTR [rcx+0x8]
  c12a57:	inc    QWORD PTR [rsi]
  c12a5a:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12a60:	movabs rcx,0xffffffff00000000
  c12a6a:	mov    r8,QWORD PTR [rsp+0x2f8]
  c12a72:	and    r8,rcx
  c12a75:	or     r8,0x6
  c12a79:	mov    rcx,QWORD PTR [rsp+0x250]
  c12a81:	mov    QWORD PTR [rsp+0x30],r8
  c12a86:	mov    QWORD PTR [rsp+0x478],rsi
  c12a8e:	mov    QWORD PTR [rsp+0x38],rsi
  c12a93:	mov    QWORD PTR [rsp+0x250],rcx
  c12a9b:	mov    QWORD PTR [rsp+0x40],rcx
  c12aa0:	lea    rcx,[r12+0x10]
  c12aa5:	mov    rsi,QWORD PTR [rcx]
  c12aa8:	cmp    QWORD PTR [rsp],rsi
  c12aac:	jae    c19a1b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0fb>
  c12ab2:	lea    rcx,[r12+0x8]
  c12ab7:	mov    rdi,QWORD PTR [rcx]
  c12aba:	lea    rsi,[rdi+r14*1]
  c12abe:	movzx  edx,bpl
  c12ac2:	mov    rcx,rdx
  c12ac5:	sub    rcx,QWORD PTR [rdi+r14*1+0x30]
  c12aca:	jae    c12ad9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31b9>
  c12acc:	mov    rcx,QWORD PTR [rsi+0x28]
  c12ad0:	shl    edx,0x4
  c12ad3:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c12ad7:	jmp    c12add <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31bd>
  c12ad9:	add    rcx,QWORD PTR [rsi+0x60]
  c12add:	mov    rdx,QWORD PTR [rsp+0x20]
  c12ae2:	cmp    rcx,QWORD PTR [rdx+0x10]
  c12ae6:	lea    rbp,[r12+0x8]
  c12aeb:	jae    c17b3b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x821b>
  c12af1:	mov    QWORD PTR [rsp+0x2f8],r8
  c12af9:	mov    rsi,QWORD PTR [rdx+0x8]
  c12afd:	lea    rcx,[rcx+rcx*2]
  c12b01:	mov    edx,DWORD PTR [rsi+rcx*8]
  c12b04:	lea    edi,[rdx-0x2]
  c12b07:	cmp    rdx,0x2
  c12b0b:	mov    r8d,0x3
  c12b11:	cmovae r8d,edi
  c12b15:	lea    rcx,[rsi+rcx*8]
  c12b19:	lea    rsi,[rip+0xffffffffff6b2df4]        # 2c5914 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf53>
  c12b20:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c12b24:	add    rdi,rsi
  c12b27:	jmp    rdi
  c12b29:	mov    r8,QWORD PTR [rcx]
  c12b2c:	mov    rdi,QWORD PTR [rcx+0x8]
  c12b30:	mov    rsi,QWORD PTR [rcx+0x10]
  c12b34:	jmp    c146a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4d81>
  c12b39:	movabs rax,0xffffffff00000000
  c12b43:	mov    rdi,QWORD PTR [rsp+0x2f0]
  c12b4b:	and    rdi,rax
  c12b4e:	or     rdi,0x2
  c12b52:	mov    rdx,QWORD PTR [rsp+0x468]
  c12b5a:	jmp    c12d02 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33e2>
  c12b5f:	movabs rax,0xffffffff00000000
  c12b69:	mov    rdi,QWORD PTR [rsp+0x2f0]
  c12b71:	and    rdi,rax
  c12b74:	or     rdi,0x3
  c12b78:	mov    rdx,QWORD PTR [rsp+0x468]
  c12b80:	jmp    c12d02 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33e2>
  c12b85:	mov    rdx,QWORD PTR [rax+0x8]
  c12b89:	inc    QWORD PTR [rdx]
  c12b8c:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12b92:	movabs rax,0xffffffff00000000
  c12b9c:	mov    rsi,QWORD PTR [rsp+0x308]
  c12ba4:	and    rsi,rax
  c12ba7:	or     rsi,0xb
  c12bab:	jmp    c12e36 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3516>
  c12bb0:	movabs rax,0xffffffff00000000
  c12bba:	mov    rsi,QWORD PTR [rsp+0x308]
  c12bc2:	and    rsi,rax
  c12bc5:	or     rsi,0x2
  c12bc9:	mov    rdx,QWORD PTR [rsp+0x4a0]
  c12bd1:	jmp    c12e36 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3516>
  c12bd6:	movabs rax,0xffffffff00000000
  c12be0:	mov    rsi,QWORD PTR [rsp+0x308]
  c12be8:	and    rsi,rax
  c12beb:	or     rsi,0x3
  c12bef:	mov    rdx,QWORD PTR [rsp+0x4a0]
  c12bf7:	jmp    c12e36 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3516>
  c12bfc:	mov    rax,QWORD PTR [r14+0x8]
  c12c00:	dec    QWORD PTR [rax]
  c12c03:	jne    c10f4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162f>
  c12c09:	lea    rdi,[r14+0x8]
  c12c0d:	call   QWORD PTR [rip+0x23aa9d]        # e4d6b0 <_DYNAMIC+0x250>
  c12c13:	jmp    c10f4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162f>
  c12c18:	test   sil,0x1
  c12c1c:	je     c15f2c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x660c>
  c12c22:	mov    rdi,QWORD PTR [rdx+0x8]
  c12c26:	inc    QWORD PTR [rdi]
  c12c29:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12c2f:	mov    ecx,0x1
  c12c34:	jmp    c15f3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x661e>
  c12c39:	mov    rax,QWORD PTR [r14+0x8]
  c12c3d:	dec    QWORD PTR [rax]
  c12c40:	jne    c1104f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x172f>
  c12c46:	lea    rdi,[r14+0x8]
  c12c4a:	call   QWORD PTR [rip+0x23aa60]        # e4d6b0 <_DYNAMIC+0x250>
  c12c50:	jmp    c1104f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x172f>
  c12c55:	test   cl,0x1
  c12c58:	je     c15f51 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6631>
  c12c5e:	mov    rdx,QWORD PTR [rax+0x8]
  c12c62:	inc    QWORD PTR [rdx]
  c12c65:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12c6b:	mov    edi,0x1
  c12c70:	jmp    c12d0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33ea>
  c12c75:	test   cl,0x1
  c12c78:	je     c15f6b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x664b>
  c12c7e:	mov    rdx,QWORD PTR [rax+0x8]
  c12c82:	inc    QWORD PTR [rdx]
  c12c85:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12c8b:	mov    esi,0x1
  c12c90:	jmp    c12e3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x351e>
  c12c95:	mov    rcx,QWORD PTR [rdx+0x8]
  c12c99:	inc    QWORD PTR [rcx]
  c12c9c:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12ca2:	movq   xmm0,rcx
  c12ca7:	mov    ecx,0x6
  c12cac:	jmp    c10fd2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16b2>
  c12cb1:	mov    r14,QWORD PTR [rcx+0x8]
  c12cb5:	inc    QWORD PTR [r14]
  c12cb8:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12cbe:	movabs rcx,0xffffffff00000000
  c12cc8:	mov    rbx,QWORD PTR [rsp+0x2e0]
  c12cd0:	and    rbx,rcx
  c12cd3:	or     rbx,0xb
  c12cd7:	jmp    c12fe1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36c1>
  c12cdc:	mov    rdx,QWORD PTR [rax+0x8]
  c12ce0:	inc    QWORD PTR [rdx]
  c12ce3:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12ce9:	movabs rax,0xffffffff00000000
  c12cf3:	mov    rdi,QWORD PTR [rsp+0x2f0]
  c12cfb:	and    rdi,rax
  c12cfe:	or     rdi,0x6
  c12d02:	mov    rax,QWORD PTR [rsp+0x240]
  c12d0a:	mov    QWORD PTR [rsp+0xe0],rdi
  c12d12:	mov    QWORD PTR [rsp+0x468],rdx
  c12d1a:	mov    QWORD PTR [rsp+0xe8],rdx
  c12d22:	mov    QWORD PTR [rsp+0x240],rax
  c12d2a:	mov    QWORD PTR [rsp+0xf0],rax
  c12d32:	lea    rax,[r12+0x10]
  c12d37:	mov    rsi,QWORD PTR [rax]
  c12d3a:	cmp    QWORD PTR [rsp],rsi
  c12d3e:	jae    c19a90 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa170>
  c12d44:	lea    rax,[r12+0x8]
  c12d49:	mov    rsi,QWORD PTR [rax]
  c12d4c:	lea    rdx,[rsi+r14*1]
  c12d50:	movzx  ecx,bpl
  c12d54:	mov    rax,rcx
  c12d57:	sub    rax,QWORD PTR [rsi+r14*1+0x30]
  c12d5c:	jae    c12d6b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x344b>
  c12d5e:	mov    rax,QWORD PTR [rdx+0x28]
  c12d62:	shl    ecx,0x4
  c12d65:	mov    rax,QWORD PTR [rax+rcx*1]
  c12d69:	jmp    c12d6f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x344f>
  c12d6b:	add    rax,QWORD PTR [rdx+0x60]
  c12d6f:	mov    rcx,QWORD PTR [rsp+0x20]
  c12d74:	cmp    rax,QWORD PTR [rcx+0x10]
  c12d78:	jae    c17b0f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x81ef>
  c12d7e:	mov    QWORD PTR [rsp+0x2f0],rdi
  c12d86:	mov    rdx,QWORD PTR [rcx+0x8]
  c12d8a:	lea    rax,[rax+rax*2]
  c12d8e:	mov    ecx,DWORD PTR [rdx+rax*8]
  c12d91:	lea    esi,[rcx-0x2]
  c12d94:	cmp    rcx,0x2
  c12d98:	mov    edi,0x3
  c12d9d:	cmovae edi,esi
  c12da0:	lea    rax,[rdx+rax*8]
  c12da4:	lea    rdx,[rip+0xffffffffff6b2ac9]        # 2c5874 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xeb3>
  c12dab:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c12daf:	add    rsi,rdx
  c12db2:	jmp    rsi
  c12db4:	mov    rdi,QWORD PTR [rax]
  c12db7:	mov    rcx,QWORD PTR [rax+0x8]
  c12dbb:	mov    rax,QWORD PTR [rax+0x10]
  c12dbf:	jmp    c14831 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f11>
  c12dc4:	movabs rcx,0xffffffff00000000
  c12dce:	mov    rbx,QWORD PTR [rsp+0x2e0]
  c12dd6:	and    rbx,rcx
  c12dd9:	or     rbx,0x2
  c12ddd:	mov    r14,QWORD PTR [rsp+0x440]
  c12de5:	jmp    c12fe1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36c1>
  c12dea:	movabs rcx,0xffffffff00000000
  c12df4:	mov    rbx,QWORD PTR [rsp+0x2e0]
  c12dfc:	and    rbx,rcx
  c12dff:	or     rbx,0x3
  c12e03:	mov    r14,QWORD PTR [rsp+0x440]
  c12e0b:	jmp    c12fe1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36c1>
  c12e10:	mov    rdx,QWORD PTR [rax+0x8]
  c12e14:	inc    QWORD PTR [rdx]
  c12e17:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12e1d:	movabs rax,0xffffffff00000000
  c12e27:	mov    rsi,QWORD PTR [rsp+0x308]
  c12e2f:	and    rsi,rax
  c12e32:	or     rsi,0x6
  c12e36:	mov    rax,QWORD PTR [rsp+0x228]
  c12e3e:	mov    QWORD PTR [rsp+0x308],rsi
  c12e46:	mov    QWORD PTR [rsp+0x70],rsi
  c12e4b:	mov    QWORD PTR [rsp+0x4a0],rdx
  c12e53:	mov    QWORD PTR [rsp+0x78],rdx
  c12e58:	mov    QWORD PTR [rsp+0x228],rax
  c12e60:	mov    QWORD PTR [rsp+0x80],rax
  c12e68:	mov    rsi,QWORD PTR [r9]
  c12e6b:	cmp    rdi,rsi
  c12e6e:	jae    c199c9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0a9>
  c12e74:	mov    rdx,QWORD PTR [rbp+0x0]
  c12e78:	lea    rcx,[rdx+r11*1]
  c12e7c:	mov    rax,r12
  c12e7f:	sub    rax,QWORD PTR [rdx+r11*1+0x30]
  c12e84:	jae    c12e94 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3574>
  c12e86:	mov    rax,QWORD PTR [rcx+0x28]
  c12e8a:	shl    r12d,0x4
  c12e8e:	mov    rax,QWORD PTR [rax+r12*1]
  c12e92:	jmp    c12e98 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3578>
  c12e94:	add    rax,QWORD PTR [rcx+0x60]
  c12e98:	mov    r12,QWORD PTR [rsp+0x8]
  c12e9d:	mov    rcx,QWORD PTR [r8+0x8]
  c12ea1:	mov    rdx,QWORD PTR [rsp+0x80]
  c12ea9:	mov    QWORD PTR [rsp+0x110],rdx
  c12eb1:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c12eb7:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c12ec0:	cmp    rax,QWORD PTR [r8+0x10]
  c12ec4:	jae    c17a9c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x817c>
  c12eca:	lea    rax,[rax+rax*2]
  c12ece:	lea    r14,[rcx+rax*8]
  c12ed2:	mov    eax,DWORD PTR [rcx+rax*8]
  c12ed5:	mov    edx,eax
  c12ed7:	sub    edx,0x2
  c12eda:	mov    ecx,0x3
  c12edf:	cmovae ecx,edx
  c12ee2:	cmp    ecx,0x8
  c12ee5:	ja     c15495 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b75>
  c12eeb:	mov    edx,0x1e7
  c12ef0:	bt     edx,ecx
  c12ef3:	jae    c12f23 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3603>
  c12ef5:	mov    rax,QWORD PTR [rsp+0x80]
  c12efd:	mov    QWORD PTR [r14+0x10],rax
  c12f01:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c12f07:	movdqu XMMWORD PTR [r14],xmm0
  c12f0c:	lea    rax,[r12+0x10]
  c12f11:	mov    rsi,QWORD PTR [rax]
  c12f14:	cmp    QWORD PTR [rsp],rsi
  c12f18:	jb     c16140 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6820>
  c12f1e:	jmp    c19ad4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1b4>
  c12f23:	cmp    ecx,0x3
  c12f26:	jne    c147bc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4e9c>
  c12f2c:	test   eax,eax
  c12f2e:	je     c12ef5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x35d5>
  c12f30:	mov    rax,QWORD PTR [r14+0x8]
  c12f34:	dec    QWORD PTR [rax]
  c12f37:	jne    c12ef5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x35d5>
  c12f39:	lea    rdi,[r14+0x8]
  c12f3d:	call   QWORD PTR [rip+0x23a765]        # e4d6a8 <_DYNAMIC+0x248>
  c12f43:	jmp    c12ef5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x35d5>
  c12f45:	test   dl,0x1
  c12f48:	je     c15f85 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6665>
  c12f4e:	mov    r14,QWORD PTR [rcx+0x8]
  c12f52:	inc    QWORD PTR [r14]
  c12f55:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12f5b:	mov    ebx,0x1
  c12f60:	jmp    c12fe9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36c9>
  c12f65:	mov    rsi,QWORD PTR [rax+0x8]
  c12f69:	inc    QWORD PTR [rsi]
  c12f6c:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12f72:	movabs rax,0xffffffff00000000
  c12f7c:	mov    rdx,QWORD PTR [rsp+0x328]
  c12f84:	and    rdx,rax
  c12f87:	or     rdx,0xb
  c12f8b:	jmp    c13214 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38f4>
  c12f90:	mov    rdi,QWORD PTR [rcx+0x8]
  c12f94:	inc    QWORD PTR [rdi]
  c12f97:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12f9d:	movabs rcx,0xffffffff00000000
  c12fa7:	mov    r8,QWORD PTR [rsp+0x300]
  c12faf:	and    r8,rcx
  c12fb2:	or     r8,0xb
  c12fb6:	jmp    c1330d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39ed>
  c12fbb:	mov    r14,QWORD PTR [rcx+0x8]
  c12fbf:	inc    QWORD PTR [r14]
  c12fc2:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c12fc8:	movabs rcx,0xffffffff00000000
  c12fd2:	mov    rbx,QWORD PTR [rsp+0x2e0]
  c12fda:	and    rbx,rcx
  c12fdd:	or     rbx,0x6
  c12fe1:	mov    rsi,QWORD PTR [rsp+0x270]
  c12fe9:	mov    QWORD PTR [rsp+0x30],rbx
  c12fee:	mov    QWORD PTR [rsp+0x38],r14
  c12ff3:	mov    QWORD PTR [rsp+0x270],rsi
  c12ffb:	mov    QWORD PTR [rsp+0x40],rsi
  c13000:	mov    rsi,QWORD PTR [r11]
  c13003:	cmp    rdi,rsi
  c13006:	jae    c19983 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa063>
  c1300c:	mov    rsi,QWORD PTR [rbp+0x0]
  c13010:	mov    r8,QWORD PTR [rsp+0x18]
  c13015:	lea    rdx,[rsi+r8*1]
  c13019:	movzx  ecx,ax
  c1301c:	mov    rax,rcx
  c1301f:	sub    rax,QWORD PTR [rsi+r8*1+0x30]
  c13024:	jae    c13033 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3713>
  c13026:	mov    rax,QWORD PTR [rdx+0x28]
  c1302a:	shl    ecx,0x4
  c1302d:	mov    rax,QWORD PTR [rax+rcx*1]
  c13031:	jmp    c13037 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3717>
  c13033:	add    rax,QWORD PTR [rdx+0x60]
  c13037:	cmp    rax,QWORD PTR [r10+0x10]
  c1303b:	jae    c17a74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8154>
  c13041:	mov    rdx,QWORD PTR [r10+0x8]
  c13045:	lea    rax,[rax+rax*2]
  c13049:	mov    ecx,DWORD PTR [rdx+rax*8]
  c1304c:	lea    esi,[rcx-0x2]
  c1304f:	cmp    rcx,0x2
  c13053:	mov    r8d,0x3
  c13059:	cmovae r8d,esi
  c1305d:	lea    rax,[rdx+rax*8]
  c13061:	lea    rdx,[rip+0xffffffffff6b2ba4]        # 2c5c0c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x124b>
  c13068:	movsxd rsi,DWORD PTR [rdx+r8*4]
  c1306c:	add    rsi,rdx
  c1306f:	jmp    rsi
  c13071:	mov    rdx,QWORD PTR [rax]
  c13074:	mov    r8,QWORD PTR [rax+0x8]
  c13078:	mov    r9,QWORD PTR [rax+0x10]
  c1307c:	jmp    c14c7f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x535f>
  c13081:	movabs rax,0xffffffff00000000
  c1308b:	mov    rdx,QWORD PTR [rsp+0x328]
  c13093:	and    rdx,rax
  c13096:	or     rdx,0x2
  c1309a:	mov    rsi,QWORD PTR [rsp+0x480]
  c130a2:	jmp    c13214 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38f4>
  c130a7:	movabs rax,0xffffffff00000000
  c130b1:	mov    rdx,QWORD PTR [rsp+0x328]
  c130b9:	and    rdx,rax
  c130bc:	or     rdx,0x3
  c130c0:	mov    rsi,QWORD PTR [rsp+0x480]
  c130c8:	jmp    c13214 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38f4>
  c130cd:	movabs rcx,0xffffffff00000000
  c130d7:	mov    r8,QWORD PTR [rsp+0x300]
  c130df:	and    r8,rcx
  c130e2:	or     r8,0x2
  c130e6:	mov    rdi,QWORD PTR [rsp+0x450]
  c130ee:	jmp    c1330d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39ed>
  c130f3:	movabs rcx,0xffffffff00000000
  c130fd:	mov    r8,QWORD PTR [rsp+0x300]
  c13105:	and    r8,rcx
  c13108:	or     r8,0x3
  c1310c:	mov    rdi,QWORD PTR [rsp+0x450]
  c13114:	jmp    c1330d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39ed>
  c13119:	mov    rsi,QWORD PTR [rax+0x8]
  c1311d:	inc    QWORD PTR [rsi]
  c13120:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13126:	movabs rax,0xffffffff00000000
  c13130:	mov    rdx,QWORD PTR [rsp+0x318]
  c13138:	and    rdx,rax
  c1313b:	or     rdx,0xb
  c1313f:	jmp    c1346b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b4b>
  c13144:	movabs rax,0xffffffff00000000
  c1314e:	mov    rdx,QWORD PTR [rsp+0x318]
  c13156:	and    rdx,rax
  c13159:	or     rdx,0x2
  c1315d:	mov    rsi,QWORD PTR [rsp+0x460]
  c13165:	jmp    c1346b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b4b>
  c1316a:	movabs rax,0xffffffff00000000
  c13174:	mov    rdx,QWORD PTR [rsp+0x318]
  c1317c:	and    rdx,rax
  c1317f:	or     rdx,0x3
  c13183:	mov    rsi,QWORD PTR [rsp+0x460]
  c1318b:	jmp    c1346b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b4b>
  c13190:	test   cl,0x1
  c13193:	je     c15f9c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x667c>
  c13199:	mov    rsi,QWORD PTR [rax+0x8]
  c1319d:	inc    QWORD PTR [rsi]
  c131a0:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c131a6:	mov    edx,0x1
  c131ab:	jmp    c1321c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38fc>
  c131ad:	test   dl,0x1
  c131b0:	je     c15fb6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6696>
  c131b6:	mov    rdi,QWORD PTR [rcx+0x8]
  c131ba:	inc    QWORD PTR [rdi]
  c131bd:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c131c3:	mov    r8d,0x1
  c131c9:	jmp    c13315 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39f5>
  c131ce:	test   cl,0x1
  c131d1:	je     c15fce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66ae>
  c131d7:	mov    rsi,QWORD PTR [rax+0x8]
  c131db:	inc    QWORD PTR [rsi]
  c131de:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c131e4:	mov    edx,0x1
  c131e9:	jmp    c13473 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b53>
  c131ee:	mov    rsi,QWORD PTR [rax+0x8]
  c131f2:	inc    QWORD PTR [rsi]
  c131f5:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c131fb:	movabs rax,0xffffffff00000000
  c13205:	mov    rdx,QWORD PTR [rsp+0x328]
  c1320d:	and    rdx,rax
  c13210:	or     rdx,0x6
  c13214:	mov    rax,QWORD PTR [rsp+0x260]
  c1321c:	mov    r15,r8
  c1321f:	mov    QWORD PTR [rsp+0x328],rdx
  c13227:	mov    QWORD PTR [rsp+0x70],rdx
  c1322c:	mov    QWORD PTR [rsp+0x480],rsi
  c13234:	mov    QWORD PTR [rsp+0x78],rsi
  c13239:	mov    QWORD PTR [rsp+0x260],rax
  c13241:	mov    QWORD PTR [rsp+0x80],rax
  c13249:	lea    rdi,[rsp+0x100]
  c13251:	lea    rsi,[rsp+0x70]
  c13256:	call   QWORD PTR [rip+0x23ea9c]        # e51cf8 <_DYNAMIC+0x4898>
  c1325c:	movzx  eax,BYTE PTR [rsp+0x100]
  c13264:	movzx  ebx,BYTE PTR [rsp+0x101]
  c1326c:	cmp    al,0xff
  c1326e:	jne    c174af <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b8f>
  c13274:	mov    eax,DWORD PTR [rsp+0x70]
  c13278:	mov    edx,eax
  c1327a:	sub    edx,0x2
  c1327d:	mov    ecx,0x3
  c13282:	cmovae ecx,edx
  c13285:	cmp    ecx,0x8
  c13288:	ja     c154b1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b91>
  c1328e:	mov    edx,0x1e7
  c13293:	bt     edx,ecx
  c13296:	jae    c132c3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39a3>
  c13298:	lea    rax,[r12+0x10]
  c1329d:	mov    rsi,QWORD PTR [rax]
  c132a0:	test   bl,0x1
  c132a3:	je     c132b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3994>
  c132a5:	cmp    QWORD PTR [rsp],rsi
  c132a9:	jb     c13e05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44e5>
  c132af:	jmp    c19d1c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3fc>
  c132b4:	cmp    QWORD PTR [rsp],rsi
  c132b8:	jb     c13dd7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44b7>
  c132be:	jmp    c19d2d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa40d>
  c132c3:	cmp    ecx,0x3
  c132c6:	jne    c14eda <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x55ba>
  c132cc:	test   eax,eax
  c132ce:	je     c13298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3978>
  c132d0:	mov    rax,QWORD PTR [rsp+0x78]
  c132d5:	dec    QWORD PTR [rax]
  c132d8:	jne    c13298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3978>
  c132da:	lea    rdi,[rsp+0x78]
  c132df:	call   QWORD PTR [rip+0x23a3c3]        # e4d6a8 <_DYNAMIC+0x248>
  c132e5:	jmp    c13298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3978>
  c132e7:	mov    rdi,QWORD PTR [rcx+0x8]
  c132eb:	inc    QWORD PTR [rdi]
  c132ee:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c132f4:	movabs rcx,0xffffffff00000000
  c132fe:	mov    r8,QWORD PTR [rsp+0x300]
  c13306:	and    r8,rcx
  c13309:	or     r8,0x6
  c1330d:	mov    rsi,QWORD PTR [rsp+0x258]
  c13315:	mov    QWORD PTR [rsp+0xe0],r8
  c1331d:	mov    QWORD PTR [rsp+0xe8],rdi
  c13325:	mov    QWORD PTR [rsp+0x258],rsi
  c1332d:	mov    QWORD PTR [rsp+0xf0],rsi
  c13335:	mov    rcx,QWORD PTR [rsp+0x8]
  c1333a:	add    rcx,0x10
  c1333e:	mov    rsi,QWORD PTR [rcx]
  c13341:	cmp    QWORD PTR [rsp],rsi
  c13345:	jae    c19a47 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa127>
  c1334b:	mov    rsi,QWORD PTR [rbp+0x0]
  c1334f:	mov    r9,QWORD PTR [rsp+0x18]
  c13354:	lea    rdx,[rsi+r9*1]
  c13358:	movzx  ecx,ax
  c1335b:	mov    rax,rcx
  c1335e:	sub    rax,QWORD PTR [rsi+r9*1+0x30]
  c13363:	jae    c13372 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3a52>
  c13365:	mov    rax,QWORD PTR [rdx+0x28]
  c13369:	shl    ecx,0x4
  c1336c:	mov    rax,QWORD PTR [rax+rcx*1]
  c13370:	jmp    c13376 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3a56>
  c13372:	add    rax,QWORD PTR [rdx+0x60]
  c13376:	cmp    rax,QWORD PTR [r14+0x10]
  c1337a:	jae    c17a4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x812d>
  c13380:	mov    QWORD PTR [rsp+0x450],rdi
  c13388:	mov    rdx,QWORD PTR [r14+0x8]
  c1338c:	lea    rax,[rax+rax*2]
  c13390:	mov    ecx,DWORD PTR [rdx+rax*8]
  c13393:	lea    esi,[rcx-0x2]
  c13396:	cmp    rcx,0x2
  c1339a:	mov    edi,0x3
  c1339f:	cmovae edi,esi
  c133a2:	lea    rax,[rdx+rax*8]
  c133a6:	lea    rdx,[rip+0xffffffffff6b25df]        # 2c598c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xfcb>
  c133ad:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c133b1:	add    rsi,rdx
  c133b4:	mov    QWORD PTR [rsp+0x300],r8
  c133bc:	jmp    rsi
  c133be:	mov    rdx,QWORD PTR [rax]
  c133c1:	mov    rsi,QWORD PTR [rax+0x8]
  c133c5:	mov    rdi,QWORD PTR [rax+0x10]
  c133c9:	jmp    c14f26 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5606>
  c133ce:	mov    rsi,QWORD PTR [rax+0x8]
  c133d2:	inc    QWORD PTR [rsi]
  c133d5:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c133db:	movabs rax,0xffffffff00000000
  c133e5:	mov    rdx,QWORD PTR [rsp+0x338]
  c133ed:	and    rdx,rax
  c133f0:	or     rdx,0xb
  c133f4:	jmp    c13796 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e76>
  c133f9:	movabs rax,0xffffffff00000000
  c13403:	mov    rdx,QWORD PTR [rsp+0x338]
  c1340b:	and    rdx,rax
  c1340e:	or     rdx,0x2
  c13412:	mov    rsi,QWORD PTR [rsp+0x490]
  c1341a:	jmp    c13796 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e76>
  c1341f:	movabs rax,0xffffffff00000000
  c13429:	mov    rdx,QWORD PTR [rsp+0x338]
  c13431:	and    rdx,rax
  c13434:	or     rdx,0x3
  c13438:	mov    rsi,QWORD PTR [rsp+0x490]
  c13440:	jmp    c13796 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e76>
  c13445:	mov    rsi,QWORD PTR [rax+0x8]
  c13449:	inc    QWORD PTR [rsi]
  c1344c:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13452:	movabs rax,0xffffffff00000000
  c1345c:	mov    rdx,QWORD PTR [rsp+0x318]
  c13464:	and    rdx,rax
  c13467:	or     rdx,0x6
  c1346b:	mov    rax,QWORD PTR [rsp+0x238]
  c13473:	mov    QWORD PTR [rsp+0x318],rdx
  c1347b:	mov    QWORD PTR [rsp+0x70],rdx
  c13480:	mov    QWORD PTR [rsp+0x460],rsi
  c13488:	mov    QWORD PTR [rsp+0x78],rsi
  c1348d:	mov    QWORD PTR [rsp+0x238],rax
  c13495:	mov    QWORD PTR [rsp+0x80],rax
  c1349d:	lea    rdi,[rsp+0x100]
  c134a5:	lea    rsi,[rsp+0x70]
  c134aa:	call   QWORD PTR [rip+0x23e748]        # e51bf8 <_DYNAMIC+0x4798>
  c134b0:	movzx  ecx,BYTE PTR [rsp+0x100]
  c134b8:	cmp    cl,0xff
  c134bb:	jne    c17aa1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8181>
  c134c1:	mov    rax,QWORD PTR [rsp+0x8]
  c134c6:	add    rax,0x10
  c134ca:	mov    rsi,QWORD PTR [rax]
  c134cd:	cmp    QWORD PTR [rsp],rsi
  c134d1:	jae    c19b3c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa21c>
  c134d7:	mov    rdx,QWORD PTR [rbp+0x0]
  c134db:	mov    rsi,QWORD PTR [rsp+0x18]
  c134e0:	lea    rcx,[rdx+rsi*1]
  c134e4:	mov    rax,r12
  c134e7:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c134ec:	jae    c134fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3bdc>
  c134ee:	mov    rax,QWORD PTR [rcx+0x28]
  c134f2:	shl    r12d,0x4
  c134f6:	mov    rax,QWORD PTR [rax+r12*1]
  c134fa:	jmp    c13500 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3be0>
  c134fc:	add    rax,QWORD PTR [rcx+0x60]
  c13500:	mov    r12,QWORD PTR [rsp+0x8]
  c13505:	mov    rdx,QWORD PTR [rsp+0x108]
  c1350d:	mov    rcx,QWORD PTR [r14+0x8]
  c13511:	mov    QWORD PTR [rsp+0x100],0x0
  c1351d:	mov    QWORD PTR [rsp+0x108],rdx
  c13525:	sar    rdx,0x3f
  c13529:	mov    QWORD PTR [rsp+0x110],rdx
  c13531:	cmp    rax,QWORD PTR [r14+0x10]
  c13535:	jae    c17f41 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8621>
  c1353b:	lea    rax,[rax+rax*2]
  c1353f:	lea    r14,[rcx+rax*8]
  c13543:	mov    eax,DWORD PTR [rcx+rax*8]
  c13546:	mov    edx,eax
  c13548:	sub    edx,0x2
  c1354b:	mov    ecx,0x3
  c13550:	cmovae ecx,edx
  c13553:	cmp    ecx,0x8
  c13556:	ja     c155d8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5cb8>
  c1355c:	mov    edx,0x1e7
  c13561:	bt     edx,ecx
  c13564:	jae    c135f5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3cd5>
  c1356a:	mov    rax,QWORD PTR [rsp+0x110]
  c13572:	mov    QWORD PTR [r14+0x10],rax
  c13576:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c1357f:	movdqu XMMWORD PTR [r14],xmm0
  c13584:	lea    rax,[r12+0x10]
  c13589:	mov    rsi,QWORD PTR [rax]
  c1358c:	cmp    QWORD PTR [rsp],rsi
  c13590:	jae    c19be0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2c0>
  c13596:	mov    rax,QWORD PTR [rbp+0x0]
  c1359a:	mov    r14,QWORD PTR [rsp+0x18]
  c1359f:	inc    QWORD PTR [rax+r14*1+0x58]
  c135a4:	mov    eax,DWORD PTR [rsp+0x70]
  c135a8:	mov    edx,eax
  c135aa:	sub    edx,0x2
  c135ad:	mov    ecx,0x3
  c135b2:	cmovae ecx,edx
  c135b5:	cmp    ecx,0x8
  c135b8:	mov    rbx,QWORD PTR [rsp+0x10]
  c135bd:	ja     c156a9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d89>
  c135c3:	mov    edx,0x1e7
  c135c8:	bt     edx,ecx
  c135cb:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c135d1:	cmp    ecx,0x3
  c135d4:	jne    c15691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d71>
  c135da:	test   eax,eax
  c135dc:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c135e2:	mov    rax,QWORD PTR [rsp+0x78]
  c135e7:	dec    QWORD PTR [rax]
  c135ea:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c135f0:	jmp    c143f9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ad9>
  c135f5:	cmp    ecx,0x3
  c135f8:	jne    c1559e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c7e>
  c135fe:	test   eax,eax
  c13600:	je     c1356a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c4a>
  c13606:	mov    rax,QWORD PTR [r14+0x8]
  c1360a:	dec    QWORD PTR [rax]
  c1360d:	jne    c1356a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c4a>
  c13613:	lea    rdi,[r14+0x8]
  c13617:	call   QWORD PTR [rip+0x23a08b]        # e4d6a8 <_DYNAMIC+0x248>
  c1361d:	jmp    c1356a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c4a>
  c13622:	test   cl,0x1
  c13625:	je     c15fe8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c8>
  c1362b:	mov    rsi,QWORD PTR [rax+0x8]
  c1362f:	inc    QWORD PTR [rsi]
  c13632:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13638:	mov    edx,0x1
  c1363d:	jmp    c1379e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e7e>
  c13642:	mov    rsi,QWORD PTR [rax+0x8]
  c13646:	inc    QWORD PTR [rsi]
  c13649:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1364f:	movabs rax,0xffffffff00000000
  c13659:	mov    rdx,QWORD PTR [rsp+0x340]
  c13661:	and    rdx,rax
  c13664:	or     rdx,0xb
  c13668:	jmp    c13a28 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4108>
  c1366d:	mov    r14,QWORD PTR [rcx+0x8]
  c13671:	inc    QWORD PTR [r14]
  c13674:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1367a:	movabs rcx,0xffffffff00000000
  c13684:	mov    rbx,QWORD PTR [rsp+0x2e8]
  c1368c:	and    rbx,rcx
  c1368f:	or     rbx,0xb
  c13693:	jmp    c13c21 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4301>
  c13698:	movabs rax,0xffffffff00000000
  c136a2:	mov    rdx,QWORD PTR [rsp+0x340]
  c136aa:	and    rdx,rax
  c136ad:	or     rdx,0x2
  c136b1:	mov    rsi,QWORD PTR [rsp+0x498]
  c136b9:	jmp    c13a28 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4108>
  c136be:	movabs rax,0xffffffff00000000
  c136c8:	mov    rdx,QWORD PTR [rsp+0x340]
  c136d0:	and    rdx,rax
  c136d3:	or     rdx,0x3
  c136d7:	mov    rsi,QWORD PTR [rsp+0x498]
  c136df:	jmp    c13a28 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4108>
  c136e4:	movabs rcx,0xffffffff00000000
  c136ee:	mov    rbx,QWORD PTR [rsp+0x2e8]
  c136f6:	and    rbx,rcx
  c136f9:	or     rbx,0x2
  c136fd:	mov    r14,QWORD PTR [rsp+0x448]
  c13705:	jmp    c13c21 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4301>
  c1370a:	movabs rcx,0xffffffff00000000
  c13714:	mov    rbx,QWORD PTR [rsp+0x2e8]
  c1371c:	and    rbx,rcx
  c1371f:	or     rbx,0x3
  c13723:	mov    r14,QWORD PTR [rsp+0x448]
  c1372b:	jmp    c13c21 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4301>
  c13730:	test   cl,0x1
  c13733:	je     c16002 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66e2>
  c13739:	mov    rsi,QWORD PTR [rax+0x8]
  c1373d:	inc    QWORD PTR [rsi]
  c13740:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13746:	mov    edx,0x1
  c1374b:	jmp    c13a30 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4110>
  c13750:	test   dl,0x1
  c13753:	je     c1601c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66fc>
  c13759:	mov    r14,QWORD PTR [rcx+0x8]
  c1375d:	inc    QWORD PTR [r14]
  c13760:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13766:	mov    ebx,0x1
  c1376b:	jmp    c13c29 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4309>
  c13770:	mov    rsi,QWORD PTR [rax+0x8]
  c13774:	inc    QWORD PTR [rsi]
  c13777:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1377d:	movabs rax,0xffffffff00000000
  c13787:	mov    rdx,QWORD PTR [rsp+0x338]
  c1378f:	and    rdx,rax
  c13792:	or     rdx,0x6
  c13796:	mov    rax,QWORD PTR [rsp+0x280]
  c1379e:	mov    QWORD PTR [rsp+0x338],rdx
  c137a6:	mov    QWORD PTR [rsp+0x30],rdx
  c137ab:	mov    QWORD PTR [rsp+0x490],rsi
  c137b3:	mov    QWORD PTR [rsp+0x38],rsi
  c137b8:	mov    QWORD PTR [rsp+0x280],rax
  c137c0:	mov    QWORD PTR [rsp+0x40],rax
  c137c5:	lea    rdi,[rsp+0x100]
  c137cd:	lea    rsi,[rsp+0x30]
  c137d2:	call   QWORD PTR [rip+0x23f4b0]        # e52c88 <_DYNAMIC+0x5828>
  c137d8:	movzx  eax,BYTE PTR [rsp+0x100]
  c137e0:	cmp    al,0xff
  c137e2:	jne    c174e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7bc6>
  c137e8:	lea    rdx,[rsp+0x108]
  c137f0:	mov    rax,QWORD PTR [rdx+0x10]
  c137f4:	lea    rcx,[rsp+0x74]
  c137f9:	mov    QWORD PTR [rcx+0x13],rax
  c137fd:	movups xmm0,XMMWORD PTR [rdx]
  c13800:	movups XMMWORD PTR [rcx+0x3],xmm0
  c13804:	movdqu xmm0,XMMWORD PTR [rcx+0x3]
  c13809:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c13812:	mov    rax,QWORD PTR [rcx+0x13]
  c13816:	mov    QWORD PTR [rsp+0xd0],rax
  c1381e:	mov    eax,DWORD PTR [rsp+0x30]
  c13822:	mov    edx,eax
  c13824:	sub    edx,0x2
  c13827:	mov    ecx,0x3
  c1382c:	cmovae ecx,edx
  c1382f:	cmp    ecx,0x8
  c13832:	ja     c154cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5baf>
  c13838:	mov    edx,0x1e7
  c1383d:	bt     edx,ecx
  c13840:	jae    c13916 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ff6>
  c13846:	mov    rax,QWORD PTR [rsp+0x8]
  c1384b:	add    rax,0x10
  c1384f:	mov    rsi,QWORD PTR [rax]
  c13852:	cmp    QWORD PTR [rsp],rsi
  c13856:	jae    c19b15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1f5>
  c1385c:	mov    rdx,QWORD PTR [rbp+0x0]
  c13860:	mov    rsi,QWORD PTR [rsp+0x18]
  c13865:	lea    rcx,[rdx+rsi*1]
  c13869:	mov    rax,r12
  c1386c:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c13871:	jae    c13881 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f61>
  c13873:	mov    rax,QWORD PTR [rcx+0x28]
  c13877:	shl    r12d,0x4
  c1387b:	mov    rax,QWORD PTR [rax+r12*1]
  c1387f:	jmp    c13885 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f65>
  c13881:	add    rax,QWORD PTR [rcx+0x60]
  c13885:	mov    r12,QWORD PTR [rsp+0x8]
  c1388a:	mov    rcx,QWORD PTR [r14+0x8]
  c1388e:	mov    rdx,QWORD PTR [rsp+0xd0]
  c13896:	mov    QWORD PTR [rsp+0x110],rdx
  c1389e:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c138a7:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c138b0:	cmp    rax,QWORD PTR [r14+0x10]
  c138b4:	jae    c17f19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85f9>
  c138ba:	lea    rax,[rax+rax*2]
  c138be:	lea    r14,[rcx+rax*8]
  c138c2:	mov    eax,DWORD PTR [rcx+rax*8]
  c138c5:	mov    edx,eax
  c138c7:	sub    edx,0x2
  c138ca:	mov    ecx,0x3
  c138cf:	cmovae ecx,edx
  c138d2:	cmp    ecx,0x8
  c138d5:	ja     c15659 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d39>
  c138db:	mov    edx,0x1e7
  c138e0:	bt     edx,ecx
  c138e3:	jae    c13945 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4025>
  c138e5:	mov    rax,QWORD PTR [rsp+0xd0]
  c138ed:	mov    QWORD PTR [r14+0x10],rax
  c138f1:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c138fa:	movdqu XMMWORD PTR [r14],xmm0
  c138ff:	lea    rax,[r12+0x10]
  c13904:	mov    rsi,QWORD PTR [rax]
  c13907:	cmp    QWORD PTR [rsp],rsi
  c1390b:	jb     c16140 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6820>
  c13911:	jmp    c19bcf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2af>
  c13916:	cmp    ecx,0x3
  c13919:	jne    c15189 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5869>
  c1391f:	test   eax,eax
  c13921:	je     c13846 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f26>
  c13927:	mov    rax,QWORD PTR [rsp+0x38]
  c1392c:	dec    QWORD PTR [rax]
  c1392f:	jne    c13846 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f26>
  c13935:	lea    rdi,[rsp+0x38]
  c1393a:	call   QWORD PTR [rip+0x239d68]        # e4d6a8 <_DYNAMIC+0x248>
  c13940:	jmp    c13846 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f26>
  c13945:	cmp    ecx,0x3
  c13948:	jne    c15621 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d01>
  c1394e:	test   eax,eax
  c13950:	je     c138e5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3fc5>
  c13952:	mov    rax,QWORD PTR [r14+0x8]
  c13956:	dec    QWORD PTR [rax]
  c13959:	jne    c138e5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3fc5>
  c1395b:	lea    rdi,[r14+0x8]
  c1395f:	call   QWORD PTR [rip+0x239d43]        # e4d6a8 <_DYNAMIC+0x248>
  c13965:	jmp    c138e5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3fc5>
  c1396a:	mov    rax,QWORD PTR [r14+0x8]
  c1396e:	dec    QWORD PTR [rax]
  c13971:	lea    rbp,[r12+0x8]
  c13976:	jne    c10ec8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a8>
  c1397c:	lea    rdi,[r14+0x8]
  c13980:	call   QWORD PTR [rip+0x239d32]        # e4d6b8 <_DYNAMIC+0x258>
  c13986:	jmp    c10ec8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a8>
  c1398b:	mov    rsi,QWORD PTR [rax+0x8]
  c1398f:	inc    QWORD PTR [rsi]
  c13992:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13998:	movabs rax,0xffffffff00000000
  c139a2:	mov    rdx,QWORD PTR [rsp+0x330]
  c139aa:	and    rdx,rax
  c139ad:	or     rdx,0xb
  c139b1:	jmp    c13d3c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x441c>
  c139b6:	movabs rax,0xffffffff00000000
  c139c0:	mov    rdx,QWORD PTR [rsp+0x330]
  c139c8:	and    rdx,rax
  c139cb:	or     rdx,0x2
  c139cf:	mov    rsi,QWORD PTR [rsp+0x488]
  c139d7:	jmp    c13d3c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x441c>
  c139dc:	movabs rax,0xffffffff00000000
  c139e6:	mov    rdx,QWORD PTR [rsp+0x330]
  c139ee:	and    rdx,rax
  c139f1:	or     rdx,0x3
  c139f5:	mov    rsi,QWORD PTR [rsp+0x488]
  c139fd:	jmp    c13d3c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x441c>
  c13a02:	mov    rsi,QWORD PTR [rax+0x8]
  c13a06:	inc    QWORD PTR [rsi]
  c13a09:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13a0f:	movabs rax,0xffffffff00000000
  c13a19:	mov    rdx,QWORD PTR [rsp+0x340]
  c13a21:	and    rdx,rax
  c13a24:	or     rdx,0x6
  c13a28:	mov    rax,QWORD PTR [rsp+0x288]
  c13a30:	mov    QWORD PTR [rsp+0x340],rdx
  c13a38:	mov    QWORD PTR [rsp+0x30],rdx
  c13a3d:	mov    QWORD PTR [rsp+0x498],rsi
  c13a45:	mov    QWORD PTR [rsp+0x38],rsi
  c13a4a:	mov    QWORD PTR [rsp+0x288],rax
  c13a52:	mov    QWORD PTR [rsp+0x40],rax
  c13a57:	lea    rdi,[rsp+0x100]
  c13a5f:	lea    rsi,[rsp+0x30]
  c13a64:	call   c1a9c0 <_RNvCsbxgXiyEKxkX_6bsl_vm6neg_op>
  c13a69:	movzx  eax,BYTE PTR [rsp+0x100]
  c13a71:	cmp    al,0xff
  c13a73:	jne    c174e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7bc6>
  c13a79:	lea    rdx,[rsp+0x108]
  c13a81:	mov    rax,QWORD PTR [rdx+0x10]
  c13a85:	lea    rcx,[rsp+0x74]
  c13a8a:	mov    QWORD PTR [rcx+0x13],rax
  c13a8e:	movups xmm0,XMMWORD PTR [rdx]
  c13a91:	movups XMMWORD PTR [rcx+0x3],xmm0
  c13a95:	movdqu xmm0,XMMWORD PTR [rcx+0x3]
  c13a9a:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c13aa3:	mov    rax,QWORD PTR [rcx+0x13]
  c13aa7:	mov    QWORD PTR [rsp+0xd0],rax
  c13aaf:	mov    eax,DWORD PTR [rsp+0x30]
  c13ab3:	mov    edx,eax
  c13ab5:	sub    edx,0x2
  c13ab8:	mov    ecx,0x3
  c13abd:	cmovae ecx,edx
  c13ac0:	cmp    ecx,0x8
  c13ac3:	ja     c154ed <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5bcd>
  c13ac9:	mov    edx,0x1e7
  c13ace:	bt     edx,ecx
  c13ad1:	jae    c13ba7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4287>
  c13ad7:	mov    rax,QWORD PTR [rsp+0x8]
  c13adc:	add    rax,0x10
  c13ae0:	mov    rsi,QWORD PTR [rax]
  c13ae3:	cmp    QWORD PTR [rsp],rsi
  c13ae7:	jae    c19ab2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa192>
  c13aed:	mov    rdx,QWORD PTR [rbp+0x0]
  c13af1:	mov    rsi,QWORD PTR [rsp+0x18]
  c13af6:	lea    rcx,[rdx+rsi*1]
  c13afa:	mov    rax,r12
  c13afd:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c13b02:	jae    c13b12 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41f2>
  c13b04:	mov    rax,QWORD PTR [rcx+0x28]
  c13b08:	shl    r12d,0x4
  c13b0c:	mov    rax,QWORD PTR [rax+r12*1]
  c13b10:	jmp    c13b16 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41f6>
  c13b12:	add    rax,QWORD PTR [rcx+0x60]
  c13b16:	mov    r12,QWORD PTR [rsp+0x8]
  c13b1b:	mov    rcx,QWORD PTR [r14+0x8]
  c13b1f:	mov    rdx,QWORD PTR [rsp+0xd0]
  c13b27:	mov    QWORD PTR [rsp+0x110],rdx
  c13b2f:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c13b38:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c13b41:	cmp    rax,QWORD PTR [r14+0x10]
  c13b45:	jae    c17f17 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85f7>
  c13b4b:	lea    rax,[rax+rax*2]
  c13b4f:	lea    r14,[rcx+rax*8]
  c13b53:	mov    eax,DWORD PTR [rcx+rax*8]
  c13b56:	mov    edx,eax
  c13b58:	sub    edx,0x2
  c13b5b:	mov    ecx,0x3
  c13b60:	cmovae ecx,edx
  c13b63:	cmp    ecx,0x8
  c13b66:	ja     c15675 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d55>
  c13b6c:	mov    edx,0x1e7
  c13b71:	bt     edx,ecx
  c13b74:	jae    c13bd6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x42b6>
  c13b76:	mov    rax,QWORD PTR [rsp+0xd0]
  c13b7e:	mov    QWORD PTR [r14+0x10],rax
  c13b82:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c13b8b:	movdqu XMMWORD PTR [r14],xmm0
  c13b90:	lea    rax,[r12+0x10]
  c13b95:	mov    rsi,QWORD PTR [rax]
  c13b98:	cmp    QWORD PTR [rsp],rsi
  c13b9c:	jb     c16140 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6820>
  c13ba2:	jmp    c19b92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa272>
  c13ba7:	cmp    ecx,0x3
  c13baa:	jne    c1521b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58fb>
  c13bb0:	test   eax,eax
  c13bb2:	je     c13ad7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41b7>
  c13bb8:	mov    rax,QWORD PTR [rsp+0x38]
  c13bbd:	dec    QWORD PTR [rax]
  c13bc0:	jne    c13ad7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41b7>
  c13bc6:	lea    rdi,[rsp+0x38]
  c13bcb:	call   QWORD PTR [rip+0x239ad7]        # e4d6a8 <_DYNAMIC+0x248>
  c13bd1:	jmp    c13ad7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41b7>
  c13bd6:	cmp    ecx,0x3
  c13bd9:	jne    c1563d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d1d>
  c13bdf:	test   eax,eax
  c13be1:	je     c13b76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4256>
  c13be3:	mov    rax,QWORD PTR [r14+0x8]
  c13be7:	dec    QWORD PTR [rax]
  c13bea:	jne    c13b76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4256>
  c13bec:	lea    rdi,[r14+0x8]
  c13bf0:	call   QWORD PTR [rip+0x239ab2]        # e4d6a8 <_DYNAMIC+0x248>
  c13bf6:	jmp    c13b76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4256>
  c13bfb:	mov    r14,QWORD PTR [rcx+0x8]
  c13bff:	inc    QWORD PTR [r14]
  c13c02:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13c08:	movabs rcx,0xffffffff00000000
  c13c12:	mov    rbx,QWORD PTR [rsp+0x2e8]
  c13c1a:	and    rbx,rcx
  c13c1d:	or     rbx,0x6
  c13c21:	mov    rsi,QWORD PTR [rsp+0x278]
  c13c29:	mov    QWORD PTR [rsp+0x30],rbx
  c13c2e:	mov    QWORD PTR [rsp+0x38],r14
  c13c33:	mov    QWORD PTR [rsp+0x278],rsi
  c13c3b:	mov    QWORD PTR [rsp+0x40],rsi
  c13c40:	mov    rsi,QWORD PTR [r11]
  c13c43:	cmp    rdi,rsi
  c13c46:	jae    c19960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa040>
  c13c4c:	mov    rsi,QWORD PTR [rbp+0x0]
  c13c50:	mov    r8,QWORD PTR [rsp+0x18]
  c13c55:	lea    rdx,[rsi+r8*1]
  c13c59:	movzx  ecx,ax
  c13c5c:	mov    rax,rcx
  c13c5f:	sub    rax,QWORD PTR [rsi+r8*1+0x30]
  c13c64:	jae    c13c73 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4353>
  c13c66:	mov    rax,QWORD PTR [rdx+0x28]
  c13c6a:	shl    ecx,0x4
  c13c6d:	mov    rax,QWORD PTR [rax+rcx*1]
  c13c71:	jmp    c13c77 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4357>
  c13c73:	add    rax,QWORD PTR [rdx+0x60]
  c13c77:	cmp    rax,QWORD PTR [r10+0x10]
  c13c7b:	jae    c17ae7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x81c7>
  c13c81:	mov    rdx,QWORD PTR [r10+0x8]
  c13c85:	lea    rax,[rax+rax*2]
  c13c89:	mov    ecx,DWORD PTR [rdx+rax*8]
  c13c8c:	lea    esi,[rcx-0x2]
  c13c8f:	cmp    rcx,0x2
  c13c93:	mov    r8d,0x3
  c13c99:	cmovae r8d,esi
  c13c9d:	lea    rax,[rdx+rax*8]
  c13ca1:	lea    rdx,[rip+0xffffffffff6b1fb4]        # 2c5c5c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x129b>
  c13ca8:	movsxd rsi,DWORD PTR [rdx+r8*4]
  c13cac:	add    rsi,rdx
  c13caf:	jmp    rsi
  c13cb1:	mov    rdx,QWORD PTR [rax]
  c13cb4:	mov    r8,QWORD PTR [rax+0x8]
  c13cb8:	mov    r9,QWORD PTR [rax+0x10]
  c13cbc:	jmp    c15284 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5964>
  c13cc1:	mov    rax,QWORD PTR [r14+0x8]
  c13cc5:	dec    QWORD PTR [rax]
  c13cc8:	jne    c10f4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162f>
  c13cce:	lea    rdi,[r14+0x8]
  c13cd2:	call   QWORD PTR [rip+0x2399e0]        # e4d6b8 <_DYNAMIC+0x258>
  c13cd8:	jmp    c10f4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162f>
  c13cdd:	test   cl,0x1
  c13ce0:	je     c16033 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6713>
  c13ce6:	mov    rsi,QWORD PTR [rax+0x8]
  c13cea:	inc    QWORD PTR [rsi]
  c13ced:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13cf3:	mov    edx,0x1
  c13cf8:	jmp    c13d44 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4424>
  c13cfa:	mov    rax,QWORD PTR [r14+0x8]
  c13cfe:	dec    QWORD PTR [rax]
  c13d01:	jne    c1104f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x172f>
  c13d07:	lea    rdi,[r14+0x8]
  c13d0b:	call   QWORD PTR [rip+0x2399a7]        # e4d6b8 <_DYNAMIC+0x258>
  c13d11:	jmp    c1104f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x172f>
  c13d16:	mov    rsi,QWORD PTR [rax+0x8]
  c13d1a:	inc    QWORD PTR [rsi]
  c13d1d:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13d23:	movabs rax,0xffffffff00000000
  c13d2d:	mov    rdx,QWORD PTR [rsp+0x330]
  c13d35:	and    rdx,rax
  c13d38:	or     rdx,0x6
  c13d3c:	mov    rax,QWORD PTR [rsp+0x268]
  c13d44:	mov    r15,r8
  c13d47:	mov    QWORD PTR [rsp+0x330],rdx
  c13d4f:	mov    QWORD PTR [rsp+0x70],rdx
  c13d54:	mov    QWORD PTR [rsp+0x488],rsi
  c13d5c:	mov    QWORD PTR [rsp+0x78],rsi
  c13d61:	mov    QWORD PTR [rsp+0x268],rax
  c13d69:	mov    QWORD PTR [rsp+0x80],rax
  c13d71:	lea    rdi,[rsp+0x100]
  c13d79:	lea    rsi,[rsp+0x70]
  c13d7e:	call   QWORD PTR [rip+0x23df74]        # e51cf8 <_DYNAMIC+0x4898>
  c13d84:	movzx  eax,BYTE PTR [rsp+0x100]
  c13d8c:	movzx  ebx,BYTE PTR [rsp+0x101]
  c13d94:	cmp    al,0xff
  c13d96:	jne    c174af <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b8f>
  c13d9c:	mov    eax,DWORD PTR [rsp+0x70]
  c13da0:	mov    edx,eax
  c13da2:	sub    edx,0x2
  c13da5:	mov    ecx,0x3
  c13daa:	cmovae ecx,edx
  c13dad:	cmp    ecx,0x8
  c13db0:	ja     c1550b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5beb>
  c13db6:	mov    edx,0x1e7
  c13dbb:	bt     edx,ecx
  c13dbe:	jae    c13e2f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x450f>
  c13dc0:	lea    rax,[r12+0x10]
  c13dc5:	mov    rsi,QWORD PTR [rax]
  c13dc8:	test   bl,0x1
  c13dcb:	je     c13dfb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44db>
  c13dcd:	cmp    QWORD PTR [rsp],rsi
  c13dd1:	jae    c19d3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa41e>
  c13dd7:	mov    rbx,r15
  c13dda:	lea    rbp,[r12+0x8]
  c13ddf:	mov    rax,QWORD PTR [rbp+0x0]
  c13de3:	inc    QWORD PTR [rax+r14*1+0x58]
  c13de8:	mov    r15d,DWORD PTR [rsp+0x2c]
  c13ded:	test   r15b,r15b
  c13df0:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c13df6:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c13dfb:	cmp    QWORD PTR [rsp],rsi
  c13dff:	jae    c19d4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa42f>
  c13e05:	mov    rbx,r15
  c13e08:	lea    rdx,[r12+0x8]
  c13e0d:	mov    rax,QWORD PTR [rdx]
  c13e10:	movsx  rcx,bp
  c13e14:	mov    rbp,rdx
  c13e17:	mov    QWORD PTR [rax+r14*1+0x58],rcx
  c13e1c:	mov    r15d,DWORD PTR [rsp+0x2c]
  c13e21:	test   r15b,r15b
  c13e24:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c13e2a:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c13e2f:	cmp    ecx,0x3
  c13e32:	jne    c15477 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b57>
  c13e38:	test   eax,eax
  c13e3a:	je     c13dc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44a0>
  c13e3c:	mov    rax,QWORD PTR [rsp+0x78]
  c13e41:	dec    QWORD PTR [rax]
  c13e44:	jne    c13dc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44a0>
  c13e4a:	lea    rdi,[rsp+0x78]
  c13e4f:	call   QWORD PTR [rip+0x239853]        # e4d6a8 <_DYNAMIC+0x248>
  c13e55:	jmp    c13dc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44a0>
  c13e5a:	mov    r10,QWORD PTR [rax+0x8]
  c13e5e:	inc    QWORD PTR [r10]
  c13e61:	mov    rax,QWORD PTR [rsp+0x8]
  c13e66:	lea    rbp,[rax+0x8]
  c13e6a:	mov    r8,QWORD PTR [rsp+0x20]
  c13e6f:	lea    rdx,[rax+0x10]
  c13e73:	mov    rdi,QWORD PTR [rsp]
  c13e77:	mov    r11,QWORD PTR [rsp+0x18]
  c13e7c:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13e82:	movabs rax,0xffffffff00000000
  c13e8c:	mov    r9,QWORD PTR [rsp+0x2b8]
  c13e94:	and    r9,rax
  c13e97:	or     r9,0xb
  c13e9b:	jmp    c13f81 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4661>
  c13ea0:	movabs rax,0xffffffff00000000
  c13eaa:	mov    r9,QWORD PTR [rsp+0x2b8]
  c13eb2:	and    r9,rax
  c13eb5:	or     r9,0x2
  c13eb9:	jmp    c13ed4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x45b4>
  c13ebb:	movabs rax,0xffffffff00000000
  c13ec5:	mov    r9,QWORD PTR [rsp+0x2b8]
  c13ecd:	and    r9,rax
  c13ed0:	or     r9,0x3
  c13ed4:	mov    rax,QWORD PTR [rsp+0x8]
  c13ed9:	lea    rbp,[rax+0x8]
  c13edd:	mov    r8,QWORD PTR [rsp+0x20]
  c13ee2:	lea    rdx,[rax+0x10]
  c13ee6:	mov    rdi,QWORD PTR [rsp]
  c13eea:	mov    r10,QWORD PTR [rsp+0x420]
  c13ef2:	mov    rsi,QWORD PTR [rsp+0x220]
  c13efa:	mov    r11,QWORD PTR [rsp+0x18]
  c13eff:	jmp    c16060 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6740>
  c13f04:	test   cl,0x1
  c13f07:	mov    rdx,QWORD PTR [rsp+0x8]
  c13f0c:	lea    rbp,[rdx+0x8]
  c13f10:	mov    r8,QWORD PTR [rsp+0x20]
  c13f15:	lea    rdx,[rdx+0x10]
  c13f19:	mov    rdi,QWORD PTR [rsp]
  c13f1d:	mov    r11,QWORD PTR [rsp+0x18]
  c13f22:	je     c1604d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x672d>
  c13f28:	mov    r10,QWORD PTR [rax+0x8]
  c13f2c:	inc    QWORD PTR [r10]
  c13f2f:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13f35:	mov    r9d,0x1
  c13f3b:	jmp    c16060 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6740>
  c13f40:	mov    r10,QWORD PTR [rax+0x8]
  c13f44:	inc    QWORD PTR [r10]
  c13f47:	mov    rax,QWORD PTR [rsp+0x8]
  c13f4c:	lea    rbp,[rax+0x8]
  c13f50:	mov    r8,QWORD PTR [rsp+0x20]
  c13f55:	lea    rdx,[rax+0x10]
  c13f59:	mov    rdi,QWORD PTR [rsp]
  c13f5d:	mov    r11,QWORD PTR [rsp+0x18]
  c13f62:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13f68:	movabs rax,0xffffffff00000000
  c13f72:	mov    r9,QWORD PTR [rsp+0x2b8]
  c13f7a:	and    r9,rax
  c13f7d:	or     r9,0x6
  c13f81:	mov    rsi,QWORD PTR [rsp+0x220]
  c13f89:	jmp    c16060 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6740>
  c13f8e:	mov    rcx,QWORD PTR [rax+0x8]
  c13f92:	inc    QWORD PTR [rcx]
  c13f95:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c13f9b:	movabs rax,0xffffffff00000000
  c13fa5:	mov    rdx,QWORD PTR [rsp+0x2b0]
  c13fad:	and    rdx,rax
  c13fb0:	or     rdx,0xb
  c13fb4:	jmp    c11733 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e13>
  c13fb9:	movabs rax,0xffffffff00000000
  c13fc3:	mov    rdx,QWORD PTR [rsp+0x2b0]
  c13fcb:	and    rdx,rax
  c13fce:	or     rdx,0x2
  c13fd2:	mov    rcx,QWORD PTR [rsp+0x418]
  c13fda:	jmp    c11733 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e13>
  c13fdf:	movabs rax,0xffffffff00000000
  c13fe9:	mov    rdx,QWORD PTR [rsp+0x2b0]
  c13ff1:	and    rdx,rax
  c13ff4:	or     rdx,0x3
  c13ff8:	mov    rcx,QWORD PTR [rsp+0x418]
  c14000:	jmp    c11733 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e13>
  c14005:	test   cl,0x1
  c14008:	je     c161b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6890>
  c1400e:	mov    rcx,QWORD PTR [rax+0x8]
  c14012:	inc    QWORD PTR [rcx]
  c14015:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1401b:	mov    edx,0x1
  c14020:	jmp    c11733 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e13>
  c14025:	mov    rcx,QWORD PTR [rax+0x8]
  c14029:	inc    QWORD PTR [rcx]
  c1402c:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14032:	movabs rax,0xffffffff00000000
  c1403c:	mov    rdx,QWORD PTR [rsp+0x2b0]
  c14044:	and    rdx,rax
  c14047:	or     rdx,0x6
  c1404b:	jmp    c11733 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e13>
  c14050:	mov    rdi,QWORD PTR [rcx+0x8]
  c14054:	inc    QWORD PTR [rdi]
  c14057:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1405d:	movabs rcx,0xffffffff00000000
  c14067:	mov    rsi,QWORD PTR [rsp+0x2a8]
  c1406f:	and    rsi,rcx
  c14072:	or     rsi,0xb
  c14076:	jmp    c14104 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47e4>
  c1407b:	movabs rcx,0xffffffff00000000
  c14085:	mov    rsi,QWORD PTR [rsp+0x2a8]
  c1408d:	and    rsi,rcx
  c14090:	or     rsi,0x2
  c14094:	mov    rdi,QWORD PTR [rsp+0x410]
  c1409c:	jmp    c14104 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47e4>
  c1409e:	movabs rcx,0xffffffff00000000
  c140a8:	mov    rsi,QWORD PTR [rsp+0x2a8]
  c140b0:	and    rsi,rcx
  c140b3:	or     rsi,0x3
  c140b7:	mov    rdi,QWORD PTR [rsp+0x410]
  c140bf:	jmp    c14104 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47e4>
  c140c1:	test   dl,0x1
  c140c4:	je     c161ca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68aa>
  c140ca:	mov    rdi,QWORD PTR [rcx+0x8]
  c140ce:	inc    QWORD PTR [rdi]
  c140d1:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c140d7:	mov    esi,0x1
  c140dc:	jmp    c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c140de:	mov    rdi,QWORD PTR [rcx+0x8]
  c140e2:	inc    QWORD PTR [rdi]
  c140e5:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c140eb:	movabs rcx,0xffffffff00000000
  c140f5:	mov    rsi,QWORD PTR [rsp+0x2a8]
  c140fd:	and    rsi,rcx
  c14100:	or     rsi,0x6
  c14104:	mov    rcx,QWORD PTR [rsp+0x1f8]
  c1410c:	imul   rax,rax,0xc8
  c14113:	add    rax,QWORD PTR [rsp+0x3a8]
  c1411b:	mov    QWORD PTR [rsp+0x100],rsi
  c14123:	mov    QWORD PTR [rsp+0x108],rdi
  c1412b:	mov    QWORD PTR [rsp+0x110],rcx
  c14133:	cmp    QWORD PTR [rax+0x28],rbp
  c14137:	jbe    c17eb6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8596>
  c1413d:	mov    QWORD PTR [rsp+0x1f8],rcx
  c14145:	mov    QWORD PTR [rsp+0x410],rdi
  c1414d:	mov    QWORD PTR [rsp+0x2a8],rsi
  c14155:	lea    rsi,[rbp*2+0x0]
  c1415d:	add    rsi,rbp
  c14160:	shl    esi,0x3
  c14163:	add    rsi,QWORD PTR [rax+0x20]
  c14167:	lea    rdi,[rsp+0x100]
  c1416f:	call   QWORD PTR [rip+0x23eb1b]        # e52c90 <_DYNAMIC+0x5830>
  c14175:	lea    rcx,[r12+0x10]
  c1417a:	mov    rsi,QWORD PTR [rcx]
  c1417d:	test   al,al
  c1417f:	lea    rbp,[r12+0x8]
  c14184:	je     c1419b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x487b>
  c14186:	cmp    QWORD PTR [rsp],rsi
  c1418a:	jae    c19d7a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa45a>
  c14190:	mov    rax,QWORD PTR [rbp+0x0]
  c14194:	inc    QWORD PTR [rax+r14*1+0x58]
  c14199:	jmp    c141b2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4892>
  c1419b:	cmp    QWORD PTR [rsp],rsi
  c1419f:	jae    c19d71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa451>
  c141a5:	mov    rax,QWORD PTR [rbp+0x0]
  c141a9:	movsx  rcx,bx
  c141ad:	mov    QWORD PTR [rax+r14*1+0x58],rcx
  c141b2:	mov    rbx,r15
  c141b5:	mov    eax,DWORD PTR [rsp+0x100]
  c141bc:	mov    edx,eax
  c141be:	sub    edx,0x2
  c141c1:	mov    ecx,0x3
  c141c6:	cmovae ecx,edx
  c141c9:	cmp    ecx,0x8
  c141cc:	mov    r15d,DWORD PTR [rsp+0x2c]
  c141d1:	ja     c155f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5cd4>
  c141d7:	mov    edx,0x1e7
  c141dc:	bt     edx,ecx
  c141df:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c141e5:	cmp    ecx,0x3
  c141e8:	jne    c155ba <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c9a>
  c141ee:	test   eax,eax
  c141f0:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c141f6:	mov    rax,QWORD PTR [rsp+0x108]
  c141fe:	dec    QWORD PTR [rax]
  c14201:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c14207:	lea    rdi,[rsp+0x108]
  c1420f:	call   QWORD PTR [rip+0x239493]        # e4d6a8 <_DYNAMIC+0x248>
  c14215:	test   r15b,r15b
  c14218:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c1421e:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c14223:	mov    rdi,QWORD PTR [rcx+0x8]
  c14227:	inc    QWORD PTR [rdi]
  c1422a:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14230:	movabs rcx,0xffffffff00000000
  c1423a:	mov    rsi,QWORD PTR [rsp+0x2a0]
  c14242:	and    rsi,rcx
  c14245:	or     rsi,0xb
  c14249:	jmp    c142d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x49b7>
  c1424e:	movabs rcx,0xffffffff00000000
  c14258:	mov    rsi,QWORD PTR [rsp+0x2a0]
  c14260:	and    rsi,rcx
  c14263:	or     rsi,0x2
  c14267:	mov    rdi,QWORD PTR [rsp+0x408]
  c1426f:	jmp    c142d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x49b7>
  c14271:	movabs rcx,0xffffffff00000000
  c1427b:	mov    rsi,QWORD PTR [rsp+0x2a0]
  c14283:	and    rsi,rcx
  c14286:	or     rsi,0x3
  c1428a:	mov    rdi,QWORD PTR [rsp+0x408]
  c14292:	jmp    c142d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x49b7>
  c14294:	test   dl,0x1
  c14297:	je     c161e4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68c4>
  c1429d:	mov    rdi,QWORD PTR [rcx+0x8]
  c142a1:	inc    QWORD PTR [rdi]
  c142a4:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c142aa:	mov    esi,0x1
  c142af:	jmp    c142df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x49bf>
  c142b1:	mov    rdi,QWORD PTR [rcx+0x8]
  c142b5:	inc    QWORD PTR [rdi]
  c142b8:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c142be:	movabs rcx,0xffffffff00000000
  c142c8:	mov    rsi,QWORD PTR [rsp+0x2a0]
  c142d0:	and    rsi,rcx
  c142d3:	or     rsi,0x6
  c142d7:	mov    rcx,QWORD PTR [rsp+0x1f0]
  c142df:	imul   rax,rax,0xc8
  c142e6:	add    rax,QWORD PTR [rsp+0x3a8]
  c142ee:	mov    QWORD PTR [rsp+0x70],rsi
  c142f3:	mov    QWORD PTR [rsp+0x78],rdi
  c142f8:	mov    QWORD PTR [rsp+0x80],rcx
  c14300:	cmp    QWORD PTR [rax+0x28],rbp
  c14304:	jbe    c17e9a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x857a>
  c1430a:	mov    QWORD PTR [rsp+0x1f0],rcx
  c14312:	mov    QWORD PTR [rsp+0x408],rdi
  c1431a:	mov    QWORD PTR [rsp+0x2a0],rsi
  c14322:	lea    rdx,[rbp*2+0x0]
  c1432a:	add    rdx,rbp
  c1432d:	shl    edx,0x3
  c14330:	add    rdx,QWORD PTR [rax+0x20]
  c14334:	lea    rcx,[rip+0xffffffffff6b23b8]        # 2c66f3 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x370>
  c1433b:	lea    rdi,[rsp+0x100]
  c14343:	lea    rsi,[rsp+0x70]
  c14348:	mov    r8d,0x1
  c1434e:	call   QWORD PTR [rip+0x23aeac]        # e4f200 <_DYNAMIC+0x1da0>
  c14354:	movzx  ecx,BYTE PTR [rsp+0x100]
  c1435c:	movzx  eax,BYTE PTR [rsp+0x101]
  c14364:	cmp    cl,0xff
  c14367:	lea    rbp,[r12+0x8]
  c1436c:	jne    c181cc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88ac>
  c14372:	lea    rcx,[r12+0x10]
  c14377:	mov    rsi,QWORD PTR [rcx]
  c1437a:	test   al,al
  c1437c:	js     c14397 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a77>
  c1437e:	cmp    QWORD PTR [rsp],rsi
  c14382:	jae    c19ce1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3c1>
  c14388:	mov    rax,QWORD PTR [rbp+0x0]
  c1438c:	movsx  rcx,bx
  c14390:	mov    QWORD PTR [rax+r14*1+0x58],rcx
  c14395:	jmp    c143aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a8a>
  c14397:	cmp    QWORD PTR [rsp],rsi
  c1439b:	jae    c19d90 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa470>
  c143a1:	mov    rax,QWORD PTR [rbp+0x0]
  c143a5:	inc    QWORD PTR [rax+r14*1+0x58]
  c143aa:	mov    rbx,r15
  c143ad:	mov    eax,DWORD PTR [rsp+0x70]
  c143b1:	mov    edx,eax
  c143b3:	sub    edx,0x2
  c143b6:	mov    ecx,0x3
  c143bb:	cmovae ecx,edx
  c143be:	cmp    ecx,0x8
  c143c1:	mov    r15d,DWORD PTR [rsp+0x2c]
  c143c6:	ja     c15a12 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60f2>
  c143cc:	mov    edx,0x1e7
  c143d1:	bt     edx,ecx
  c143d4:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c143da:	cmp    ecx,0x3
  c143dd:	jne    c159fa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60da>
  c143e3:	test   eax,eax
  c143e5:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c143eb:	mov    rax,QWORD PTR [rsp+0x78]
  c143f0:	dec    QWORD PTR [rax]
  c143f3:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c143f9:	lea    rdi,[rsp+0x78]
  c143fe:	call   QWORD PTR [rip+0x2392a4]        # e4d6a8 <_DYNAMIC+0x248>
  c14404:	test   r15b,r15b
  c14407:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c1440d:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c14412:	mov    rax,QWORD PTR [rcx+0x8]
  c14416:	inc    QWORD PTR [rax]
  c14419:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1441f:	movq   xmm0,rax
  c14424:	mov    eax,0xb
  c14429:	jmp    c1621e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68fe>
  c1442e:	mov    eax,0x2
  c14433:	jmp    c1443a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4b1a>
  c14435:	mov    eax,0x3
  c1443a:	jmp    c1621e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68fe>
  c1443f:	mov    rax,QWORD PTR [rcx+0x8]
  c14443:	inc    QWORD PTR [rax]
  c14446:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1444c:	movq   xmm0,rax
  c14451:	mov    eax,0xb
  c14456:	jmp    c164b2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b92>
  c1445b:	mov    eax,0x2
  c14460:	jmp    c14467 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4b47>
  c14462:	mov    eax,0x3
  c14467:	jmp    c164b2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b92>
  c1446c:	mov    rax,QWORD PTR [rcx+0x8]
  c14470:	inc    QWORD PTR [rax]
  c14473:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14479:	movq   xmm0,rax
  c1447e:	mov    eax,0xb
  c14483:	jmp    c1676d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e4d>
  c14488:	mov    eax,0x2
  c1448d:	jmp    c14494 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4b74>
  c1448f:	mov    eax,0x3
  c14494:	jmp    c1676d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e4d>
  c14499:	test   dl,0x1
  c1449c:	je     c161fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68de>
  c144a2:	mov    rsi,QWORD PTR [rcx+0x8]
  c144a6:	inc    QWORD PTR [rsi]
  c144a9:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c144af:	mov    eax,0x1
  c144b4:	jmp    c16210 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68f0>
  c144b9:	test   dl,0x1
  c144bc:	je     c16492 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b72>
  c144c2:	mov    rsi,QWORD PTR [rcx+0x8]
  c144c6:	inc    QWORD PTR [rsi]
  c144c9:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c144cf:	mov    eax,0x1
  c144d4:	jmp    c164a4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b84>
  c144d9:	test   dl,0x1
  c144dc:	je     c1674d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e2d>
  c144e2:	mov    rsi,QWORD PTR [rcx+0x8]
  c144e6:	inc    QWORD PTR [rsi]
  c144e9:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c144ef:	mov    eax,0x1
  c144f4:	jmp    c1675f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e3f>
  c144f9:	mov    rax,QWORD PTR [rcx+0x8]
  c144fd:	inc    QWORD PTR [rax]
  c14500:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14506:	movq   xmm0,rax
  c1450b:	mov    eax,0x6
  c14510:	jmp    c1621e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68fe>
  c14515:	mov    rax,QWORD PTR [rcx+0x8]
  c14519:	inc    QWORD PTR [rax]
  c1451c:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14522:	movq   xmm0,rax
  c14527:	mov    eax,0x6
  c1452c:	jmp    c164b2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b92>
  c14531:	mov    rax,QWORD PTR [rcx+0x8]
  c14535:	inc    QWORD PTR [rax]
  c14538:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1453e:	movq   xmm0,rax
  c14543:	mov    eax,0xb
  c14548:	jmp    c16a28 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7108>
  c1454d:	mov    rax,QWORD PTR [rcx+0x8]
  c14551:	inc    QWORD PTR [rax]
  c14554:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1455a:	movq   xmm0,rax
  c1455f:	mov    eax,0x6
  c14564:	jmp    c1676d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e4d>
  c14569:	mov    eax,0x2
  c1456e:	jmp    c14575 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c55>
  c14570:	mov    eax,0x3
  c14575:	jmp    c16a28 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7108>
  c1457a:	test   dl,0x1
  c1457d:	je     c16a08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x70e8>
  c14583:	mov    rsi,QWORD PTR [rcx+0x8]
  c14587:	inc    QWORD PTR [rsi]
  c1458a:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14590:	mov    eax,0x1
  c14595:	jmp    c16a1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x70fa>
  c1459a:	mov    rax,QWORD PTR [rcx+0x8]
  c1459e:	inc    QWORD PTR [rax]
  c145a1:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c145a7:	movq   xmm0,rax
  c145ac:	mov    eax,0x6
  c145b1:	jmp    c16a28 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7108>
  c145b6:	mov    rdi,QWORD PTR [rcx+0x8]
  c145ba:	inc    QWORD PTR [rdi]
  c145bd:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c145c3:	movabs rcx,0xffffffff00000000
  c145cd:	mov    r8,QWORD PTR [rsp+0x298]
  c145d5:	and    r8,rcx
  c145d8:	or     r8,0xb
  c145dc:	jmp    c14699 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4d79>
  c145e1:	movabs rcx,0xffffffff00000000
  c145eb:	mov    r8,QWORD PTR [rsp+0x298]
  c145f3:	and    r8,rcx
  c145f6:	or     r8,0x2
  c145fa:	mov    rdi,QWORD PTR [rsp+0x400]
  c14602:	jmp    c14699 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4d79>
  c14607:	movabs rcx,0xffffffff00000000
  c14611:	mov    r8,QWORD PTR [rsp+0x298]
  c14619:	and    r8,rcx
  c1461c:	or     r8,0x3
  c14620:	mov    rdi,QWORD PTR [rsp+0x400]
  c14628:	jmp    c14699 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4d79>
  c1462a:	test   dl,0x1
  c1462d:	je     c16d05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x73e5>
  c14633:	mov    rdi,QWORD PTR [rcx+0x8]
  c14637:	inc    QWORD PTR [rdi]
  c1463a:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14640:	mov    r8d,0x1
  c14646:	jmp    c146a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4d81>
  c14648:	mov    rcx,QWORD PTR [rax+0x8]
  c1464c:	inc    QWORD PTR [rcx]
  c1464f:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14655:	movabs rax,0xffffffff00000000
  c1465f:	mov    rdi,QWORD PTR [rsp+0x2d8]
  c14667:	and    rdi,rax
  c1466a:	or     rdi,0xb
  c1466e:	jmp    c14829 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f09>
  c14673:	mov    rdi,QWORD PTR [rcx+0x8]
  c14677:	inc    QWORD PTR [rdi]
  c1467a:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14680:	movabs rcx,0xffffffff00000000
  c1468a:	mov    r8,QWORD PTR [rsp+0x298]
  c14692:	and    r8,rcx
  c14695:	or     r8,0x6
  c14699:	mov    rsi,QWORD PTR [rsp+0x218]
  c146a1:	mov    QWORD PTR [rsp+0x70],r8
  c146a6:	mov    QWORD PTR [rsp+0x78],rdi
  c146ab:	mov    QWORD PTR [rsp+0x218],rsi
  c146b3:	mov    QWORD PTR [rsp+0x80],rsi
  c146bb:	lea    rcx,[r12+0x10]
  c146c0:	mov    rsi,QWORD PTR [rcx]
  c146c3:	cmp    QWORD PTR [rsp],rsi
  c146c7:	jae    c19ae5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1c5>
  c146cd:	mov    rsi,QWORD PTR [rbp+0x0]
  c146d1:	lea    rdx,[rsi+r14*1]
  c146d5:	movzx  ecx,ax
  c146d8:	mov    rax,rcx
  c146db:	sub    rax,QWORD PTR [rsi+r14*1+0x30]
  c146e0:	jae    c146ef <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4dcf>
  c146e2:	mov    rax,QWORD PTR [rdx+0x28]
  c146e6:	shl    ecx,0x4
  c146e9:	mov    rax,QWORD PTR [rax+rcx*1]
  c146ed:	jmp    c146f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4dd3>
  c146ef:	add    rax,QWORD PTR [rdx+0x60]
  c146f3:	mov    rcx,QWORD PTR [rsp+0x20]
  c146f8:	cmp    rax,QWORD PTR [rcx+0x10]
  c146fc:	jae    c180d4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x87b4>
  c14702:	mov    QWORD PTR [rsp+0x400],rdi
  c1470a:	mov    rdx,QWORD PTR [rcx+0x8]
  c1470e:	lea    rax,[rax+rax*2]
  c14712:	mov    ecx,DWORD PTR [rdx+rax*8]
  c14715:	lea    esi,[rcx-0x2]
  c14718:	cmp    rcx,0x2
  c1471c:	mov    edi,0x3
  c14721:	cmovae edi,esi
  c14724:	lea    rax,[rdx+rax*8]
  c14728:	lea    rdx,[rip+0xffffffffff6b120d]        # 2c593c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf7b>
  c1472f:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c14733:	add    rsi,rdx
  c14736:	mov    QWORD PTR [rsp+0x298],r8
  c1473e:	jmp    rsi
  c14740:	mov    rdx,QWORD PTR [rax]
  c14743:	mov    rsi,QWORD PTR [rax+0x8]
  c14747:	mov    rdi,QWORD PTR [rax+0x10]
  c1474b:	jmp    c15778 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e58>
  c14750:	movabs rax,0xffffffff00000000
  c1475a:	mov    rdi,QWORD PTR [rsp+0x2d8]
  c14762:	and    rdi,rax
  c14765:	or     rdi,0x2
  c14769:	mov    rcx,QWORD PTR [rsp+0x1c8]
  c14771:	jmp    c14829 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f09>
  c14776:	movabs rax,0xffffffff00000000
  c14780:	mov    rdi,QWORD PTR [rsp+0x2d8]
  c14788:	and    rdi,rax
  c1478b:	or     rdi,0x3
  c1478f:	mov    rcx,QWORD PTR [rsp+0x1c8]
  c14797:	jmp    c14829 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f09>
  c1479c:	test   cl,0x1
  c1479f:	je     c16d1d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x73fd>
  c147a5:	mov    rcx,QWORD PTR [rax+0x8]
  c147a9:	inc    QWORD PTR [rcx]
  c147ac:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c147b2:	mov    edi,0x1
  c147b7:	mov    rax,rsi
  c147ba:	jmp    c14831 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f11>
  c147bc:	mov    rax,QWORD PTR [r14+0x8]
  c147c0:	dec    QWORD PTR [rax]
  c147c3:	jne    c12ef5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x35d5>
  c147c9:	lea    rdi,[r14+0x8]
  c147cd:	call   QWORD PTR [rip+0x238edd]        # e4d6b0 <_DYNAMIC+0x250>
  c147d3:	jmp    c12ef5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x35d5>
  c147d8:	mov    r8,QWORD PTR [rax+0x8]
  c147dc:	inc    QWORD PTR [r8]
  c147df:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c147e5:	movabs rax,0xffffffff00000000
  c147ef:	mov    rdx,QWORD PTR [rsp+0x2c0]
  c147f7:	and    rdx,rax
  c147fa:	or     rdx,0xb
  c147fe:	jmp    c14c77 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5357>
  c14803:	mov    rcx,QWORD PTR [rax+0x8]
  c14807:	inc    QWORD PTR [rcx]
  c1480a:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14810:	movabs rax,0xffffffff00000000
  c1481a:	mov    rdi,QWORD PTR [rsp+0x2d8]
  c14822:	and    rdi,rax
  c14825:	or     rdi,0x6
  c14829:	mov    rax,QWORD PTR [rsp+0x1d0]
  c14831:	mov    QWORD PTR [rsp+0x1c8],rcx
  c14839:	mov    QWORD PTR [rsp+0xc0],rdi
  c14841:	mov    QWORD PTR [rsp+0xc8],rcx
  c14849:	mov    QWORD PTR [rsp+0xd0],rax
  c14851:	cmp    DWORD PTR [rsp+0xe0],0xb
  c14859:	mov    QWORD PTR [rsp+0x2d8],rdi
  c14861:	mov    QWORD PTR [rsp+0x1d0],rax
  c14869:	jne    c149ed <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x50cd>
  c1486f:	mov    rsi,QWORD PTR [rsp+0xe8]
  c14877:	cmp    BYTE PTR [rsi+0x10],0xf
  c1487b:	jne    c149ed <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x50cd>
  c14881:	add    rsi,0x18
  c14885:	mov    rax,QWORD PTR [rsp+0x378]
  c1488d:	mov    rcx,QWORD PTR [rax]
  c14890:	test   rcx,rcx
  c14893:	cmovne rcx,rax
  c14897:	mov    rdx,QWORD PTR [rsp+0x370]
  c1489f:	mov    rax,QWORD PTR [rdx]
  c148a2:	test   rax,rax
  c148a5:	cmovne rax,rdx
  c148a9:	mov    rdx,QWORD PTR [rsp+0x398]
  c148b1:	movq   xmm0,QWORD PTR [rdx]
  c148b5:	mov    rdx,QWORD PTR [rsp+0x3a0]
  c148bd:	movq   xmm1,QWORD PTR [rdx]
  c148c1:	punpcklqdq xmm1,xmm0
  c148c5:	mov    rdx,QWORD PTR [rsp+0x630]
  c148cd:	mov    QWORD PTR [rsp+0x100],rdx
  c148d5:	mov    rdx,QWORD PTR [rip+0x238ea4]        # e4d780 <_DYNAMIC+0x320>
  c148dc:	mov    QWORD PTR [rsp+0x108],rdx
  c148e4:	mov    BYTE PTR [rsp+0x188],0x0
  c148ec:	mov    rdx,QWORD PTR [rsp+0x640]
  c148f4:	movups xmm0,XMMWORD PTR [rdx]
  c148f7:	movups XMMWORD PTR [rsp+0x110],xmm0
  c148ff:	movdqu xmm0,XMMWORD PTR [rdx+0x10]
  c14904:	movdqu XMMWORD PTR [rsp+0x120],xmm0
  c1490d:	mov    rdx,QWORD PTR [rsp+0x388]
  c14915:	mov    QWORD PTR [rsp+0x130],rdx
  c1491d:	mov    rdx,QWORD PTR [rsp+0x390]
  c14925:	mov    QWORD PTR [rsp+0x138],rdx
  c1492d:	mov    rdx,QWORD PTR [rsp+0x380]
  c14935:	mov    QWORD PTR [rsp+0x140],rdx
  c1493d:	mov    QWORD PTR [rsp+0x148],rcx
  c14945:	mov    QWORD PTR [rsp+0x150],0x0
  c14951:	mov    QWORD PTR [rsp+0x160],0x0
  c1495d:	pxor   xmm0,xmm0
  c14961:	pcmpeqd xmm0,xmm1
  c14965:	pshufd xmm1,xmm0,0xb1
  c1496a:	pand   xmm1,xmm0
  c1496e:	pandn  xmm1,XMMWORD PTR [rsp+0x520]
  c14977:	movdqu XMMWORD PTR [rsp+0x170],xmm1
  c14980:	mov    QWORD PTR [rsp+0x180],rax
  c14988:	mov    rax,QWORD PTR [rsp+0xd0]
  c14990:	mov    QWORD PTR [rsp+0x40],rax
  c14995:	movdqu xmm0,XMMWORD PTR [rsp+0xc0]
  c1499e:	movdqa XMMWORD PTR [rsp+0x30],xmm0
  c149a4:	sub    rsp,0x8
  c149a8:	lea    rax,[rsp+0x108]
  c149b0:	lea    rdi,[rsp+0x78]
  c149b5:	lea    r8,[rsp+0x38]
  c149ba:	mov    rdx,QWORD PTR [rsp+0x4b8]
  c149c2:	mov    ecx,ebx
  c149c4:	mov    r9,QWORD PTR [rsp+0x1b8]
  c149cc:	push   rax
  c149cd:	call   c37bc0 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7linking18component_prop_set>
  c149d2:	add    rsp,0x10
  c149d6:	mov    rbx,QWORD PTR [rsp+0x10]
  c149db:	cmp    BYTE PTR [rsp+0x70],0xff
  c149e0:	jne    c18eb4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9594>
  c149e6:	xor    ebp,ebp
  c149e8:	jmp    c14b38 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5218>
  c149ed:	cmp    QWORD PTR [rsp+0x4c0],rbx
  c149f5:	jbe    c185ef <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ccf>
  c149fb:	mov    DWORD PTR [rsp+0x2c],r15d
  c14a00:	lea    rax,[rbx+rbx*2]
  c14a04:	mov    rsi,QWORD PTR [rsp+0x4b8]
  c14a0c:	mov    r12,QWORD PTR [rsi+rax*8+0x8]
  c14a11:	mov    ecx,edi
  c14a13:	sub    ecx,0x2
  c14a16:	mov    edx,0x3
  c14a1b:	cmovae edx,ecx
  c14a1e:	mov    r15,QWORD PTR [rsi+rax*8+0x10]
  c14a23:	lea    rax,[rip+0xffffffffff6b0e72]        # 2c589c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xedb>
  c14a2a:	movsxd rcx,DWORD PTR [rax+rdx*4]
  c14a2e:	add    rcx,rax
  c14a31:	jmp    rcx
  c14a33:	mov    rax,QWORD PTR [rsp+0xd0]
  c14a3b:	mov    QWORD PTR [rsp+0x110],rax
  c14a43:	movdqu xmm0,XMMWORD PTR [rsp+0xc0]
  c14a4c:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c14a55:	mov    rax,QWORD PTR [rsp+0x190]
  c14a5d:	mov    rcx,QWORD PTR [rsp+0x4c8]
  c14a65:	cmp    QWORD PTR [rsp+0x3b8],rcx
  c14a6d:	jae    c1864d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d2d>
  c14a73:	cmp    r13,QWORD PTR [rax+0x10]
  c14a77:	jae    c1865b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d3b>
  c14a7d:	lea    r8,[r13*2+0x0]
  c14a85:	add    r8,r13
  c14a88:	shl    r8,0x3
  c14a8c:	add    r8,QWORD PTR [rax+0x8]
  c14a90:	lea    rdi,[rsp+0x70]
  c14a95:	lea    rsi,[rsp+0xe0]
  c14a9d:	lea    rcx,[rsp+0x100]
  c14aa5:	mov    edx,ebx
  c14aa7:	call   QWORD PTR [rip+0x23e1eb]        # e52c98 <_DYNAMIC+0x5838>
  c14aad:	movzx  eax,BYTE PTR [rsp+0x70]
  c14ab2:	cmp    al,0x5
  c14ab4:	setne  bpl
  c14ab8:	mov    rbx,QWORD PTR [rsp+0x10]
  c14abd:	je     c14ad2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51b2>
  c14abf:	cmp    al,0xff
  c14ac1:	mov    r12,QWORD PTR [rsp+0x8]
  c14ac6:	mov    r15d,DWORD PTR [rsp+0x2c]
  c14acb:	je     c14b38 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5218>
  c14acd:	jmp    c18ac3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x91a3>
  c14ad2:	mov    rax,QWORD PTR [rsp+0xd0]
  c14ada:	mov    QWORD PTR [rsp+0x40],rax
  c14adf:	movdqu xmm0,XMMWORD PTR [rsp+0xc0]
  c14ae8:	movdqa XMMWORD PTR [rsp+0x30],xmm0
  c14aee:	lea    rdi,[rsp+0x100]
  c14af6:	lea    rsi,[rsp+0xe0]
  c14afe:	lea    r8,[rsp+0x30]
  c14b03:	mov    rdx,r12
  c14b06:	mov    rcx,r15
  c14b09:	call   QWORD PTR [rip+0x23e191]        # e52ca0 <_DYNAMIC+0x5840>
  c14b0f:	cmp    BYTE PTR [rsp+0x100],0xff
  c14b17:	mov    r12,QWORD PTR [rsp+0x8]
  c14b1c:	mov    r15d,DWORD PTR [rsp+0x2c]
  c14b21:	jne    c18aeb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x91cb>
  c14b27:	cmp    BYTE PTR [rsp+0x70],0xff
  c14b2c:	je     c14b38 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5218>
  c14b2e:	lea    rdi,[rsp+0x70]
  c14b33:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.3092253909692456873>
  c14b38:	lea    rax,[r12+0x10]
  c14b3d:	mov    rsi,QWORD PTR [rax]
  c14b40:	cmp    QWORD PTR [rsp],rsi
  c14b44:	jae    c19ccb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3ab>
  c14b4a:	lea    rax,[r12+0x8]
  c14b4f:	mov    rax,QWORD PTR [rax]
  c14b52:	inc    QWORD PTR [rax+r14*1+0x58]
  c14b57:	test   bpl,bpl
  c14b5a:	je     c14b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5249>
  c14b5c:	lea    rdi,[rsp+0xc0]
  c14b64:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c14b69:	mov    eax,DWORD PTR [rsp+0xe0]
  c14b70:	mov    edx,eax
  c14b72:	sub    edx,0x2
  c14b75:	mov    ecx,0x3
  c14b7a:	cmovae ecx,edx
  c14b7d:	cmp    ecx,0x8
  c14b80:	ja     c15c79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6359>
  c14b86:	mov    edx,0x1e7
  c14b8b:	bt     edx,ecx
  c14b8e:	lea    rbp,[r12+0x8]
  c14b93:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c14b99:	cmp    ecx,0x3
  c14b9c:	jne    c15c4c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x632c>
  c14ba2:	test   eax,eax
  c14ba4:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c14baa:	mov    rax,QWORD PTR [rsp+0xe8]
  c14bb2:	dec    QWORD PTR [rax]
  c14bb5:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c14bbb:	jmp    c1510b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x57eb>
  c14bc0:	movabs rax,0xffffffff00000000
  c14bca:	mov    rdx,QWORD PTR [rsp+0x2c0]
  c14bd2:	and    rdx,rax
  c14bd5:	or     rdx,0x2
  c14bd9:	mov    r8,QWORD PTR [rsp+0x428]
  c14be1:	jmp    c14c77 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5357>
  c14be6:	movabs rax,0xffffffff00000000
  c14bf0:	mov    rdx,QWORD PTR [rsp+0x2c0]
  c14bf8:	and    rdx,rax
  c14bfb:	or     rdx,0x3
  c14bff:	mov    r8,QWORD PTR [rsp+0x428]
  c14c07:	jmp    c14c77 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5357>
  c14c09:	test   cl,0x1
  c14c0c:	je     c16d3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x741a>
  c14c12:	mov    r8,QWORD PTR [rax+0x8]
  c14c16:	inc    QWORD PTR [r8]
  c14c19:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14c1f:	mov    edx,0x1
  c14c24:	jmp    c14c7f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x535f>
  c14c26:	mov    rsi,QWORD PTR [rax+0x8]
  c14c2a:	inc    QWORD PTR [rsi]
  c14c2d:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14c33:	movabs rax,0xffffffff00000000
  c14c3d:	mov    rdx,QWORD PTR [rsp+0x2d0]
  c14c45:	and    rdx,rax
  c14c48:	or     rdx,0xb
  c14c4c:	jmp    c14f1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x55fe>
  c14c51:	mov    r8,QWORD PTR [rax+0x8]
  c14c55:	inc    QWORD PTR [r8]
  c14c58:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14c5e:	movabs rax,0xffffffff00000000
  c14c68:	mov    rdx,QWORD PTR [rsp+0x2c0]
  c14c70:	and    rdx,rax
  c14c73:	or     rdx,0x6
  c14c77:	mov    r9,QWORD PTR [rsp+0x200]
  c14c7f:	mov    QWORD PTR [rsp+0x70],rdx
  c14c84:	mov    QWORD PTR [rsp+0x78],r8
  c14c89:	mov    QWORD PTR [rsp+0x80],r9
  c14c91:	mov    rsi,QWORD PTR [r11]
  c14c94:	cmp    rdi,rsi
  c14c97:	jae    c19aa6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa186>
  c14c9d:	mov    QWORD PTR [rsp+0x440],r14
  c14ca5:	mov    QWORD PTR [rsp+0x2e0],rbx
  c14cad:	mov    rcx,QWORD PTR [rbp+0x0]
  c14cb1:	mov    rsi,QWORD PTR [rsp+0x18]
  c14cb6:	lea    rax,[rcx+rsi*1]
  c14cba:	mov    rbx,r12
  c14cbd:	sub    rbx,QWORD PTR [rcx+rsi*1+0x30]
  c14cc2:	mov    QWORD PTR [rsp+0x2c0],rdx
  c14cca:	mov    QWORD PTR [rsp+0x428],r8
  c14cd2:	mov    QWORD PTR [rsp+0x200],r9
  c14cda:	mov    ebp,r15d
  c14cdd:	jae    c14ced <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x53cd>
  c14cdf:	mov    rax,QWORD PTR [rax+0x28]
  c14ce3:	shl    r12d,0x4
  c14ce7:	mov    rbx,QWORD PTR [rax+r12*1]
  c14ceb:	jmp    c14cf1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x53d1>
  c14ced:	add    rbx,QWORD PTR [rax+0x60]
  c14cf1:	mov    r12,QWORD PTR [rsp+0x8]
  c14cf6:	mov    r15,QWORD PTR [r10+0x8]
  c14cfa:	mov    r14,QWORD PTR [r10+0x10]
  c14cfe:	lea    rdi,[rsp+0x30]
  c14d03:	lea    rsi,[rsp+0x70]
  c14d08:	call   QWORD PTR [rip+0x23df82]        # e52c90 <_DYNAMIC+0x5830>
  c14d0e:	xor    al,0x1
  c14d10:	mov    BYTE PTR [rsp+0x104],al
  c14d17:	mov    DWORD PTR [rsp+0x100],0x4
  c14d22:	cmp    rbx,r14
  c14d25:	jae    c1813e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x881e>
  c14d2b:	lea    rax,[rbx+rbx*2]
  c14d2f:	lea    r14,[r15+rax*8]
  c14d33:	mov    eax,DWORD PTR [r15+rax*8]
  c14d37:	mov    edx,eax
  c14d39:	sub    edx,0x2
  c14d3c:	mov    ecx,0x3
  c14d41:	cmovae ecx,edx
  c14d44:	cmp    ecx,0x8
  c14d47:	ja     c158d4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5fb4>
  c14d4d:	mov    edx,0x1e7
  c14d52:	bt     edx,ecx
  c14d55:	mov    rbx,QWORD PTR [rsp+0x18]
  c14d5a:	mov    r15d,ebp
  c14d5d:	mov    rbp,QWORD PTR [rsp+0x198]
  c14d65:	jae    c14e18 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54f8>
  c14d6b:	mov    rax,QWORD PTR [rsp+0x110]
  c14d73:	mov    QWORD PTR [r14+0x10],rax
  c14d77:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c14d80:	movdqu XMMWORD PTR [r14],xmm0
  c14d85:	lea    rax,[r12+0x10]
  c14d8a:	mov    rsi,QWORD PTR [rax]
  c14d8d:	cmp    QWORD PTR [rsp],rsi
  c14d91:	jae    c19bf6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2d6>
  c14d97:	mov    rax,QWORD PTR [rbp+0x0]
  c14d9b:	mov    r14,rbx
  c14d9e:	inc    QWORD PTR [rax+rbx*1+0x58]
  c14da3:	mov    eax,DWORD PTR [rsp+0x70]
  c14da7:	mov    edx,eax
  c14da9:	sub    edx,0x2
  c14dac:	mov    ecx,0x3
  c14db1:	cmovae ecx,edx
  c14db4:	cmp    ecx,0x8
  c14db7:	mov    rbx,QWORD PTR [rsp+0x10]
  c14dbc:	ja     c15968 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6048>
  c14dc2:	mov    edx,0x1e7
  c14dc7:	bt     edx,ecx
  c14dca:	jae    c14e45 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5525>
  c14dcc:	mov    eax,DWORD PTR [rsp+0x30]
  c14dd0:	mov    edx,eax
  c14dd2:	sub    edx,0x2
  c14dd5:	mov    ecx,0x3
  c14dda:	cmovae ecx,edx
  c14ddd:	cmp    ecx,0x8
  c14de0:	ja     c159d4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60b4>
  c14de6:	mov    edx,0x1e7
  c14deb:	bt     edx,ecx
  c14dee:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c14df4:	cmp    ecx,0x3
  c14df7:	jne    c159a4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6084>
  c14dfd:	test   eax,eax
  c14dff:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c14e05:	mov    rax,QWORD PTR [rsp+0x38]
  c14e0a:	dec    QWORD PTR [rax]
  c14e0d:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c14e13:	jmp    c1585c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f3c>
  c14e18:	cmp    ecx,0x3
  c14e1b:	jne    c1589c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f7c>
  c14e21:	test   eax,eax
  c14e23:	je     c14d6b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x544b>
  c14e29:	mov    rax,QWORD PTR [r14+0x8]
  c14e2d:	dec    QWORD PTR [rax]
  c14e30:	jne    c14d6b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x544b>
  c14e36:	lea    rdi,[r14+0x8]
  c14e3a:	call   QWORD PTR [rip+0x238868]        # e4d6a8 <_DYNAMIC+0x248>
  c14e40:	jmp    c14d6b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x544b>
  c14e45:	cmp    ecx,0x3
  c14e48:	jne    c1592c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x600c>
  c14e4e:	test   eax,eax
  c14e50:	je     c14dcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54ac>
  c14e56:	mov    rax,QWORD PTR [rsp+0x78]
  c14e5b:	dec    QWORD PTR [rax]
  c14e5e:	jne    c14dcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54ac>
  c14e64:	lea    rdi,[rsp+0x78]
  c14e69:	call   QWORD PTR [rip+0x238839]        # e4d6a8 <_DYNAMIC+0x248>
  c14e6f:	jmp    c14dcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54ac>
  c14e74:	movabs rax,0xffffffff00000000
  c14e7e:	mov    rdx,QWORD PTR [rsp+0x2d0]
  c14e86:	and    rdx,rax
  c14e89:	or     rdx,0x2
  c14e8d:	mov    rsi,QWORD PTR [rsp+0x438]
  c14e95:	jmp    c14f1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x55fe>
  c14e9a:	movabs rax,0xffffffff00000000
  c14ea4:	mov    rdx,QWORD PTR [rsp+0x2d0]
  c14eac:	and    rdx,rax
  c14eaf:	or     rdx,0x3
  c14eb3:	mov    rsi,QWORD PTR [rsp+0x438]
  c14ebb:	jmp    c14f1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x55fe>
  c14ebd:	test   cl,0x1
  c14ec0:	je     c16d51 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7431>
  c14ec6:	mov    rsi,QWORD PTR [rax+0x8]
  c14eca:	inc    QWORD PTR [rsi]
  c14ecd:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14ed3:	mov    edx,0x1
  c14ed8:	jmp    c14f26 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5606>
  c14eda:	mov    rax,QWORD PTR [rsp+0x78]
  c14edf:	dec    QWORD PTR [rax]
  c14ee2:	jne    c13298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3978>
  c14ee8:	lea    rdi,[rsp+0x78]
  c14eed:	call   QWORD PTR [rip+0x2387bd]        # e4d6b0 <_DYNAMIC+0x250>
  c14ef3:	jmp    c13298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3978>
  c14ef8:	mov    rsi,QWORD PTR [rax+0x8]
  c14efc:	inc    QWORD PTR [rsi]
  c14eff:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c14f05:	movabs rax,0xffffffff00000000
  c14f0f:	mov    rdx,QWORD PTR [rsp+0x2d0]
  c14f17:	and    rdx,rax
  c14f1a:	or     rdx,0x6
  c14f1e:	mov    rdi,QWORD PTR [rsp+0x210]
  c14f26:	mov    QWORD PTR [rsp+0x2d0],rdx
  c14f2e:	mov    QWORD PTR [rsp+0xc0],rdx
  c14f36:	mov    QWORD PTR [rsp+0x438],rsi
  c14f3e:	mov    QWORD PTR [rsp+0xc8],rsi
  c14f46:	mov    QWORD PTR [rsp+0x210],rdi
  c14f4e:	mov    QWORD PTR [rsp+0xd0],rdi
  c14f56:	lea    rdi,[rsp+0x100]
  c14f5e:	lea    rsi,[rsp+0xe0]
  c14f66:	lea    rdx,[rsp+0xc0]
  c14f6e:	mov    rcx,QWORD PTR [rsp+0x630]
  c14f76:	call   QWORD PTR [rip+0x23cc84]        # e51c00 <_DYNAMIC+0x47a0>
  c14f7c:	movzx  eax,BYTE PTR [rsp+0x100]
  c14f84:	cmp    al,0xff
  c14f86:	jne    c180fb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x87db>
  c14f8c:	lea    rdx,[rsp+0x104]
  c14f94:	mov    rax,QWORD PTR [rdx+0x14]
  c14f98:	lea    rcx,[rsp+0x74]
  c14f9d:	mov    QWORD PTR [rcx+0x13],rax
  c14fa1:	movups xmm0,XMMWORD PTR [rdx+0x4]
  c14fa5:	movups XMMWORD PTR [rcx+0x3],xmm0
  c14fa9:	movdqu xmm0,XMMWORD PTR [rcx+0x3]
  c14fae:	movdqa XMMWORD PTR [rsp+0x30],xmm0
  c14fb4:	mov    rax,QWORD PTR [rcx+0x13]
  c14fb8:	mov    QWORD PTR [rsp+0x40],rax
  c14fbd:	mov    rax,QWORD PTR [rsp+0x8]
  c14fc2:	add    rax,0x10
  c14fc6:	mov    rsi,QWORD PTR [rax]
  c14fc9:	cmp    QWORD PTR [rsp],rsi
  c14fcd:	jae    c19bb9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa299>
  c14fd3:	mov    rdx,QWORD PTR [rbp+0x0]
  c14fd7:	mov    rsi,QWORD PTR [rsp+0x18]
  c14fdc:	lea    rcx,[rdx+rsi*1]
  c14fe0:	mov    rax,r12
  c14fe3:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c14fe8:	jae    c14ff8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56d8>
  c14fea:	mov    rax,QWORD PTR [rcx+0x28]
  c14fee:	shl    r12d,0x4
  c14ff2:	mov    rax,QWORD PTR [rax+r12*1]
  c14ff6:	jmp    c14ffc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56dc>
  c14ff8:	add    rax,QWORD PTR [rcx+0x60]
  c14ffc:	mov    r12,QWORD PTR [rsp+0x8]
  c15001:	mov    rcx,QWORD PTR [r14+0x8]
  c15005:	mov    rdx,QWORD PTR [rsp+0x40]
  c1500a:	mov    QWORD PTR [rsp+0x110],rdx
  c15012:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c15018:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c15021:	cmp    rax,QWORD PTR [r14+0x10]
  c15025:	jae    c18485 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b65>
  c1502b:	lea    rax,[rax+rax*2]
  c1502f:	lea    r14,[rcx+rax*8]
  c15033:	mov    eax,DWORD PTR [rcx+rax*8]
  c15036:	mov    edx,eax
  c15038:	sub    edx,0x2
  c1503b:	mov    ecx,0x3
  c15040:	cmovae ecx,edx
  c15043:	cmp    ecx,0x8
  c15046:	ja     c15a55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6135>
  c1504c:	mov    edx,0x1e7
  c15051:	bt     edx,ecx
  c15054:	jae    c15127 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5807>
  c1505a:	mov    rax,QWORD PTR [rsp+0x40]
  c1505f:	mov    QWORD PTR [r14+0x10],rax
  c15063:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c15069:	movdqu XMMWORD PTR [r14],xmm0
  c1506e:	lea    rax,[r12+0x10]
  c15073:	mov    rsi,QWORD PTR [rax]
  c15076:	cmp    QWORD PTR [rsp],rsi
  c1507a:	jae    c19c67 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa347>
  c15080:	mov    rax,QWORD PTR [rbp+0x0]
  c15084:	mov    r14,QWORD PTR [rsp+0x18]
  c15089:	inc    QWORD PTR [rax+r14*1+0x58]
  c1508e:	mov    eax,DWORD PTR [rsp+0xc0]
  c15095:	mov    edx,eax
  c15097:	sub    edx,0x2
  c1509a:	mov    ecx,0x3
  c1509f:	cmovae ecx,edx
  c150a2:	cmp    ecx,0x8
  c150a5:	mov    rbx,QWORD PTR [rsp+0x10]
  c150aa:	ja     c15a95 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6175>
  c150b0:	mov    edx,0x1e7
  c150b5:	bt     edx,ecx
  c150b8:	jae    c15154 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5834>
  c150be:	mov    eax,DWORD PTR [rsp+0xe0]
  c150c5:	mov    edx,eax
  c150c7:	sub    edx,0x2
  c150ca:	mov    ecx,0x3
  c150cf:	cmovae ecx,edx
  c150d2:	cmp    ecx,0x8
  c150d5:	ja     c15acf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x61af>
  c150db:	mov    edx,0x1e7
  c150e0:	bt     edx,ecx
  c150e3:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c150e9:	cmp    ecx,0x3
  c150ec:	jne    c15ab9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6199>
  c150f2:	test   eax,eax
  c150f4:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c150fa:	mov    rax,QWORD PTR [rsp+0xe8]
  c15102:	dec    QWORD PTR [rax]
  c15105:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c1510b:	lea    rdi,[rsp+0xe8]
  c15113:	call   QWORD PTR [rip+0x23858f]        # e4d6a8 <_DYNAMIC+0x248>
  c15119:	test   r15b,r15b
  c1511c:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c15122:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c15127:	cmp    ecx,0x3
  c1512a:	jne    c15a39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6119>
  c15130:	test   eax,eax
  c15132:	je     c1505a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x573a>
  c15138:	mov    rax,QWORD PTR [r14+0x8]
  c1513c:	dec    QWORD PTR [rax]
  c1513f:	jne    c1505a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x573a>
  c15145:	lea    rdi,[r14+0x8]
  c15149:	call   QWORD PTR [rip+0x238559]        # e4d6a8 <_DYNAMIC+0x248>
  c1514f:	jmp    c1505a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x573a>
  c15154:	cmp    ecx,0x3
  c15157:	jne    c15a71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6151>
  c1515d:	test   eax,eax
  c1515f:	je     c150be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x579e>
  c15165:	mov    rax,QWORD PTR [rsp+0xc8]
  c1516d:	dec    QWORD PTR [rax]
  c15170:	jne    c150be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x579e>
  c15176:	lea    rdi,[rsp+0xc8]
  c1517e:	call   QWORD PTR [rip+0x238524]        # e4d6a8 <_DYNAMIC+0x248>
  c15184:	jmp    c150be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x579e>
  c15189:	mov    rax,QWORD PTR [rsp+0x38]
  c1518e:	dec    QWORD PTR [rax]
  c15191:	jne    c13846 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f26>
  c15197:	lea    rdi,[rsp+0x38]
  c1519c:	call   QWORD PTR [rip+0x23850e]        # e4d6b0 <_DYNAMIC+0x250>
  c151a2:	jmp    c13846 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f26>
  c151a7:	mov    r8,QWORD PTR [rax+0x8]
  c151ab:	inc    QWORD PTR [r8]
  c151ae:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c151b4:	movabs rax,0xffffffff00000000
  c151be:	mov    rdx,QWORD PTR [rsp+0x2c8]
  c151c6:	and    rdx,rax
  c151c9:	or     rdx,0xb
  c151cd:	jmp    c1527c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x595c>
  c151d2:	movabs rax,0xffffffff00000000
  c151dc:	mov    rdx,QWORD PTR [rsp+0x2c8]
  c151e4:	and    rdx,rax
  c151e7:	or     rdx,0x2
  c151eb:	mov    r8,QWORD PTR [rsp+0x430]
  c151f3:	jmp    c1527c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x595c>
  c151f8:	movabs rax,0xffffffff00000000
  c15202:	mov    rdx,QWORD PTR [rsp+0x2c8]
  c1520a:	and    rdx,rax
  c1520d:	or     rdx,0x3
  c15211:	mov    r8,QWORD PTR [rsp+0x430]
  c15219:	jmp    c1527c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x595c>
  c1521b:	mov    rax,QWORD PTR [rsp+0x38]
  c15220:	dec    QWORD PTR [rax]
  c15223:	jne    c13ad7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41b7>
  c15229:	lea    rdi,[rsp+0x38]
  c1522e:	call   QWORD PTR [rip+0x23847c]        # e4d6b0 <_DYNAMIC+0x250>
  c15234:	jmp    c13ad7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41b7>
  c15239:	test   cl,0x1
  c1523c:	je     c16d68 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7448>
  c15242:	mov    r8,QWORD PTR [rax+0x8]
  c15246:	inc    QWORD PTR [r8]
  c15249:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1524f:	mov    edx,0x1
  c15254:	jmp    c15284 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5964>
  c15256:	mov    r8,QWORD PTR [rax+0x8]
  c1525a:	inc    QWORD PTR [r8]
  c1525d:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c15263:	movabs rax,0xffffffff00000000
  c1526d:	mov    rdx,QWORD PTR [rsp+0x2c8]
  c15275:	and    rdx,rax
  c15278:	or     rdx,0x6
  c1527c:	mov    r9,QWORD PTR [rsp+0x208]
  c15284:	mov    QWORD PTR [rsp+0x70],rdx
  c15289:	mov    QWORD PTR [rsp+0x78],r8
  c1528e:	mov    QWORD PTR [rsp+0x80],r9
  c15296:	mov    rsi,QWORD PTR [r11]
  c15299:	cmp    rdi,rsi
  c1529c:	jae    c19ac8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1a8>
  c152a2:	mov    QWORD PTR [rsp+0x448],r14
  c152aa:	mov    QWORD PTR [rsp+0x2e8],rbx
  c152b2:	mov    rcx,QWORD PTR [rbp+0x0]
  c152b6:	mov    rsi,QWORD PTR [rsp+0x18]
  c152bb:	lea    rax,[rcx+rsi*1]
  c152bf:	mov    rbx,r12
  c152c2:	sub    rbx,QWORD PTR [rcx+rsi*1+0x30]
  c152c7:	mov    QWORD PTR [rsp+0x2c8],rdx
  c152cf:	mov    QWORD PTR [rsp+0x430],r8
  c152d7:	mov    QWORD PTR [rsp+0x208],r9
  c152df:	mov    ebp,r15d
  c152e2:	jae    c152f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59d2>
  c152e4:	mov    rax,QWORD PTR [rax+0x28]
  c152e8:	shl    r12d,0x4
  c152ec:	mov    rbx,QWORD PTR [rax+r12*1]
  c152f0:	jmp    c152f6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59d6>
  c152f2:	add    rbx,QWORD PTR [rax+0x60]
  c152f6:	mov    r12,QWORD PTR [rsp+0x8]
  c152fb:	mov    r15,QWORD PTR [r10+0x8]
  c152ff:	mov    r14,QWORD PTR [r10+0x10]
  c15303:	lea    rdi,[rsp+0x30]
  c15308:	lea    rsi,[rsp+0x70]
  c1530d:	call   QWORD PTR [rip+0x23d97d]        # e52c90 <_DYNAMIC+0x5830>
  c15313:	mov    BYTE PTR [rsp+0x104],al
  c1531a:	mov    DWORD PTR [rsp+0x100],0x4
  c15325:	cmp    rbx,r14
  c15328:	jae    c18175 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8855>
  c1532e:	lea    rax,[rbx+rbx*2]
  c15332:	lea    r14,[r15+rax*8]
  c15336:	mov    eax,DWORD PTR [r15+rax*8]
  c1533a:	mov    edx,eax
  c1533c:	sub    edx,0x2
  c1533f:	mov    ecx,0x3
  c15344:	cmovae ecx,edx
  c15347:	cmp    ecx,0x8
  c1534a:	ja     c15900 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5fe0>
  c15350:	mov    edx,0x1e7
  c15355:	bt     edx,ecx
  c15358:	mov    rbx,QWORD PTR [rsp+0x18]
  c1535d:	mov    r15d,ebp
  c15360:	mov    rbp,QWORD PTR [rsp+0x198]
  c15368:	jae    c1541b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5afb>
  c1536e:	mov    rax,QWORD PTR [rsp+0x110]
  c15376:	mov    QWORD PTR [r14+0x10],rax
  c1537a:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c15383:	movdqu XMMWORD PTR [r14],xmm0
  c15388:	lea    rax,[r12+0x10]
  c1538d:	mov    rsi,QWORD PTR [rax]
  c15390:	cmp    QWORD PTR [rsp],rsi
  c15394:	jae    c19ba3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa283>
  c1539a:	mov    rax,QWORD PTR [rbp+0x0]
  c1539e:	mov    r14,rbx
  c153a1:	inc    QWORD PTR [rax+rbx*1+0x58]
  c153a6:	mov    eax,DWORD PTR [rsp+0x70]
  c153aa:	mov    edx,eax
  c153ac:	sub    edx,0x2
  c153af:	mov    ecx,0x3
  c153b4:	cmovae ecx,edx
  c153b7:	cmp    ecx,0x8
  c153ba:	mov    rbx,QWORD PTR [rsp+0x10]
  c153bf:	ja     c15986 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6066>
  c153c5:	mov    edx,0x1e7
  c153ca:	bt     edx,ecx
  c153cd:	jae    c15448 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b28>
  c153cf:	mov    eax,DWORD PTR [rsp+0x30]
  c153d3:	mov    edx,eax
  c153d5:	sub    edx,0x2
  c153d8:	mov    ecx,0x3
  c153dd:	cmovae ecx,edx
  c153e0:	cmp    ecx,0x8
  c153e3:	ja     c159e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60c7>
  c153e9:	mov    edx,0x1e7
  c153ee:	bt     edx,ecx
  c153f1:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c153f7:	cmp    ecx,0x3
  c153fa:	jne    c159bc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x609c>
  c15400:	test   eax,eax
  c15402:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15408:	mov    rax,QWORD PTR [rsp+0x38]
  c1540d:	dec    QWORD PTR [rax]
  c15410:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15416:	jmp    c1585c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f3c>
  c1541b:	cmp    ecx,0x3
  c1541e:	jne    c158b8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f98>
  c15424:	test   eax,eax
  c15426:	je     c1536e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a4e>
  c1542c:	mov    rax,QWORD PTR [r14+0x8]
  c15430:	dec    QWORD PTR [rax]
  c15433:	jne    c1536e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a4e>
  c15439:	lea    rdi,[r14+0x8]
  c1543d:	call   QWORD PTR [rip+0x238265]        # e4d6a8 <_DYNAMIC+0x248>
  c15443:	jmp    c1536e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a4e>
  c15448:	cmp    ecx,0x3
  c1544b:	jne    c1594a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x602a>
  c15451:	test   eax,eax
  c15453:	je     c153cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5aaf>
  c15459:	mov    rax,QWORD PTR [rsp+0x78]
  c1545e:	dec    QWORD PTR [rax]
  c15461:	jne    c153cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5aaf>
  c15467:	lea    rdi,[rsp+0x78]
  c1546c:	call   QWORD PTR [rip+0x238236]        # e4d6a8 <_DYNAMIC+0x248>
  c15472:	jmp    c153cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5aaf>
  c15477:	mov    rax,QWORD PTR [rsp+0x78]
  c1547c:	dec    QWORD PTR [rax]
  c1547f:	jne    c13dc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44a0>
  c15485:	lea    rdi,[rsp+0x78]
  c1548a:	call   QWORD PTR [rip+0x238220]        # e4d6b0 <_DYNAMIC+0x250>
  c15490:	jmp    c13dc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44a0>
  c15495:	mov    rax,QWORD PTR [r14+0x8]
  c15499:	dec    QWORD PTR [rax]
  c1549c:	jne    c12ef5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x35d5>
  c154a2:	lea    rdi,[r14+0x8]
  c154a6:	call   QWORD PTR [rip+0x23820c]        # e4d6b8 <_DYNAMIC+0x258>
  c154ac:	jmp    c12ef5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x35d5>
  c154b1:	mov    rax,QWORD PTR [rsp+0x78]
  c154b6:	dec    QWORD PTR [rax]
  c154b9:	jne    c13298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3978>
  c154bf:	lea    rdi,[rsp+0x78]
  c154c4:	call   QWORD PTR [rip+0x2381ee]        # e4d6b8 <_DYNAMIC+0x258>
  c154ca:	jmp    c13298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3978>
  c154cf:	mov    rax,QWORD PTR [rsp+0x38]
  c154d4:	dec    QWORD PTR [rax]
  c154d7:	jne    c13846 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f26>
  c154dd:	lea    rdi,[rsp+0x38]
  c154e2:	call   QWORD PTR [rip+0x2381d0]        # e4d6b8 <_DYNAMIC+0x258>
  c154e8:	jmp    c13846 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f26>
  c154ed:	mov    rax,QWORD PTR [rsp+0x38]
  c154f2:	dec    QWORD PTR [rax]
  c154f5:	jne    c13ad7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41b7>
  c154fb:	lea    rdi,[rsp+0x38]
  c15500:	call   QWORD PTR [rip+0x2381b2]        # e4d6b8 <_DYNAMIC+0x258>
  c15506:	jmp    c13ad7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41b7>
  c1550b:	mov    rax,QWORD PTR [rsp+0x78]
  c15510:	dec    QWORD PTR [rax]
  c15513:	jne    c13dc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44a0>
  c15519:	lea    rdi,[rsp+0x78]
  c1551e:	call   QWORD PTR [rip+0x238194]        # e4d6b8 <_DYNAMIC+0x258>
  c15524:	jmp    c13dc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44a0>
  c15529:	mov    rax,QWORD PTR [r14+0x8]
  c1552d:	dec    QWORD PTR [rax]
  c15530:	jne    c11a75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2155>
  c15536:	lea    rdi,[r14+0x8]
  c1553a:	call   QWORD PTR [rip+0x238170]        # e4d6b0 <_DYNAMIC+0x250>
  c15540:	jmp    c11a75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2155>
  c15545:	mov    rax,QWORD PTR [r14+0x8]
  c15549:	dec    QWORD PTR [rax]
  c1554c:	jne    c11a75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2155>
  c15552:	lea    rdi,[r14+0x8]
  c15556:	call   QWORD PTR [rip+0x23815c]        # e4d6b8 <_DYNAMIC+0x258>
  c1555c:	jmp    c11a75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2155>
  c15561:	mov    rax,QWORD PTR [r14+0x8]
  c15565:	dec    QWORD PTR [rax]
  c15568:	jne    c117ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e8c>
  c1556e:	lea    rdi,[r14+0x8]
  c15572:	call   QWORD PTR [rip+0x238138]        # e4d6b0 <_DYNAMIC+0x250>
  c15578:	jmp    c117ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e8c>
  c1557d:	mov    rax,QWORD PTR [r14+0x8]
  c15581:	dec    QWORD PTR [rax]
  c15584:	lea    rbp,[r12+0x8]
  c15589:	jne    c117ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e8c>
  c1558f:	lea    rdi,[r14+0x8]
  c15593:	call   QWORD PTR [rip+0x23811f]        # e4d6b8 <_DYNAMIC+0x258>
  c15599:	jmp    c117ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e8c>
  c1559e:	mov    rax,QWORD PTR [r14+0x8]
  c155a2:	dec    QWORD PTR [rax]
  c155a5:	jne    c1356a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c4a>
  c155ab:	lea    rdi,[r14+0x8]
  c155af:	call   QWORD PTR [rip+0x2380fb]        # e4d6b0 <_DYNAMIC+0x250>
  c155b5:	jmp    c1356a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c4a>
  c155ba:	mov    rax,QWORD PTR [rsp+0x108]
  c155c2:	dec    QWORD PTR [rax]
  c155c5:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c155cb:	lea    rdi,[rsp+0x108]
  c155d3:	jmp    c15c65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6345>
  c155d8:	mov    rax,QWORD PTR [r14+0x8]
  c155dc:	dec    QWORD PTR [rax]
  c155df:	jne    c1356a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c4a>
  c155e5:	lea    rdi,[r14+0x8]
  c155e9:	call   QWORD PTR [rip+0x2380c9]        # e4d6b8 <_DYNAMIC+0x258>
  c155ef:	jmp    c1356a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c4a>
  c155f4:	mov    rax,QWORD PTR [rsp+0x108]
  c155fc:	dec    QWORD PTR [rax]
  c155ff:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15605:	lea    rdi,[rsp+0x108]
  c1560d:	call   QWORD PTR [rip+0x2380a5]        # e4d6b8 <_DYNAMIC+0x258>
  c15613:	test   r15b,r15b
  c15616:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c1561c:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c15621:	mov    rax,QWORD PTR [r14+0x8]
  c15625:	dec    QWORD PTR [rax]
  c15628:	jne    c138e5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3fc5>
  c1562e:	lea    rdi,[r14+0x8]
  c15632:	call   QWORD PTR [rip+0x238078]        # e4d6b0 <_DYNAMIC+0x250>
  c15638:	jmp    c138e5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3fc5>
  c1563d:	mov    rax,QWORD PTR [r14+0x8]
  c15641:	dec    QWORD PTR [rax]
  c15644:	jne    c13b76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4256>
  c1564a:	lea    rdi,[r14+0x8]
  c1564e:	call   QWORD PTR [rip+0x23805c]        # e4d6b0 <_DYNAMIC+0x250>
  c15654:	jmp    c13b76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4256>
  c15659:	mov    rax,QWORD PTR [r14+0x8]
  c1565d:	dec    QWORD PTR [rax]
  c15660:	jne    c138e5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3fc5>
  c15666:	lea    rdi,[r14+0x8]
  c1566a:	call   QWORD PTR [rip+0x238048]        # e4d6b8 <_DYNAMIC+0x258>
  c15670:	jmp    c138e5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3fc5>
  c15675:	mov    rax,QWORD PTR [r14+0x8]
  c15679:	dec    QWORD PTR [rax]
  c1567c:	jne    c13b76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4256>
  c15682:	lea    rdi,[r14+0x8]
  c15686:	call   QWORD PTR [rip+0x23802c]        # e4d6b8 <_DYNAMIC+0x258>
  c1568c:	jmp    c13b76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4256>
  c15691:	mov    rax,QWORD PTR [rsp+0x78]
  c15696:	dec    QWORD PTR [rax]
  c15699:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c1569f:	lea    rdi,[rsp+0x78]
  c156a4:	jmp    c15c65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6345>
  c156a9:	mov    rax,QWORD PTR [rsp+0x78]
  c156ae:	dec    QWORD PTR [rax]
  c156b1:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c156b7:	jmp    c15a20 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6100>
  c156bc:	mov    rsi,QWORD PTR [rax+0x8]
  c156c0:	inc    QWORD PTR [rsi]
  c156c3:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c156c9:	movabs rax,0xffffffff00000000
  c156d3:	mov    rdx,QWORD PTR [rsp+0x290]
  c156db:	and    rdx,rax
  c156de:	or     rdx,0xb
  c156e2:	jmp    c15770 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e50>
  c156e7:	movabs rax,0xffffffff00000000
  c156f1:	mov    rdx,QWORD PTR [rsp+0x290]
  c156f9:	and    rdx,rax
  c156fc:	or     rdx,0x2
  c15700:	mov    rsi,QWORD PTR [rsp+0x3f8]
  c15708:	jmp    c15770 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e50>
  c1570a:	movabs rax,0xffffffff00000000
  c15714:	mov    rdx,QWORD PTR [rsp+0x290]
  c1571c:	and    rdx,rax
  c1571f:	or     rdx,0x3
  c15723:	mov    rsi,QWORD PTR [rsp+0x3f8]
  c1572b:	jmp    c15770 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e50>
  c1572d:	test   cl,0x1
  c15730:	je     c16d7f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x745f>
  c15736:	mov    rsi,QWORD PTR [rax+0x8]
  c1573a:	inc    QWORD PTR [rsi]
  c1573d:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c15743:	mov    edx,0x1
  c15748:	jmp    c15778 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e58>
  c1574a:	mov    rsi,QWORD PTR [rax+0x8]
  c1574e:	inc    QWORD PTR [rsi]
  c15751:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c15757:	movabs rax,0xffffffff00000000
  c15761:	mov    rdx,QWORD PTR [rsp+0x290]
  c15769:	and    rdx,rax
  c1576c:	or     rdx,0x6
  c15770:	mov    rdi,QWORD PTR [rsp+0x1e8]
  c15778:	mov    QWORD PTR [rsp+0x290],rdx
  c15780:	mov    QWORD PTR [rsp+0x5d0],rdx
  c15788:	mov    QWORD PTR [rsp+0x3f8],rsi
  c15790:	mov    QWORD PTR [rsp+0x5d8],rsi
  c15798:	mov    QWORD PTR [rsp+0x1e8],rdi
  c157a0:	mov    QWORD PTR [rsp+0x5e0],rdi
  c157a8:	lea    rdi,[rsp+0x100]
  c157b0:	lea    rsi,[rsp+0x30]
  c157b5:	lea    rdx,[rsp+0x70]
  c157ba:	lea    rcx,[rsp+0x5d0]
  c157c2:	call   QWORD PTR [rip+0x23d4e0]        # e52ca8 <_DYNAMIC+0x5848>
  c157c8:	cmp    BYTE PTR [rsp+0x100],0xff
  c157d0:	jne    c184ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bcc>
  c157d6:	lea    rax,[r12+0x10]
  c157db:	mov    rsi,QWORD PTR [rax]
  c157de:	cmp    QWORD PTR [rsp],rsi
  c157e2:	jae    c19c1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2fe>
  c157e8:	mov    rax,QWORD PTR [rbp+0x0]
  c157ec:	inc    QWORD PTR [rax+r14*1+0x58]
  c157f1:	mov    eax,DWORD PTR [rsp+0x70]
  c157f5:	mov    edx,eax
  c157f7:	sub    edx,0x2
  c157fa:	mov    ecx,0x3
  c157ff:	cmovae ecx,edx
  c15802:	cmp    ecx,0x8
  c15805:	ja     c15b91 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6271>
  c1580b:	mov    edx,0x1e7
  c15810:	bt     edx,ecx
  c15813:	jae    c15875 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f55>
  c15815:	mov    eax,DWORD PTR [rsp+0x30]
  c15819:	mov    edx,eax
  c1581b:	sub    edx,0x2
  c1581e:	mov    ecx,0x3
  c15823:	cmovae ecx,edx
  c15826:	cmp    ecx,0x8
  c15829:	ja     c15bc7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62a7>
  c1582f:	mov    edx,0x1e7
  c15834:	bt     edx,ecx
  c15837:	jb     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c1583d:	cmp    ecx,0x3
  c15840:	jne    c15baf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x628f>
  c15846:	test   eax,eax
  c15848:	je     c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c1584e:	mov    rax,QWORD PTR [rsp+0x38]
  c15853:	dec    QWORD PTR [rax]
  c15856:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c1585c:	lea    rdi,[rsp+0x38]
  c15861:	call   QWORD PTR [rip+0x237e41]        # e4d6a8 <_DYNAMIC+0x248>
  c15867:	test   r15b,r15b
  c1586a:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c15870:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c15875:	cmp    ecx,0x3
  c15878:	jne    c15b73 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6253>
  c1587e:	test   eax,eax
  c15880:	je     c15815 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ef5>
  c15882:	mov    rax,QWORD PTR [rsp+0x78]
  c15887:	dec    QWORD PTR [rax]
  c1588a:	jne    c15815 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ef5>
  c1588c:	lea    rdi,[rsp+0x78]
  c15891:	call   QWORD PTR [rip+0x237e11]        # e4d6a8 <_DYNAMIC+0x248>
  c15897:	jmp    c15815 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ef5>
  c1589c:	mov    rax,QWORD PTR [r14+0x8]
  c158a0:	dec    QWORD PTR [rax]
  c158a3:	jne    c14d6b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x544b>
  c158a9:	lea    rdi,[r14+0x8]
  c158ad:	call   QWORD PTR [rip+0x237dfd]        # e4d6b0 <_DYNAMIC+0x250>
  c158b3:	jmp    c14d6b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x544b>
  c158b8:	mov    rax,QWORD PTR [r14+0x8]
  c158bc:	dec    QWORD PTR [rax]
  c158bf:	jne    c1536e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a4e>
  c158c5:	lea    rdi,[r14+0x8]
  c158c9:	call   QWORD PTR [rip+0x237de1]        # e4d6b0 <_DYNAMIC+0x250>
  c158cf:	jmp    c1536e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a4e>
  c158d4:	mov    rax,QWORD PTR [r14+0x8]
  c158d8:	dec    QWORD PTR [rax]
  c158db:	mov    rbx,QWORD PTR [rsp+0x18]
  c158e0:	mov    r15d,ebp
  c158e3:	mov    rbp,QWORD PTR [rsp+0x198]
  c158eb:	jne    c14d6b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x544b>
  c158f1:	lea    rdi,[r14+0x8]
  c158f5:	call   QWORD PTR [rip+0x237dbd]        # e4d6b8 <_DYNAMIC+0x258>
  c158fb:	jmp    c14d6b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x544b>
  c15900:	mov    rax,QWORD PTR [r14+0x8]
  c15904:	dec    QWORD PTR [rax]
  c15907:	mov    rbx,QWORD PTR [rsp+0x18]
  c1590c:	mov    r15d,ebp
  c1590f:	mov    rbp,QWORD PTR [rsp+0x198]
  c15917:	jne    c1536e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a4e>
  c1591d:	lea    rdi,[r14+0x8]
  c15921:	call   QWORD PTR [rip+0x237d91]        # e4d6b8 <_DYNAMIC+0x258>
  c15927:	jmp    c1536e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a4e>
  c1592c:	mov    rax,QWORD PTR [rsp+0x78]
  c15931:	dec    QWORD PTR [rax]
  c15934:	jne    c14dcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54ac>
  c1593a:	lea    rdi,[rsp+0x78]
  c1593f:	call   QWORD PTR [rip+0x237d6b]        # e4d6b0 <_DYNAMIC+0x250>
  c15945:	jmp    c14dcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54ac>
  c1594a:	mov    rax,QWORD PTR [rsp+0x78]
  c1594f:	dec    QWORD PTR [rax]
  c15952:	jne    c153cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5aaf>
  c15958:	lea    rdi,[rsp+0x78]
  c1595d:	call   QWORD PTR [rip+0x237d4d]        # e4d6b0 <_DYNAMIC+0x250>
  c15963:	jmp    c153cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5aaf>
  c15968:	mov    rax,QWORD PTR [rsp+0x78]
  c1596d:	dec    QWORD PTR [rax]
  c15970:	jne    c14dcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54ac>
  c15976:	lea    rdi,[rsp+0x78]
  c1597b:	call   QWORD PTR [rip+0x237d37]        # e4d6b8 <_DYNAMIC+0x258>
  c15981:	jmp    c14dcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54ac>
  c15986:	mov    rax,QWORD PTR [rsp+0x78]
  c1598b:	dec    QWORD PTR [rax]
  c1598e:	jne    c153cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5aaf>
  c15994:	lea    rdi,[rsp+0x78]
  c15999:	call   QWORD PTR [rip+0x237d19]        # e4d6b8 <_DYNAMIC+0x258>
  c1599f:	jmp    c153cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5aaf>
  c159a4:	mov    rax,QWORD PTR [rsp+0x38]
  c159a9:	dec    QWORD PTR [rax]
  c159ac:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c159b2:	lea    rdi,[rsp+0x38]
  c159b7:	jmp    c15c65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6345>
  c159bc:	mov    rax,QWORD PTR [rsp+0x38]
  c159c1:	dec    QWORD PTR [rax]
  c159c4:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c159ca:	lea    rdi,[rsp+0x38]
  c159cf:	jmp    c15c65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6345>
  c159d4:	mov    rax,QWORD PTR [rsp+0x38]
  c159d9:	dec    QWORD PTR [rax]
  c159dc:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c159e2:	jmp    c15bd5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62b5>
  c159e7:	mov    rax,QWORD PTR [rsp+0x38]
  c159ec:	dec    QWORD PTR [rax]
  c159ef:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c159f5:	jmp    c15bd5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62b5>
  c159fa:	mov    rax,QWORD PTR [rsp+0x78]
  c159ff:	dec    QWORD PTR [rax]
  c15a02:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15a08:	lea    rdi,[rsp+0x78]
  c15a0d:	jmp    c15c65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6345>
  c15a12:	mov    rax,QWORD PTR [rsp+0x78]
  c15a17:	dec    QWORD PTR [rax]
  c15a1a:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15a20:	lea    rdi,[rsp+0x78]
  c15a25:	call   QWORD PTR [rip+0x237c8d]        # e4d6b8 <_DYNAMIC+0x258>
  c15a2b:	test   r15b,r15b
  c15a2e:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c15a34:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c15a39:	mov    rax,QWORD PTR [r14+0x8]
  c15a3d:	dec    QWORD PTR [rax]
  c15a40:	jne    c1505a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x573a>
  c15a46:	lea    rdi,[r14+0x8]
  c15a4a:	call   QWORD PTR [rip+0x237c60]        # e4d6b0 <_DYNAMIC+0x250>
  c15a50:	jmp    c1505a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x573a>
  c15a55:	mov    rax,QWORD PTR [r14+0x8]
  c15a59:	dec    QWORD PTR [rax]
  c15a5c:	jne    c1505a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x573a>
  c15a62:	lea    rdi,[r14+0x8]
  c15a66:	call   QWORD PTR [rip+0x237c4c]        # e4d6b8 <_DYNAMIC+0x258>
  c15a6c:	jmp    c1505a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x573a>
  c15a71:	mov    rax,QWORD PTR [rsp+0xc8]
  c15a79:	dec    QWORD PTR [rax]
  c15a7c:	jne    c150be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x579e>
  c15a82:	lea    rdi,[rsp+0xc8]
  c15a8a:	call   QWORD PTR [rip+0x237c20]        # e4d6b0 <_DYNAMIC+0x250>
  c15a90:	jmp    c150be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x579e>
  c15a95:	mov    rax,QWORD PTR [rsp+0xc8]
  c15a9d:	dec    QWORD PTR [rax]
  c15aa0:	jne    c150be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x579e>
  c15aa6:	lea    rdi,[rsp+0xc8]
  c15aae:	call   QWORD PTR [rip+0x237c04]        # e4d6b8 <_DYNAMIC+0x258>
  c15ab4:	jmp    c150be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x579e>
  c15ab9:	mov    rax,QWORD PTR [rsp+0xe8]
  c15ac1:	dec    QWORD PTR [rax]
  c15ac4:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15aca:	jmp    c15c5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x633d>
  c15acf:	mov    rax,QWORD PTR [rsp+0xe8]
  c15ad7:	dec    QWORD PTR [rax]
  c15ada:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15ae0:	jmp    c15c8f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x636f>
  c15ae5:	mov    rax,QWORD PTR [r14+0x8]
  c15ae9:	dec    QWORD PTR [rax]
  c15aec:	jne    c12713 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2df3>
  c15af2:	lea    rdi,[r14+0x8]
  c15af6:	call   QWORD PTR [rip+0x237bb4]        # e4d6b0 <_DYNAMIC+0x250>
  c15afc:	jmp    c12713 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2df3>
  c15b01:	mov    rax,QWORD PTR [r14+0x8]
  c15b05:	dec    QWORD PTR [rax]
  c15b08:	jne    c12713 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2df3>
  c15b0e:	lea    rdi,[r14+0x8]
  c15b12:	call   QWORD PTR [rip+0x237ba0]        # e4d6b8 <_DYNAMIC+0x258>
  c15b18:	jmp    c12713 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2df3>
  c15b1d:	mov    rax,QWORD PTR [rsp+0x360]
  c15b25:	dec    QWORD PTR [rax]
  c15b28:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15b2e:	lea    rdi,[rsp+0x360]
  c15b36:	jmp    c15c65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6345>
  c15b3b:	mov    rax,QWORD PTR [rsp+0x360]
  c15b43:	dec    QWORD PTR [rax]
  c15b46:	mov    r12,QWORD PTR [rsp+0x8]
  c15b4b:	mov    rbp,rbx
  c15b4e:	mov    rbx,rsi
  c15b51:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15b57:	lea    rdi,[rsp+0x360]
  c15b5f:	call   QWORD PTR [rip+0x237b53]        # e4d6b8 <_DYNAMIC+0x258>
  c15b65:	test   r15b,r15b
  c15b68:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c15b6e:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c15b73:	mov    rax,QWORD PTR [rsp+0x78]
  c15b78:	dec    QWORD PTR [rax]
  c15b7b:	jne    c15815 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ef5>
  c15b81:	lea    rdi,[rsp+0x78]
  c15b86:	call   QWORD PTR [rip+0x237b24]        # e4d6b0 <_DYNAMIC+0x250>
  c15b8c:	jmp    c15815 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ef5>
  c15b91:	mov    rax,QWORD PTR [rsp+0x78]
  c15b96:	dec    QWORD PTR [rax]
  c15b99:	jne    c15815 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ef5>
  c15b9f:	lea    rdi,[rsp+0x78]
  c15ba4:	call   QWORD PTR [rip+0x237b0e]        # e4d6b8 <_DYNAMIC+0x258>
  c15baa:	jmp    c15815 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ef5>
  c15baf:	mov    rax,QWORD PTR [rsp+0x38]
  c15bb4:	dec    QWORD PTR [rax]
  c15bb7:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15bbd:	lea    rdi,[rsp+0x38]
  c15bc2:	jmp    c15c65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6345>
  c15bc7:	mov    rax,QWORD PTR [rsp+0x38]
  c15bcc:	dec    QWORD PTR [rax]
  c15bcf:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15bd5:	lea    rdi,[rsp+0x38]
  c15bda:	call   QWORD PTR [rip+0x237ad8]        # e4d6b8 <_DYNAMIC+0x258>
  c15be0:	test   r15b,r15b
  c15be3:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c15be9:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c15bee:	mov    rax,QWORD PTR [r14+0x8]
  c15bf2:	dec    QWORD PTR [rax]
  c15bf5:	jne    c12146 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2826>
  c15bfb:	lea    rdi,[r14+0x8]
  c15bff:	call   QWORD PTR [rip+0x237aab]        # e4d6b0 <_DYNAMIC+0x250>
  c15c05:	jmp    c12146 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2826>
  c15c0a:	mov    rax,QWORD PTR [r14+0x8]
  c15c0e:	dec    QWORD PTR [rax]
  c15c11:	jne    c12146 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2826>
  c15c17:	lea    rdi,[r14+0x8]
  c15c1b:	call   QWORD PTR [rip+0x237a97]        # e4d6b8 <_DYNAMIC+0x258>
  c15c21:	jmp    c12146 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2826>
  c15c26:	mov    rax,QWORD PTR [rsp+0xe8]
  c15c2e:	dec    QWORD PTR [rax]
  c15c31:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15c37:	jmp    c15c5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x633d>
  c15c39:	mov    rax,QWORD PTR [rsp+0xe8]
  c15c41:	dec    QWORD PTR [rax]
  c15c44:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15c4a:	jmp    c15c8f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x636f>
  c15c4c:	mov    rax,QWORD PTR [rsp+0xe8]
  c15c54:	dec    QWORD PTR [rax]
  c15c57:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15c5d:	lea    rdi,[rsp+0xe8]
  c15c65:	call   QWORD PTR [rip+0x237a45]        # e4d6b0 <_DYNAMIC+0x250>
  c15c6b:	test   r15b,r15b
  c15c6e:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c15c74:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c15c79:	mov    rax,QWORD PTR [rsp+0xe8]
  c15c81:	dec    QWORD PTR [rax]
  c15c84:	lea    rbp,[r12+0x8]
  c15c89:	jne    c16b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7240>
  c15c8f:	lea    rdi,[rsp+0xe8]
  c15c97:	call   QWORD PTR [rip+0x237a1b]        # e4d6b8 <_DYNAMIC+0x258>
  c15c9d:	test   r15b,r15b
  c15ca0:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c15ca6:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c15cab:	mov    rax,QWORD PTR [rsp+0x1c8]
  c15cb3:	inc    QWORD PTR [rax]
  c15cb6:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c15cbc:	mov    QWORD PTR [rsp+0x108],rax
  c15cc4:	mov    DWORD PTR [rsp+0x100],0xb
  c15ccf:	jmp    c14a55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5135>
  c15cd4:	mov    DWORD PTR [rsp+0x100],0x2
  c15cdf:	jmp    c14a55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5135>
  c15ce4:	mov    DWORD PTR [rsp+0x100],0x3
  c15cef:	jmp    c14a55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5135>
  c15cf4:	test   dil,0x1
  c15cf8:	je     c16d96 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7476>
  c15cfe:	mov    rax,QWORD PTR [rsp+0x1c8]
  c15d06:	inc    QWORD PTR [rax]
  c15d09:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c15d0f:	mov    ecx,0x1
  c15d14:	jmp    c16d9f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x747f>
  c15d19:	mov    rax,QWORD PTR [rsp+0x1c8]
  c15d21:	inc    QWORD PTR [rax]
  c15d24:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c15d2a:	mov    QWORD PTR [rsp+0x108],rax
  c15d32:	mov    DWORD PTR [rsp+0x100],0x6
  c15d3d:	jmp    c14a55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5135>
  c15d42:	mov    esi,DWORD PTR [rcx+0x4]
  c15d45:	mov    rdx,QWORD PTR [rcx+0x8]
  c15d49:	mov    rcx,QWORD PTR [rcx+0x10]
  c15d4d:	mov    r9,QWORD PTR [rsp+0x20]
  c15d52:	mov    DWORD PTR [rsp+0x70],eax
  c15d56:	mov    DWORD PTR [rsp+0x74],esi
  c15d5a:	mov    QWORD PTR [rsp+0x78],rdx
  c15d5f:	mov    QWORD PTR [rsp+0x80],rcx
  c15d67:	mov    rsi,QWORD PTR [r8]
  c15d6a:	cmp    rdi,rsi
  c15d6d:	jae    c199a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa086>
  c15d73:	mov    rdx,QWORD PTR [rbp+0x0]
  c15d77:	lea    rcx,[rdx+r10*1]
  c15d7b:	mov    rax,r12
  c15d7e:	sub    rax,QWORD PTR [rdx+r10*1+0x30]
  c15d83:	jae    c15d93 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6473>
  c15d85:	mov    rax,QWORD PTR [rcx+0x28]
  c15d89:	shl    r12d,0x4
  c15d8d:	mov    rax,QWORD PTR [rax+r12*1]
  c15d91:	jmp    c15d97 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6477>
  c15d93:	add    rax,QWORD PTR [rcx+0x60]
  c15d97:	mov    r12,QWORD PTR [rsp+0x8]
  c15d9c:	mov    rcx,QWORD PTR [r9+0x8]
  c15da0:	mov    rdx,QWORD PTR [rsp+0x80]
  c15da8:	mov    QWORD PTR [rsp+0x110],rdx
  c15db0:	movdqa xmm0,XMMWORD PTR [rsp+0x70]
  c15db6:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c15dbf:	cmp    rax,QWORD PTR [r9+0x10]
  c15dc3:	jae    c17a0b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80eb>
  c15dc9:	lea    rax,[rax+rax*2]
  c15dcd:	lea    r14,[rcx+rax*8]
  c15dd1:	mov    eax,DWORD PTR [rcx+rax*8]
  c15dd4:	mov    edx,eax
  c15dd6:	sub    edx,0x2
  c15dd9:	mov    ecx,0x3
  c15dde:	cmovae ecx,edx
  c15de1:	cmp    ecx,0x8
  c15de4:	ja     c15e51 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6531>
  c15de6:	mov    edx,0x1e7
  c15deb:	bt     edx,ecx
  c15dee:	jae    c15e1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64fe>
  c15df0:	mov    rax,QWORD PTR [rsp+0x80]
  c15df8:	mov    QWORD PTR [r14+0x10],rax
  c15dfc:	movdqa xmm0,XMMWORD PTR [rsp+0x70]
  c15e02:	movdqu XMMWORD PTR [r14],xmm0
  c15e07:	lea    rax,[r12+0x10]
  c15e0c:	mov    rsi,QWORD PTR [rax]
  c15e0f:	cmp    QWORD PTR [rsp],rsi
  c15e13:	jb     c16140 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6820>
  c15e19:	jmp    c19b2b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa20b>
  c15e1e:	cmp    ecx,0x3
  c15e21:	jne    c15e3c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x651c>
  c15e23:	test   eax,eax
  c15e25:	je     c15df0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d0>
  c15e27:	mov    rax,QWORD PTR [r14+0x8]
  c15e2b:	dec    QWORD PTR [rax]
  c15e2e:	jne    c15df0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d0>
  c15e30:	lea    rdi,[r14+0x8]
  c15e34:	call   QWORD PTR [rip+0x23786e]        # e4d6a8 <_DYNAMIC+0x248>
  c15e3a:	jmp    c15df0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d0>
  c15e3c:	mov    rax,QWORD PTR [r14+0x8]
  c15e40:	dec    QWORD PTR [rax]
  c15e43:	jne    c15df0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d0>
  c15e45:	lea    rdi,[r14+0x8]
  c15e49:	call   QWORD PTR [rip+0x237861]        # e4d6b0 <_DYNAMIC+0x250>
  c15e4f:	jmp    c15df0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d0>
  c15e51:	mov    rax,QWORD PTR [r14+0x8]
  c15e55:	dec    QWORD PTR [rax]
  c15e58:	jne    c15df0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d0>
  c15e5a:	lea    rdi,[r14+0x8]
  c15e5e:	call   QWORD PTR [rip+0x237854]        # e4d6b8 <_DYNAMIC+0x258>
  c15e64:	jmp    c15df0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d0>
  c15e66:	mov    rsi,QWORD PTR [rax+0x8]
  c15e6a:	mov    rdi,QWORD PTR [rax+0x10]
  c15e6e:	mov    edx,DWORD PTR [rax+0x4]
  c15e71:	shl    rdx,0x20
  c15e75:	or     rdx,rcx
  c15e78:	mov    rcx,rdi
  c15e7b:	mov    rax,QWORD PTR [rsp+0x190]
  c15e83:	jmp    c11de0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x24c0>
  c15e88:	mov    rdi,QWORD PTR [rcx+0x8]
  c15e8c:	mov    r8,QWORD PTR [rcx+0x10]
  c15e90:	mov    esi,DWORD PTR [rcx+0x4]
  c15e93:	mov    rcx,r8
  c15e96:	shl    rsi,0x20
  c15e9a:	or     rsi,rdx
  c15e9d:	jmp    c122c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x29a0>
  c15ea2:	mov    rdi,QWORD PTR [rdx+0x8]
  c15ea6:	mov    r8,QWORD PTR [rdx+0x10]
  c15eaa:	mov    ecx,DWORD PTR [rdx+0x4]
  c15ead:	shl    rcx,0x20
  c15eb1:	or     rcx,rsi
  c15eb4:	movq   xmm1,r8
  c15eb9:	movq   xmm0,rdi
  c15ebe:	punpcklqdq xmm0,xmm1
  c15ec2:	jmp    c10cd7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b7>
  c15ec7:	mov    rdi,QWORD PTR [rdx+0x8]
  c15ecb:	mov    r8,QWORD PTR [rdx+0x10]
  c15ecf:	mov    ecx,DWORD PTR [rdx+0x4]
  c15ed2:	shl    rcx,0x20
  c15ed6:	or     rcx,rsi
  c15ed9:	movq   xmm1,r8
  c15ede:	movq   xmm0,rdi
  c15ee3:	punpcklqdq xmm0,xmm1
  c15ee7:	jmp    c10d5b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x143b>
  c15eec:	mov    rdi,QWORD PTR [rdx+0x8]
  c15ef0:	mov    r8,QWORD PTR [rdx+0x10]
  c15ef4:	mov    ecx,DWORD PTR [rdx+0x4]
  c15ef7:	shl    rcx,0x20
  c15efb:	or     rcx,rsi
  c15efe:	movq   xmm1,r8
  c15f03:	movq   xmm0,rdi
  c15f08:	punpcklqdq xmm0,xmm1
  c15f0c:	jmp    c10ddf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14bf>
  c15f11:	mov    rsi,QWORD PTR [rcx+0x8]
  c15f15:	mov    rdi,QWORD PTR [rcx+0x10]
  c15f19:	mov    r8d,DWORD PTR [rcx+0x4]
  c15f1d:	mov    rcx,rdi
  c15f20:	shl    r8,0x20
  c15f24:	or     r8,rdx
  c15f27:	jmp    c12a81 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3161>
  c15f2c:	mov    rdi,QWORD PTR [rdx+0x8]
  c15f30:	mov    r8,QWORD PTR [rdx+0x10]
  c15f34:	mov    ecx,DWORD PTR [rdx+0x4]
  c15f37:	shl    rcx,0x20
  c15f3b:	or     rcx,rsi
  c15f3e:	movq   xmm1,r8
  c15f43:	movq   xmm0,rdi
  c15f48:	punpcklqdq xmm0,xmm1
  c15f4c:	jmp    c10fd2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16b2>
  c15f51:	mov    rdx,QWORD PTR [rax+0x8]
  c15f55:	mov    rsi,QWORD PTR [rax+0x10]
  c15f59:	mov    edi,DWORD PTR [rax+0x4]
  c15f5c:	shl    rdi,0x20
  c15f60:	or     rdi,rcx
  c15f63:	mov    rax,rsi
  c15f66:	jmp    c12d0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33ea>
  c15f6b:	mov    rdx,QWORD PTR [rax+0x8]
  c15f6f:	mov    r10,QWORD PTR [rax+0x10]
  c15f73:	mov    esi,DWORD PTR [rax+0x4]
  c15f76:	shl    rsi,0x20
  c15f7a:	or     rsi,rcx
  c15f7d:	mov    rax,r10
  c15f80:	jmp    c12e3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x351e>
  c15f85:	mov    r14,QWORD PTR [rcx+0x8]
  c15f89:	mov    rsi,QWORD PTR [rcx+0x10]
  c15f8d:	mov    ebx,DWORD PTR [rcx+0x4]
  c15f90:	shl    rbx,0x20
  c15f94:	or     rbx,rdx
  c15f97:	jmp    c12fe9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36c9>
  c15f9c:	mov    rsi,QWORD PTR [rax+0x8]
  c15fa0:	mov    rdi,QWORD PTR [rax+0x10]
  c15fa4:	mov    edx,DWORD PTR [rax+0x4]
  c15fa7:	shl    rdx,0x20
  c15fab:	or     rdx,rcx
  c15fae:	mov    rax,rdi
  c15fb1:	jmp    c1321c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38fc>
  c15fb6:	mov    rdi,QWORD PTR [rcx+0x8]
  c15fba:	mov    rsi,QWORD PTR [rcx+0x10]
  c15fbe:	mov    r8d,DWORD PTR [rcx+0x4]
  c15fc2:	shl    r8,0x20
  c15fc6:	or     r8,rdx
  c15fc9:	jmp    c13315 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39f5>
  c15fce:	mov    rsi,QWORD PTR [rax+0x8]
  c15fd2:	mov    rdi,QWORD PTR [rax+0x10]
  c15fd6:	mov    edx,DWORD PTR [rax+0x4]
  c15fd9:	shl    rdx,0x20
  c15fdd:	or     rdx,rcx
  c15fe0:	mov    rax,rdi
  c15fe3:	jmp    c13473 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b53>
  c15fe8:	mov    rsi,QWORD PTR [rax+0x8]
  c15fec:	mov    rdi,QWORD PTR [rax+0x10]
  c15ff0:	mov    edx,DWORD PTR [rax+0x4]
  c15ff3:	shl    rdx,0x20
  c15ff7:	or     rdx,rcx
  c15ffa:	mov    rax,rdi
  c15ffd:	jmp    c1379e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e7e>
  c16002:	mov    rsi,QWORD PTR [rax+0x8]
  c16006:	mov    rdi,QWORD PTR [rax+0x10]
  c1600a:	mov    edx,DWORD PTR [rax+0x4]
  c1600d:	shl    rdx,0x20
  c16011:	or     rdx,rcx
  c16014:	mov    rax,rdi
  c16017:	jmp    c13a30 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4110>
  c1601c:	mov    r14,QWORD PTR [rcx+0x8]
  c16020:	mov    rsi,QWORD PTR [rcx+0x10]
  c16024:	mov    ebx,DWORD PTR [rcx+0x4]
  c16027:	shl    rbx,0x20
  c1602b:	or     rbx,rdx
  c1602e:	jmp    c13c29 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4309>
  c16033:	mov    rsi,QWORD PTR [rax+0x8]
  c16037:	mov    rdi,QWORD PTR [rax+0x10]
  c1603b:	mov    edx,DWORD PTR [rax+0x4]
  c1603e:	shl    rdx,0x20
  c16042:	or     rdx,rcx
  c16045:	mov    rax,rdi
  c16048:	jmp    c13d44 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4424>
  c1604d:	mov    r10,QWORD PTR [rax+0x8]
  c16051:	mov    rsi,QWORD PTR [rax+0x10]
  c16055:	mov    r9d,DWORD PTR [rax+0x4]
  c16059:	shl    r9,0x20
  c1605d:	or     r9,rcx
  c16060:	mov    QWORD PTR [rsp+0x70],r9
  c16065:	mov    QWORD PTR [rsp+0x78],r10
  c1606a:	mov    QWORD PTR [rsp+0x220],rsi
  c16072:	mov    QWORD PTR [rsp+0x80],rsi
  c1607a:	mov    rsi,QWORD PTR [rdx]
  c1607d:	cmp    rdi,rsi
  c16080:	jae    c19af1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1d1>
  c16086:	mov    rdx,QWORD PTR [rbp+0x0]
  c1608a:	lea    rcx,[rdx+r11*1]
  c1608e:	mov    rax,r12
  c16091:	sub    rax,QWORD PTR [rdx+r11*1+0x30]
  c16096:	jae    c160a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6786>
  c16098:	mov    rax,QWORD PTR [rcx+0x28]
  c1609c:	shl    r12d,0x4
  c160a0:	mov    rax,QWORD PTR [rax+r12*1]
  c160a4:	jmp    c160aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x678a>
  c160a6:	add    rax,QWORD PTR [rcx+0x60]
  c160aa:	mov    r12,QWORD PTR [rsp+0x8]
  c160af:	mov    rcx,QWORD PTR [r8+0x8]
  c160b3:	mov    rdx,QWORD PTR [rsp+0x80]
  c160bb:	mov    QWORD PTR [rsp+0x110],rdx
  c160c3:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c160c9:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c160d2:	cmp    rax,QWORD PTR [r8+0x10]
  c160d6:	jae    c17ee9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85c9>
  c160dc:	mov    QWORD PTR [rsp+0x420],r10
  c160e4:	mov    QWORD PTR [rsp+0x2b8],r9
  c160ec:	lea    rax,[rax+rax*2]
  c160f0:	lea    r14,[rcx+rax*8]
  c160f4:	mov    eax,DWORD PTR [rcx+rax*8]
  c160f7:	mov    edx,eax
  c160f9:	sub    edx,0x2
  c160fc:	mov    ecx,0x3
  c16101:	cmovae ecx,edx
  c16104:	cmp    ecx,0x8
  c16107:	ja     c16194 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6874>
  c1610d:	mov    edx,0x1e7
  c16112:	bt     edx,ecx
  c16115:	jae    c16161 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6841>
  c16117:	mov    rax,QWORD PTR [rsp+0x80]
  c1611f:	mov    QWORD PTR [r14+0x10],rax
  c16123:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c16129:	movdqu XMMWORD PTR [r14],xmm0
  c1612e:	lea    rax,[r12+0x10]
  c16133:	mov    rsi,QWORD PTR [rax]
  c16136:	cmp    QWORD PTR [rsp],rsi
  c1613a:	jae    c19b81 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa261>
  c16140:	mov    rax,QWORD PTR [rbp+0x0]
  c16144:	mov    r14,QWORD PTR [rsp+0x18]
  c16149:	inc    QWORD PTR [rax+r14*1+0x58]
  c1614e:	mov    rbx,QWORD PTR [rsp+0x10]
  c16153:	test   r15b,r15b
  c16156:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c1615c:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c16161:	cmp    ecx,0x3
  c16164:	jne    c1617f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x685f>
  c16166:	test   eax,eax
  c16168:	je     c16117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67f7>
  c1616a:	mov    rax,QWORD PTR [r14+0x8]
  c1616e:	dec    QWORD PTR [rax]
  c16171:	jne    c16117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67f7>
  c16173:	lea    rdi,[r14+0x8]
  c16177:	call   QWORD PTR [rip+0x23752b]        # e4d6a8 <_DYNAMIC+0x248>
  c1617d:	jmp    c16117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67f7>
  c1617f:	mov    rax,QWORD PTR [r14+0x8]
  c16183:	dec    QWORD PTR [rax]
  c16186:	jne    c16117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67f7>
  c16188:	lea    rdi,[r14+0x8]
  c1618c:	call   QWORD PTR [rip+0x23751e]        # e4d6b0 <_DYNAMIC+0x250>
  c16192:	jmp    c16117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67f7>
  c16194:	mov    rax,QWORD PTR [r14+0x8]
  c16198:	dec    QWORD PTR [rax]
  c1619b:	jne    c16117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67f7>
  c161a1:	lea    rdi,[r14+0x8]
  c161a5:	call   QWORD PTR [rip+0x23750d]        # e4d6b8 <_DYNAMIC+0x258>
  c161ab:	jmp    c16117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67f7>
  c161b0:	mov    rsi,QWORD PTR [rax+0x8]
  c161b4:	mov    r9,QWORD PTR [rax+0x10]
  c161b8:	mov    edx,DWORD PTR [rax+0x4]
  c161bb:	shl    rdx,0x20
  c161bf:	or     rdx,rcx
  c161c2:	mov    rcx,rsi
  c161c5:	jmp    c11733 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e13>
  c161ca:	mov    rdi,QWORD PTR [rcx+0x8]
  c161ce:	mov    r8,QWORD PTR [rcx+0x10]
  c161d2:	mov    esi,DWORD PTR [rcx+0x4]
  c161d5:	mov    rcx,r8
  c161d8:	shl    rsi,0x20
  c161dc:	or     rsi,rdx
  c161df:	jmp    c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c161e4:	mov    rdi,QWORD PTR [rcx+0x8]
  c161e8:	mov    r8,QWORD PTR [rcx+0x10]
  c161ec:	mov    esi,DWORD PTR [rcx+0x4]
  c161ef:	mov    rcx,r8
  c161f2:	shl    rsi,0x20
  c161f6:	or     rsi,rdx
  c161f9:	jmp    c142df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x49bf>
  c161fe:	mov    rsi,QWORD PTR [rcx+0x8]
  c16202:	mov    rdi,QWORD PTR [rcx+0x10]
  c16206:	mov    eax,DWORD PTR [rcx+0x4]
  c16209:	shl    rax,0x20
  c1620d:	or     rax,rdx
  c16210:	movq   xmm1,rdi
  c16215:	movq   xmm0,rsi
  c1621a:	punpcklqdq xmm0,xmm1
  c1621e:	mov    r15,r9
  c16221:	mov    QWORD PTR [rsp+0x70],rax
  c16226:	movdqu XMMWORD PTR [rsp+0x78],xmm0
  c1622c:	lea    rcx,[rip+0xffffffffff6b04c4]        # 2c66f7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x374>
  c16233:	lea    rdi,[rsp+0x100]
  c1623b:	lea    rsi,[rsp+0x30]
  c16240:	lea    rdx,[rsp+0x70]
  c16245:	mov    r8d,0x2
  c1624b:	call   QWORD PTR [rip+0x238faf]        # e4f200 <_DYNAMIC+0x1da0>
  c16251:	movzx  ecx,BYTE PTR [rsp+0x100]
  c16259:	movzx  ebp,BYTE PTR [rsp+0x101]
  c16261:	cmp    cl,0xff
  c16264:	jne    c17fce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x86ae>
  c1626a:	mov    rax,r12
  c1626d:	sub    rax,r15
  c16270:	jae    c16280 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6960>
  c16272:	mov    rax,QWORD PTR [rbx+0x28]
  c16276:	shl    r12d,0x4
  c1627a:	mov    rax,QWORD PTR [rax+r12*1]
  c1627e:	jmp    c16284 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6964>
  c16280:	add    rax,QWORD PTR [rbx+0x60]
  c16284:	mov    r12,QWORD PTR [rsp+0x8]
  c16289:	cmp    rax,r13
  c1628c:	jae    c18333 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a13>
  c16292:	not    bpl
  c16295:	shr    bpl,0x7
  c16299:	lea    rax,[rax+rax*2]
  c1629d:	lea    r15,[r14+rax*8]
  c162a1:	mov    eax,DWORD PTR [r14+rax*8]
  c162a5:	mov    edx,eax
  c162a7:	sub    edx,0x2
  c162aa:	mov    ecx,0x3
  c162af:	cmovae ecx,edx
  c162b2:	cmp    ecx,0x8
  c162b5:	ja     c163e2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ac2>
  c162bb:	mov    edx,0x1e7
  c162c0:	bt     edx,ecx
  c162c3:	mov    rbx,QWORD PTR [rsp+0x10]
  c162c8:	jae    c1634f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a2f>
  c162ce:	mov    DWORD PTR [r15],0x4
  c162d5:	mov    BYTE PTR [r15+0x4],bpl
  c162d9:	mov    eax,DWORD PTR [rsp+0x70]
  c162dd:	mov    edx,eax
  c162df:	sub    edx,0x2
  c162e2:	mov    ecx,0x3
  c162e7:	cmovae ecx,edx
  c162ea:	cmp    ecx,0x8
  c162ed:	ja     c16421 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b01>
  c162f3:	mov    edx,0x1e7
  c162f8:	bt     edx,ecx
  c162fb:	mov    r14,QWORD PTR [rsp+0x18]
  c16300:	lea    rbp,[r12+0x8]
  c16305:	mov    r13,QWORD PTR [rsp+0x1a0]
  c1630d:	mov    r15d,DWORD PTR [rsp+0x2c]
  c16312:	jae    c16378 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a58>
  c16314:	mov    eax,DWORD PTR [rsp+0x30]
  c16318:	mov    edx,eax
  c1631a:	sub    edx,0x2
  c1631d:	mov    ecx,0x3
  c16322:	cmovae ecx,edx
  c16325:	cmp    ecx,0x8
  c16328:	ja     c16474 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b54>
  c1632e:	mov    edx,0x1e7
  c16333:	bt     edx,ecx
  c16336:	jae    c1639f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a7f>
  c16338:	lea    rax,[r12+0x10]
  c1633d:	mov    rsi,QWORD PTR [rax]
  c16340:	cmp    QWORD PTR [rsp],rsi
  c16344:	jb     c16b55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7235>
  c1634a:	jmp    c19c34 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa314>
  c1634f:	cmp    ecx,0x3
  c16352:	jne    c163c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6aa6>
  c16354:	test   eax,eax
  c16356:	je     c162ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69ae>
  c1635c:	mov    rax,QWORD PTR [r15+0x8]
  c16360:	dec    QWORD PTR [rax]
  c16363:	jne    c162ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69ae>
  c16369:	lea    rdi,[r15+0x8]
  c1636d:	call   QWORD PTR [rip+0x237335]        # e4d6a8 <_DYNAMIC+0x248>
  c16373:	jmp    c162ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69ae>
  c16378:	cmp    ecx,0x3
  c1637b:	jne    c16403 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ae3>
  c16381:	test   eax,eax
  c16383:	je     c16314 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69f4>
  c16385:	mov    rax,QWORD PTR [rsp+0x78]
  c1638a:	dec    QWORD PTR [rax]
  c1638d:	jne    c16314 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69f4>
  c1638f:	lea    rdi,[rsp+0x78]
  c16394:	call   QWORD PTR [rip+0x23730e]        # e4d6a8 <_DYNAMIC+0x248>
  c1639a:	jmp    c16314 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69f4>
  c1639f:	cmp    ecx,0x3
  c163a2:	jne    c16456 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b36>
  c163a8:	test   eax,eax
  c163aa:	je     c16338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a18>
  c163ac:	mov    rax,QWORD PTR [rsp+0x38]
  c163b1:	dec    QWORD PTR [rax]
  c163b4:	jne    c16338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a18>
  c163b6:	lea    rdi,[rsp+0x38]
  c163bb:	call   QWORD PTR [rip+0x2372e7]        # e4d6a8 <_DYNAMIC+0x248>
  c163c1:	jmp    c16338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a18>
  c163c6:	mov    rax,QWORD PTR [r15+0x8]
  c163ca:	dec    QWORD PTR [rax]
  c163cd:	jne    c162ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69ae>
  c163d3:	lea    rdi,[r15+0x8]
  c163d7:	call   QWORD PTR [rip+0x2372d3]        # e4d6b0 <_DYNAMIC+0x250>
  c163dd:	jmp    c162ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69ae>
  c163e2:	mov    rax,QWORD PTR [r15+0x8]
  c163e6:	dec    QWORD PTR [rax]
  c163e9:	mov    rbx,QWORD PTR [rsp+0x10]
  c163ee:	jne    c162ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69ae>
  c163f4:	lea    rdi,[r15+0x8]
  c163f8:	call   QWORD PTR [rip+0x2372ba]        # e4d6b8 <_DYNAMIC+0x258>
  c163fe:	jmp    c162ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69ae>
  c16403:	mov    rax,QWORD PTR [rsp+0x78]
  c16408:	dec    QWORD PTR [rax]
  c1640b:	jne    c16314 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69f4>
  c16411:	lea    rdi,[rsp+0x78]
  c16416:	call   QWORD PTR [rip+0x237294]        # e4d6b0 <_DYNAMIC+0x250>
  c1641c:	jmp    c16314 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69f4>
  c16421:	mov    rax,QWORD PTR [rsp+0x78]
  c16426:	dec    QWORD PTR [rax]
  c16429:	mov    r14,QWORD PTR [rsp+0x18]
  c1642e:	lea    rbp,[r12+0x8]
  c16433:	mov    r13,QWORD PTR [rsp+0x1a0]
  c1643b:	mov    r15d,DWORD PTR [rsp+0x2c]
  c16440:	jne    c16314 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69f4>
  c16446:	lea    rdi,[rsp+0x78]
  c1644b:	call   QWORD PTR [rip+0x237267]        # e4d6b8 <_DYNAMIC+0x258>
  c16451:	jmp    c16314 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69f4>
  c16456:	mov    rax,QWORD PTR [rsp+0x38]
  c1645b:	dec    QWORD PTR [rax]
  c1645e:	jne    c16338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a18>
  c16464:	lea    rdi,[rsp+0x38]
  c16469:	call   QWORD PTR [rip+0x237241]        # e4d6b0 <_DYNAMIC+0x250>
  c1646f:	jmp    c16338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a18>
  c16474:	mov    rax,QWORD PTR [rsp+0x38]
  c16479:	dec    QWORD PTR [rax]
  c1647c:	jne    c16338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a18>
  c16482:	lea    rdi,[rsp+0x38]
  c16487:	call   QWORD PTR [rip+0x23722b]        # e4d6b8 <_DYNAMIC+0x258>
  c1648d:	jmp    c16338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a18>
  c16492:	mov    rsi,QWORD PTR [rcx+0x8]
  c16496:	mov    rdi,QWORD PTR [rcx+0x10]
  c1649a:	mov    eax,DWORD PTR [rcx+0x4]
  c1649d:	shl    rax,0x20
  c164a1:	or     rax,rdx
  c164a4:	movq   xmm1,rdi
  c164a9:	movq   xmm0,rsi
  c164ae:	punpcklqdq xmm0,xmm1
  c164b2:	mov    QWORD PTR [rsp+0x70],rax
  c164b7:	movdqu XMMWORD PTR [rsp+0x78],xmm0
  c164bd:	lea    rcx,[rip+0xffffffffff6b0230]        # 2c66f4 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x371>
  c164c4:	lea    rdi,[rsp+0x100]
  c164cc:	lea    rsi,[rsp+0x30]
  c164d1:	lea    rdx,[rsp+0x70]
  c164d6:	mov    r8d,0x1
  c164dc:	call   QWORD PTR [rip+0x238d1e]        # e4f200 <_DYNAMIC+0x1da0>
  c164e2:	movzx  r13d,BYTE PTR [rsp+0x100]
  c164eb:	movzx  ecx,BYTE PTR [rsp+0x101]
  c164f3:	cmp    r13b,0xff
  c164f7:	jne    c18026 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8706>
  c164fd:	mov    rax,r12
  c16500:	sub    rax,r14
  c16503:	jae    c16513 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6bf3>
  c16505:	mov    rax,QWORD PTR [rbx+0x28]
  c16509:	shl    r12d,0x4
  c1650d:	mov    rax,QWORD PTR [rax+r12*1]
  c16511:	jmp    c16517 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6bf7>
  c16513:	add    rax,QWORD PTR [rbx+0x60]
  c16517:	test   cl,cl
  c16519:	setg   r14b
  c1651d:	cmp    rax,rbp
  c16520:	jae    c183dc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8abc>
  c16526:	lea    rax,[rax+rax*2]
  c1652a:	lea    r12,[r15+rax*8]
  c1652e:	mov    eax,DWORD PTR [r15+rax*8]
  c16532:	mov    edx,eax
  c16534:	sub    edx,0x2
  c16537:	mov    ecx,0x3
  c1653c:	cmovae ecx,edx
  c1653f:	cmp    ecx,0x8
  c16542:	ja     c1668c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d6c>
  c16548:	mov    edx,0x1e7
  c1654d:	bt     edx,ecx
  c16550:	mov    rbx,QWORD PTR [rsp+0x18]
  c16555:	mov    rdx,QWORD PTR [rsp+0x8]
  c1655a:	lea    rbp,[rdx+0x8]
  c1655e:	mov    r13,QWORD PTR [rsp+0x1a0]
  c16566:	jae    c165ed <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ccd>
  c1656c:	mov    DWORD PTR [r12],0x4
  c16574:	mov    BYTE PTR [r12+0x4],r14b
  c16579:	mov    eax,DWORD PTR [rsp+0x70]
  c1657d:	mov    edx,eax
  c1657f:	sub    edx,0x2
  c16582:	mov    ecx,0x3
  c16587:	cmovae ecx,edx
  c1658a:	cmp    ecx,0x8
  c1658d:	ja     c166de <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dbe>
  c16593:	mov    edx,0x1e7
  c16598:	bt     edx,ecx
  c1659b:	mov    r15,QWORD PTR [rsp+0x10]
  c165a0:	mov    r12,QWORD PTR [rsp+0x8]
  c165a5:	mov    r14,rbx
  c165a8:	jae    c16618 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6cf8>
  c165aa:	mov    eax,DWORD PTR [rsp+0x30]
  c165ae:	mov    edx,eax
  c165b0:	sub    edx,0x2
  c165b3:	mov    ecx,0x3
  c165b8:	cmovae ecx,edx
  c165bb:	cmp    ecx,0x8
  c165be:	ja     c16727 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e07>
  c165c4:	mov    edx,0x1e7
  c165c9:	bt     edx,ecx
  c165cc:	mov    rbx,r15
  c165cf:	mov    r15d,DWORD PTR [rsp+0x2c]
  c165d4:	jae    c16643 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d23>
  c165d6:	lea    rax,[r12+0x10]
  c165db:	mov    rsi,QWORD PTR [rax]
  c165de:	cmp    QWORD PTR [rsp],rsi
  c165e2:	jb     c16b55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7235>
  c165e8:	jmp    c19c45 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa325>
  c165ed:	cmp    ecx,0x3
  c165f0:	jne    c1666e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d4e>
  c165f2:	test   eax,eax
  c165f4:	je     c1656c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c4c>
  c165fa:	mov    rax,QWORD PTR [r12+0x8]
  c165ff:	dec    QWORD PTR [rax]
  c16602:	jne    c1656c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c4c>
  c16608:	lea    rdi,[r12+0x8]
  c1660d:	call   QWORD PTR [rip+0x237095]        # e4d6a8 <_DYNAMIC+0x248>
  c16613:	jmp    c1656c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c4c>
  c16618:	cmp    ecx,0x3
  c1661b:	jne    c166c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6da0>
  c16621:	test   eax,eax
  c16623:	je     c165aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c8a>
  c16625:	mov    rax,QWORD PTR [rsp+0x78]
  c1662a:	dec    QWORD PTR [rax]
  c1662d:	jne    c165aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c8a>
  c16633:	lea    rdi,[rsp+0x78]
  c16638:	call   QWORD PTR [rip+0x23706a]        # e4d6a8 <_DYNAMIC+0x248>
  c1663e:	jmp    c165aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c8a>
  c16643:	cmp    ecx,0x3
  c16646:	jne    c16709 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6de9>
  c1664c:	test   eax,eax
  c1664e:	je     c165d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6cb6>
  c16650:	mov    rax,QWORD PTR [rsp+0x38]
  c16655:	dec    QWORD PTR [rax]
  c16658:	jne    c165d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6cb6>
  c1665e:	lea    rdi,[rsp+0x38]
  c16663:	call   QWORD PTR [rip+0x23703f]        # e4d6a8 <_DYNAMIC+0x248>
  c16669:	jmp    c165d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6cb6>
  c1666e:	mov    rax,QWORD PTR [r12+0x8]
  c16673:	dec    QWORD PTR [rax]
  c16676:	jne    c1656c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c4c>
  c1667c:	lea    rdi,[r12+0x8]
  c16681:	call   QWORD PTR [rip+0x237029]        # e4d6b0 <_DYNAMIC+0x250>
  c16687:	jmp    c1656c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c4c>
  c1668c:	mov    rax,QWORD PTR [r12+0x8]
  c16691:	dec    QWORD PTR [rax]
  c16694:	mov    rbx,QWORD PTR [rsp+0x18]
  c16699:	mov    rax,QWORD PTR [rsp+0x8]
  c1669e:	lea    rbp,[rax+0x8]
  c166a2:	mov    r13,QWORD PTR [rsp+0x1a0]
  c166aa:	jne    c1656c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c4c>
  c166b0:	lea    rdi,[r12+0x8]
  c166b5:	call   QWORD PTR [rip+0x236ffd]        # e4d6b8 <_DYNAMIC+0x258>
  c166bb:	jmp    c1656c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c4c>
  c166c0:	mov    rax,QWORD PTR [rsp+0x78]
  c166c5:	dec    QWORD PTR [rax]
  c166c8:	jne    c165aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c8a>
  c166ce:	lea    rdi,[rsp+0x78]
  c166d3:	call   QWORD PTR [rip+0x236fd7]        # e4d6b0 <_DYNAMIC+0x250>
  c166d9:	jmp    c165aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c8a>
  c166de:	mov    rax,QWORD PTR [rsp+0x78]
  c166e3:	dec    QWORD PTR [rax]
  c166e6:	mov    r15,QWORD PTR [rsp+0x10]
  c166eb:	mov    r12,QWORD PTR [rsp+0x8]
  c166f0:	mov    r14,rbx
  c166f3:	jne    c165aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c8a>
  c166f9:	lea    rdi,[rsp+0x78]
  c166fe:	call   QWORD PTR [rip+0x236fb4]        # e4d6b8 <_DYNAMIC+0x258>
  c16704:	jmp    c165aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c8a>
  c16709:	mov    rax,QWORD PTR [rsp+0x38]
  c1670e:	dec    QWORD PTR [rax]
  c16711:	jne    c165d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6cb6>
  c16717:	lea    rdi,[rsp+0x38]
  c1671c:	call   QWORD PTR [rip+0x236f8e]        # e4d6b0 <_DYNAMIC+0x250>
  c16722:	jmp    c165d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6cb6>
  c16727:	mov    rax,QWORD PTR [rsp+0x38]
  c1672c:	dec    QWORD PTR [rax]
  c1672f:	mov    rbx,r15
  c16732:	mov    r15d,DWORD PTR [rsp+0x2c]
  c16737:	jne    c165d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6cb6>
  c1673d:	lea    rdi,[rsp+0x38]
  c16742:	call   QWORD PTR [rip+0x236f70]        # e4d6b8 <_DYNAMIC+0x258>
  c16748:	jmp    c165d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6cb6>
  c1674d:	mov    rsi,QWORD PTR [rcx+0x8]
  c16751:	mov    rdi,QWORD PTR [rcx+0x10]
  c16755:	mov    eax,DWORD PTR [rcx+0x4]
  c16758:	shl    rax,0x20
  c1675c:	or     rax,rdx
  c1675f:	movq   xmm1,rdi
  c16764:	movq   xmm0,rsi
  c16769:	punpcklqdq xmm0,xmm1
  c1676d:	mov    QWORD PTR [rsp+0x70],rax
  c16772:	movdqu XMMWORD PTR [rsp+0x78],xmm0
  c16778:	lea    rcx,[rip+0xffffffffff6aff76]        # 2c66f5 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x372>
  c1677f:	lea    rdi,[rsp+0x100]
  c16787:	lea    rsi,[rsp+0x30]
  c1678c:	lea    rdx,[rsp+0x70]
  c16791:	mov    r8d,0x2
  c16797:	call   QWORD PTR [rip+0x238a63]        # e4f200 <_DYNAMIC+0x1da0>
  c1679d:	movzx  r13d,BYTE PTR [rsp+0x100]
  c167a6:	movzx  ecx,BYTE PTR [rsp+0x101]
  c167ae:	cmp    r13b,0xff
  c167b2:	jne    c1807d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x875d>
  c167b8:	mov    rax,r12
  c167bb:	sub    rax,r14
  c167be:	jae    c167ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6eae>
  c167c0:	mov    rax,QWORD PTR [rbx+0x28]
  c167c4:	shl    r12d,0x4
  c167c8:	mov    rax,QWORD PTR [rax+r12*1]
  c167cc:	jmp    c167d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6eb2>
  c167ce:	add    rax,QWORD PTR [rbx+0x60]
  c167d2:	test   cl,cl
  c167d4:	setle  r14b
  c167d8:	cmp    rax,rbp
  c167db:	jae    c182af <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x898f>
  c167e1:	lea    rax,[rax+rax*2]
  c167e5:	lea    r12,[r15+rax*8]
  c167e9:	mov    eax,DWORD PTR [r15+rax*8]
  c167ed:	mov    edx,eax
  c167ef:	sub    edx,0x2
  c167f2:	mov    ecx,0x3
  c167f7:	cmovae ecx,edx
  c167fa:	cmp    ecx,0x8
  c167fd:	ja     c16947 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7027>
  c16803:	mov    edx,0x1e7
  c16808:	bt     edx,ecx
  c1680b:	mov    rbx,QWORD PTR [rsp+0x18]
  c16810:	mov    rdx,QWORD PTR [rsp+0x8]
  c16815:	lea    rbp,[rdx+0x8]
  c16819:	mov    r13,QWORD PTR [rsp+0x1a0]
  c16821:	jae    c168a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f88>
  c16827:	mov    DWORD PTR [r12],0x4
  c1682f:	mov    BYTE PTR [r12+0x4],r14b
  c16834:	mov    eax,DWORD PTR [rsp+0x70]
  c16838:	mov    edx,eax
  c1683a:	sub    edx,0x2
  c1683d:	mov    ecx,0x3
  c16842:	cmovae ecx,edx
  c16845:	cmp    ecx,0x8
  c16848:	ja     c16999 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7079>
  c1684e:	mov    edx,0x1e7
  c16853:	bt     edx,ecx
  c16856:	mov    r15,QWORD PTR [rsp+0x10]
  c1685b:	mov    r12,QWORD PTR [rsp+0x8]
  c16860:	mov    r14,rbx
  c16863:	jae    c168d3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fb3>
  c16865:	mov    eax,DWORD PTR [rsp+0x30]
  c16869:	mov    edx,eax
  c1686b:	sub    edx,0x2
  c1686e:	mov    ecx,0x3
  c16873:	cmovae ecx,edx
  c16876:	cmp    ecx,0x8
  c16879:	ja     c169e2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x70c2>
  c1687f:	mov    edx,0x1e7
  c16884:	bt     edx,ecx
  c16887:	mov    rbx,r15
  c1688a:	mov    r15d,DWORD PTR [rsp+0x2c]
  c1688f:	jae    c168fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fde>
  c16891:	lea    rax,[r12+0x10]
  c16896:	mov    rsi,QWORD PTR [rax]
  c16899:	cmp    QWORD PTR [rsp],rsi
  c1689d:	jb     c16b55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7235>
  c168a3:	jmp    c19c56 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa336>
  c168a8:	cmp    ecx,0x3
  c168ab:	jne    c16929 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7009>
  c168ad:	test   eax,eax
  c168af:	je     c16827 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f07>
  c168b5:	mov    rax,QWORD PTR [r12+0x8]
  c168ba:	dec    QWORD PTR [rax]
  c168bd:	jne    c16827 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f07>
  c168c3:	lea    rdi,[r12+0x8]
  c168c8:	call   QWORD PTR [rip+0x236dda]        # e4d6a8 <_DYNAMIC+0x248>
  c168ce:	jmp    c16827 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f07>
  c168d3:	cmp    ecx,0x3
  c168d6:	jne    c1697b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x705b>
  c168dc:	test   eax,eax
  c168de:	je     c16865 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f45>
  c168e0:	mov    rax,QWORD PTR [rsp+0x78]
  c168e5:	dec    QWORD PTR [rax]
  c168e8:	jne    c16865 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f45>
  c168ee:	lea    rdi,[rsp+0x78]
  c168f3:	call   QWORD PTR [rip+0x236daf]        # e4d6a8 <_DYNAMIC+0x248>
  c168f9:	jmp    c16865 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f45>
  c168fe:	cmp    ecx,0x3
  c16901:	jne    c169c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x70a4>
  c16907:	test   eax,eax
  c16909:	je     c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c1690b:	mov    rax,QWORD PTR [rsp+0x38]
  c16910:	dec    QWORD PTR [rax]
  c16913:	jne    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c16919:	lea    rdi,[rsp+0x38]
  c1691e:	call   QWORD PTR [rip+0x236d84]        # e4d6a8 <_DYNAMIC+0x248>
  c16924:	jmp    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c16929:	mov    rax,QWORD PTR [r12+0x8]
  c1692e:	dec    QWORD PTR [rax]
  c16931:	jne    c16827 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f07>
  c16937:	lea    rdi,[r12+0x8]
  c1693c:	call   QWORD PTR [rip+0x236d6e]        # e4d6b0 <_DYNAMIC+0x250>
  c16942:	jmp    c16827 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f07>
  c16947:	mov    rax,QWORD PTR [r12+0x8]
  c1694c:	dec    QWORD PTR [rax]
  c1694f:	mov    rbx,QWORD PTR [rsp+0x18]
  c16954:	mov    rax,QWORD PTR [rsp+0x8]
  c16959:	lea    rbp,[rax+0x8]
  c1695d:	mov    r13,QWORD PTR [rsp+0x1a0]
  c16965:	jne    c16827 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f07>
  c1696b:	lea    rdi,[r12+0x8]
  c16970:	call   QWORD PTR [rip+0x236d42]        # e4d6b8 <_DYNAMIC+0x258>
  c16976:	jmp    c16827 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f07>
  c1697b:	mov    rax,QWORD PTR [rsp+0x78]
  c16980:	dec    QWORD PTR [rax]
  c16983:	jne    c16865 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f45>
  c16989:	lea    rdi,[rsp+0x78]
  c1698e:	call   QWORD PTR [rip+0x236d1c]        # e4d6b0 <_DYNAMIC+0x250>
  c16994:	jmp    c16865 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f45>
  c16999:	mov    rax,QWORD PTR [rsp+0x78]
  c1699e:	dec    QWORD PTR [rax]
  c169a1:	mov    r15,QWORD PTR [rsp+0x10]
  c169a6:	mov    r12,QWORD PTR [rsp+0x8]
  c169ab:	mov    r14,rbx
  c169ae:	jne    c16865 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f45>
  c169b4:	lea    rdi,[rsp+0x78]
  c169b9:	call   QWORD PTR [rip+0x236cf9]        # e4d6b8 <_DYNAMIC+0x258>
  c169bf:	jmp    c16865 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f45>
  c169c4:	mov    rax,QWORD PTR [rsp+0x38]
  c169c9:	dec    QWORD PTR [rax]
  c169cc:	jne    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c169d2:	lea    rdi,[rsp+0x38]
  c169d7:	call   QWORD PTR [rip+0x236cd3]        # e4d6b0 <_DYNAMIC+0x250>
  c169dd:	jmp    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c169e2:	mov    rax,QWORD PTR [rsp+0x38]
  c169e7:	dec    QWORD PTR [rax]
  c169ea:	mov    rbx,r15
  c169ed:	mov    r15d,DWORD PTR [rsp+0x2c]
  c169f2:	jne    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c169f8:	lea    rdi,[rsp+0x38]
  c169fd:	call   QWORD PTR [rip+0x236cb5]        # e4d6b8 <_DYNAMIC+0x258>
  c16a03:	jmp    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c16a08:	mov    rsi,QWORD PTR [rcx+0x8]
  c16a0c:	mov    rdi,QWORD PTR [rcx+0x10]
  c16a10:	mov    eax,DWORD PTR [rcx+0x4]
  c16a13:	shl    rax,0x20
  c16a17:	or     rax,rdx
  c16a1a:	movq   xmm1,rdi
  c16a1f:	movq   xmm0,rsi
  c16a24:	punpcklqdq xmm0,xmm1
  c16a28:	mov    QWORD PTR [rsp+0x70],rax
  c16a2d:	movdqu XMMWORD PTR [rsp+0x78],xmm0
  c16a33:	lea    rcx,[rip+0xffffffffff6afcb9]        # 2c66f3 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x370>
  c16a3a:	lea    rdi,[rsp+0x100]
  c16a42:	lea    rsi,[rsp+0x30]
  c16a47:	lea    rdx,[rsp+0x70]
  c16a4c:	mov    r8d,0x1
  c16a52:	call   QWORD PTR [rip+0x2387a8]        # e4f200 <_DYNAMIC+0x1da0>
  c16a58:	movzx  edx,BYTE PTR [rsp+0x100]
  c16a60:	movzx  ecx,BYTE PTR [rsp+0x101]
  c16a68:	cmp    dl,0xff
  c16a6b:	jne    c17f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8654>
  c16a71:	mov    rax,r12
  c16a74:	sub    rax,rbp
  c16a77:	jae    c16a87 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7167>
  c16a79:	mov    rax,QWORD PTR [rbx+0x28]
  c16a7d:	shl    r12d,0x4
  c16a81:	mov    rax,QWORD PTR [rax+r12*1]
  c16a85:	jmp    c16a8b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x716b>
  c16a87:	add    rax,QWORD PTR [rbx+0x60]
  c16a8b:	mov    r12,QWORD PTR [rsp+0x8]
  c16a90:	cmp    rax,r14
  c16a93:	jae    c1820d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88ed>
  c16a99:	shr    cl,0x7
  c16a9c:	mov    ebp,ecx
  c16a9e:	lea    rax,[rax+rax*2]
  c16aa2:	lea    r14,[r15+rax*8]
  c16aa6:	mov    eax,DWORD PTR [r15+rax*8]
  c16aaa:	mov    edx,eax
  c16aac:	sub    edx,0x2
  c16aaf:	mov    ecx,0x3
  c16ab4:	cmovae ecx,edx
  c16ab7:	cmp    ecx,0x8
  c16aba:	ja     c16c57 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7337>
  c16ac0:	mov    edx,0x1e7
  c16ac5:	bt     edx,ecx
  c16ac8:	mov    rbx,QWORD PTR [rsp+0x18]
  c16acd:	jae    c16bb0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7290>
  c16ad3:	mov    DWORD PTR [r14],0x4
  c16ada:	mov    BYTE PTR [r14+0x4],bpl
  c16ade:	mov    eax,DWORD PTR [rsp+0x70]
  c16ae2:	mov    edx,eax
  c16ae4:	sub    edx,0x2
  c16ae7:	mov    ecx,0x3
  c16aec:	cmovae ecx,edx
  c16aef:	cmp    ecx,0x8
  c16af2:	ja     c16c96 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7376>
  c16af8:	mov    edx,0x1e7
  c16afd:	bt     edx,ecx
  c16b00:	mov    r15,QWORD PTR [rsp+0x10]
  c16b05:	lea    rbp,[r12+0x8]
  c16b0a:	mov    r14,rbx
  c16b0d:	jae    c16bdd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72bd>
  c16b13:	mov    eax,DWORD PTR [rsp+0x30]
  c16b17:	mov    edx,eax
  c16b19:	sub    edx,0x2
  c16b1c:	mov    ecx,0x3
  c16b21:	cmovae ecx,edx
  c16b24:	cmp    ecx,0x8
  c16b27:	ja     c16cdf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x73bf>
  c16b2d:	mov    edx,0x1e7
  c16b32:	bt     edx,ecx
  c16b35:	mov    rbx,r15
  c16b38:	mov    r15d,DWORD PTR [rsp+0x2c]
  c16b3d:	jae    c16c0c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72ec>
  c16b43:	lea    rax,[r12+0x10]
  c16b48:	mov    rsi,QWORD PTR [rax]
  c16b4b:	cmp    QWORD PTR [rsp],rsi
  c16b4f:	jae    c19ca4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa384>
  c16b55:	mov    rax,QWORD PTR [rbp+0x0]
  c16b59:	inc    QWORD PTR [rax+r14*1+0x58]
  c16b5e:	xchg   ax,ax
  c16b60:	test   r15b,r15b
  c16b63:	je     c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c16b69:	lea    rax,[r12+0x10]
  c16b6e:	mov    rsi,QWORD PTR [rax]
  c16b71:	cmp    QWORD PTR [rsp],rsi
  c16b75:	jae    c19755 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e35>
  c16b7b:	mov    rax,QWORD PTR [rbp+0x0]
  c16b7f:	mov    r13,QWORD PTR [rax+r14*1+0x58]
  c16b84:	cmp    r13,QWORD PTR [rsp+0x1d8]
  c16b8c:	jae    c1738f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a6f>
  c16b92:	dec    r15b
  c16b95:	mov    rax,QWORD PTR [rsp+0x1c0]
  c16b9d:	cmp    r13,QWORD PTR [rsp+0x1d8]
  c16ba5:	jb     c0fc60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x340>
  c16bab:	jmp    c1973d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e1d>
  c16bb0:	cmp    ecx,0x3
  c16bb3:	jne    c16c3b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x731b>
  c16bb9:	test   eax,eax
  c16bbb:	je     c16ad3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71b3>
  c16bc1:	mov    rax,QWORD PTR [r14+0x8]
  c16bc5:	dec    QWORD PTR [rax]
  c16bc8:	jne    c16ad3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71b3>
  c16bce:	lea    rdi,[r14+0x8]
  c16bd2:	call   QWORD PTR [rip+0x236ad0]        # e4d6a8 <_DYNAMIC+0x248>
  c16bd8:	jmp    c16ad3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71b3>
  c16bdd:	cmp    ecx,0x3
  c16be0:	jne    c16c78 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7358>
  c16be6:	test   eax,eax
  c16be8:	je     c16b13 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71f3>
  c16bee:	mov    rax,QWORD PTR [rsp+0x78]
  c16bf3:	dec    QWORD PTR [rax]
  c16bf6:	jne    c16b13 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71f3>
  c16bfc:	lea    rdi,[rsp+0x78]
  c16c01:	call   QWORD PTR [rip+0x236aa1]        # e4d6a8 <_DYNAMIC+0x248>
  c16c07:	jmp    c16b13 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71f3>
  c16c0c:	cmp    ecx,0x3
  c16c0f:	jne    c16cc1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x73a1>
  c16c15:	test   eax,eax
  c16c17:	je     c16b43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7223>
  c16c1d:	mov    rax,QWORD PTR [rsp+0x38]
  c16c22:	dec    QWORD PTR [rax]
  c16c25:	jne    c16b43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7223>
  c16c2b:	lea    rdi,[rsp+0x38]
  c16c30:	call   QWORD PTR [rip+0x236a72]        # e4d6a8 <_DYNAMIC+0x248>
  c16c36:	jmp    c16b43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7223>
  c16c3b:	mov    rax,QWORD PTR [r14+0x8]
  c16c3f:	dec    QWORD PTR [rax]
  c16c42:	jne    c16ad3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71b3>
  c16c48:	lea    rdi,[r14+0x8]
  c16c4c:	call   QWORD PTR [rip+0x236a5e]        # e4d6b0 <_DYNAMIC+0x250>
  c16c52:	jmp    c16ad3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71b3>
  c16c57:	mov    rax,QWORD PTR [r14+0x8]
  c16c5b:	dec    QWORD PTR [rax]
  c16c5e:	mov    rbx,QWORD PTR [rsp+0x18]
  c16c63:	jne    c16ad3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71b3>
  c16c69:	lea    rdi,[r14+0x8]
  c16c6d:	call   QWORD PTR [rip+0x236a45]        # e4d6b8 <_DYNAMIC+0x258>
  c16c73:	jmp    c16ad3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71b3>
  c16c78:	mov    rax,QWORD PTR [rsp+0x78]
  c16c7d:	dec    QWORD PTR [rax]
  c16c80:	jne    c16b13 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71f3>
  c16c86:	lea    rdi,[rsp+0x78]
  c16c8b:	call   QWORD PTR [rip+0x236a1f]        # e4d6b0 <_DYNAMIC+0x250>
  c16c91:	jmp    c16b13 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71f3>
  c16c96:	mov    rax,QWORD PTR [rsp+0x78]
  c16c9b:	dec    QWORD PTR [rax]
  c16c9e:	mov    r15,QWORD PTR [rsp+0x10]
  c16ca3:	lea    rbp,[r12+0x8]
  c16ca8:	mov    r14,rbx
  c16cab:	jne    c16b13 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71f3>
  c16cb1:	lea    rdi,[rsp+0x78]
  c16cb6:	call   QWORD PTR [rip+0x2369fc]        # e4d6b8 <_DYNAMIC+0x258>
  c16cbc:	jmp    c16b13 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71f3>
  c16cc1:	mov    rax,QWORD PTR [rsp+0x38]
  c16cc6:	dec    QWORD PTR [rax]
  c16cc9:	jne    c16b43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7223>
  c16ccf:	lea    rdi,[rsp+0x38]
  c16cd4:	call   QWORD PTR [rip+0x2369d6]        # e4d6b0 <_DYNAMIC+0x250>
  c16cda:	jmp    c16b43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7223>
  c16cdf:	mov    rax,QWORD PTR [rsp+0x38]
  c16ce4:	dec    QWORD PTR [rax]
  c16ce7:	mov    rbx,r15
  c16cea:	mov    r15d,DWORD PTR [rsp+0x2c]
  c16cef:	jne    c16b43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7223>
  c16cf5:	lea    rdi,[rsp+0x38]
  c16cfa:	call   QWORD PTR [rip+0x2369b8]        # e4d6b8 <_DYNAMIC+0x258>
  c16d00:	jmp    c16b43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7223>
  c16d05:	mov    rdi,QWORD PTR [rcx+0x8]
  c16d09:	mov    rsi,QWORD PTR [rcx+0x10]
  c16d0d:	mov    r8d,DWORD PTR [rcx+0x4]
  c16d11:	shl    r8,0x20
  c16d15:	or     r8,rdx
  c16d18:	jmp    c146a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4d81>
  c16d1d:	mov    rdx,QWORD PTR [rax+0x8]
  c16d21:	mov    rsi,QWORD PTR [rax+0x10]
  c16d25:	mov    edi,DWORD PTR [rax+0x4]
  c16d28:	shl    rdi,0x20
  c16d2c:	or     rdi,rcx
  c16d2f:	mov    rcx,rdx
  c16d32:	mov    rax,rsi
  c16d35:	jmp    c14831 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f11>
  c16d3a:	mov    r8,QWORD PTR [rax+0x8]
  c16d3e:	mov    r9,QWORD PTR [rax+0x10]
  c16d42:	mov    edx,DWORD PTR [rax+0x4]
  c16d45:	shl    rdx,0x20
  c16d49:	or     rdx,rcx
  c16d4c:	jmp    c14c7f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x535f>
  c16d51:	mov    rsi,QWORD PTR [rax+0x8]
  c16d55:	mov    rdi,QWORD PTR [rax+0x10]
  c16d59:	mov    edx,DWORD PTR [rax+0x4]
  c16d5c:	shl    rdx,0x20
  c16d60:	or     rdx,rcx
  c16d63:	jmp    c14f26 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5606>
  c16d68:	mov    r8,QWORD PTR [rax+0x8]
  c16d6c:	mov    r9,QWORD PTR [rax+0x10]
  c16d70:	mov    edx,DWORD PTR [rax+0x4]
  c16d73:	shl    rdx,0x20
  c16d77:	or     rdx,rcx
  c16d7a:	jmp    c15284 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5964>
  c16d7f:	mov    rsi,QWORD PTR [rax+0x8]
  c16d83:	mov    rdi,QWORD PTR [rax+0x10]
  c16d87:	mov    edx,DWORD PTR [rax+0x4]
  c16d8a:	shl    rdx,0x20
  c16d8e:	or     rdx,rcx
  c16d91:	jmp    c15778 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e58>
  c16d96:	mov    rax,rdi
  c16d99:	shr    rax,0x20
  c16d9d:	mov    ecx,edi
  c16d9f:	mov    DWORD PTR [rsp+0x100],ecx
  c16da6:	mov    DWORD PTR [rsp+0x104],eax
  c16dad:	mov    rax,QWORD PTR [rsp+0x1c8]
  c16db5:	mov    QWORD PTR [rsp+0x108],rax
  c16dbd:	mov    rax,QWORD PTR [rsp+0x1d0]
  c16dc5:	mov    QWORD PTR [rsp+0x110],rax
  c16dcd:	jmp    c14a55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5135>
  c16dd2:	mov    rdx,QWORD PTR [rsp+0x1e0]
  c16dda:	movzx  eax,BYTE PTR [rdx+0xc5]
  c16de1:	xor    ecx,ecx
  c16de3:	sub    al,BYTE PTR [rdx+0xc3]
  c16de9:	movzx  eax,al
  c16dec:	cmovb  eax,ecx
  c16def:	mov    rdi,QWORD PTR [rsp+0x20]
  c16df4:	mov    rbx,QWORD PTR [rdi+0x10]
  c16df8:	movzx  esi,al
  c16dfb:	add    rsi,rbx
  c16dfe:	mov    DWORD PTR [rsp+0x100],0x2
  c16e09:	lea    rdx,[rsp+0x100]
  c16e11:	call   c33260 <_RNvMs1_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueE6resizeCsbxgXiyEKxkX_6bsl_vm>
  c16e16:	mov    r15,QWORD PTR [rsp+0x10]
  c16e1b:	mov    rax,r12
  c16e1e:	mov    r12,QWORD PTR [r12+0x10]
  c16e23:	cmp    QWORD PTR [rax],r12
  c16e26:	je     c16f64 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7644>
  c16e2c:	cmp    QWORD PTR [rsp],r12
  c16e30:	jae    c19da6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa486>
  c16e36:	mov    rdi,QWORD PTR [rsp+0x8]
  c16e3b:	mov    rax,QWORD PTR [rdi+0x8]
  c16e3f:	mov    ecx,DWORD PTR [rax+r14*1+0x70]
  c16e44:	mov    rdx,QWORD PTR [rsp+0x40]
  c16e49:	lea    rsi,[rsp+0x104]
  c16e51:	mov    QWORD PTR [rsi+0x2c],rdx
  c16e55:	movups xmm0,XMMWORD PTR [rsp+0x30]
  c16e5a:	movups XMMWORD PTR [rsi+0x1c],xmm0
  c16e5e:	mov    rdx,QWORD PTR [rsp+0x80]
  c16e66:	mov    QWORD PTR [rsi+0x44],rdx
  c16e6a:	movups xmm0,XMMWORD PTR [rsp+0x70]
  c16e6f:	movups XMMWORD PTR [rsi+0x34],xmm0
  c16e73:	mov    DWORD PTR [rsp+0x170],ecx
  c16e7a:	mov    rcx,QWORD PTR [rsp+0x4a8]
  c16e82:	mov    QWORD PTR [rsp+0x150],rcx
  c16e8a:	mov    QWORD PTR [rsp+0x158],0x0
  c16e96:	mov    QWORD PTR [rsp+0x160],rbx
  c16e9e:	mov    QWORD PTR [rsp+0x168],rbx
  c16ea6:	mov    BYTE PTR [rsp+0x174],bpl
  c16eae:	mov    QWORD PTR [rsp+0x100],0x0
  c16eba:	cmp    r12,QWORD PTR [rdi]
  c16ebd:	lea    rbp,[rdi+0x8]
  c16ec1:	mov    rbx,r15
  c16ec4:	mov    r15d,DWORD PTR [rsp+0x2c]
  c16ec9:	jne    c16eda <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x75ba>
  c16ecb:	call   QWORD PTR [rip+0x23bddf]        # e52cb0 <_DYNAMIC+0x5850>
  c16ed1:	mov    rax,QWORD PTR [rbp+0x0]
  c16ed5:	mov    rdi,QWORD PTR [rsp+0x8]
  c16eda:	imul   rcx,r12,0x78
  c16ede:	mov    rdx,QWORD PTR [rsp+0x170]
  c16ee6:	mov    QWORD PTR [rax+rcx*1+0x70],rdx
  c16eeb:	movups xmm0,XMMWORD PTR [rsp+0x160]
  c16ef3:	movups XMMWORD PTR [rax+rcx*1+0x60],xmm0
  c16ef8:	movups xmm0,XMMWORD PTR [rsp+0x150]
  c16f00:	movups XMMWORD PTR [rax+rcx*1+0x50],xmm0
  c16f05:	movups xmm0,XMMWORD PTR [rsp+0x140]
  c16f0d:	movups XMMWORD PTR [rax+rcx*1+0x40],xmm0
  c16f12:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c16f1b:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c16f24:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c16f2c:	movups xmm3,XMMWORD PTR [rsp+0x130]
  c16f34:	movups XMMWORD PTR [rax+rcx*1+0x30],xmm3
  c16f39:	movups XMMWORD PTR [rax+rcx*1+0x20],xmm2
  c16f3e:	movdqu XMMWORD PTR [rax+rcx*1+0x10],xmm1
  c16f44:	movdqu XMMWORD PTR [rax+rcx*1],xmm0
  c16f49:	inc    r12
  c16f4c:	lea    rax,[rdi+0x10]
  c16f50:	mov    QWORD PTR [rax],r12
  c16f53:	mov    r12,rdi
  c16f56:	test   r15b,r15b
  c16f59:	jne    c16b69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7249>
  c16f5f:	jmp    c0fd3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a>
  c16f64:	mov    edx,0x1
  c16f69:	mov    ecx,0x8
  c16f6e:	mov    r8d,0x78
  c16f74:	mov    rdi,QWORD PTR [rsp+0x8]
  c16f79:	mov    rsi,r12
  c16f7c:	mov    r12,rdi
  c16f7f:	call   c4eb20 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsbxgXiyEKxkX_6bsl_vm>
  c16f84:	lea    rax,[r12+0x10]
  c16f89:	mov    r12,QWORD PTR [rax]
  c16f8c:	cmp    QWORD PTR [rsp],r12
  c16f90:	jb     c16e36 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7516>
  c16f96:	jmp    c19da6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa486>
  c16f9b:	inc    r14b
  c16f9e:	mov    r8,QWORD PTR [rsp+0x548]
  c16fa6:	movzx  eax,BYTE PTR [r8+r11*1]
  c16fab:	lea    rcx,[rip+0xffffffffff6aea02]        # 2c59b4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xff3>
  c16fb2:	movsxd rax,DWORD PTR [rcx+rax*4]
  c16fb6:	add    rax,rcx
  c16fb9:	mov    rdx,QWORD PTR [rsp]
  c16fbd:	mov    r12,QWORD PTR [rsp+0x8]
  c16fc2:	jmp    rax
  c16fc4:	mov    QWORD PTR [rsp+0x348],r11
  c16fcc:	lea    rax,[r12+0x10]
  c16fd1:	mov    rcx,r12
  c16fd4:	mov    r12,QWORD PTR [rax]
  c16fd7:	cmp    rdx,r12
  c16fda:	lea    rax,[rcx+0x8]
  c16fde:	mov    rsi,QWORD PTR [rsp+0x18]
  c16fe3:	jae    c19799 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e79>
  c16fe9:	mov    rdx,QWORD PTR [rax]
  c16fec:	lea    rcx,[rdx+rsi*1]
  c16ff0:	movzx  eax,r14b
  c16ff4:	mov    rbx,rax
  c16ff7:	sub    rbx,QWORD PTR [rdx+rsi*1+0x30]
  c16ffc:	jb     c1710a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x77ea>
  c17002:	add    rbx,QWORD PTR [rcx+0x60]
  c17006:	mov    r15b,0x1
  c17009:	mov    r12,QWORD PTR [rsp+0x40]
  c1700e:	cmp    r12,QWORD PTR [rsp+0x30]
  c17013:	jne    c17309 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79e9>
  c17019:	jmp    c172fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79de>
  c1701e:	mov    QWORD PTR [rsp+0x348],r11
  c17026:	lea    rax,[r12+0x10]
  c1702b:	mov    rcx,r12
  c1702e:	mov    r12,QWORD PTR [rax]
  c17031:	cmp    rdx,r12
  c17034:	lea    rax,[rcx+0x8]
  c17038:	mov    rsi,QWORD PTR [rsp+0x18]
  c1703d:	jae    c197ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e8b>
  c17043:	mov    rdx,QWORD PTR [rax]
  c17046:	lea    rcx,[rdx+rsi*1]
  c1704a:	movzx  eax,r14b
  c1704e:	mov    rbx,rax
  c17051:	sub    rbx,QWORD PTR [rdx+rsi*1+0x30]
  c17056:	jae    c17065 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7745>
  c17058:	mov    rcx,QWORD PTR [rcx+0x28]
  c1705c:	shl    eax,0x4
  c1705f:	mov    rbx,QWORD PTR [rcx+rax*1]
  c17063:	jmp    c17069 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7749>
  c17065:	add    rbx,QWORD PTR [rcx+0x60]
  c17069:	mov    rax,QWORD PTR [rsp+0x20]
  c1706e:	cmp    rbx,QWORD PTR [rax+0x10]
  c17072:	jae    c17440 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b20>
  c17078:	mov    rax,QWORD PTR [rax+0x8]
  c1707c:	lea    rcx,[rbx+rbx*2]
  c17080:	lea    r15,[rax+rcx*8]
  c17084:	mov    eax,DWORD PTR [rax+rcx*8]
  c17087:	mov    edx,eax
  c17089:	sub    edx,0x2
  c1708c:	mov    ecx,0x3
  c17091:	cmovae ecx,edx
  c17094:	cmp    ecx,0x8
  c17097:	ja     c17373 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a53>
  c1709d:	mov    edx,0x1e7
  c170a2:	bt     edx,ecx
  c170a5:	jae    c171a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7881>
  c170ab:	mov    DWORD PTR [r15],0x2
  c170b2:	xor    r15d,r15d
  c170b5:	mov    r12,QWORD PTR [rsp+0x40]
  c170ba:	cmp    r12,QWORD PTR [rsp+0x30]
  c170bf:	je     c172fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79de>
  c170c5:	jmp    c17309 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79e9>
  c170ca:	lea    rax,[r12+0x10]
  c170cf:	mov    rcx,r12
  c170d2:	mov    r12,QWORD PTR [rax]
  c170d5:	cmp    rdx,r12
  c170d8:	lea    rax,[rcx+0x8]
  c170dc:	mov    rsi,QWORD PTR [rsp+0x18]
  c170e1:	mov    QWORD PTR [rsp+0x348],r11
  c170e9:	jae    c197a2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e82>
  c170ef:	mov    rdx,QWORD PTR [rax]
  c170f2:	lea    rcx,[rdx+rsi*1]
  c170f6:	movzx  eax,BYTE PTR [r8+r11*1+0x1]
  c170fc:	mov    rbx,rax
  c170ff:	sub    rbx,QWORD PTR [rdx+rsi*1+0x30]
  c17104:	jae    c17002 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x76e2>
  c1710a:	mov    rcx,QWORD PTR [rcx+0x28]
  c1710e:	shl    eax,0x4
  c17111:	mov    rbx,QWORD PTR [rcx+rax*1]
  c17115:	mov    r15b,0x1
  c17118:	mov    r12,QWORD PTR [rsp+0x40]
  c1711d:	cmp    r12,QWORD PTR [rsp+0x30]
  c17122:	jne    c17309 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79e9>
  c17128:	jmp    c172fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79de>
  c1712d:	movzx  r15d,WORD PTR [r8+r11*1+0x2]
  c17133:	mov    rax,QWORD PTR [rsp+0x1b8]
  c1713b:	cmp    QWORD PTR [rax+0x10],r15
  c1713f:	mov    r8,QWORD PTR [rsp+0x560]
  c17147:	mov    r9,QWORD PTR [rsp+0x4d8]
  c1714f:	mov    r10,QWORD PTR [rsp+0x558]
  c17157:	mov    QWORD PTR [rsp+0x348],r11
  c1715f:	jbe    c1741b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7afb>
  c17165:	mov    rdx,QWORD PTR [rax+0x8]
  c17169:	lea    rsi,[r15+r15*2]
  c1716d:	mov    ecx,DWORD PTR [rdx+rsi*8]
  c17170:	mov    edi,ecx
  c17172:	sub    edi,0x2
  c17175:	mov    eax,0x3
  c1717a:	cmovb  edi,eax
  c1717d:	lea    rdx,[rdx+rsi*8]
  c17181:	lea    rsi,[rip+0xffffffffff6ae840]        # 2c59c8 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1007>
  c17188:	movsxd rdi,DWORD PTR [rsi+rdi*4]
  c1718c:	add    rdi,rsi
  c1718f:	jmp    rdi
  c17191:	mov    r9d,DWORD PTR [rdx+0x4]
  c17195:	mov    r10,QWORD PTR [rdx+0x8]
  c17199:	mov    r8,QWORD PTR [rdx+0x10]
  c1719d:	mov    eax,ecx
  c1719f:	jmp    c1720a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x78ea>
  c171a1:	cmp    ecx,0x3
  c171a4:	jne    c17357 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a37>
  c171aa:	test   eax,eax
  c171ac:	je     c170ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x778b>
  c171b2:	mov    rax,QWORD PTR [r15+0x8]
  c171b6:	dec    QWORD PTR [rax]
  c171b9:	jne    c170ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x778b>
  c171bf:	lea    rdi,[r15+0x8]
  c171c3:	call   QWORD PTR [rip+0x2364df]        # e4d6a8 <_DYNAMIC+0x248>
  c171c9:	jmp    c170ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x778b>
  c171ce:	mov    r10,QWORD PTR [rdx+0x8]
  c171d2:	mov    eax,0xb
  c171d7:	jmp    c17201 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x78e1>
  c171d9:	mov    eax,0x2
  c171de:	jmp    c1720a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x78ea>
  c171e0:	test   cl,0x1
  c171e3:	je     c17191 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7871>
  c171e5:	mov    r10,QWORD PTR [rdx+0x8]
  c171e9:	mov    eax,0x1
  c171ee:	inc    QWORD PTR [r10]
  c171f1:	jne    c1720a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x78ea>
  c171f3:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c171f8:	mov    r10,QWORD PTR [rdx+0x8]
  c171fc:	mov    eax,0x6
  c17201:	inc    QWORD PTR [r10]
  c17204:	je     c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1720a:	mov    eax,eax
  c1720c:	mov    QWORD PTR [rsp+0x4d8],r9
  c17214:	mov    rcx,r9
  c17217:	shl    rcx,0x20
  c1721b:	or     rcx,rax
  c1721e:	mov    QWORD PTR [rsp+0x588],rcx
  c17226:	mov    QWORD PTR [rsp+0x558],r10
  c1722e:	mov    QWORD PTR [rsp+0x590],r10
  c17236:	mov    QWORD PTR [rsp+0x560],r8
  c1723e:	mov    QWORD PTR [rsp+0x598],r8
  c17246:	mov    r12,QWORD PTR [rsp+0x20]
  c1724b:	mov    rbx,QWORD PTR [r12+0x10]
  c17250:	cmp    rbx,QWORD PTR [r12]
  c17254:	jne    c1725f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x793f>
  c17256:	mov    rdi,r12
  c17259:	call   QWORD PTR [rip+0x238009]        # e4f268 <_DYNAMIC+0x1e08>
  c1725f:	mov    rax,QWORD PTR [r12+0x8]
  c17264:	lea    rcx,[rbx+rbx*2]
  c17268:	mov    rdx,QWORD PTR [rsp+0x598]
  c17270:	mov    QWORD PTR [rax+rcx*8+0x10],rdx
  c17275:	movdqu xmm0,XMMWORD PTR [rsp+0x588]
  c1727e:	movdqu XMMWORD PTR [rax+rcx*8],xmm0
  c17283:	lea    rax,[rbx+0x1]
  c17287:	mov    QWORD PTR [r12+0x10],rax
  c1728c:	mov    rcx,QWORD PTR [rsp+0x8]
  c17291:	lea    rax,[rcx+0x10]
  c17295:	mov    r12,QWORD PTR [rax]
  c17298:	cmp    QWORD PTR [rsp],r12
  c1729c:	jae    c197b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e94>
  c172a2:	lea    rax,[rcx+0x8]
  c172a6:	mov    rax,QWORD PTR [rax]
  c172a9:	mov    rcx,QWORD PTR [rsp+0x18]
  c172ae:	mov    r13d,DWORD PTR [rax+rcx*1+0x70]
  c172b3:	mov    r12,QWORD PTR [rsp+0x80]
  c172bb:	cmp    r12,QWORD PTR [rsp+0x70]
  c172c0:	jne    c172cd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79ad>
  c172c2:	lea    rdi,[rsp+0x70]
  c172c7:	call   QWORD PTR [rip+0x23b9eb]        # e52cb8 <_DYNAMIC+0x5858>
  c172cd:	mov    rax,QWORD PTR [rsp+0x78]
  c172d2:	lea    rcx,[r12+r12*2]
  c172d6:	mov    QWORD PTR [rax+rcx*8],rbx
  c172da:	mov    DWORD PTR [rax+rcx*8+0x8],r13d
  c172df:	mov    QWORD PTR [rax+rcx*8+0x10],r15
  c172e4:	inc    r12
  c172e7:	mov    QWORD PTR [rsp+0x80],r12
  c172ef:	mov    r15b,0x1
  c172f2:	mov    r12,QWORD PTR [rsp+0x40]
  c172f7:	cmp    r12,QWORD PTR [rsp+0x30]
  c172fc:	jne    c17309 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79e9>
  c172fe:	lea    rdi,[rsp+0x30]
  c17303:	call   QWORD PTR [rip+0x23b9b7]        # e52cc0 <_DYNAMIC+0x5860>
  c17309:	mov    rax,QWORD PTR [rsp+0x38]
  c1730e:	mov    rcx,r12
  c17311:	shl    rcx,0x4
  c17315:	mov    QWORD PTR [rax+rcx*1],rbx
  c17319:	mov    BYTE PTR [rax+rcx*1+0x8],r15b
  c1731e:	inc    r12
  c17321:	mov    QWORD PTR [rsp+0x40],r12
  c17326:	mov    r11,QWORD PTR [rsp+0x348]
  c1732e:	add    r11,0x4
  c17332:	cmp    QWORD PTR [rsp+0x550],r11
  c1733a:	jne    c16f9b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x767b>
  c17340:	mov    r14,QWORD PTR [rsp+0x18]
  c17345:	mov    r12,QWORD PTR [rsp+0x8]
  c1734a:	mov    r13,QWORD PTR [rsp+0x1a0]
  c17352:	jmp    c16dd2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b2>
  c17357:	mov    rax,QWORD PTR [r15+0x8]
  c1735b:	dec    QWORD PTR [rax]
  c1735e:	jne    c170ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x778b>
  c17364:	lea    rdi,[r15+0x8]
  c17368:	call   QWORD PTR [rip+0x236342]        # e4d6b0 <_DYNAMIC+0x250>
  c1736e:	jmp    c170ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x778b>
  c17373:	mov    rax,QWORD PTR [r15+0x8]
  c17377:	dec    QWORD PTR [rax]
  c1737a:	jne    c170ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x778b>
  c17380:	lea    rdi,[r15+0x8]
  c17384:	call   QWORD PTR [rip+0x23632e]        # e4d6b8 <_DYNAMIC+0x258>
  c1738a:	jmp    c170ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x778b>
  c1738f:	mov    DWORD PTR [rbx+0x8],0xc
  c17396:	mov    BYTE PTR [rbx],0xff
  c17399:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c1739e:	mov    eax,DWORD PTR [rsp+0x108]
  c173a5:	movups xmm0,XMMWORD PTR [rsp+0x10c]
  c173ad:	movaps XMMWORD PTR [rsp+0x3c0],xmm0
  c173b5:	mov    ecx,DWORD PTR [rsp+0x11c]
  c173bc:	mov    DWORD PTR [rsp+0x3d0],ecx
  c173c3:	cmp    eax,0xffffffff
  c173c6:	je     c173e2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ac2>
  c173c8:	mov    ecx,DWORD PTR [rsp+0x3d0]
  c173cf:	mov    DWORD PTR [rsp+0x40],ecx
  c173d3:	movaps xmm0,XMMWORD PTR [rsp+0x3c0]
  c173db:	movaps XMMWORD PTR [rsp+0x30],xmm0
  c173e0:	jmp    c173e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ac7>
  c173e2:	mov    eax,0xc
  c173e7:	mov    DWORD PTR [rbx+0x8],eax
  c173ea:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c173f0:	movdqu XMMWORD PTR [rbx+0xc],xmm0
  c173f5:	mov    eax,DWORD PTR [rsp+0x40]
  c173f9:	mov    DWORD PTR [rbx+0x1c],eax
  c173fc:	mov    BYTE PTR [rbx],0xff
  c173ff:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17404:	xor    r13d,r13d
  c17407:	mov    r12,QWORD PTR [rsp+0x538]
  c1740f:	mov    rdi,r13
  c17412:	mov    rsi,r12
  c17415:	call   QWORD PTR [rip+0x23632d]        # e4d748 <_DYNAMIC+0x2e8>
  c1741b:	mov    rcx,QWORD PTR [rsp+0x10]
  c17420:	mov    BYTE PTR [rcx],0x1f
  c17423:	lea    rax,[rip+0xffffffffff6aecee]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1742a:	mov    QWORD PTR [rcx+0x8],rax
  c1742e:	mov    QWORD PTR [rcx+0x10],0x4f
  c17436:	mov    eax,0x18
  c1743b:	jmp    c18577 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c57>
  c17440:	mov    rcx,QWORD PTR [rsp+0x10]
  c17445:	mov    BYTE PTR [rcx],0x1f
  c17448:	lea    rax,[rip+0xffffffffff6af4bd]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c1744f:	mov    QWORD PTR [rcx+0x8],rax
  c17453:	mov    r8d,0x4f
  c17459:	jmp    c18572 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c52>
  c1745e:	mov    rcx,QWORD PTR [rsp+0x10]
  c17463:	mov    BYTE PTR [rcx],0x1f
  c17466:	lea    rax,[rip+0xffffffffff6af244]        # 2c66b1 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x32e>
  c1746d:	mov    QWORD PTR [rcx+0x8],rax
  c17471:	mov    QWORD PTR [rcx+0x10],0x42
  c17479:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c1747e:	mov    r13b,0x1f
  c17481:	lea    rbx,[rip+0xffffffffff6aec90]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17488:	mov    r15d,0x4f
  c1748e:	jmp    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c17493:	mov    BYTE PTR [r15],0x1f
  c17497:	lea    rax,[rip+0xffffffffff6aedf5]        # 2c6293 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x18d2>
  c1749e:	mov    QWORD PTR [r15+0x8],rax
  c174a2:	mov    QWORD PTR [r15+0x10],0x3a
  c174aa:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c174af:	movdqu xmm0,XMMWORD PTR [rsp+0x102]
  c174b8:	movdqu xmm1,XMMWORD PTR [rsp+0x112]
  c174c1:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c174c9:	movups XMMWORD PTR [r15+0x20],xmm2
  c174ce:	movdqu XMMWORD PTR [r15+0x12],xmm1
  c174d4:	movdqu XMMWORD PTR [r15+0x2],xmm0
  c174da:	mov    BYTE PTR [r15],al
  c174dd:	mov    BYTE PTR [r15+0x1],bl
  c174e1:	jmp    c181fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88de>
  c174e6:	movups xmm0,XMMWORD PTR [rsp+0x101]
  c174ee:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c174f7:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c174ff:	movdqu XMMWORD PTR [rsp+0x7f],xmm1
  c17505:	movaps XMMWORD PTR [rsp+0x70],xmm0
  c1750a:	movups XMMWORD PTR [rbx+0x20],xmm2
  c1750e:	movups xmm0,XMMWORD PTR [rsp+0x7f]
  c17513:	movups XMMWORD PTR [rbx+0x10],xmm0
  c17517:	movdqa xmm0,XMMWORD PTR [rsp+0x70]
  c1751d:	movdqu XMMWORD PTR [rbx+0x1],xmm0
  c17522:	mov    BYTE PTR [rbx],al
  c17524:	jmp    c1851d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bfd>
  c17529:	test   r14b,0x1
  c1752d:	je     c18732 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e12>
  c17533:	mov    r12,QWORD PTR [rsp+0x8]
  c17538:	lea    rax,[r12+0x10]
  c1753d:	mov    rsi,QWORD PTR [rax]
  c17540:	mov    rdi,QWORD PTR [rsp]
  c17544:	cmp    rdi,rsi
  c17547:	mov    rbx,QWORD PTR [rsp+0x10]
  c1754c:	jae    c19de5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4c5>
  c17552:	lea    rax,[r12+0x8]
  c17557:	mov    rsi,QWORD PTR [rax]
  c1755a:	mov    rdi,QWORD PTR [rsp+0x18]
  c1755f:	lea    rdx,[rsi+rdi*1]
  c17563:	movzx  ecx,bpl
  c17567:	mov    rax,rcx
  c1756a:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c1756f:	mov    r14,QWORD PTR [rsp+0x20]
  c17574:	jae    c18c00 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92e0>
  c1757a:	mov    rax,QWORD PTR [rdx+0x28]
  c1757e:	shl    ecx,0x4
  c17581:	mov    rax,QWORD PTR [rax+rcx*1]
  c17585:	jmp    c18c04 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92e4>
  c1758a:	mov    rax,QWORD PTR [rsp+0x1a8]
  c17592:	mov    rsi,QWORD PTR [rax]
  c17595:	mov    rdi,QWORD PTR [rsp]
  c17599:	cmp    rdi,rsi
  c1759c:	jae    c19dd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4b8>
  c175a2:	mov    rax,QWORD PTR [rsp+0x198]
  c175aa:	mov    rdi,QWORD PTR [rax]
  c175ad:	mov    rax,QWORD PTR [rsp+0x20]
  c175b2:	mov    rax,QWORD PTR [rax+0x10]
  c175b6:	mov    r8,QWORD PTR [rsp+0x18]
  c175bb:	lea    rsi,[rdi+r8*1]
  c175bf:	movzx  edx,bpl
  c175c3:	mov    rcx,rdx
  c175c6:	sub    rcx,QWORD PTR [rdi+r8*1+0x30]
  c175cb:	mov    rdi,QWORD PTR [rsp+0x10]
  c175d0:	jae    c18751 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e31>
  c175d6:	mov    rcx,QWORD PTR [rsi+0x28]
  c175da:	shl    edx,0x4
  c175dd:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c175e1:	jmp    c18755 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e35>
  c175e6:	mov    rcx,QWORD PTR [rsp+0x10]
  c175eb:	mov    BYTE PTR [rcx],0x1f
  c175ee:	lea    rax,[rip+0xffffffffff6af162]        # 2c6757 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x3d4>
  c175f5:	mov    QWORD PTR [rcx+0x8],rax
  c175f9:	mov    QWORD PTR [rcx+0x10],0x5c
  c17601:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17606:	lea    rax,[rip+0xffffffffff6aecc0]        # 2c62cd <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x190c>
  c1760d:	jmp    c17a1f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80ff>
  c17612:	mov    BYTE PTR [r14],0x1f
  c17616:	lea    rax,[rip+0xffffffffff6aeafb]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1761d:	mov    QWORD PTR [r14+0x8],rax
  c17621:	mov    QWORD PTR [r14+0x10],0x4f
  c17629:	mov    rax,QWORD PTR [rsp+0x230]
  c17631:	mov    QWORD PTR [r14+0x18],rax
  c17635:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c1763a:	mov    BYTE PTR [r14],0x1f
  c1763e:	lea    rax,[rip+0xffffffffff6aead3]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17645:	mov    QWORD PTR [r14+0x8],rax
  c17649:	mov    QWORD PTR [r14+0x10],0x4f
  c17651:	mov    rax,QWORD PTR [rsp+0x248]
  c17659:	mov    QWORD PTR [r14+0x18],rax
  c1765d:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17662:	mov    BYTE PTR [rbx],0x1f
  c17665:	lea    rax,[rip+0xffffffffff6aeaac]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1766c:	mov    QWORD PTR [rbx+0x8],rax
  c17670:	mov    QWORD PTR [rbx+0x10],0x4f
  c17678:	mov    rax,QWORD PTR [rsp+0x250]
  c17680:	mov    QWORD PTR [rbx+0x18],rax
  c17684:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17689:	jmp    c17f19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85f9>
  c1768e:	mov    BYTE PTR [rbx],0x1f
  c17691:	lea    rax,[rip+0xffffffffff6aea80]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17698:	mov    QWORD PTR [rbx+0x8],rax
  c1769c:	mov    QWORD PTR [rbx+0x10],0x4f
  c176a4:	mov    rax,QWORD PTR [rsp+0x238]
  c176ac:	mov    QWORD PTR [rbx+0x18],rax
  c176b0:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c176b5:	mov    BYTE PTR [r8],0x1f
  c176b9:	lea    rax,[rip+0xffffffffff6aea58]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c176c0:	mov    QWORD PTR [r8+0x8],rax
  c176c4:	mov    QWORD PTR [r8+0x10],0x4f
  c176cc:	mov    rax,QWORD PTR [rsp+0x268]
  c176d4:	mov    QWORD PTR [r8+0x18],rax
  c176d8:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c176dd:	mov    BYTE PTR [rbx],0x1f
  c176e0:	lea    rax,[rip+0xffffffffff6aea31]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c176e7:	mov    QWORD PTR [rbx+0x8],rax
  c176eb:	mov    QWORD PTR [rbx+0x10],0x4f
  c176f3:	mov    eax,0x18
  c176f8:	mov    rcx,QWORD PTR [rsp+0x228]
  c17700:	mov    QWORD PTR [rbx+rax*1],rcx
  c17704:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17709:	mov    r15b,0x1f
  c1770c:	lea    rbx,[rip+0xffffffffff6aea05]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17713:	mov    r14d,0x4f
  c17719:	jmp    c1826f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x894f>
  c1771e:	mov    BYTE PTR [rbx],0x1f
  c17721:	lea    rax,[rip+0xffffffffff6ae9f0]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17728:	mov    QWORD PTR [rbx+0x8],rax
  c1772c:	mov    QWORD PTR [rbx+0x10],0x4f
  c17734:	mov    rax,QWORD PTR [rsp+0x280]
  c1773c:	mov    QWORD PTR [rbx+0x18],rax
  c17740:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17745:	jmp    c17f19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85f9>
  c1774a:	mov    BYTE PTR [r9],0x1f
  c1774e:	lea    rax,[rip+0xffffffffff6ae9c3]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17755:	mov    QWORD PTR [r9+0x8],rax
  c17759:	mov    QWORD PTR [r9+0x10],0x4f
  c17761:	mov    rax,QWORD PTR [rsp+0x278]
  c17769:	mov    QWORD PTR [r9+0x18],rax
  c1776d:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17772:	mov    BYTE PTR [rbx],0x1f
  c17775:	lea    rax,[rip+0xffffffffff6ae99c]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1777c:	mov    QWORD PTR [rbx+0x8],rax
  c17780:	mov    QWORD PTR [rbx+0x10],0x4f
  c17788:	mov    rax,QWORD PTR [rsp+0x258]
  c17790:	mov    QWORD PTR [rbx+0x18],rax
  c17794:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17799:	jmp    c17f19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85f9>
  c1779e:	mov    rcx,QWORD PTR [rsp+0x10]
  c177a3:	mov    BYTE PTR [rcx],0x1f
  c177a6:	lea    rax,[rip+0xffffffffff6ae96b]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c177ad:	mov    QWORD PTR [rcx+0x8],rax
  c177b1:	mov    QWORD PTR [rcx+0x10],0x4f
  c177b9:	mov    rax,QWORD PTR [rsp+0x240]
  c177c1:	mov    QWORD PTR [rcx+0x18],rax
  c177c5:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c177ca:	mov    r15b,0x1f
  c177cd:	lea    rbx,[rip+0xffffffffff6ae944]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c177d4:	mov    r14d,0x4f
  c177da:	jmp    c18393 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a73>
  c177df:	mov    BYTE PTR [r8],0x1f
  c177e3:	lea    rax,[rip+0xffffffffff6ae92e]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c177ea:	mov    QWORD PTR [r8+0x8],rax
  c177ee:	mov    QWORD PTR [r8+0x10],0x4f
  c177f6:	mov    rax,QWORD PTR [rsp+0x260]
  c177fe:	mov    QWORD PTR [r8+0x18],rax
  c17802:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17807:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c17810:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c17819:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c17821:	mov    r15,QWORD PTR [rsp+0x10]
  c17826:	movups XMMWORD PTR [r15+0x20],xmm2
  c1782b:	movdqu XMMWORD PTR [r15+0x10],xmm1
  c17831:	movdqu XMMWORD PTR [r15],xmm0
  c17836:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c1783b:	mov    BYTE PTR [rbx],0x1f
  c1783e:	lea    rax,[rip+0xffffffffff6ae8d3]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17845:	mov    QWORD PTR [rbx+0x8],rax
  c17849:	mov    QWORD PTR [rbx+0x10],0x4f
  c17851:	mov    rax,QWORD PTR [rsp+0x288]
  c17859:	mov    QWORD PTR [rbx+0x18],rax
  c1785d:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17862:	movdqu xmm0,XMMWORD PTR [rsp+0x108]
  c1786b:	movdqu xmm1,XMMWORD PTR [rsp+0x118]
  c17874:	movups xmm2,XMMWORD PTR [rsp+0x128]
  c1787c:	movups XMMWORD PTR [rsp+0x54],xmm2
  c17881:	movdqu XMMWORD PTR [rsp+0x44],xmm1
  c17887:	movdqu XMMWORD PTR [rsp+0x34],xmm0
  c1788d:	movups XMMWORD PTR [r14+0x20],xmm2
  c17892:	movdqu XMMWORD PTR [r14+0x10],xmm1
  c17898:	movdqu XMMWORD PTR [r14],xmm0
  c1789d:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c178a2:	mov    BYTE PTR [r9],0x1f
  c178a6:	lea    rax,[rip+0xffffffffff6ae86b]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c178ad:	mov    QWORD PTR [r9+0x8],rax
  c178b1:	mov    QWORD PTR [r9+0x10],0x4f
  c178b9:	mov    rax,QWORD PTR [rsp+0x270]
  c178c1:	mov    QWORD PTR [r9+0x18],rax
  c178c5:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c178ca:	mov    rcx,QWORD PTR [rsp+0x10]
  c178cf:	mov    BYTE PTR [rcx],0x1f
  c178d2:	lea    rax,[rip+0xffffffffff6aeeda]        # 2c67b3 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x430>
  c178d9:	mov    QWORD PTR [rcx+0x8],rax
  c178dd:	mov    QWORD PTR [rcx+0x10],0x51
  c178e5:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c178ea:	mov    BYTE PTR [rbx],0x1f
  c178ed:	lea    rax,[rip+0xffffffffff6ae824]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c178f4:	mov    QWORD PTR [rbx+0x8],rax
  c178f8:	mov    QWORD PTR [rbx+0x10],0x4f
  c17900:	mov    eax,0x18
  c17905:	mov    rcx,QWORD PTR [rsp+0x220]
  c1790d:	mov    QWORD PTR [rbx+rax*1],rcx
  c17911:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17916:	mov    BYTE PTR [rbx],0x1f
  c17919:	lea    rax,[rip+0xffffffffff6ae7f8]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17920:	mov    QWORD PTR [rbx+0x8],rax
  c17924:	mov    QWORD PTR [rbx+0x10],0x4f
  c1792c:	mov    QWORD PTR [rbx+0x18],r9
  c17930:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17935:	mov    BYTE PTR [r15],0x1f
  c17939:	lea    rax,[rip+0xffffffffff6ae7d8]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17940:	mov    QWORD PTR [r15+0x8],rax
  c17944:	mov    QWORD PTR [r15+0x10],0x4f
  c1794c:	mov    rax,QWORD PTR [rsp+0x1f0]
  c17954:	mov    QWORD PTR [r15+0x18],rax
  c17958:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c1795d:	mov    BYTE PTR [r15],0x1f
  c17961:	lea    rax,[rip+0xffffffffff6ae7b0]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17968:	mov    QWORD PTR [r15+0x8],rax
  c1796c:	mov    QWORD PTR [r15+0x10],0x4f
  c17974:	mov    rax,QWORD PTR [rsp+0x1f8]
  c1797c:	mov    QWORD PTR [r15+0x18],rax
  c17980:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17985:	movups xmm0,XMMWORD PTR [rsp+0x101]
  c1798d:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c17996:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c1799e:	movdqu XMMWORD PTR [rsp+0x3f],xmm1
  c179a4:	movaps XMMWORD PTR [rsp+0x30],xmm0
  c179a9:	movups XMMWORD PTR [r14+0x20],xmm2
  c179ae:	movups xmm0,XMMWORD PTR [rsp+0x3f]
  c179b3:	movups XMMWORD PTR [r14+0x10],xmm0
  c179b8:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c179be:	movdqu XMMWORD PTR [r14+0x1],xmm0
  c179c4:	mov    BYTE PTR [r14],al
  c179c7:	jmp    c17e8b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x856b>
  c179cc:	mov    r13b,0x1f
  c179cf:	lea    rbx,[rip+0xffffffffff6ae742]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c179d6:	mov    r15d,0x4f
  c179dc:	jmp    c18414 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af4>
  c179e1:	mov    r15b,0x1f
  c179e4:	lea    rbx,[rip+0xffffffffff6ae72d]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c179eb:	mov    r14d,0x4f
  c179f1:	jmp    c1836b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a4b>
  c179f6:	mov    r15b,0x1f
  c179f9:	lea    rbx,[rip+0xffffffffff6ae718]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a00:	mov    r14d,0x4f
  c17a06:	jmp    c18245 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8925>
  c17a0b:	lea    rdi,[rsp+0x100]
  c17a13:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17a18:	lea    rax,[rip+0xffffffffff6aeeed]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c17a1f:	mov    rcx,QWORD PTR [rsp+0x10]
  c17a24:	mov    BYTE PTR [rcx],0x1f
  c17a27:	mov    QWORD PTR [rcx+0x8],rax
  c17a2b:	mov    QWORD PTR [rcx+0x10],0x4f
  c17a33:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17a38:	mov    r13b,0x1f
  c17a3b:	lea    rbx,[rip+0xffffffffff6ae6d6]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a42:	mov    r15d,0x4f
  c17a48:	jmp    c182e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c7>
  c17a4d:	mov    BYTE PTR [rbx],0x1f
  c17a50:	lea    rax,[rip+0xffffffffff6ae6c1]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a57:	mov    QWORD PTR [rbx+0x8],rax
  c17a5b:	mov    QWORD PTR [rbx+0x10],0x4f
  c17a63:	mov    rax,QWORD PTR [rsp+0x210]
  c17a6b:	mov    QWORD PTR [rbx+0x18],rax
  c17a6f:	jmp    c184ba <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b9a>
  c17a74:	mov    BYTE PTR [r9],0x1f
  c17a78:	lea    rax,[rip+0xffffffffff6ae699]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a7f:	mov    QWORD PTR [r9+0x8],rax
  c17a83:	mov    QWORD PTR [r9+0x10],0x4f
  c17a8b:	mov    rax,QWORD PTR [rsp+0x200]
  c17a93:	mov    QWORD PTR [r9+0x18],rax
  c17a97:	jmp    c18170 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8850>
  c17a9c:	jmp    c17ee9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85c9>
  c17aa1:	mov    eax,DWORD PTR [rsp+0x101]
  c17aa8:	mov    edx,DWORD PTR [rsp+0x104]
  c17aaf:	mov    DWORD PTR [rbx+0x4],edx
  c17ab2:	mov    DWORD PTR [rbx+0x1],eax
  c17ab5:	mov    rax,QWORD PTR [rsp+0x108]
  c17abd:	movups xmm0,XMMWORD PTR [rsp+0x120]
  c17ac5:	movups XMMWORD PTR [rbx+0x20],xmm0
  c17ac9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c17ad2:	movdqu XMMWORD PTR [rbx+0x10],xmm0
  c17ad7:	mov    BYTE PTR [rbx],cl
  c17ad9:	mov    ecx,0x8
  c17ade:	mov    QWORD PTR [rbx+rcx*1],rax
  c17ae2:	jmp    c181fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88de>
  c17ae7:	mov    BYTE PTR [r9],0x1f
  c17aeb:	lea    rax,[rip+0xffffffffff6ae626]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17af2:	mov    QWORD PTR [r9+0x8],rax
  c17af6:	mov    QWORD PTR [r9+0x10],0x4f
  c17afe:	mov    rax,QWORD PTR [rsp+0x208]
  c17b06:	mov    QWORD PTR [r9+0x18],rax
  c17b0a:	jmp    c181a7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8887>
  c17b0f:	mov    rcx,QWORD PTR [rsp+0x10]
  c17b14:	mov    BYTE PTR [rcx],0x1f
  c17b17:	lea    rax,[rip+0xffffffffff6ae5fa]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17b1e:	mov    QWORD PTR [rcx+0x8],rax
  c17b22:	mov    QWORD PTR [rcx+0x10],0x4f
  c17b2a:	mov    rax,QWORD PTR [rsp+0x1d0]
  c17b32:	mov    QWORD PTR [rcx+0x18],rax
  c17b36:	jmp    c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c17b3b:	mov    BYTE PTR [rbx],0x1f
  c17b3e:	lea    rax,[rip+0xffffffffff6ae5d3]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17b45:	mov    QWORD PTR [rbx+0x8],rax
  c17b49:	mov    QWORD PTR [rbx+0x10],0x4f
  c17b51:	mov    rax,QWORD PTR [rsp+0x218]
  c17b59:	mov    QWORD PTR [rbx+0x18],rax
  c17b5d:	jmp    c1851d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bfd>
  c17b62:	movdqu xmm0,XMMWORD PTR [rsp+0x108]
  c17b6b:	movdqu xmm1,XMMWORD PTR [rsp+0x118]
  c17b74:	movups xmm2,XMMWORD PTR [rsp+0x128]
  c17b7c:	movups XMMWORD PTR [rsp+0x54],xmm2
  c17b81:	movdqu XMMWORD PTR [rsp+0x44],xmm1
  c17b87:	movdqu XMMWORD PTR [rsp+0x34],xmm0
  c17b8d:	movups XMMWORD PTR [r14+0x20],xmm2
  c17b92:	movdqu XMMWORD PTR [r14+0x10],xmm1
  c17b98:	movdqu XMMWORD PTR [r14],xmm0
  c17b9d:	jmp    c18ea2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9582>
  c17ba2:	mov    rax,QWORD PTR [rsp+0x1e0]
  c17baa:	movzx  esi,BYTE PTR [rax+0xc5]
  c17bb1:	lea    rdi,[rsp+0x100]
  c17bb9:	mov    ecx,0x8
  c17bbe:	mov    r8d,0x18
  c17bc4:	xor    edx,edx
  c17bc6:	call   c4f540 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsbxgXiyEKxkX_6bsl_vm>
  c17bcb:	mov    rdi,QWORD PTR [rsp+0x108]
  c17bd3:	cmp    BYTE PTR [rsp+0x100],0x0
  c17bdb:	jne    c19778 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e58>
  c17be1:	mov    rax,QWORD PTR [rsp+0x110]
  c17be9:	mov    QWORD PTR [rsp+0xc0],rdi
  c17bf1:	mov    QWORD PTR [rsp+0xc8],rax
  c17bf9:	mov    QWORD PTR [rsp+0xd0],0x0
  c17c05:	mov    r15,QWORD PTR [rbx+0x10]
  c17c09:	lea    rdi,[rsp+0x100]
  c17c11:	mov    ecx,0x8
  c17c16:	mov    r8d,0x10
  c17c1c:	mov    rsi,r15
  c17c1f:	xor    edx,edx
  c17c21:	call   c4f540 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsbxgXiyEKxkX_6bsl_vm>
  c17c26:	mov    rdi,QWORD PTR [rsp+0x108]
  c17c2e:	cmp    BYTE PTR [rsp+0x100],0x0
  c17c36:	jne    c19786 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e66>
  c17c3c:	mov    rax,QWORD PTR [rsp+0x110]
  c17c44:	mov    QWORD PTR [rsp+0x30],rdi
  c17c49:	mov    QWORD PTR [rsp+0x38],rax
  c17c4e:	mov    QWORD PTR [rsp+0x40],0x0
  c17c57:	mov    rbx,QWORD PTR [rbx+0x8]
  c17c5b:	shl    r15,0x2
  c17c5f:	mov    QWORD PTR [rsp+0x8],r15
  c17c64:	xor    r13d,r13d
  c17c67:	lea    rax,[rip+0x21e36a]        # e35fd8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x738>
  c17c6e:	mov    QWORD PTR [rsp+0x1b0],rax
  c17c76:	cmp    QWORD PTR [rsp+0x8],r13
  c17c7b:	mov    r15,QWORD PTR [rsp+0x18]
  c17c80:	je     c18926 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9006>
  c17c86:	movzx  eax,BYTE PTR [rbx+r13*1]
  c17c8b:	lea    rcx,[rip+0xffffffffff6add5e]        # 2c59f0 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x102f>
  c17c92:	movsxd rax,DWORD PTR [rcx+rax*4]
  c17c96:	add    rax,rcx
  c17c99:	jmp    rax
  c17c9b:	mov    rax,QWORD PTR [rsp+0x1a8]
  c17ca3:	mov    rsi,QWORD PTR [rax]
  c17ca6:	cmp    QWORD PTR [rsp],rsi
  c17caa:	jae    c19db2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa492>
  c17cb0:	mov    rax,QWORD PTR [rsp+0x198]
  c17cb8:	mov    rsi,QWORD PTR [rax]
  c17cbb:	lea    rdx,[rsi+r15*1]
  c17cbf:	movzx  ecx,r14b
  c17cc3:	mov    rax,rcx
  c17cc6:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c17ccb:	jae    c17d82 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8462>
  c17cd1:	mov    rax,QWORD PTR [rdx+0x28]
  c17cd5:	shl    ecx,0x4
  c17cd8:	mov    rax,QWORD PTR [rax+rcx*1]
  c17cdc:	jmp    c17d86 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8466>
  c17ce1:	movzx  eax,WORD PTR [rbx+r13*1+0x2]
  c17ce7:	mov    rcx,QWORD PTR [rsp+0x1b8]
  c17cef:	cmp    QWORD PTR [rcx+0x10],rax
  c17cf3:	jbe    c19127 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9807>
  c17cf9:	lea    rsi,[rax+rax*2]
  c17cfd:	shl    esi,0x3
  c17d00:	add    rsi,QWORD PTR [rcx+0x8]
  c17d04:	lea    rdi,[rsp+0x100]
  c17d0c:	call   c24e60 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c17d11:	mov    rax,QWORD PTR [rsp+0x100]
  c17d19:	mov    rcx,QWORD PTR [rsp+0x110]
  c17d21:	mov    QWORD PTR [rsp+0x1d8],rcx
  c17d29:	jmp    c17e0c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x84ec>
  c17d2e:	mov    DWORD PTR [rsp+0x508],0x2
  c17d39:	xor    r12d,r12d
  c17d3c:	jmp    c17e29 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8509>
  c17d41:	mov    rax,QWORD PTR [rsp+0x1a8]
  c17d49:	mov    rsi,QWORD PTR [rax]
  c17d4c:	cmp    QWORD PTR [rsp],rsi
  c17d50:	jae    c19dc1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4a1>
  c17d56:	mov    rax,QWORD PTR [rsp+0x198]
  c17d5e:	mov    rsi,QWORD PTR [rax]
  c17d61:	lea    rdx,[rsi+r15*1]
  c17d65:	movzx  ecx,BYTE PTR [rbx+r13*1+0x1]
  c17d6b:	mov    rax,rcx
  c17d6e:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c17d73:	jae    c17dc8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x84a8>
  c17d75:	mov    rax,QWORD PTR [rdx+0x28]
  c17d79:	shl    ecx,0x4
  c17d7c:	mov    rax,QWORD PTR [rax+rcx*1]
  c17d80:	jmp    c17dcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x84ac>
  c17d82:	add    rax,QWORD PTR [rdx+0x60]
  c17d86:	mov    rcx,QWORD PTR [rsp+0x20]
  c17d8b:	cmp    rax,QWORD PTR [rcx+0x10]
  c17d8f:	jae    c19153 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9833>
  c17d95:	mov    rcx,QWORD PTR [rcx+0x8]
  c17d99:	lea    rax,[rax+rax*2]
  c17d9d:	lea    rsi,[rcx+rax*8]
  c17da1:	lea    rdi,[rsp+0x100]
  c17da9:	call   c24e60 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c17dae:	mov    rax,QWORD PTR [rsp+0x100]
  c17db6:	mov    rcx,QWORD PTR [rsp+0x110]
  c17dbe:	mov    QWORD PTR [rsp+0x1c0],rcx
  c17dc6:	jmp    c17e0c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x84ec>
  c17dc8:	add    rax,QWORD PTR [rdx+0x60]
  c17dcc:	mov    rcx,QWORD PTR [rsp+0x20]
  c17dd1:	cmp    rax,QWORD PTR [rcx+0x10]
  c17dd5:	jae    c1917f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x985f>
  c17ddb:	mov    rcx,QWORD PTR [rcx+0x8]
  c17ddf:	lea    rax,[rax+rax*2]
  c17de3:	lea    rsi,[rcx+rax*8]
  c17de7:	lea    rdi,[rsp+0x100]
  c17def:	call   c24e60 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c17df4:	mov    rax,QWORD PTR [rsp+0x100]
  c17dfc:	mov    rcx,QWORD PTR [rsp+0x110]
  c17e04:	mov    QWORD PTR [rsp+0x350],rcx
  c17e0c:	movdqu xmm0,XMMWORD PTR [rsp+0x108]
  c17e15:	mov    QWORD PTR [rsp+0x508],rax
  c17e1d:	movdqu XMMWORD PTR [rsp+0x510],xmm0
  c17e26:	mov    r12b,0x1
  c17e29:	mov    r15,QWORD PTR [rsp+0xd0]
  c17e31:	lea    rdi,[rsp+0xc0]
  c17e39:	lea    rsi,[rsp+0x508]
  c17e41:	call   c24420 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueE8push_mutCsbxgXiyEKxkX_6bsl_vm>
  c17e46:	inc    r14b
  c17e49:	add    r13,0x4
  c17e4d:	movzx  edx,r12b
  c17e51:	lea    rdi,[rsp+0x30]
  c17e56:	mov    rsi,r15
  c17e59:	call   c243c0 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCsbxgXiyEKxkX_6bsl_vm9ParamSlotE8push_mutBG_>
  c17e5e:	jmp    c17c76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8356>
  c17e63:	lea    rdi,[rsp+0x100]
  c17e6b:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17e70:	mov    rcx,QWORD PTR [rsp+0x10]
  c17e75:	mov    BYTE PTR [rcx],0x1f
  c17e78:	lea    rax,[rip+0xffffffffff6aea8d]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c17e7f:	mov    QWORD PTR [rcx+0x8],rax
  c17e83:	mov    QWORD PTR [rcx+0x10],0x4f
  c17e8b:	lea    rdi,[rsp+0x70]
  c17e90:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c17e95:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17e9a:	mov    BYTE PTR [r15],0x1f
  c17e9e:	lea    rax,[rip+0xffffffffff6ae428]        # 2c62cd <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x190c>
  c17ea5:	mov    QWORD PTR [r15+0x8],rax
  c17ea9:	mov    QWORD PTR [r15+0x10],0x4f
  c17eb1:	jmp    c181fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88de>
  c17eb6:	mov    BYTE PTR [r15],0x1f
  c17eba:	lea    rax,[rip+0xffffffffff6ae40c]        # 2c62cd <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x190c>
  c17ec1:	mov    QWORD PTR [r15+0x8],rax
  c17ec5:	mov    QWORD PTR [r15+0x10],0x4f
  c17ecd:	lea    rdi,[rsp+0x100]
  c17ed5:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17eda:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17edf:	lea    rdi,[rsp+0x4f0]
  c17ee7:	jmp    c17f21 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8601>
  c17ee9:	lea    rdi,[rsp+0x100]
  c17ef1:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17ef6:	mov    BYTE PTR [rbx],0x1f
  c17ef9:	lea    rax,[rip+0xffffffffff6aea0c]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c17f00:	mov    QWORD PTR [rbx+0x8],rax
  c17f04:	mov    eax,0x4f
  c17f09:	mov    ecx,0x10
  c17f0e:	mov    QWORD PTR [rbx+rcx*1],rax
  c17f12:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17f17:	jmp    c17f19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85f9>
  c17f19:	lea    rdi,[rsp+0x100]
  c17f21:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17f26:	mov    BYTE PTR [rbx],0x1f
  c17f29:	lea    rax,[rip+0xffffffffff6ae9dc]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c17f30:	mov    QWORD PTR [rbx+0x8],rax
  c17f34:	mov    QWORD PTR [rbx+0x10],0x4f
  c17f3c:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c17f41:	lea    rdi,[rsp+0x100]
  c17f49:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17f4e:	mov    rbx,QWORD PTR [rsp+0x10]
  c17f53:	mov    BYTE PTR [rbx],0x1f
  c17f56:	lea    rax,[rip+0xffffffffff6ae9af]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c17f5d:	mov    QWORD PTR [rbx+0x8],rax
  c17f61:	mov    eax,0x4f
  c17f66:	mov    ecx,0x10
  c17f6b:	mov    QWORD PTR [rbx+rcx*1],rax
  c17f6f:	jmp    c181fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88de>
  c17f74:	mov    ebp,ecx
  c17f76:	movzx  eax,WORD PTR [rsp+0x106]
  c17f7e:	mov    WORD PTR [rsp+0xe4],ax
  c17f86:	mov    eax,DWORD PTR [rsp+0x102]
  c17f8d:	mov    DWORD PTR [rsp+0xe0],eax
  c17f94:	mov    rbx,QWORD PTR [rsp+0x108]
  c17f9c:	mov    r14,QWORD PTR [rsp+0x110]
  c17fa4:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c17fad:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c17fb6:	mov    rax,QWORD PTR [rsp+0x128]
  c17fbe:	mov    QWORD PTR [rsp+0xd0],rax
  c17fc6:	mov    r15d,edx
  c17fc9:	jmp    c1821d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88fd>
  c17fce:	movzx  eax,WORD PTR [rsp+0x106]
  c17fd6:	mov    WORD PTR [rsp+0xe4],ax
  c17fde:	mov    eax,DWORD PTR [rsp+0x102]
  c17fe5:	mov    DWORD PTR [rsp+0xe0],eax
  c17fec:	mov    rbx,QWORD PTR [rsp+0x108]
  c17ff4:	mov    r14,QWORD PTR [rsp+0x110]
  c17ffc:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c18005:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c1800e:	mov    rax,QWORD PTR [rsp+0x128]
  c18016:	mov    QWORD PTR [rsp+0xd0],rax
  c1801e:	mov    r15d,ecx
  c18021:	jmp    c18343 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a23>
  c18026:	mov    ebp,ecx
  c18028:	movzx  eax,WORD PTR [rsp+0x106]
  c18030:	mov    WORD PTR [rsp+0xe4],ax
  c18038:	mov    eax,DWORD PTR [rsp+0x102]
  c1803f:	mov    DWORD PTR [rsp+0xe0],eax
  c18046:	mov    rbx,QWORD PTR [rsp+0x108]
  c1804e:	mov    r15,QWORD PTR [rsp+0x110]
  c18056:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c1805f:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c18068:	mov    rax,QWORD PTR [rsp+0x128]
  c18070:	mov    QWORD PTR [rsp+0xd0],rax
  c18078:	jmp    c183ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8acc>
  c1807d:	mov    ebp,ecx
  c1807f:	movzx  eax,WORD PTR [rsp+0x106]
  c18087:	mov    WORD PTR [rsp+0xe4],ax
  c1808f:	mov    eax,DWORD PTR [rsp+0x102]
  c18096:	mov    DWORD PTR [rsp+0xe0],eax
  c1809d:	mov    rbx,QWORD PTR [rsp+0x108]
  c180a5:	mov    r15,QWORD PTR [rsp+0x110]
  c180ad:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c180b6:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c180bf:	mov    rax,QWORD PTR [rsp+0x128]
  c180c7:	mov    QWORD PTR [rsp+0xd0],rax
  c180cf:	jmp    c182bf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x899f>
  c180d4:	mov    BYTE PTR [rbx],0x1f
  c180d7:	lea    rax,[rip+0xffffffffff6ae03a]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c180de:	mov    QWORD PTR [rbx+0x8],rax
  c180e2:	mov    QWORD PTR [rbx+0x10],0x4f
  c180ea:	mov    rax,QWORD PTR [rsp+0x1e8]
  c180f2:	mov    QWORD PTR [rbx+0x18],rax
  c180f6:	jmp    c18513 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bf3>
  c180fb:	movups xmm0,XMMWORD PTR [rsp+0x101]
  c18103:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c1810c:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c18114:	movdqu XMMWORD PTR [rsp+0x7f],xmm1
  c1811a:	movaps XMMWORD PTR [rsp+0x70],xmm0
  c1811f:	movups XMMWORD PTR [rbx+0x20],xmm2
  c18123:	movups xmm0,XMMWORD PTR [rsp+0x7f]
  c18128:	movups XMMWORD PTR [rbx+0x10],xmm0
  c1812c:	movdqa xmm0,XMMWORD PTR [rsp+0x70]
  c18132:	movdqu XMMWORD PTR [rbx+0x1],xmm0
  c18137:	mov    BYTE PTR [rbx],al
  c18139:	jmp    c184ad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b8d>
  c1813e:	lea    rdi,[rsp+0x100]
  c18146:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1814b:	mov    rcx,QWORD PTR [rsp+0x10]
  c18150:	mov    BYTE PTR [rcx],0x1f
  c18153:	lea    rax,[rip+0xffffffffff6ae7b2]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c1815a:	mov    QWORD PTR [rcx+0x8],rax
  c1815e:	mov    QWORD PTR [rcx+0x10],0x4f
  c18166:	lea    rdi,[rsp+0x70]
  c1816b:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18170:	jmp    c1851d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bfd>
  c18175:	lea    rdi,[rsp+0x100]
  c1817d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18182:	mov    rcx,QWORD PTR [rsp+0x10]
  c18187:	mov    BYTE PTR [rcx],0x1f
  c1818a:	lea    rax,[rip+0xffffffffff6ae77b]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c18191:	mov    QWORD PTR [rcx+0x8],rax
  c18195:	mov    QWORD PTR [rcx+0x10],0x4f
  c1819d:	lea    rdi,[rsp+0x70]
  c181a2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c181a7:	jmp    c1851d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bfd>
  c181ac:	mov    rcx,QWORD PTR [rsp+0x10]
  c181b1:	mov    BYTE PTR [rcx],0x23
  c181b4:	lea    rax,[rip+0xffffffffff6ae68d]        # 2c6848 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x4c5>
  c181bb:	mov    QWORD PTR [rcx+0x8],rax
  c181bf:	mov    QWORD PTR [rcx+0x10],0x3f
  c181c7:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c181cc:	movdqu xmm0,XMMWORD PTR [rsp+0x102]
  c181d5:	movdqu xmm1,XMMWORD PTR [rsp+0x112]
  c181de:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c181e6:	movups XMMWORD PTR [r15+0x20],xmm2
  c181eb:	movdqu XMMWORD PTR [r15+0x12],xmm1
  c181f1:	movdqu XMMWORD PTR [r15+0x2],xmm0
  c181f7:	mov    BYTE PTR [r15],cl
  c181fa:	mov    BYTE PTR [r15+0x1],al
  c181fe:	lea    rdi,[rsp+0x70]
  c18203:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18208:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c1820d:	mov    r15b,0x1f
  c18210:	lea    rbx,[rip+0xffffffffff6ae6f5]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c18217:	mov    r14d,0x4f
  c1821d:	mov    eax,DWORD PTR [rsp+0x70]
  c18221:	mov    edx,eax
  c18223:	sub    edx,0x2
  c18226:	mov    ecx,0x3
  c1822b:	cmovae ecx,edx
  c1822e:	cmp    ecx,0x8
  c18231:	ja     c18efb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x95db>
  c18237:	mov    edx,0x1e7
  c1823c:	bt     edx,ecx
  c1823f:	jae    c18971 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9051>
  c18245:	mov    eax,DWORD PTR [rsp+0x30]
  c18249:	mov    edx,eax
  c1824b:	sub    edx,0x2
  c1824e:	mov    ecx,0x3
  c18253:	cmovae ecx,edx
  c18256:	cmp    ecx,0x8
  c18259:	ja     c18b96 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9276>
  c1825f:	mov    edx,0x1e7
  c18264:	bt     edx,ecx
  c18267:	jae    c186d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8db2>
  c1826d:	mov    edx,ebp
  c1826f:	movzx  eax,WORD PTR [rsp+0xe4]
  c18277:	mov    rcx,QWORD PTR [rsp+0x10]
  c1827c:	mov    WORD PTR [rcx+0x6],ax
  c18280:	mov    eax,DWORD PTR [rsp+0xe0]
  c18287:	mov    DWORD PTR [rcx+0x2],eax
  c1828a:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c18293:	movdqu XMMWORD PTR [rcx+0x18],xmm0
  c18298:	mov    rax,QWORD PTR [rsp+0xd0]
  c182a0:	mov    QWORD PTR [rcx+0x28],rax
  c182a4:	mov    BYTE PTR [rcx],r15b
  c182a7:	mov    BYTE PTR [rcx+0x1],dl
  c182aa:	jmp    c183cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8aaf>
  c182af:	mov    r13b,0x1f
  c182b2:	lea    rbx,[rip+0xffffffffff6ae653]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c182b9:	mov    r15d,0x4f
  c182bf:	mov    eax,DWORD PTR [rsp+0x70]
  c182c3:	mov    edx,eax
  c182c5:	sub    edx,0x2
  c182c8:	mov    ecx,0x3
  c182cd:	cmovae ecx,edx
  c182d0:	cmp    ecx,0x8
  c182d3:	ja     c18f91 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9671>
  c182d9:	mov    edx,0x1e7
  c182de:	bt     edx,ecx
  c182e1:	jae    c189cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x90af>
  c182e7:	mov    eax,DWORD PTR [rsp+0x30]
  c182eb:	mov    edx,eax
  c182ed:	sub    edx,0x2
  c182f0:	mov    ecx,0x3
  c182f5:	cmovae ecx,edx
  c182f8:	cmp    ecx,0x8
  c182fb:	ja     c18be2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92c2>
  c18301:	mov    edx,0x1e7
  c18306:	bt     edx,ecx
  c18309:	jb     c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c1830f:	cmp    ecx,0x3
  c18312:	jne    c18bc4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92a4>
  c18318:	test   eax,eax
  c1831a:	je     c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18320:	mov    rax,QWORD PTR [rsp+0x38]
  c18325:	dec    QWORD PTR [rax]
  c18328:	jne    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c1832e:	jmp    c18722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e02>
  c18333:	mov    r15b,0x1f
  c18336:	lea    rbx,[rip+0xffffffffff6ae5cf]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c1833d:	mov    r14d,0x4f
  c18343:	mov    eax,DWORD PTR [rsp+0x70]
  c18347:	mov    edx,eax
  c18349:	sub    edx,0x2
  c1834c:	mov    ecx,0x3
  c18351:	cmovae ecx,edx
  c18354:	cmp    ecx,0x8
  c18357:	ja     c18f55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9635>
  c1835d:	mov    edx,0x1e7
  c18362:	bt     edx,ecx
  c18365:	jae    c189a0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9080>
  c1836b:	mov    eax,DWORD PTR [rsp+0x30]
  c1836f:	mov    edx,eax
  c18371:	sub    edx,0x2
  c18374:	mov    ecx,0x3
  c18379:	cmovae ecx,edx
  c1837c:	cmp    ecx,0x8
  c1837f:	ja     c18b78 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9258>
  c18385:	mov    edx,0x1e7
  c1838a:	bt     edx,ecx
  c1838d:	jae    c186a3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d83>
  c18393:	movzx  eax,WORD PTR [rsp+0xe4]
  c1839b:	mov    rcx,QWORD PTR [rsp+0x10]
  c183a0:	mov    WORD PTR [rcx+0x6],ax
  c183a4:	mov    eax,DWORD PTR [rsp+0xe0]
  c183ab:	mov    DWORD PTR [rcx+0x2],eax
  c183ae:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c183b7:	movdqu XMMWORD PTR [rcx+0x18],xmm0
  c183bc:	mov    rax,QWORD PTR [rsp+0xd0]
  c183c4:	mov    QWORD PTR [rcx+0x28],rax
  c183c8:	mov    BYTE PTR [rcx],r15b
  c183cb:	mov    BYTE PTR [rcx+0x1],bpl
  c183cf:	mov    QWORD PTR [rcx+0x8],rbx
  c183d3:	mov    QWORD PTR [rcx+0x10],r14
  c183d7:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c183dc:	mov    r13b,0x1f
  c183df:	lea    rbx,[rip+0xffffffffff6ae526]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c183e6:	mov    r15d,0x4f
  c183ec:	mov    eax,DWORD PTR [rsp+0x70]
  c183f0:	mov    edx,eax
  c183f2:	sub    edx,0x2
  c183f5:	mov    ecx,0x3
  c183fa:	cmovae ecx,edx
  c183fd:	cmp    ecx,0x8
  c18400:	ja     c18faf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x968f>
  c18406:	mov    edx,0x1e7
  c1840b:	bt     edx,ecx
  c1840e:	jae    c189fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x90de>
  c18414:	mov    eax,DWORD PTR [rsp+0x30]
  c18418:	mov    edx,eax
  c1841a:	sub    edx,0x2
  c1841d:	mov    ecx,0x3
  c18422:	cmovae ecx,edx
  c18425:	cmp    ecx,0x8
  c18428:	ja     c18bb4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9294>
  c1842e:	mov    edx,0x1e7
  c18433:	bt     edx,ecx
  c18436:	jae    c18703 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8de3>
  c1843c:	movzx  eax,WORD PTR [rsp+0xe4]
  c18444:	mov    rcx,QWORD PTR [rsp+0x10]
  c18449:	mov    WORD PTR [rcx+0x6],ax
  c1844d:	mov    eax,DWORD PTR [rsp+0xe0]
  c18454:	mov    DWORD PTR [rcx+0x2],eax
  c18457:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c18460:	movdqu XMMWORD PTR [rcx+0x18],xmm0
  c18465:	mov    rax,QWORD PTR [rsp+0xd0]
  c1846d:	mov    QWORD PTR [rcx+0x28],rax
  c18471:	mov    BYTE PTR [rcx],r13b
  c18474:	mov    BYTE PTR [rcx+0x1],bpl
  c18478:	mov    QWORD PTR [rcx+0x8],rbx
  c1847c:	mov    QWORD PTR [rcx+0x10],r15
  c18480:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c18485:	lea    rdi,[rsp+0x100]
  c1848d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18492:	mov    rcx,QWORD PTR [rsp+0x10]
  c18497:	mov    BYTE PTR [rcx],0x1f
  c1849a:	lea    rax,[rip+0xffffffffff6ae46b]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c184a1:	mov    QWORD PTR [rcx+0x8],rax
  c184a5:	mov    QWORD PTR [rcx+0x10],0x4f
  c184ad:	lea    rdi,[rsp+0xc0]
  c184b5:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c184ba:	jmp    c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c184bf:	lea    rdi,[rsp+0x100]
  c184c7:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c184cc:	mov    rcx,QWORD PTR [rsp+0x10]
  c184d1:	mov    BYTE PTR [rcx],0x1f
  c184d4:	lea    rax,[rip+0xffffffffff6ae431]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c184db:	mov    QWORD PTR [rcx+0x8],rax
  c184df:	mov    QWORD PTR [rcx+0x10],0x4f
  c184e7:	jmp    c18e98 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9578>
  c184ec:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c184f5:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c184fe:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c18506:	movups XMMWORD PTR [rbx+0x20],xmm2
  c1850a:	movdqu XMMWORD PTR [rbx+0x10],xmm1
  c1850f:	movdqu XMMWORD PTR [rbx],xmm0
  c18513:	lea    rdi,[rsp+0x70]
  c18518:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1851d:	lea    rdi,[rsp+0x30]
  c18522:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18527:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c1852c:	lea    rdi,[rsp+0x100]
  c18534:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18539:	mov    rcx,QWORD PTR [rsp+0x10]
  c1853e:	mov    BYTE PTR [rcx],0x1f
  c18541:	lea    rax,[rip+0xffffffffff6ae3c4]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c18548:	mov    QWORD PTR [rcx+0x8],rax
  c1854c:	mov    QWORD PTR [rcx+0x10],0x4f
  c18554:	jmp    c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c18559:	mov    rcx,QWORD PTR [rsp+0x10]
  c1855e:	mov    BYTE PTR [rcx],0x1f
  c18561:	lea    rax,[rip+0xffffffffff6ae29c]        # 2c6804 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x481>
  c18568:	mov    QWORD PTR [rcx+0x8],rax
  c1856c:	mov    r8d,0x44
  c18572:	mov    eax,0x10
  c18577:	mov    QWORD PTR [rcx+rax*1],r8
  c1857b:	mov    rax,QWORD PTR [rsp+0x70]
  c18580:	test   rax,rax
  c18583:	je     c1859d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c7d>
  c18585:	mov    rdi,QWORD PTR [rsp+0x78]
  c1858a:	shl    rax,0x3
  c1858e:	lea    rsi,[rax+rax*2]
  c18592:	mov    edx,0x8
  c18597:	call   QWORD PTR [rip+0x235103]        # e4d6a0 <_DYNAMIC+0x240>
  c1859d:	mov    rsi,QWORD PTR [rsp+0x30]
  c185a2:	test   rsi,rsi
  c185a5:	je     c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c185ab:	mov    rdi,QWORD PTR [rsp+0x38]
  c185b0:	shl    rsi,0x4
  c185b4:	mov    edx,0x8
  c185b9:	call   QWORD PTR [rip+0x2350e1]        # e4d6a0 <_DYNAMIC+0x240>
  c185bf:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c185c4:	lea    rax,[rip+0xffffffffff6adc42]        # 2c620d <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x184c>
  c185cb:	mov    ecx,0x41
  c185d0:	jmp    c185de <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8cbe>
  c185d2:	lea    rax,[rip+0xffffffffff6adc75]        # 2c624e <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x188d>
  c185d9:	mov    ecx,0x45
  c185de:	mov    BYTE PTR [r14],0x1f
  c185e2:	mov    QWORD PTR [r14+0x8],rax
  c185e6:	mov    QWORD PTR [r14+0x10],rcx
  c185ea:	jmp    c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c185ef:	mov    rcx,QWORD PTR [rsp+0x10]
  c185f4:	mov    BYTE PTR [rcx],0x1f
  c185f7:	lea    rax,[rip+0xffffffffff6adbb8]        # 2c61b6 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x17f5>
  c185fe:	mov    QWORD PTR [rcx+0x8],rax
  c18602:	mov    QWORD PTR [rcx+0x10],0x57
  c1860a:	jmp    c18684 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d64>
  c1860c:	movups xmm0,XMMWORD PTR [rsp+0x101]
  c18614:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c1861d:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c18625:	movdqu XMMWORD PTR [rsp+0x3f],xmm1
  c1862b:	movaps XMMWORD PTR [rsp+0x30],xmm0
  c18630:	mov    rcx,QWORD PTR [rsp+0x10]
  c18635:	movups XMMWORD PTR [rcx+0x20],xmm2
  c18639:	movups xmm0,XMMWORD PTR [rsp+0x3f]
  c1863e:	movups XMMWORD PTR [rcx+0x10],xmm0
  c18642:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c18648:	jmp    c18e91 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9571>
  c1864d:	lea    rax,[rip+0xffffffffff6adbb9]        # 2c620d <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x184c>
  c18654:	mov    ecx,0x41
  c18659:	jmp    c18667 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d47>
  c1865b:	lea    rax,[rip+0xffffffffff6adbec]        # 2c624e <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x188d>
  c18662:	mov    ecx,0x45
  c18667:	mov    rdx,QWORD PTR [rsp+0x10]
  c1866c:	mov    BYTE PTR [rdx],0x1f
  c1866f:	mov    QWORD PTR [rdx+0x8],rax
  c18673:	mov    QWORD PTR [rdx+0x10],rcx
  c18677:	lea    rdi,[rsp+0x100]
  c1867f:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18684:	lea    rdi,[rsp+0xc0]
  c1868c:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18691:	lea    rdi,[rsp+0xe0]
  c18699:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1869e:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c186a3:	cmp    ecx,0x3
  c186a6:	jne    c18b2c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x920c>
  c186ac:	test   eax,eax
  c186ae:	je     c18393 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a73>
  c186b4:	mov    rax,QWORD PTR [rsp+0x38]
  c186b9:	dec    QWORD PTR [rax]
  c186bc:	jne    c18393 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a73>
  c186c2:	lea    rdi,[rsp+0x38]
  c186c7:	call   QWORD PTR [rip+0x234fdb]        # e4d6a8 <_DYNAMIC+0x248>
  c186cd:	jmp    c18393 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a73>
  c186d2:	cmp    ecx,0x3
  c186d5:	mov    edx,ebp
  c186d7:	jne    c18b4a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x922a>
  c186dd:	test   eax,eax
  c186df:	je     c1826f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x894f>
  c186e5:	mov    rax,QWORD PTR [rsp+0x38]
  c186ea:	dec    QWORD PTR [rax]
  c186ed:	jne    c1826f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x894f>
  c186f3:	lea    rdi,[rsp+0x38]
  c186f8:	call   QWORD PTR [rip+0x234faa]        # e4d6a8 <_DYNAMIC+0x248>
  c186fe:	jmp    c1826d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x894d>
  c18703:	cmp    ecx,0x3
  c18706:	jne    c18b68 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9248>
  c1870c:	test   eax,eax
  c1870e:	je     c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18714:	mov    rax,QWORD PTR [rsp+0x38]
  c18719:	dec    QWORD PTR [rax]
  c1871c:	jne    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18722:	lea    rdi,[rsp+0x38]
  c18727:	call   QWORD PTR [rip+0x234f7b]        # e4d6a8 <_DYNAMIC+0x248>
  c1872d:	jmp    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18732:	mov    DWORD PTR [rsp+0x5b8],0x2
  c1873d:	mov    rbx,QWORD PTR [rsp+0x10]
  c18742:	mov    r14,QWORD PTR [rsp+0x20]
  c18747:	mov    r12,QWORD PTR [rsp+0x8]
  c1874c:	jmp    c18c49 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9329>
  c18751:	add    rcx,QWORD PTR [rsi+0x60]
  c18755:	cmp    rcx,rax
  c18758:	mov    r14,QWORD PTR [rsp+0x198]
  c18760:	jae    c18882 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8f62>
  c18766:	mov    rax,QWORD PTR [rsp+0x20]
  c1876b:	mov    rax,QWORD PTR [rax+0x8]
  c1876f:	lea    rcx,[rcx+rcx*2]
  c18773:	lea    rsi,[rax+rcx*8]
  c18777:	lea    rdi,[rsp+0x100]
  c1877f:	call   c24e60 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c18784:	mov    rax,QWORD PTR [rsp+0x100]
  c1878c:	movdqu xmm0,XMMWORD PTR [rsp+0x108]
  c18795:	mov    QWORD PTR [rsp+0xe0],rax
  c1879d:	movdqu XMMWORD PTR [rsp+0xe8],xmm0
  c187a6:	lea    rdi,[rsp+0x100]
  c187ae:	lea    rsi,[rsp+0xe0]
  c187b6:	call   QWORD PTR [rip+0x23a50c]        # e52cc8 <_DYNAMIC+0x5868>
  c187bc:	cmp    DWORD PTR [rsp+0x100],0x1
  c187c4:	jne    c18d4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x942f>
  c187ca:	mov    rax,QWORD PTR [rsp+0x108]
  c187d2:	mov    rdx,QWORD PTR [rsp+0x650]
  c187da:	cmp    rax,QWORD PTR [rdx+0xa8]
  c187e1:	jne    c18fcd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x96ad>
  c187e7:	mov    rcx,QWORD PTR [rsp+0x110]
  c187ef:	lea    rax,[rip+0xffffffffff6ae091]        # 2c6887 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x504>
  c187f6:	cmp    rcx,QWORD PTR [rdx+0x88]
  c187fd:	jae    c19469 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b49>
  c18803:	lea    rbx,[rcx+rcx*2]
  c18807:	shl    rbx,0x4
  c1880b:	add    rbx,QWORD PTR [rdx+0x80]
  c18812:	mov    QWORD PTR [rsp+0x108],rax
  c1881a:	mov    QWORD PTR [rsp+0x110],0x40
  c18826:	mov    BYTE PTR [rsp+0x100],0x1f
  c1882e:	lea    rdi,[rsp+0x100]
  c18836:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.3092253909692456873>
  c1883b:	movzx  eax,BYTE PTR [rbx]
  c1883e:	cmp    al,0xfe
  c18840:	jne    c194b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b94>
  c18846:	add    rbx,0x8
  c1884a:	lea    rsi,[rsp+0x658]
  c18852:	mov    rdi,rbx
  c18855:	call   c3b7a0 <_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequejE8containsCsbxgXiyEKxkX_6bsl_vm>
  c1885a:	test   al,al
  c1885c:	jne    c1886e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8f4e>
  c1885e:	mov    rdi,rbx
  c18861:	mov    rsi,QWORD PTR [rsp+0x4e0]
  c18869:	call   c3b160 <_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequejE13push_back_mutCsbxgXiyEKxkX_6bsl_vm>
  c1886e:	mov    rax,QWORD PTR [rsp+0x10]
  c18873:	mov    DWORD PTR [rax+0x8],0xf
  c1887a:	mov    BYTE PTR [rax],0xff
  c1887d:	jmp    c1971c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dfc>
  c18882:	mov    BYTE PTR [rdi],0x1f
  c18885:	lea    rax,[rip+0xffffffffff6ad88c]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1888c:	mov    QWORD PTR [rdi+0x8],rax
  c18890:	mov    QWORD PTR [rdi+0x10],0x4f
  c18898:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c1889d:	mov    rcx,QWORD PTR [rsp+0x10]
  c188a2:	mov    BYTE PTR [rcx],0x1f
  c188a5:	lea    rax,[rip+0xffffffffff6ade4d]        # 2c66f9 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x376>
  c188ac:	mov    QWORD PTR [rcx+0x8],rax
  c188b0:	mov    QWORD PTR [rcx+0x10],0x5e
  c188b8:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c188bd:	mov    ecx,DWORD PTR [rsp+0x101]
  c188c4:	mov    edx,DWORD PTR [rsp+0x104]
  c188cb:	mov    rsi,QWORD PTR [rsp+0x10]
  c188d0:	mov    DWORD PTR [rsi+0x4],edx
  c188d3:	mov    DWORD PTR [rsi+0x1],ecx
  c188d6:	mov    rcx,QWORD PTR [rsp+0x128]
  c188de:	movdqu xmm0,XMMWORD PTR [rsp+0x108]
  c188e7:	movdqu xmm1,XMMWORD PTR [rsp+0x118]
  c188f0:	mov    BYTE PTR [rsi],al
  c188f2:	movdqu XMMWORD PTR [rsi+0x8],xmm0
  c188f7:	movdqu XMMWORD PTR [rsi+0x18],xmm1
  c188fc:	mov    QWORD PTR [rsi+0x28],rcx
  c18900:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c18905:	lea    rdi,[rsp+0x100]
  c1890d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18912:	mov    rcx,QWORD PTR [rsp+0x10]
  c18917:	mov    BYTE PTR [rcx],0x1f
  c1891a:	lea    rax,[rip+0xffffffffff6adfeb]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c18921:	jmp    c17a27 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8107>
  c18926:	lea    rdi,[rsp+0xc0]
  c1892e:	mov    rsi,QWORD PTR [rsp+0x1e0]
  c18936:	call   c0daa0 <_RNvCsbxgXiyEKxkX_6bsl_vm18push_own_registers>
  c1893b:	mov    rbx,QWORD PTR [rsp+0x10]
  c18940:	mov    r12,QWORD PTR [rsp]
  c18944:	mov    rsi,QWORD PTR [rsp+0x650]
  c1894c:	mov    rax,QWORD PTR [rsp+0x1e0]
  c18954:	cmp    BYTE PTR [rax+0xc0],0x0
  c1895b:	je     c18dd3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x94b3>
  c18961:	mov    eax,0x2
  c18966:	mov    r14d,0x2
  c1896c:	jmp    c191ff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x98df>
  c18971:	cmp    ecx,0x3
  c18974:	jne    c18edd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x95bd>
  c1897a:	test   eax,eax
  c1897c:	je     c18245 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8925>
  c18982:	mov    rax,QWORD PTR [rsp+0x78]
  c18987:	dec    QWORD PTR [rax]
  c1898a:	jne    c18245 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8925>
  c18990:	lea    rdi,[rsp+0x78]
  c18995:	call   QWORD PTR [rip+0x234d0d]        # e4d6a8 <_DYNAMIC+0x248>
  c1899b:	jmp    c18245 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8925>
  c189a0:	cmp    ecx,0x3
  c189a3:	jne    c18f19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x95f9>
  c189a9:	test   eax,eax
  c189ab:	je     c1836b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a4b>
  c189b1:	mov    rax,QWORD PTR [rsp+0x78]
  c189b6:	dec    QWORD PTR [rax]
  c189b9:	jne    c1836b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a4b>
  c189bf:	lea    rdi,[rsp+0x78]
  c189c4:	call   QWORD PTR [rip+0x234cde]        # e4d6a8 <_DYNAMIC+0x248>
  c189ca:	jmp    c1836b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a4b>
  c189cf:	cmp    ecx,0x3
  c189d2:	jne    c18f37 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9617>
  c189d8:	test   eax,eax
  c189da:	je     c182e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c7>
  c189e0:	mov    rax,QWORD PTR [rsp+0x78]
  c189e5:	dec    QWORD PTR [rax]
  c189e8:	jne    c182e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c7>
  c189ee:	lea    rdi,[rsp+0x78]
  c189f3:	call   QWORD PTR [rip+0x234caf]        # e4d6a8 <_DYNAMIC+0x248>
  c189f9:	jmp    c182e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c7>
  c189fe:	cmp    ecx,0x3
  c18a01:	jne    c18f73 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9653>
  c18a07:	test   eax,eax
  c18a09:	je     c18414 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af4>
  c18a0f:	mov    rax,QWORD PTR [rsp+0x78]
  c18a14:	dec    QWORD PTR [rax]
  c18a17:	jne    c18414 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af4>
  c18a1d:	lea    rdi,[rsp+0x78]
  c18a22:	call   QWORD PTR [rip+0x234c80]        # e4d6a8 <_DYNAMIC+0x248>
  c18a28:	jmp    c18414 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af4>
  c18a2d:	lea    rcx,[rsp+0x74]
  c18a32:	movups xmm0,XMMWORD PTR [rcx+0x1c]
  c18a36:	movups XMMWORD PTR [r14+0x20],xmm0
  c18a3b:	movdqu xmm0,XMMWORD PTR [rcx-0x3]
  c18a40:	movdqu xmm1,XMMWORD PTR [rcx+0xc]
  c18a45:	movdqu XMMWORD PTR [r14+0x1],xmm0
  c18a4b:	movdqu XMMWORD PTR [r14+0x10],xmm1
  c18a51:	mov    BYTE PTR [r14],al
  c18a54:	jmp    c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c18a59:	mov    BYTE PTR [r14],0x1f
  c18a5d:	lea    rax,[rip+0xffffffffff6ad752]        # 2c61b6 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x17f5>
  c18a64:	mov    QWORD PTR [r14+0x8],rax
  c18a68:	mov    QWORD PTR [r14+0x10],0x57
  c18a70:	jmp    c18ab4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9194>
  c18a72:	movups xmm0,XMMWORD PTR [rsp+0x101]
  c18a7a:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c18a83:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c18a8b:	movdqu XMMWORD PTR [rsp+0x3f],xmm1
  c18a91:	movaps XMMWORD PTR [rsp+0x30],xmm0
  c18a96:	movups XMMWORD PTR [r14+0x20],xmm2
  c18a9b:	movups xmm0,XMMWORD PTR [rsp+0x3f]
  c18aa0:	movups XMMWORD PTR [r14+0x10],xmm0
  c18aa5:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c18aab:	movdqu XMMWORD PTR [r14+0x1],xmm0
  c18ab1:	mov    BYTE PTR [r14],al
  c18ab4:	lea    rdi,[rsp+0x70]
  c18ab9:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c18abe:	jmp    c18dce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x94ae>
  c18ac3:	lea    rcx,[rsp+0x74]
  c18ac8:	movdqu xmm0,XMMWORD PTR [rcx-0x3]
  c18acd:	movdqu xmm1,XMMWORD PTR [rcx+0xd]
  c18ad2:	movups xmm2,XMMWORD PTR [rcx+0x1c]
  c18ad6:	movups XMMWORD PTR [rbx+0x20],xmm2
  c18ada:	movdqu XMMWORD PTR [rbx+0x11],xmm1
  c18adf:	movdqu XMMWORD PTR [rbx+0x1],xmm0
  c18ae4:	mov    BYTE PTR [rbx],al
  c18ae6:	jmp    c18684 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d64>
  c18aeb:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c18af4:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c18afd:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c18b05:	movups XMMWORD PTR [rbx+0x20],xmm2
  c18b09:	movdqu XMMWORD PTR [rbx+0x10],xmm1
  c18b0e:	movdqu XMMWORD PTR [rbx],xmm0
  c18b12:	cmp    BYTE PTR [rsp+0x70],0xff
  c18b17:	je     c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c18b1d:	lea    rdi,[rsp+0x70]
  c18b22:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.3092253909692456873>
  c18b27:	jmp    c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c18b2c:	mov    rax,QWORD PTR [rsp+0x38]
  c18b31:	dec    QWORD PTR [rax]
  c18b34:	jne    c18393 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a73>
  c18b3a:	lea    rdi,[rsp+0x38]
  c18b3f:	call   QWORD PTR [rip+0x234b6b]        # e4d6b0 <_DYNAMIC+0x250>
  c18b45:	jmp    c18393 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a73>
  c18b4a:	mov    rax,QWORD PTR [rsp+0x38]
  c18b4f:	dec    QWORD PTR [rax]
  c18b52:	jne    c1826f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x894f>
  c18b58:	lea    rdi,[rsp+0x38]
  c18b5d:	call   QWORD PTR [rip+0x234b4d]        # e4d6b0 <_DYNAMIC+0x250>
  c18b63:	jmp    c1826d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x894d>
  c18b68:	mov    rax,QWORD PTR [rsp+0x38]
  c18b6d:	dec    QWORD PTR [rax]
  c18b70:	jne    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18b76:	jmp    c18bd2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92b2>
  c18b78:	mov    rax,QWORD PTR [rsp+0x38]
  c18b7d:	dec    QWORD PTR [rax]
  c18b80:	jne    c18393 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a73>
  c18b86:	lea    rdi,[rsp+0x38]
  c18b8b:	call   QWORD PTR [rip+0x234b27]        # e4d6b8 <_DYNAMIC+0x258>
  c18b91:	jmp    c18393 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a73>
  c18b96:	mov    rax,QWORD PTR [rsp+0x38]
  c18b9b:	dec    QWORD PTR [rax]
  c18b9e:	jne    c1826d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x894d>
  c18ba4:	lea    rdi,[rsp+0x38]
  c18ba9:	call   QWORD PTR [rip+0x234b09]        # e4d6b8 <_DYNAMIC+0x258>
  c18baf:	jmp    c1826d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x894d>
  c18bb4:	mov    rax,QWORD PTR [rsp+0x38]
  c18bb9:	dec    QWORD PTR [rax]
  c18bbc:	jne    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18bc2:	jmp    c18bf0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92d0>
  c18bc4:	mov    rax,QWORD PTR [rsp+0x38]
  c18bc9:	dec    QWORD PTR [rax]
  c18bcc:	jne    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18bd2:	lea    rdi,[rsp+0x38]
  c18bd7:	call   QWORD PTR [rip+0x234ad3]        # e4d6b0 <_DYNAMIC+0x250>
  c18bdd:	jmp    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18be2:	mov    rax,QWORD PTR [rsp+0x38]
  c18be7:	dec    QWORD PTR [rax]
  c18bea:	jne    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18bf0:	lea    rdi,[rsp+0x38]
  c18bf5:	call   QWORD PTR [rip+0x234abd]        # e4d6b8 <_DYNAMIC+0x258>
  c18bfb:	jmp    c1843c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1c>
  c18c00:	add    rax,QWORD PTR [rdx+0x60]
  c18c04:	cmp    rax,QWORD PTR [r14+0x10]
  c18c08:	jae    c18d40 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9420>
  c18c0e:	lea    rsi,[rax+rax*2]
  c18c12:	shl    rsi,0x3
  c18c16:	add    rsi,QWORD PTR [r14+0x8]
  c18c1a:	lea    rdi,[rsp+0x100]
  c18c22:	call   c24e60 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c18c27:	mov    rax,QWORD PTR [rsp+0x100]
  c18c2f:	movdqu xmm0,XMMWORD PTR [rsp+0x108]
  c18c38:	mov    QWORD PTR [rsp+0x5b8],rax
  c18c40:	movdqu XMMWORD PTR [rsp+0x5c0],xmm0
  c18c49:	mov    rax,QWORD PTR [rsp+0x620]
  c18c51:	mov    r9,QWORD PTR [rax+0x10]
  c18c55:	sub    rsp,0x8
  c18c59:	lea    rax,[rsp+0x5c0]
  c18c61:	lea    rdi,[rsp+0x108]
  c18c69:	mov    rsi,r12
  c18c6c:	mov    rdx,r14
  c18c6f:	mov    rcx,QWORD PTR [rsp+0x1c0]
  c18c77:	mov    r8,QWORD PTR [rsp+0x4f0]
  c18c7f:	push   rax
  c18c80:	call   c0dae0 <_RNvCsbxgXiyEKxkX_6bsl_vm20do_return_with_value>
  c18c85:	add    rsp,0x10
  c18c89:	movzx  eax,BYTE PTR [rsp+0x100]
  c18c91:	cmp    al,0xff
  c18c93:	je     c18cf2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x93d2>
  c18c95:	mov    ecx,DWORD PTR [rsp+0x101]
  c18c9c:	mov    edx,DWORD PTR [rsp+0x104]
  c18ca3:	mov    DWORD PTR [rbx+0x4],edx
  c18ca6:	mov    DWORD PTR [rbx+0x1],ecx
  c18ca9:	mov    ecx,DWORD PTR [rsp+0x108]
  c18cb0:	movups xmm0,XMMWORD PTR [rsp+0x10c]
  c18cb8:	movaps XMMWORD PTR [rsp+0x3e0],xmm0
  c18cc0:	mov    edx,DWORD PTR [rsp+0x11c]
  c18cc7:	mov    DWORD PTR [rsp+0x3f0],edx
  c18cce:	movups xmm0,XMMWORD PTR [rsp+0x120]
  c18cd6:	movups XMMWORD PTR [rbx+0x20],xmm0
  c18cda:	mov    edx,DWORD PTR [rsp+0x3f0]
  c18ce1:	mov    DWORD PTR [rbx+0x1c],edx
  c18ce4:	movdqa xmm0,XMMWORD PTR [rsp+0x3e0]
  c18ced:	jmp    c0fab9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x199>
  c18cf2:	mov    eax,DWORD PTR [rsp+0x108]
  c18cf9:	movups xmm0,XMMWORD PTR [rsp+0x10c]
  c18d01:	movaps XMMWORD PTR [rsp+0x3e0],xmm0
  c18d09:	mov    ecx,DWORD PTR [rsp+0x11c]
  c18d10:	mov    DWORD PTR [rsp+0x3f0],ecx
  c18d17:	cmp    eax,0xffffffff
  c18d1a:	je     c191ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x988b>
  c18d20:	mov    ecx,DWORD PTR [rsp+0x3f0]
  c18d27:	mov    DWORD PTR [rsp+0x80],ecx
  c18d2e:	movaps xmm0,XMMWORD PTR [rsp+0x3e0]
  c18d36:	movaps XMMWORD PTR [rsp+0x70],xmm0
  c18d3b:	jmp    c191b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9890>
  c18d40:	mov    BYTE PTR [rbx],0x1f
  c18d43:	lea    rax,[rip+0xffffffffff6ad3ce]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c18d4a:	jmp    c17f30 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8610>
  c18d4f:	mov    rax,QWORD PTR [rsp+0x1a8]
  c18d57:	mov    rsi,QWORD PTR [rax]
  c18d5a:	cmp    QWORD PTR [rsp],rsi
  c18d5e:	mov    rdi,QWORD PTR [rsp+0x18]
  c18d63:	jae    c19e07 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4e7>
  c18d69:	mov    rdx,QWORD PTR [r14]
  c18d6c:	lea    rcx,[rdx+rdi*1]
  c18d70:	mov    rax,r12
  c18d73:	sub    rax,QWORD PTR [rdx+rdi*1+0x30]
  c18d78:	jae    c19048 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9728>
  c18d7e:	mov    rax,QWORD PTR [rcx+0x28]
  c18d82:	shl    r12d,0x4
  c18d86:	mov    rax,QWORD PTR [rax+r12*1]
  c18d8a:	jmp    c1904c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x972c>
  c18d8f:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c18d94:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c18d9d:	movups xmm2,XMMWORD PTR [rsp+0x90]
  c18da5:	movdqu XMMWORD PTR [rsp+0x3f],xmm1
  c18dab:	movaps XMMWORD PTR [rsp+0x30],xmm0
  c18db0:	movups XMMWORD PTR [r14+0x20],xmm2
  c18db5:	movups xmm0,XMMWORD PTR [rsp+0x3f]
  c18dba:	movups XMMWORD PTR [r14+0x10],xmm0
  c18dbf:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c18dc5:	movdqu XMMWORD PTR [r14+0x1],xmm0
  c18dcb:	mov    BYTE PTR [r14],al
  c18dce:	jmp    c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c18dd3:	lea    rdi,[rsp+0x100]
  c18ddb:	call   c49100 <_RNvMs0_NtCsbxgXiyEKxkX_6bsl_vm9schedulerNtB5_10AsyncState11new_promise>
  c18de0:	movzx  eax,BYTE PTR [rsp+0x100]
  c18de8:	cmp    al,0xff
  c18dea:	je     c191ca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x98aa>
  c18df0:	mov    ecx,DWORD PTR [rsp+0x101]
  c18df7:	mov    edx,DWORD PTR [rsp+0x104]
  c18dfe:	mov    DWORD PTR [rbx+0x4],edx
  c18e01:	mov    DWORD PTR [rbx+0x1],ecx
  c18e04:	mov    rcx,QWORD PTR [rsp+0x108]
  c18e0c:	mov    edx,DWORD PTR [rsp+0x110]
  c18e13:	movdqu xmm0,XMMWORD PTR [rsp+0x114]
  c18e1c:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c18e22:	mov    esi,DWORD PTR [rsp+0x124]
  c18e29:	mov    DWORD PTR [rsp+0x80],esi
  c18e30:	mov    rdi,QWORD PTR [rsp+0x128]
  c18e38:	mov    DWORD PTR [rbx+0x24],esi
  c18e3b:	movdqu XMMWORD PTR [rbx+0x14],xmm0
  c18e40:	mov    BYTE PTR [rbx],al
  c18e42:	mov    QWORD PTR [rbx+0x8],rcx
  c18e46:	mov    DWORD PTR [rbx+0x10],edx
  c18e49:	mov    QWORD PTR [rbx+0x28],rdi
  c18e4d:	jmp    c19439 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b19>
  c18e52:	movups xmm0,XMMWORD PTR [rsp+0x31]
  c18e57:	movdqu xmm1,XMMWORD PTR [rsp+0x40]
  c18e5d:	movups xmm2,XMMWORD PTR [rsp+0x50]
  c18e62:	movdqu XMMWORD PTR [rsp+0xcf],xmm1
  c18e6b:	movaps XMMWORD PTR [rsp+0xc0],xmm0
  c18e73:	mov    rcx,QWORD PTR [rsp+0x10]
  c18e78:	movups XMMWORD PTR [rcx+0x20],xmm2
  c18e7c:	movups xmm0,XMMWORD PTR [rsp+0xcf]
  c18e84:	movups XMMWORD PTR [rcx+0x10],xmm0
  c18e88:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c18e91:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c18e96:	mov    BYTE PTR [rcx],al
  c18e98:	lea    rdi,[rsp+0x70]
  c18e9d:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c18ea2:	lea    rdi,[rsp+0x358]
  c18eaa:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18eaf:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c18eb4:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c18eba:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c18ec3:	movups xmm2,XMMWORD PTR [rsp+0x90]
  c18ecb:	movups XMMWORD PTR [rbx+0x20],xmm2
  c18ecf:	movdqu XMMWORD PTR [rbx+0x10],xmm1
  c18ed4:	movdqu XMMWORD PTR [rbx],xmm0
  c18ed8:	jmp    c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c18edd:	mov    rax,QWORD PTR [rsp+0x78]
  c18ee2:	dec    QWORD PTR [rax]
  c18ee5:	jne    c18245 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8925>
  c18eeb:	lea    rdi,[rsp+0x78]
  c18ef0:	call   QWORD PTR [rip+0x2347ba]        # e4d6b0 <_DYNAMIC+0x250>
  c18ef6:	jmp    c18245 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8925>
  c18efb:	mov    rax,QWORD PTR [rsp+0x78]
  c18f00:	dec    QWORD PTR [rax]
  c18f03:	jne    c18245 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8925>
  c18f09:	lea    rdi,[rsp+0x78]
  c18f0e:	call   QWORD PTR [rip+0x2347a4]        # e4d6b8 <_DYNAMIC+0x258>
  c18f14:	jmp    c18245 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8925>
  c18f19:	mov    rax,QWORD PTR [rsp+0x78]
  c18f1e:	dec    QWORD PTR [rax]
  c18f21:	jne    c1836b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a4b>
  c18f27:	lea    rdi,[rsp+0x78]
  c18f2c:	call   QWORD PTR [rip+0x23477e]        # e4d6b0 <_DYNAMIC+0x250>
  c18f32:	jmp    c1836b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a4b>
  c18f37:	mov    rax,QWORD PTR [rsp+0x78]
  c18f3c:	dec    QWORD PTR [rax]
  c18f3f:	jne    c182e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c7>
  c18f45:	lea    rdi,[rsp+0x78]
  c18f4a:	call   QWORD PTR [rip+0x234760]        # e4d6b0 <_DYNAMIC+0x250>
  c18f50:	jmp    c182e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c7>
  c18f55:	mov    rax,QWORD PTR [rsp+0x78]
  c18f5a:	dec    QWORD PTR [rax]
  c18f5d:	jne    c1836b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a4b>
  c18f63:	lea    rdi,[rsp+0x78]
  c18f68:	call   QWORD PTR [rip+0x23474a]        # e4d6b8 <_DYNAMIC+0x258>
  c18f6e:	jmp    c1836b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a4b>
  c18f73:	mov    rax,QWORD PTR [rsp+0x78]
  c18f78:	dec    QWORD PTR [rax]
  c18f7b:	jne    c18414 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af4>
  c18f81:	lea    rdi,[rsp+0x78]
  c18f86:	call   QWORD PTR [rip+0x234724]        # e4d6b0 <_DYNAMIC+0x250>
  c18f8c:	jmp    c18414 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af4>
  c18f91:	mov    rax,QWORD PTR [rsp+0x78]
  c18f96:	dec    QWORD PTR [rax]
  c18f99:	jne    c182e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c7>
  c18f9f:	lea    rdi,[rsp+0x78]
  c18fa4:	call   QWORD PTR [rip+0x23470e]        # e4d6b8 <_DYNAMIC+0x258>
  c18faa:	jmp    c182e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c7>
  c18faf:	mov    rax,QWORD PTR [rsp+0x78]
  c18fb4:	dec    QWORD PTR [rax]
  c18fb7:	jne    c18414 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af4>
  c18fbd:	lea    rdi,[rsp+0x78]
  c18fc2:	call   QWORD PTR [rip+0x2346f0]        # e4d6b8 <_DYNAMIC+0x258>
  c18fc8:	jmp    c18414 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af4>
  c18fcd:	call   QWORD PTR [rip+0x23478d]        # e4d760 <_DYNAMIC+0x300>
  c18fd3:	mov    edi,0x45
  c18fd8:	mov    esi,0x1
  c18fdd:	call   QWORD PTR [rip+0x234785]        # e4d768 <_DYNAMIC+0x308>
  c18fe3:	test   rax,rax
  c18fe6:	mov    rdx,QWORD PTR [rsp+0x10]
  c18feb:	je     c19e3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa51e>
  c18ff1:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6ad8ff]        # 2c68f7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x574>
  c18ff8:	movups XMMWORD PTR [rax+0x30],xmm0
  c18ffc:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6ad8e4]        # 2c68e7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x564>
  c19003:	movups XMMWORD PTR [rax+0x20],xmm0
  c19007:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6ad8c9]        # 2c68d7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x554>
  c1900e:	movups XMMWORD PTR [rax+0x10],xmm0
  c19012:	movdqu xmm0,XMMWORD PTR [rip+0xffffffffff6ad8ad]        # 2c68c7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x544>
  c1901a:	movdqu XMMWORD PTR [rax],xmm0
  c1901e:	movabs rcx,0x83d1bad081d183d1
  c19028:	mov    QWORD PTR [rax+0x3d],rcx
  c1902c:	mov    BYTE PTR [rdx],0x1e
  c1902f:	mov    QWORD PTR [rdx+0x8],0x45
  c19037:	mov    QWORD PTR [rdx+0x10],rax
  c1903b:	mov    QWORD PTR [rdx+0x18],0x45
  c19043:	jmp    c1971c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dfc>
  c19048:	add    rax,QWORD PTR [rcx+0x60]
  c1904c:	mov    rbx,QWORD PTR [rsp+0x10]
  c19051:	mov    rsi,QWORD PTR [rsp+0x20]
  c19056:	mov    rcx,QWORD PTR [rsi+0x8]
  c1905a:	mov    rdx,QWORD PTR [rsp+0xf0]
  c19062:	mov    QWORD PTR [rsp+0x80],rdx
  c1906a:	movdqu xmm0,XMMWORD PTR [rsp+0xe0]
  c19073:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c19079:	cmp    rax,QWORD PTR [rsi+0x10]
  c1907d:	jae    c190fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x97dd>
  c1907f:	lea    rax,[rax+rax*2]
  c19083:	lea    r15,[rcx+rax*8]
  c19087:	mov    rax,QWORD PTR [rsp+0xf0]
  c1908f:	mov    QWORD PTR [rsp+0x110],rax
  c19097:	movups xmm0,XMMWORD PTR [rsp+0xe0]
  c1909f:	movaps XMMWORD PTR [rsp+0x100],xmm0
  c190a7:	mov    rdi,r15
  c190aa:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c190af:	mov    rax,QWORD PTR [rsp+0x110]
  c190b7:	mov    QWORD PTR [r15+0x10],rax
  c190bb:	movdqa xmm0,XMMWORD PTR [rsp+0x100]
  c190c4:	movdqu XMMWORD PTR [r15],xmm0
  c190c9:	mov    rax,QWORD PTR [rsp+0x1a8]
  c190d1:	mov    rsi,QWORD PTR [rax]
  c190d4:	mov    rdi,QWORD PTR [rsp]
  c190d8:	cmp    rdi,rsi
  c190db:	jae    c19e50 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa530>
  c190e1:	mov    rax,QWORD PTR [r14]
  c190e4:	mov    rcx,QWORD PTR [rsp+0x18]
  c190e9:	inc    QWORD PTR [rax+rcx*1+0x58]
  c190ee:	mov    DWORD PTR [rbx+0x8],0xd
  c190f5:	mov    BYTE PTR [rbx],0xff
  c190f8:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c190fd:	lea    rdi,[rsp+0x70]
  c19102:	jmp    c17f21 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8601>
  c19107:	mov    rcx,QWORD PTR [rsp+0x10]
  c1910c:	mov    BYTE PTR [rcx],0x1f
  c1910f:	lea    rax,[rip+0xffffffffff6ad6ee]        # 2c6804 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x481>
  c19116:	mov    QWORD PTR [rcx+0x8],rax
  c1911a:	mov    QWORD PTR [rcx+0x10],0x44
  c19122:	jmp    c19439 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b19>
  c19127:	mov    rcx,QWORD PTR [rsp+0x10]
  c1912c:	mov    BYTE PTR [rcx],0x1f
  c1912f:	lea    rax,[rip+0xffffffffff6acfe2]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c19136:	mov    QWORD PTR [rcx+0x8],rax
  c1913a:	mov    QWORD PTR [rcx+0x10],0x4f
  c19142:	mov    rax,QWORD PTR [rsp+0x1d8]
  c1914a:	mov    QWORD PTR [rcx+0x18],rax
  c1914e:	jmp    c19439 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b19>
  c19153:	mov    rcx,QWORD PTR [rsp+0x10]
  c19158:	mov    BYTE PTR [rcx],0x1f
  c1915b:	lea    rax,[rip+0xffffffffff6acfb6]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c19162:	mov    QWORD PTR [rcx+0x8],rax
  c19166:	mov    QWORD PTR [rcx+0x10],0x4f
  c1916e:	mov    rax,QWORD PTR [rsp+0x1c0]
  c19176:	mov    QWORD PTR [rcx+0x18],rax
  c1917a:	jmp    c19439 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b19>
  c1917f:	mov    rcx,QWORD PTR [rsp+0x10]
  c19184:	mov    BYTE PTR [rcx],0x1f
  c19187:	lea    rax,[rip+0xffffffffff6acf8a]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1918e:	mov    QWORD PTR [rcx+0x8],rax
  c19192:	mov    QWORD PTR [rcx+0x10],0x4f
  c1919a:	mov    rax,QWORD PTR [rsp+0x350]
  c191a2:	mov    QWORD PTR [rcx+0x18],rax
  c191a6:	jmp    c19439 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b19>
  c191ab:	mov    eax,0xc
  c191b0:	mov    DWORD PTR [rbx+0x8],eax
  c191b3:	movdqa xmm0,XMMWORD PTR [rsp+0x70]
  c191b9:	movdqu XMMWORD PTR [rbx+0xc],xmm0
  c191be:	mov    eax,DWORD PTR [rsp+0x80]
  c191c5:	jmp    c173f9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ad9>
  c191ca:	mov    rbx,QWORD PTR [rsp+0x108]
  c191d2:	mov    eax,DWORD PTR [rsp+0x110]
  c191d9:	mov    ecx,DWORD PTR [rsp+0x124]
  c191e0:	movdqu xmm0,XMMWORD PTR [rsp+0x114]
  c191e9:	movdqa XMMWORD PTR [rsp+0x5a0],xmm0
  c191f2:	mov    DWORD PTR [rsp+0x5b0],ecx
  c191f9:	mov    r14d,0x1
  c191ff:	mov    DWORD PTR [rsp+0x70],eax
  c19203:	mov    eax,DWORD PTR [rsp+0x5b0]
  c1920a:	mov    DWORD PTR [rsp+0x84],eax
  c19211:	movdqa xmm0,XMMWORD PTR [rsp+0x5a0]
  c1921a:	movdqu XMMWORD PTR [rsp+0x74],xmm0
  c19220:	mov    rax,QWORD PTR [rsp+0x1a8]
  c19228:	mov    rsi,QWORD PTR [rax]
  c1922b:	cmp    r12,rsi
  c1922e:	jae    c19df2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4d2>
  c19234:	mov    rax,QWORD PTR [rsp+0x198]
  c1923c:	mov    rsi,QWORD PTR [rax]
  c1923f:	lea    rdx,[rsi+r15*1]
  c19243:	movzx  ecx,bpl
  c19247:	mov    rax,rcx
  c1924a:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c1924f:	jae    c1925e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x993e>
  c19251:	mov    rax,QWORD PTR [rdx+0x28]
  c19255:	shl    ecx,0x4
  c19258:	mov    rax,QWORD PTR [rax+rcx*1]
  c1925c:	jmp    c19262 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9942>
  c1925e:	add    rax,QWORD PTR [rdx+0x60]
  c19262:	mov    rsi,QWORD PTR [rsp+0x20]
  c19267:	mov    rcx,QWORD PTR [rsi+0x8]
  c1926b:	mov    rdx,QWORD PTR [rsp+0x80]
  c19273:	mov    QWORD PTR [rsp+0x110],rdx
  c1927b:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c19281:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c1928a:	cmp    rax,QWORD PTR [rsi+0x10]
  c1928e:	mov    r13,QWORD PTR [rsp+0x198]
  c19296:	jae    c19411 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9af1>
  c1929c:	lea    rax,[rax+rax*2]
  c192a0:	lea    r15,[rcx+rax*8]
  c192a4:	mov    rdi,r15
  c192a7:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c192ac:	mov    rax,QWORD PTR [rsp+0x80]
  c192b4:	mov    QWORD PTR [r15+0x10],rax
  c192b8:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c192be:	movdqu XMMWORD PTR [r15],xmm0
  c192c3:	mov    rax,QWORD PTR [rsp+0x1a8]
  c192cb:	mov    rsi,QWORD PTR [rax]
  c192ce:	cmp    r12,rsi
  c192d1:	jae    c19e1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4fa>
  c192d7:	mov    rax,QWORD PTR [r13+0x0]
  c192db:	mov    rcx,QWORD PTR [rsp+0x18]
  c192e0:	inc    QWORD PTR [rax+rcx*1+0x58]
  c192e5:	call   c24da0 <_RNvNtCscdodAO9FK5_5alloc5boxed14box_new_uninit>
  c192ea:	mov    r15,rax
  c192ed:	mov    rax,QWORD PTR [rsp+0x1a8]
  c192f5:	mov    rsi,QWORD PTR [rax]
  c192f8:	cmp    r12,rsi
  c192fb:	jae    c19e2c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa50c>
  c19301:	mov    rax,QWORD PTR [r13+0x0]
  c19305:	mov    rcx,QWORD PTR [rsp+0x18]
  c1930a:	mov    eax,DWORD PTR [rax+rcx*1+0x70]
  c1930e:	mov    rcx,QWORD PTR [rsp+0x1e0]
  c19316:	movzx  ecx,BYTE PTR [rcx+0xc3]
  c1931d:	mov    QWORD PTR [r15],0x0
  c19324:	movups xmm0,XMMWORD PTR [rsp+0x30]
  c19329:	movups XMMWORD PTR [r15+0x20],xmm0
  c1932e:	mov    rdx,QWORD PTR [rsp+0x40]
  c19333:	mov    QWORD PTR [r15+0x30],rdx
  c19337:	mov    QWORD PTR [r15+0x38],0x0
  c1933f:	mov    QWORD PTR [r15+0x40],0x8
  c19347:	mov    QWORD PTR [r15+0x48],0x0
  c1934f:	mov    rdx,QWORD PTR [rsp+0x4a8]
  c19357:	mov    QWORD PTR [r15+0x50],rdx
  c1935b:	mov    QWORD PTR [r15+0x58],0x0
  c19363:	mov    QWORD PTR [r15+0x60],rcx
  c19367:	mov    QWORD PTR [r15+0x68],0x0
  c1936f:	mov    DWORD PTR [r15+0x70],eax
  c19373:	mov    BYTE PTR [r15+0x74],0x0
  c19378:	mov    rax,QWORD PTR [rsp+0xd0]
  c19380:	mov    QWORD PTR [rsp+0x138],rax
  c19388:	movdqu xmm0,XMMWORD PTR [rsp+0xc0]
  c19391:	movdqu XMMWORD PTR [rsp+0x128],xmm0
  c1939a:	mov    rdi,QWORD PTR [rsp+0x650]
  c193a2:	mov    rax,QWORD PTR [rdi+0xb0]
  c193a9:	mov    QWORD PTR [rsp+0x110],0x1
  c193b5:	mov    QWORD PTR [rsp+0x118],r15
  c193bd:	mov    QWORD PTR [rsp+0x120],0x1
  c193c9:	mov    DWORD PTR [rsp+0x140],0xffffffff
  c193d4:	mov    QWORD PTR [rsp+0x100],r14
  c193dc:	mov    QWORD PTR [rsp+0x108],rbx
  c193e4:	mov    QWORD PTR [rsp+0x158],rax
  c193ec:	lea    rsi,[rsp+0x100]
  c193f4:	call   c49020 <_RNvMs0_NtCsbxgXiyEKxkX_6bsl_vm9schedulerNtB5_10AsyncState11insert_task>
  c193f9:	mov    rcx,QWORD PTR [rsp+0x10]
  c193fe:	mov    DWORD PTR [rcx+0x8],0xe
  c19405:	mov    QWORD PTR [rcx+0x10],rax
  c19409:	mov    BYTE PTR [rcx],0xff
  c1940c:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c19411:	lea    rdi,[rsp+0x100]
  c19419:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1941e:	mov    rcx,QWORD PTR [rsp+0x10]
  c19423:	mov    BYTE PTR [rcx],0x1f
  c19426:	lea    rax,[rip+0xffffffffff6ad4df]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c1942d:	mov    QWORD PTR [rcx+0x8],rax
  c19431:	mov    QWORD PTR [rcx+0x10],0x4f
  c19439:	mov    rsi,QWORD PTR [rsp+0x30]
  c1943e:	test   rsi,rsi
  c19441:	je     c19457 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b37>
  c19443:	mov    rdi,QWORD PTR [rsp+0x38]
  c19448:	shl    rsi,0x4
  c1944c:	mov    edx,0x8
  c19451:	call   QWORD PTR [rip+0x234249]        # e4d6a0 <_DYNAMIC+0x240>
  c19457:	lea    rdi,[rsp+0xc0]
  c1945f:	call   c0a040 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueEECsbxgXiyEKxkX_6bsl_vm>
  c19464:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c19469:	mov    QWORD PTR [rsp+0x108],rax
  c19471:	mov    QWORD PTR [rsp+0x110],0x40
  c1947d:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c19486:	mov    rdx,QWORD PTR [rsp+0x10]
  c1948b:	movdqu XMMWORD PTR [rdx+0x20],xmm0
  c19490:	mov    rcx,QWORD PTR [rsp+0x110]
  c19498:	mov    QWORD PTR [rdx+0x10],rcx
  c1949c:	mov    rcx,QWORD PTR [rsp+0x118]
  c194a4:	mov    QWORD PTR [rdx+0x18],rcx
  c194a8:	mov    BYTE PTR [rdx],0x1f
  c194ab:	mov    QWORD PTR [rdx+0x8],rax
  c194af:	jmp    c1971c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dfc>
  c194b4:	cmp    al,0xff
  c194b6:	je     c195d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9cb7>
  c194bc:	lea    rdi,[rsp+0x100]
  c194c4:	mov    rsi,rbx
  c194c7:	call   c24f00 <_RNvXs8_NtCs54fMbAdz0qV_6bsl_rt5errorNtB5_7RtErrorNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c194cc:	movzx  eax,BYTE PTR [rsp+0x100]
  c194d4:	movups xmm0,XMMWORD PTR [rsp+0x101]
  c194dc:	movaps XMMWORD PTR [rsp+0x70],xmm0
  c194e1:	movups xmm0,XMMWORD PTR [rsp+0x110]
  c194e9:	movups XMMWORD PTR [rsp+0x7f],xmm0
  c194ee:	movups xmm0,XMMWORD PTR [rsp+0x120]
  c194f6:	mov    rcx,QWORD PTR [rsp+0x10]
  c194fb:	movups XMMWORD PTR [rcx+0x20],xmm0
  c194ff:	movaps xmm0,XMMWORD PTR [rsp+0x70]
  c19504:	movaps XMMWORD PTR [rsp+0x30],xmm0
  c19509:	movups xmm0,XMMWORD PTR [rsp+0x7f]
  c1950e:	movups XMMWORD PTR [rsp+0x3f],xmm0
  c19513:	movups xmm0,XMMWORD PTR [rsp+0x3f]
  c19518:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1951c:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c19522:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c19527:	mov    BYTE PTR [rcx],al
  c19529:	jmp    c1971c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dfc>
  c1952e:	mov    rax,QWORD PTR [rsp+0x1a8]
  c19536:	mov    rsi,QWORD PTR [rax]
  c19539:	cmp    QWORD PTR [rsp],rsi
  c1953d:	jae    c19e5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa53d>
  c19543:	mov    rax,QWORD PTR [rsp+0x198]
  c1954b:	mov    rax,QWORD PTR [rax]
  c1954e:	mov    rcx,QWORD PTR [rsp+0x20]
  c19553:	mov    rsi,QWORD PTR [rcx+0x8]
  c19557:	mov    rdx,QWORD PTR [rcx+0x10]
  c1955b:	mov    rcx,QWORD PTR [rsp+0x18]
  c19560:	lea    rax,[rax+rcx*1+0x58]
  c19565:	lea    rdi,[rsp+0x100]
  c1956d:	mov    rcx,r15
  c19570:	mov    r8,rbp
  c19573:	push   rbx
  c19574:	push   rax
  c19575:	call   c0f560 <_RNvCsbxgXiyEKxkX_6bsl_vm24numeric_for_i64_overflow>
  c1957a:	add    rsp,0x10
  c1957e:	cmp    BYTE PTR [rsp+0x100],0xff
  c19586:	je     c195c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ca6>
  c19588:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c19591:	movdqu xmm1,XMMWORD PTR [rsp+0x110]
  c1959a:	movups xmm2,XMMWORD PTR [rsp+0x120]
  c195a2:	mov    rax,QWORD PTR [rsp+0x10]
  c195a7:	movups XMMWORD PTR [rax+0x20],xmm2
  c195ab:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c195b0:	movdqu XMMWORD PTR [rax],xmm0
  c195b4:	add    rsp,0x5e8
  c195bb:	pop    rbx
  c195bc:	pop    r12
  c195be:	pop    r13
  c195c0:	pop    r14
  c195c2:	pop    r15
  c195c4:	pop    rbp
  c195c5:	ret
  c195c6:	mov    rax,QWORD PTR [rsp+0x10]
  c195cb:	mov    DWORD PTR [rax+0x8],0xc
  c195d2:	mov    BYTE PTR [rax],0xff
  c195d5:	jmp    c195b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c94>
  c195d7:	add    rbx,0x8
  c195db:	lea    rdi,[rsp+0x100]
  c195e3:	mov    rsi,rbx
  c195e6:	call   c24e60 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c195eb:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c195f4:	movdqu XMMWORD PTR [rsp+0x77],xmm0
  c195fa:	mov    rax,QWORD PTR [rsp+0x110]
  c19602:	movdqu XMMWORD PTR [rsp+0x37],xmm0
  c19608:	movdqa XMMWORD PTR [rsp+0xc0],xmm0
  c19611:	mov    QWORD PTR [rsp+0xd0],rax
  c19619:	mov    rax,QWORD PTR [rsp+0x1a8]
  c19621:	mov    rsi,QWORD PTR [rax]
  c19624:	cmp    QWORD PTR [rsp],rsi
  c19628:	jae    c19e6e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa54e>
  c1962e:	mov    rax,QWORD PTR [rsp+0x198]
  c19636:	mov    rdx,QWORD PTR [rax]
  c19639:	mov    rsi,QWORD PTR [rsp+0x18]
  c1963e:	lea    rcx,[rdx+rsi*1]
  c19642:	mov    rax,r12
  c19645:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c1964a:	jae    c1965a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d3a>
  c1964c:	mov    rax,QWORD PTR [rcx+0x28]
  c19650:	shl    r12d,0x4
  c19654:	mov    rax,QWORD PTR [rax+r12*1]
  c19658:	jmp    c1965e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d3e>
  c1965a:	add    rax,QWORD PTR [rcx+0x60]
  c1965e:	mov    rsi,QWORD PTR [rsp+0x20]
  c19663:	mov    rcx,QWORD PTR [rsi+0x8]
  c19667:	mov    rdx,QWORD PTR [rsp+0xd0]
  c1966f:	mov    QWORD PTR [rsp+0x110],rdx
  c19677:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c19680:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c19689:	cmp    rax,QWORD PTR [rsi+0x10]
  c1968d:	jae    c196f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dd4>
  c1968f:	lea    rax,[rax+rax*2]
  c19693:	lea    r15,[rcx+rax*8]
  c19697:	mov    rdi,r15
  c1969a:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1969f:	mov    rax,QWORD PTR [rsp+0xd0]
  c196a7:	mov    QWORD PTR [r15+0x10],rax
  c196ab:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c196b4:	movdqu XMMWORD PTR [r15],xmm0
  c196b9:	mov    rax,QWORD PTR [rsp+0x1a8]
  c196c1:	mov    rsi,QWORD PTR [rax]
  c196c4:	cmp    QWORD PTR [rsp],rsi
  c196c8:	jae    c19e81 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa561>
  c196ce:	mov    rax,QWORD PTR [rsp+0x198]
  c196d6:	mov    rax,QWORD PTR [rax]
  c196d9:	mov    rcx,QWORD PTR [rsp+0x18]
  c196de:	inc    QWORD PTR [rax+rcx*1+0x58]
  c196e3:	mov    rax,QWORD PTR [rsp+0x10]
  c196e8:	mov    DWORD PTR [rax+0x8],0xd
  c196ef:	mov    BYTE PTR [rax],0xff
  c196f2:	jmp    c1971c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dfc>
  c196f4:	lea    rdi,[rsp+0x100]
  c196fc:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c19701:	mov    rcx,QWORD PTR [rsp+0x10]
  c19706:	mov    BYTE PTR [rcx],0x1f
  c19709:	lea    rax,[rip+0xffffffffff6ad1fc]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.3092253909692456873+0x589>
  c19710:	mov    QWORD PTR [rcx+0x8],rax
  c19714:	mov    QWORD PTR [rcx+0x10],0x4f
  c1971c:	jmp    c18691 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d71>
  c19721:	lea    rcx,[rip+0x21d260]        # e36988 <anon.c2b893ca1edaacc1e9ca389f72ce6453.254.llvm.3092253909692456873>
  c19728:	mov    edx,0x3
  c1972d:	xor    edi,edi
  c1972f:	mov    rsi,r8
  c19732:	call   QWORD PTR [rip+0x234088]        # e4d7c0 <_DYNAMIC+0x360>
  c19738:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c1973d:	lea    rdx,[rip+0x21c1ec]        # e35930 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x90>
  c19744:	mov    rdi,r13
  c19747:	mov    rsi,QWORD PTR [rsp+0x1d8]
  c1974f:	call   QWORD PTR [rip+0x234023]        # e4d778 <_DYNAMIC+0x318>
  c19755:	lea    rdx,[rip+0x21cb84]        # e362e0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0xa40>
  c1975c:	mov    rdi,QWORD PTR [rsp]
  c19760:	call   QWORD PTR [rip+0x234012]        # e4d778 <_DYNAMIC+0x318>
  c19766:	lea    rdx,[rip+0x21c1ab]        # e35918 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x78>
  c1976d:	mov    rdi,r10
  c19770:	xor    esi,esi
  c19772:	call   QWORD PTR [rip+0x234000]        # e4d778 <_DYNAMIC+0x318>
  c19778:	mov    rsi,QWORD PTR [rsp+0x110]
  c19780:	call   QWORD PTR [rip+0x233fc2]        # e4d748 <_DYNAMIC+0x2e8>
  c19786:	mov    rsi,QWORD PTR [rsp+0x110]
  c1978e:	call   QWORD PTR [rip+0x233fb4]        # e4d748 <_DYNAMIC+0x2e8>
  c19794:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19799:	lea    rdx,[rip+0x21c778]        # e35f18 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x678>
  c197a0:	jmp    c197bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9b>
  c197a2:	lea    rdx,[rip+0x21c787]        # e35f30 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x690>
  c197a9:	jmp    c197bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9b>
  c197ab:	lea    rdx,[rip+0x21c7ae]        # e35f60 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x6c0>
  c197b2:	jmp    c197bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9b>
  c197b4:	lea    rdx,[rip+0x21c78d]        # e35f48 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x6a8>
  c197bb:	mov    rdi,QWORD PTR [rsp]
  c197bf:	mov    rsi,r12
  c197c2:	call   QWORD PTR [rip+0x233fb0]        # e4d778 <_DYNAMIC+0x318>
  c197c8:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c197cd:	lea    rdx,[rip+0x21c534]        # e35d08 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x468>
  c197d4:	mov    rdi,QWORD PTR [rsp]
  c197d8:	call   QWORD PTR [rip+0x233f9a]        # e4d778 <_DYNAMIC+0x318>
  c197de:	lea    rdx,[rip+0x21c35b]        # e35b40 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x2a0>
  c197e5:	call   QWORD PTR [rip+0x233f8d]        # e4d778 <_DYNAMIC+0x318>
  c197eb:	lea    rdx,[rip+0x21c3de]        # e35bd0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x330>
  c197f2:	call   QWORD PTR [rip+0x233f80]        # e4d778 <_DYNAMIC+0x318>
  c197f8:	lea    rdx,[rip+0x21c9d1]        # e361d0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x930>
  c197ff:	call   QWORD PTR [rip+0x233f73]        # e4d778 <_DYNAMIC+0x318>
  c19805:	lea    rdx,[rip+0x21c544]        # e35d50 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x4b0>
  c1980c:	mov    rdi,QWORD PTR [rsp]
  c19810:	call   QWORD PTR [rip+0x233f62]        # e4d778 <_DYNAMIC+0x318>
  c19816:	lea    rdx,[rip+0x21bfc3]        # e357e0 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c1981d:	call   QWORD PTR [rip+0x233f55]        # e4d778 <_DYNAMIC+0x318>
  c19823:	lea    rdx,[rip+0x21bfb6]        # e357e0 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c1982a:	call   QWORD PTR [rip+0x233f48]        # e4d778 <_DYNAMIC+0x318>
  c19830:	lea    rdx,[rip+0x21c5a9]        # e35de0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x540>
  c19837:	mov    rdi,QWORD PTR [rsp]
  c1983b:	call   QWORD PTR [rip+0x233f37]        # e4d778 <_DYNAMIC+0x318>
  c19841:	lea    rdx,[rip+0x21c550]        # e35d98 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x4f8>
  c19848:	mov    rdi,QWORD PTR [rsp]
  c1984c:	call   QWORD PTR [rip+0x233f26]        # e4d778 <_DYNAMIC+0x318>
  c19852:	lea    rdx,[rip+0x21c227]        # e35a80 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x1e0>
  c19859:	call   QWORD PTR [rip+0x233f19]        # e4d778 <_DYNAMIC+0x318>
  c1985f:	lea    rdx,[rip+0x21c1ea]        # e35a50 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x1b0>
  c19866:	call   QWORD PTR [rip+0x233f0c]        # e4d778 <_DYNAMIC+0x318>
  c1986c:	lea    rdx,[rip+0x21c9ed]        # e36260 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x9c0>
  c19873:	mov    rdi,QWORD PTR [rsp]
  c19877:	call   QWORD PTR [rip+0x233efb]        # e4d778 <_DYNAMIC+0x318>
  c1987d:	lea    rdx,[rip+0x21c304]        # e35b88 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x2e8>
  c19884:	call   QWORD PTR [rip+0x233eee]        # e4d778 <_DYNAMIC+0x318>
  c1988a:	lea    rdx,[rip+0x21c5af]        # e35e40 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x5a0>
  c19891:	mov    rdi,QWORD PTR [rsp]
  c19895:	call   QWORD PTR [rip+0x233edd]        # e4d778 <_DYNAMIC+0x318>
  c1989b:	lea    rdx,[rip+0x21c8e6]        # e36188 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x8e8>
  c198a2:	mov    rdi,QWORD PTR [rsp]
  c198a6:	call   QWORD PTR [rip+0x233ecc]        # e4d778 <_DYNAMIC+0x318>
  c198ac:	lea    rdx,[rip+0x21c5a5]        # e35e58 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x5b8>
  c198b3:	mov    rdi,QWORD PTR [rsp]
  c198b7:	call   QWORD PTR [rip+0x233ebb]        # e4d778 <_DYNAMIC+0x318>
  c198bd:	lea    rdx,[rip+0x21bf1c]        # e357e0 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c198c4:	call   QWORD PTR [rip+0x233eae]        # e4d778 <_DYNAMIC+0x318>
  c198ca:	lea    rdx,[rip+0x21c41f]        # e35cf0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x450>
  c198d1:	mov    rdi,QWORD PTR [rsp]
  c198d5:	call   QWORD PTR [rip+0x233e9d]        # e4d778 <_DYNAMIC+0x318>
  c198db:	lea    rdx,[rip+0x21c066]        # e35948 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0xa8>
  c198e2:	call   QWORD PTR [rip+0x233e90]        # e4d778 <_DYNAMIC+0x318>
  c198e8:	lea    rdx,[rip+0x21c539]        # e35e28 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x588>
  c198ef:	mov    rdi,QWORD PTR [rsp]
  c198f3:	call   QWORD PTR [rip+0x233e7f]        # e4d778 <_DYNAMIC+0x318>
  c198f9:	lea    rdx,[rip+0x21c918]        # e36218 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x978>
  c19900:	mov    rdi,QWORD PTR [rsp]
  c19904:	call   QWORD PTR [rip+0x233e6e]        # e4d778 <_DYNAMIC+0x318>
  c1990a:	lea    rdx,[rip+0x21c10f]        # e35a20 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x180>
  c19911:	call   QWORD PTR [rip+0x233e61]        # e4d778 <_DYNAMIC+0x318>
  c19917:	lea    rdx,[rip+0x21c312]        # e35c30 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x390>
  c1991e:	call   QWORD PTR [rip+0x233e54]        # e4d778 <_DYNAMIC+0x318>
  c19924:	lea    rdx,[rip+0x21c755]        # e36080 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x7e0>
  c1992b:	call   QWORD PTR [rip+0x233e47]        # e4d778 <_DYNAMIC+0x318>
  c19931:	lea    rdx,[rip+0x21c808]        # e36140 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x8a0>
  c19938:	mov    rdi,QWORD PTR [rsp]
  c1993c:	call   QWORD PTR [rip+0x233e36]        # e4d778 <_DYNAMIC+0x318>
  c19942:	lea    rdx,[rip+0x21be97]        # e357e0 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c19949:	call   QWORD PTR [rip+0x233e29]        # e4d778 <_DYNAMIC+0x318>
  c1994f:	lea    rdx,[rip+0x21c78a]        # e360e0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x840>
  c19956:	mov    rdi,QWORD PTR [rsp]
  c1995a:	call   QWORD PTR [rip+0x233e18]        # e4d778 <_DYNAMIC+0x318>
  c19960:	lea    rdx,[rip+0x21c281]        # e35be8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x348>
  c19967:	call   QWORD PTR [rip+0x233e0b]        # e4d778 <_DYNAMIC+0x318>
  c1996d:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19972:	lea    rdx,[rip+0x21c17f]        # e35af8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x258>
  c19979:	mov    rdi,QWORD PTR [rsp]
  c1997d:	call   QWORD PTR [rip+0x233df5]        # e4d778 <_DYNAMIC+0x318>
  c19983:	lea    rdx,[rip+0x21c2be]        # e35c48 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x3a8>
  c1998a:	call   QWORD PTR [rip+0x233de8]        # e4d778 <_DYNAMIC+0x318>
  c19990:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19995:	lea    rdx,[rip+0x21c18c]        # e35b28 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x288>
  c1999c:	mov    rdi,QWORD PTR [rsp]
  c199a0:	call   QWORD PTR [rip+0x233dd2]        # e4d778 <_DYNAMIC+0x318>
  c199a6:	lea    rdx,[rip+0x21c043]        # e359f0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x150>
  c199ad:	call   QWORD PTR [rip+0x233dc5]        # e4d778 <_DYNAMIC+0x318>
  c199b3:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c199b8:	lea    rdx,[rip+0x21c0d9]        # e35a98 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x1f8>
  c199bf:	mov    rdi,QWORD PTR [rsp]
  c199c3:	call   QWORD PTR [rip+0x233daf]        # e4d778 <_DYNAMIC+0x318>
  c199c9:	lea    rdx,[rip+0x21bf90]        # e35960 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0xc0>
  c199d0:	call   QWORD PTR [rip+0x233da2]        # e4d778 <_DYNAMIC+0x318>
  c199d6:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c199db:	lea    rdx,[rip+0x21c0e6]        # e35ac8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x228>
  c199e2:	mov    rdi,QWORD PTR [rsp]
  c199e6:	call   QWORD PTR [rip+0x233d8c]        # e4d778 <_DYNAMIC+0x318>
  c199ec:	lea    rdx,[rip+0x21bfcd]        # e359c0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x120>
  c199f3:	call   QWORD PTR [rip+0x233d7f]        # e4d778 <_DYNAMIC+0x318>
  c199f9:	lea    rdx,[rip+0x21c0b0]        # e35ab0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x210>
  c19a00:	mov    rdi,QWORD PTR [rsp]
  c19a04:	call   QWORD PTR [rip+0x233d6e]        # e4d778 <_DYNAMIC+0x318>
  c19a0a:	lea    rdx,[rip+0x21c057]        # e35a68 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x1c8>
  c19a11:	mov    rdi,QWORD PTR [rsp]
  c19a15:	call   QWORD PTR [rip+0x233d5d]        # e4d778 <_DYNAMIC+0x318>
  c19a1b:	lea    rdx,[rip+0x21c6d6]        # e360f8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x858>
  c19a22:	mov    rdi,QWORD PTR [rsp]
  c19a26:	call   QWORD PTR [rip+0x233d4c]        # e4d778 <_DYNAMIC+0x318>
  c19a2c:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19a31:	lea    rdx,[rip+0x21c840]        # e36278 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x9d8>
  c19a38:	mov    rdi,QWORD PTR [rsp]
  c19a3c:	call   QWORD PTR [rip+0x233d36]        # e4d778 <_DYNAMIC+0x318>
  c19a42:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19a47:	lea    rdx,[rip+0x21c64a]        # e36098 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x7f8>
  c19a4e:	mov    rdi,QWORD PTR [rsp]
  c19a52:	call   QWORD PTR [rip+0x233d20]        # e4d778 <_DYNAMIC+0x318>
  c19a58:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19a5d:	lea    rdx,[rip+0x21bfd4]        # e35a38 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x198>
  c19a64:	mov    rdi,QWORD PTR [rsp]
  c19a68:	call   QWORD PTR [rip+0x233d0a]        # e4d778 <_DYNAMIC+0x318>
  c19a6e:	lea    rdx,[rip+0x21c09b]        # e35b10 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x270>
  c19a75:	mov    rdi,QWORD PTR [rsp]
  c19a79:	call   QWORD PTR [rip+0x233cf9]        # e4d778 <_DYNAMIC+0x318>
  c19a7f:	lea    rdx,[rip+0x21c05a]        # e35ae0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x240>
  c19a86:	mov    rdi,QWORD PTR [rsp]
  c19a8a:	call   QWORD PTR [rip+0x233ce8]        # e4d778 <_DYNAMIC+0x318>
  c19a90:	lea    rdx,[rip+0x21c709]        # e361a0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x900>
  c19a97:	mov    rdi,QWORD PTR [rsp]
  c19a9b:	call   QWORD PTR [rip+0x233cd7]        # e4d778 <_DYNAMIC+0x318>
  c19aa1:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19aa6:	lea    rdx,[rip+0x21c1b3]        # e35c60 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x3c0>
  c19aad:	jmp    c19bfd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2dd>
  c19ab2:	lea    rdx,[rip+0x21c09f]        # e35b58 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x2b8>
  c19ab9:	mov    rdi,QWORD PTR [rsp]
  c19abd:	call   QWORD PTR [rip+0x233cb5]        # e4d778 <_DYNAMIC+0x318>
  c19ac3:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19ac8:	lea    rdx,[rip+0x21c131]        # e35c00 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x360>
  c19acf:	jmp    c19baa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa28a>
  c19ad4:	lea    rdx,[rip+0x21be9d]        # e35978 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0xd8>
  c19adb:	mov    rdi,QWORD PTR [rsp]
  c19adf:	call   QWORD PTR [rip+0x233c93]        # e4d778 <_DYNAMIC+0x318>
  c19ae5:	lea    rdx,[rip+0x21c624]        # e36110 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x870>
  c19aec:	jmp    c19c25 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa305>
  c19af1:	lea    rdx,[rip+0x21be98]        # e35990 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0xf0>
  c19af8:	call   QWORD PTR [rip+0x233c7a]        # e4d778 <_DYNAMIC+0x318>
  c19afe:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19b03:	lea    rdx,[rip+0x21c726]        # e36230 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x990>
  c19b0a:	call   QWORD PTR [rip+0x233c68]        # e4d778 <_DYNAMIC+0x318>
  c19b10:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19b15:	lea    rdx,[rip+0x21c084]        # e35ba0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x300>
  c19b1c:	mov    rdi,QWORD PTR [rsp]
  c19b20:	call   QWORD PTR [rip+0x233c52]        # e4d778 <_DYNAMIC+0x318>
  c19b26:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19b2b:	lea    rdx,[rip+0x21bed6]        # e35a08 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x168>
  c19b32:	mov    rdi,QWORD PTR [rsp]
  c19b36:	call   QWORD PTR [rip+0x233c3c]        # e4d778 <_DYNAMIC+0x318>
  c19b3c:	lea    rdx,[rip+0x21c6a5]        # e361e8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x948>
  c19b43:	jmp    c19be7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2c7>
  c19b48:	lea    rdx,[rip+0x21c6f9]        # e36248 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x9a8>
  c19b4f:	mov    rdi,QWORD PTR [rsp]
  c19b53:	call   QWORD PTR [rip+0x233c1f]        # e4d778 <_DYNAMIC+0x318>
  c19b59:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19b5e:	lea    rdx,[rip+0x21c74b]        # e362b0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0xa10>
  c19b65:	call   QWORD PTR [rip+0x233c0d]        # e4d778 <_DYNAMIC+0x318>
  c19b6b:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19b70:	lea    rdx,[rip+0x21be61]        # e359d8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x138>
  c19b77:	mov    rdi,QWORD PTR [rsp]
  c19b7b:	call   QWORD PTR [rip+0x233bf7]        # e4d778 <_DYNAMIC+0x318>
  c19b81:	lea    rdx,[rip+0x21be20]        # e359a8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x108>
  c19b88:	mov    rdi,QWORD PTR [rsp]
  c19b8c:	call   QWORD PTR [rip+0x233be6]        # e4d778 <_DYNAMIC+0x318>
  c19b92:	lea    rdx,[rip+0x21bfd7]        # e35b70 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x2d0>
  c19b99:	mov    rdi,QWORD PTR [rsp]
  c19b9d:	call   QWORD PTR [rip+0x233bd5]        # e4d778 <_DYNAMIC+0x318>
  c19ba3:	lea    rdx,[rip+0x21c06e]        # e35c18 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x378>
  c19baa:	mov    rdi,QWORD PTR [rsp]
  c19bae:	call   QWORD PTR [rip+0x233bc4]        # e4d778 <_DYNAMIC+0x318>
  c19bb4:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19bb9:	lea    rdx,[rip+0x21c4f0]        # e360b0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x810>
  c19bc0:	mov    rdi,QWORD PTR [rsp]
  c19bc4:	call   QWORD PTR [rip+0x233bae]        # e4d778 <_DYNAMIC+0x318>
  c19bca:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19bcf:	lea    rdx,[rip+0x21bfe2]        # e35bb8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x318>
  c19bd6:	mov    rdi,QWORD PTR [rsp]
  c19bda:	call   QWORD PTR [rip+0x233b98]        # e4d778 <_DYNAMIC+0x318>
  c19be0:	lea    rdx,[rip+0x21c619]        # e36200 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x960>
  c19be7:	mov    rdi,QWORD PTR [rsp]
  c19beb:	call   QWORD PTR [rip+0x233b87]        # e4d778 <_DYNAMIC+0x318>
  c19bf1:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19bf6:	lea    rdx,[rip+0x21c07b]        # e35c78 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x3d8>
  c19bfd:	mov    rdi,QWORD PTR [rsp]
  c19c01:	call   QWORD PTR [rip+0x233b71]        # e4d778 <_DYNAMIC+0x318>
  c19c07:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19c0c:	lea    rdx,[rip+0x21c545]        # e36158 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x8b8>
  c19c13:	call   QWORD PTR [rip+0x233b5f]        # e4d778 <_DYNAMIC+0x318>
  c19c19:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19c1e:	lea    rdx,[rip+0x21c503]        # e36128 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x888>
  c19c25:	mov    rdi,QWORD PTR [rsp]
  c19c29:	call   QWORD PTR [rip+0x233b49]        # e4d778 <_DYNAMIC+0x318>
  c19c2f:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19c34:	lea    rdx,[rip+0x21c09d]        # e35cd8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x438>
  c19c3b:	mov    rdi,QWORD PTR [rsp]
  c19c3f:	call   QWORD PTR [rip+0x233b33]        # e4d778 <_DYNAMIC+0x318>
  c19c45:	lea    rdx,[rip+0x21c05c]        # e35ca8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x408>
  c19c4c:	mov    rdi,QWORD PTR [rsp]
  c19c50:	call   QWORD PTR [rip+0x233b22]        # e4d778 <_DYNAMIC+0x318>
  c19c56:	lea    rdx,[rip+0x21c063]        # e35cc0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x420>
  c19c5d:	mov    rdi,QWORD PTR [rsp]
  c19c61:	call   QWORD PTR [rip+0x233b11]        # e4d778 <_DYNAMIC+0x318>
  c19c67:	lea    rdx,[rip+0x21c45a]        # e360c8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x828>
  c19c6e:	mov    rdi,QWORD PTR [rsp]
  c19c72:	call   QWORD PTR [rip+0x233b00]        # e4d778 <_DYNAMIC+0x318>
  c19c78:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19c7d:	lea    rdx,[rip+0x21c264]        # e35ee8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x648>
  c19c84:	mov    rdi,QWORD PTR [rsp]
  c19c88:	call   QWORD PTR [rip+0x233aea]        # e4d778 <_DYNAMIC+0x318>
  c19c8e:	lea    rdx,[rip+0x21c633]        # e362c8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0xa28>
  c19c95:	mov    rdi,QWORD PTR [rsp]
  c19c99:	call   QWORD PTR [rip+0x233ad9]        # e4d778 <_DYNAMIC+0x318>
  c19c9f:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19ca4:	lea    rdx,[rip+0x21bfe5]        # e35c90 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x3f0>
  c19cab:	mov    rdi,QWORD PTR [rsp]
  c19caf:	call   QWORD PTR [rip+0x233ac3]        # e4d778 <_DYNAMIC+0x318>
  c19cb5:	lea    rdx,[rip+0x21c4b4]        # e36170 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x8d0>
  c19cbc:	mov    rdi,QWORD PTR [rsp]
  c19cc0:	call   QWORD PTR [rip+0x233ab2]        # e4d778 <_DYNAMIC+0x318>
  c19cc6:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19ccb:	lea    rdx,[rip+0x21c4e6]        # e361b8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x918>
  c19cd2:	mov    rdi,QWORD PTR [rsp]
  c19cd6:	call   QWORD PTR [rip+0x233a9c]        # e4d778 <_DYNAMIC+0x318>
  c19cdc:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19ce1:	lea    rdx,[rip+0x21c110]        # e35df8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x558>
  c19ce8:	jmp    c19d97 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa477>
  c19ced:	lea    rdx,[rip+0x21c17c]        # e35e70 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x5d0>
  c19cf4:	mov    rdi,QWORD PTR [rsp]
  c19cf8:	call   QWORD PTR [rip+0x233a7a]        # e4d778 <_DYNAMIC+0x318>
  c19cfe:	lea    rdx,[rip+0x21c1b3]        # e35eb8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x618>
  c19d05:	mov    rdi,QWORD PTR [rsp]
  c19d09:	call   QWORD PTR [rip+0x233a69]        # e4d778 <_DYNAMIC+0x318>
  c19d0f:	lea    rdx,[rip+0x21c18a]        # e35ea0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x600>
  c19d16:	call   QWORD PTR [rip+0x233a5c]        # e4d778 <_DYNAMIC+0x318>
  c19d1c:	lea    rdx,[rip+0x21c05d]        # e35d80 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x4e0>
  c19d23:	mov    rdi,QWORD PTR [rsp]
  c19d27:	call   QWORD PTR [rip+0x233a4b]        # e4d778 <_DYNAMIC+0x318>
  c19d2d:	lea    rdx,[rip+0x21c034]        # e35d68 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x4c8>
  c19d34:	mov    rdi,QWORD PTR [rsp]
  c19d38:	call   QWORD PTR [rip+0x233a3a]        # e4d778 <_DYNAMIC+0x318>
  c19d3e:	lea    rdx,[rip+0x21bff3]        # e35d38 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x498>
  c19d45:	mov    rdi,QWORD PTR [rsp]
  c19d49:	call   QWORD PTR [rip+0x233a29]        # e4d778 <_DYNAMIC+0x318>
  c19d4f:	lea    rdx,[rip+0x21bfca]        # e35d20 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x480>
  c19d56:	mov    rdi,QWORD PTR [rsp]
  c19d5a:	call   QWORD PTR [rip+0x233a18]        # e4d778 <_DYNAMIC+0x318>
  c19d60:	lea    rdx,[rip+0x21c121]        # e35e88 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x5e8>
  c19d67:	mov    rdi,QWORD PTR [rsp]
  c19d6b:	call   QWORD PTR [rip+0x233a07]        # e4d778 <_DYNAMIC+0x318>
  c19d71:	lea    rdx,[rip+0x21c038]        # e35db0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x510>
  c19d78:	jmp    c19d81 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa461>
  c19d7a:	lea    rdx,[rip+0x21c047]        # e35dc8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x528>
  c19d81:	mov    rdi,QWORD PTR [rsp]
  c19d85:	call   QWORD PTR [rip+0x2339ed]        # e4d778 <_DYNAMIC+0x318>
  c19d8b:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19d90:	lea    rdx,[rip+0x21c079]        # e35e10 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x570>
  c19d97:	mov    rdi,QWORD PTR [rsp]
  c19d9b:	call   QWORD PTR [rip+0x2339d7]        # e4d778 <_DYNAMIC+0x318>
  c19da1:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19da6:	lea    rdx,[rip+0x21c153]        # e35f00 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x660>
  c19dad:	jmp    c197bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9b>
  c19db2:	lea    rax,[rip+0x21c207]        # e35fc0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x720>
  c19db9:	mov    QWORD PTR [rsp+0x1b0],rax
  c19dc1:	mov    rdi,QWORD PTR [rsp]
  c19dc5:	mov    rdx,QWORD PTR [rsp+0x1b0]
  c19dcd:	call   QWORD PTR [rip+0x2339a5]        # e4d778 <_DYNAMIC+0x318>
  c19dd3:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19dd8:	lea    rdx,[rip+0x21c211]        # e35ff0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x750>
  c19ddf:	call   QWORD PTR [rip+0x233993]        # e4d778 <_DYNAMIC+0x318>
  c19de5:	lea    rdx,[rip+0x21c27c]        # e36068 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x7c8>
  c19dec:	call   QWORD PTR [rip+0x233986]        # e4d778 <_DYNAMIC+0x318>
  c19df2:	lea    rdx,[rip+0x21c17f]        # e35f78 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x6d8>
  c19df9:	mov    rdi,r12
  c19dfc:	call   QWORD PTR [rip+0x233976]        # e4d778 <_DYNAMIC+0x318>
  c19e02:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19e07:	lea    rdx,[rip+0x21c22a]        # e36038 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x798>
  c19e0e:	mov    rdi,QWORD PTR [rsp]
  c19e12:	call   QWORD PTR [rip+0x233960]        # e4d778 <_DYNAMIC+0x318>
  c19e18:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19e1a:	lea    rdx,[rip+0x21c16f]        # e35f90 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x6f0>
  c19e21:	mov    rdi,r12
  c19e24:	call   QWORD PTR [rip+0x23394e]        # e4d778 <_DYNAMIC+0x318>
  c19e2a:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19e2c:	lea    rdx,[rip+0x21c175]        # e35fa8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x708>
  c19e33:	mov    rdi,r12
  c19e36:	call   QWORD PTR [rip+0x23393c]        # e4d778 <_DYNAMIC+0x318>
  c19e3c:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19e3e:	mov    edi,0x1
  c19e43:	mov    esi,0x45
  c19e48:	call   QWORD PTR [rip+0x2338fa]        # e4d748 <_DYNAMIC+0x2e8>
  c19e4e:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19e50:	lea    rdx,[rip+0x21c1f9]        # e36050 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x7b0>
  c19e57:	call   QWORD PTR [rip+0x23391b]        # e4d778 <_DYNAMIC+0x318>
  c19e5d:	lea    rdx,[rip+0x21c06c]        # e35ed0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x630>
  c19e64:	mov    rdi,QWORD PTR [rsp]
  c19e68:	call   QWORD PTR [rip+0x23390a]        # e4d778 <_DYNAMIC+0x318>
  c19e6e:	lea    rdx,[rip+0x21c193]        # e36008 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x768>
  c19e75:	mov    rdi,QWORD PTR [rsp]
  c19e79:	call   QWORD PTR [rip+0x2338f9]        # e4d778 <_DYNAMIC+0x318>
  c19e7f:	jmp    c19e92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa572>
  c19e81:	lea    rdx,[rip+0x21c198]        # e36020 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.3092253909692456873+0x780>
  c19e88:	mov    rdi,QWORD PTR [rsp]
  c19e8c:	call   QWORD PTR [rip+0x2338e6]        # e4d778 <_DYNAMIC+0x318>
  c19e92:	ud2
  c19e94:	mov    rbx,rax
  c19e97:	mov    rax,QWORD PTR [rsp+0xd0]
  c19e9f:	mov    QWORD PTR [r15+0x10],rax
  c19ea3:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c19eac:	movdqu XMMWORD PTR [r15],xmm0
  c19eb1:	jmp    c19f5f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa63f>
  c19eb6:	jmp    c19f5c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa63c>
  c19ebb:	mov    rbx,rax
  c19ebe:	lea    rdi,[rsp+0xc0]
  c19ec6:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c19ecb:	jmp    c19f5f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa63f>
  c19ed0:	mov    rbx,rax
  c19ed3:	mov    rax,QWORD PTR [rsp+0x110]
  c19edb:	mov    QWORD PTR [r15+0x10],rax
  c19edf:	movaps xmm0,XMMWORD PTR [rsp+0x100]
  c19ee7:	movups XMMWORD PTR [r15],xmm0
  c19eeb:	mov    rdi,rbx
  c19eee:	call   d9b1f0 <_Unwind_Resume@plt>
  c19ef3:	mov    rbx,rax
  c19ef6:	mov    esi,0x78
  c19efb:	mov    edx,0x8
  c19f00:	mov    rdi,r15
  c19f03:	call   QWORD PTR [rip+0x233797]        # e4d6a0 <_DYNAMIC+0x240>
  c19f09:	jmp    c1a26c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa94c>
  c19f0e:	mov    rbx,rax
  c19f11:	mov    rax,QWORD PTR [rsp+0x80]
  c19f19:	mov    QWORD PTR [r15+0x10],rax
  c19f1d:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c19f23:	movdqu XMMWORD PTR [r15],xmm0
  c19f28:	jmp    c1a26c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa94c>
  c19f2d:	jmp    c19f91 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa671>
  c19f2f:	jmp    c19fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6bb>
  c19f34:	jmp    c19f89 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa669>
  c19f36:	jmp    c19fd3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6b3>
  c19f3b:	jmp    c1a486 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab66>
  c19f40:	mov    rbx,rax
  c19f43:	lea    rdi,[rsp+0x70]
  c19f48:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c19f4d:	jmp    c1a26c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa94c>
  c19f52:	jmp    c1a269 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa949>
  c19f57:	jmp    c1a49b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab7b>
  c19f5c:	mov    rbx,rax
  c19f5f:	lea    rdi,[rsp+0xe0]
  c19f67:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c19f6c:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c19f71:	jmp    c1a22a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa90a>
  c19f76:	mov    rbx,rax
  c19f79:	mov    DWORD PTR [r14],0x4
  c19f80:	mov    BYTE PTR [r14+0x4],bpl
  c19f84:	jmp    c1a2ef <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa9cf>
  c19f89:	mov    rbx,rax
  c19f8c:	jmp    c1a37c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa5c>
  c19f91:	mov    rbx,rax
  c19f94:	jmp    c1a31b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa9fb>
  c19f99:	mov    rbx,rax
  c19f9c:	mov    rax,QWORD PTR [rsp+0xf0]
  c19fa4:	mov    QWORD PTR [r14+0x10],rax
  c19fa8:	movdqa xmm0,XMMWORD PTR [rsp+0xe0]
  c19fb1:	movdqu XMMWORD PTR [r14],xmm0
  c19fb6:	jmp    c1a5af <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac8f>
  c19fbb:	mov    rbx,rax
  c19fbe:	mov    DWORD PTR [r15],0x4
  c19fc5:	mov    BYTE PTR [r15+0x4],bpl
  c19fc9:	jmp    c1a372 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa52>
  c19fce:	jmp    c1a46a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab4a>
  c19fd3:	mov    rbx,rax
  c19fd6:	jmp    c1a2f9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa9d9>
  c19fdb:	mov    rbx,rax
  c19fde:	jmp    c1a3cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaaaf>
  c19fe3:	mov    rbx,rax
  c19fe6:	mov    rax,QWORD PTR [rsp+0xd0]
  c19fee:	mov    QWORD PTR [r14+0x10],rax
  c19ff2:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c19ffb:	movdqu XMMWORD PTR [r14],xmm0
  c1a000:	jmp    c1a49e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab7e>
  c1a005:	jmp    c1a481 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab61>
  c1a00a:	mov    rbx,rax
  c1a00d:	mov    rax,QWORD PTR [rsp+0x40]
  c1a012:	mov    QWORD PTR [r14+0x10],rax
  c1a016:	movdqa xmm0,XMMWORD PTR [rsp+0x30]
  c1a01c:	movdqu XMMWORD PTR [r14],xmm0
  c1a021:	jmp    c1a333 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa13>
  c1a026:	mov    rbx,rax
  c1a029:	mov    DWORD PTR [r12],0x4
  c1a031:	mov    BYTE PTR [r12+0x4],r14b
  c1a036:	jmp    c1a311 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa9f1>
  c1a03b:	mov    rbx,rax
  c1a03e:	mov    DWORD PTR [r12],0x4
  c1a046:	mov    BYTE PTR [r12+0x4],r14b
  c1a04b:	jmp    c1a3c5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaaa5>
  c1a050:	mov    rbx,rax
  c1a053:	mov    rax,QWORD PTR [rsp+0x110]
  c1a05b:	mov    QWORD PTR [r14+0x10],rax
  c1a05f:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c1a068:	movdqu XMMWORD PTR [r14],xmm0
  c1a06d:	jmp    c1a51b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabfb>
  c1a072:	mov    rbx,rax
  c1a075:	mov    rax,QWORD PTR [rsp+0xd0]
  c1a07d:	mov    QWORD PTR [r14+0x10],rax
  c1a081:	movdqa xmm0,XMMWORD PTR [rsp+0xc0]
  c1a08a:	movdqu XMMWORD PTR [r14],xmm0
  c1a08f:	jmp    c1a4d3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabb3>
  c1a094:	jmp    c1a45a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab3a>
  c1a099:	mov    rbx,rax
  c1a09c:	mov    rax,QWORD PTR [rsp+0x110]
  c1a0a4:	mov    QWORD PTR [r14+0x10],rax
  c1a0a8:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c1a0b1:	movdqu XMMWORD PTR [r14],xmm0
  c1a0b6:	jmp    c1a509 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabe9>
  c1a0bb:	jmp    c1a0e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa7c6>
  c1a0bd:	jmp    c1a136 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa816>
  c1a0bf:	jmp    c1a462 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab42>
  c1a0c4:	mov    rbx,rax
  c1a0c7:	mov    rax,QWORD PTR [rsp+0x110]
  c1a0cf:	mov    QWORD PTR [r14+0x10],rax
  c1a0d3:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c1a0dc:	movdqu XMMWORD PTR [r14],xmm0
  c1a0e1:	jmp    c1a537 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac17>
  c1a0e6:	mov    rbx,rax
  c1a0e9:	mov    rax,QWORD PTR [rsp+0xd0]
  c1a0f1:	mov    QWORD PTR [r14+0x10],rax
  c1a0f5:	movaps xmm0,XMMWORD PTR [rsp+0xc0]
  c1a0fd:	movups XMMWORD PTR [r14],xmm0
  c1a101:	mov    rdi,rbx
  c1a104:	call   d9b1f0 <_Unwind_Resume@plt>
  c1a109:	mov    rbx,rax
  c1a10c:	mov    rax,QWORD PTR [rsp+0x500]
  c1a114:	mov    QWORD PTR [r14+0x10],rax
  c1a118:	movups xmm0,XMMWORD PTR [rsp+0x4f0]
  c1a120:	movups XMMWORD PTR [r14],xmm0
  c1a124:	mov    rdi,rbx
  c1a127:	call   d9b1f0 <_Unwind_Resume@plt>
  c1a12c:	jmp    c1a3a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa88>
  c1a131:	jmp    c1a345 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa25>
  c1a136:	mov    rbx,rax
  c1a139:	mov    rax,QWORD PTR [rsp+0x80]
  c1a141:	mov    QWORD PTR [r14+0x10],rax
  c1a145:	movups xmm0,XMMWORD PTR [rsp+0x70]
  c1a14a:	movups XMMWORD PTR [r14],xmm0
  c1a14e:	mov    rdi,rbx
  c1a151:	call   d9b1f0 <_Unwind_Resume@plt>
  c1a156:	mov    rbx,rax
  c1a159:	mov    rax,QWORD PTR [rsp+0x80]
  c1a161:	mov    QWORD PTR [r14+0x10],rax
  c1a165:	movaps xmm0,XMMWORD PTR [rsp+0x70]
  c1a16a:	movups XMMWORD PTR [r14],xmm0
  c1a16e:	mov    rdi,rbx
  c1a171:	call   d9b1f0 <_Unwind_Resume@plt>
  c1a176:	jmp    c1a17a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa85a>
  c1a178:	jmp    c1a17a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa85a>
  c1a17a:	mov    rbx,rax
  c1a17d:	mov    rax,QWORD PTR [rsp+0x110]
  c1a185:	mov    QWORD PTR [r14+0x10],rax
  c1a189:	movups xmm0,XMMWORD PTR [rsp+0x100]
  c1a191:	movups XMMWORD PTR [r14],xmm0
  c1a195:	mov    rdi,rbx
  c1a198:	call   d9b1f0 <_Unwind_Resume@plt>
  c1a19d:	mov    rbx,rax
  c1a1a0:	lea    rdi,[rsp+0x100]
  c1a1a8:	call   c0a360 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm5FrameEBD_>
  c1a1ad:	mov    rdi,rbx
  c1a1b0:	call   d9b1f0 <_Unwind_Resume@plt>
  c1a1b5:	jmp    c1a54f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac2f>
  c1a1ba:	jmp    c1a269 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa949>
  c1a1bf:	mov    rbx,rax
  c1a1c2:	mov    DWORD PTR [r15],0x2
  c1a1c9:	jmp    c1a552 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac32>
  c1a1ce:	mov    rbx,rax
  c1a1d1:	cmp    BYTE PTR [rsp+0x70],0xff
  c1a1d6:	je     c1a489 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab69>
  c1a1dc:	lea    rdi,[rsp+0x70]
  c1a1e1:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.3092253909692456873>
  c1a1e6:	jmp    c1a489 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab69>
  c1a1eb:	mov    rbx,rax
  c1a1ee:	lea    rdi,[rsp+0x70]
  c1a1f3:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c1a1f8:	jmp    c1a49e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab7e>
  c1a1fd:	jmp    c1a486 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab66>
  c1a202:	jmp    c1a486 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab66>
  c1a207:	mov    rbx,rax
  c1a20a:	mov    rax,QWORD PTR [rsp+0x110]
  c1a212:	mov    QWORD PTR [r15+0x10],rax
  c1a216:	movups xmm0,XMMWORD PTR [rsp+0x100]
  c1a21e:	movups XMMWORD PTR [r15],xmm0
  c1a222:	mov    rdi,rbx
  c1a225:	call   d9b1f0 <_Unwind_Resume@plt>
  c1a22a:	mov    rbx,rax
  c1a22d:	jmp    c1a23b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa91b>
  c1a22f:	mov    rbx,rax
  c1a232:	test   bpl,bpl
  c1a235:	je     c1a489 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab69>
  c1a23b:	lea    rdi,[rsp+0xc0]
  c1a243:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a248:	jmp    c1a489 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab69>
  c1a24d:	jmp    c1a293 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa973>
  c1a24f:	mov    rbx,rax
  c1a252:	lea    rdi,[rsp+0xc0]
  c1a25a:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a25f:	jmp    c1a49e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab7e>
  c1a264:	jmp    c1a49b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab7b>
  c1a269:	mov    rbx,rax
  c1a26c:	mov    rsi,QWORD PTR [rsp+0x30]
  c1a271:	test   rsi,rsi
  c1a274:	je     c1a59d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac7d>
  c1a27a:	mov    rdi,QWORD PTR [rsp+0x38]
  c1a27f:	shl    rsi,0x4
  c1a283:	mov    edx,0x8
  c1a288:	call   QWORD PTR [rip+0x233412]        # e4d6a0 <_DYNAMIC+0x240>
  c1a28e:	jmp    c1a59d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac7d>
  c1a293:	mov    rbx,rax
  c1a296:	lea    rdi,[rsp+0x70]
  c1a29b:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a2a0:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a2a5:	mov    rbx,rax
  c1a2a8:	lea    rdi,[rsp+0x30]
  c1a2ad:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a2b2:	jmp    c1a333 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa13>
  c1a2b4:	jmp    c1a4e2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabc2>
  c1a2b9:	jmp    c1a2d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa9b7>
  c1a2bb:	mov    rbx,rax
  c1a2be:	lea    rdi,[rsp+0xe0]
  c1a2c6:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a2cb:	jmp    c1a5af <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac8f>
  c1a2d0:	jmp    c1a5ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac8c>
  c1a2d5:	jmp    c1a330 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa10>
  c1a2d7:	mov    rbx,rax
  c1a2da:	lea    rdi,[rsp+0x100]
  c1a2e2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a2e7:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a2ec:	mov    rbx,rax
  c1a2ef:	lea    rdi,[rsp+0x70]
  c1a2f4:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a2f9:	lea    rdi,[rsp+0x30]
  c1a2fe:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a303:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a308:	call   QWORD PTR [rip+0x2333b2]        # e4d6c0 <_DYNAMIC+0x260>
  c1a30e:	mov    rbx,rax
  c1a311:	lea    rdi,[rsp+0x70]
  c1a316:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a31b:	lea    rdi,[rsp+0x30]
  c1a320:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a325:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a32a:	call   QWORD PTR [rip+0x233390]        # e4d6c0 <_DYNAMIC+0x260>
  c1a330:	mov    rbx,rax
  c1a333:	lea    rdi,[rsp+0xc0]
  c1a33b:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a340:	jmp    c1a46d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab4d>
  c1a345:	mov    rbx,rax
  c1a348:	lea    rdi,[rsp+0xc0]
  c1a350:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a355:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a35a:	mov    rbx,rax
  c1a35d:	lea    rdi,[rsp+0xc0]
  c1a365:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a36a:	jmp    c1a4d3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabb3>
  c1a36f:	mov    rbx,rax
  c1a372:	lea    rdi,[rsp+0x70]
  c1a377:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a37c:	lea    rdi,[rsp+0x30]
  c1a381:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a386:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a38b:	call   QWORD PTR [rip+0x23332f]        # e4d6c0 <_DYNAMIC+0x260>
  c1a391:	mov    rbx,rax
  c1a394:	lea    rdi,[rsp+0x70]
  c1a399:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a39e:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a3a3:	jmp    c1a534 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac14>
  c1a3a8:	mov    rbx,rax
  c1a3ab:	lea    rdi,[rsp+0xc0]
  c1a3b3:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a3b8:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a3bd:	jmp    c1a518 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabf8>
  c1a3c2:	mov    rbx,rax
  c1a3c5:	lea    rdi,[rsp+0x70]
  c1a3ca:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a3cf:	lea    rdi,[rsp+0x30]
  c1a3d4:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a3d9:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a3de:	call   QWORD PTR [rip+0x2332dc]        # e4d6c0 <_DYNAMIC+0x260>
  c1a3e4:	jmp    c1a4d0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabb0>
  c1a3e9:	mov    rbx,rax
  c1a3ec:	lea    rdi,[rsp+0x30]
  c1a3f1:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a3f6:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a3fb:	mov    rbx,rax
  c1a3fe:	lea    rdi,[rsp+0x30]
  c1a403:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a408:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a40d:	mov    rbx,rax
  c1a410:	lea    rdi,[rsp+0x70]
  c1a415:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a41a:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a41f:	mov    rbx,rax
  c1a422:	lea    rdi,[rsp+0x70]
  c1a427:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a42c:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a431:	mov    rbx,rax
  c1a434:	lea    rdi,[rsp+0x70]
  c1a439:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a43e:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a443:	jmp    c1a506 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabe6>
  c1a448:	mov    rbx,rax
  c1a44b:	lea    rdi,[rsp+0x70]
  c1a450:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a455:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a45a:	mov    rbx,rax
  c1a45d:	jmp    c1a525 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac05>
  c1a462:	mov    rbx,rax
  c1a465:	jmp    c1a541 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac21>
  c1a46a:	mov    rbx,rax
  c1a46d:	lea    rdi,[rsp+0xe0]
  c1a475:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a47a:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a47f:	jmp    c1a4fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabde>
  c1a481:	mov    rbx,rax
  c1a484:	jmp    c1a4ef <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabcf>
  c1a486:	mov    rbx,rax
  c1a489:	lea    rdi,[rsp+0xe0]
  c1a491:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a496:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a49b:	mov    rbx,rax
  c1a49e:	lea    rdi,[rsp+0xe0]
  c1a4a6:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a4ab:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a4b0:	mov    rbx,rax
  c1a4b3:	lea    rdi,[rsp+0x588]
  c1a4bb:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a4c0:	jmp    c1a552 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac32>
  c1a4c5:	call   QWORD PTR [rip+0x2331f5]        # e4d6c0 <_DYNAMIC+0x260>
  c1a4cb:	jmp    c1a5ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac8c>
  c1a4d0:	mov    rbx,rax
  c1a4d3:	lea    rdi,[rsp+0x70]
  c1a4d8:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1a4dd:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a4e2:	mov    rbx,rax
  c1a4e5:	lea    rdi,[rsp+0x70]
  c1a4ea:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a4ef:	lea    rdi,[rsp+0x30]
  c1a4f4:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a4f9:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a4fe:	mov    rbx,rax
  c1a501:	jmp    c1a5b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac99>
  c1a506:	mov    rbx,rax
  c1a509:	lea    rdi,[rsp+0x70]
  c1a50e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a513:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a518:	mov    rbx,rax
  c1a51b:	lea    rdi,[rsp+0x70]
  c1a520:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a525:	lea    rdi,[rsp+0x30]
  c1a52a:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a52f:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a534:	mov    rbx,rax
  c1a537:	lea    rdi,[rsp+0x70]
  c1a53c:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a541:	lea    rdi,[rsp+0x30]
  c1a546:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a54b:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a54d:	jmp    c1a54f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac2f>
  c1a54f:	mov    rbx,rax
  c1a552:	mov    rax,QWORD PTR [rsp+0x70]
  c1a557:	test   rax,rax
  c1a55a:	je     c1a574 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac54>
  c1a55c:	mov    rdi,QWORD PTR [rsp+0x78]
  c1a561:	shl    rax,0x3
  c1a565:	lea    rsi,[rax+rax*2]
  c1a569:	mov    edx,0x8
  c1a56e:	call   QWORD PTR [rip+0x23312c]        # e4d6a0 <_DYNAMIC+0x240>
  c1a574:	mov    rsi,QWORD PTR [rsp+0x30]
  c1a579:	test   rsi,rsi
  c1a57c:	je     c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a57e:	mov    rdi,QWORD PTR [rsp+0x38]
  c1a583:	shl    rsi,0x4
  c1a587:	mov    edx,0x8
  c1a58c:	call   QWORD PTR [rip+0x23310e]        # e4d6a0 <_DYNAMIC+0x240>
  c1a592:	mov    rdi,rbx
  c1a595:	call   d9b1f0 <_Unwind_Resume@plt>
  c1a59a:	mov    rbx,rax
  c1a59d:	lea    rdi,[rsp+0xc0]
  c1a5a5:	call   c0a040 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueEECsbxgXiyEKxkX_6bsl_vm>
  c1a5aa:	jmp    c1a5c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaca6>
  c1a5ac:	mov    rbx,rax
  c1a5af:	lea    rdi,[rsp+0x70]
  c1a5b4:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1a5b9:	lea    rdi,[rsp+0x358]
  c1a5c1:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a5c6:	mov    rdi,rbx
  c1a5c9:	call   d9b1f0 <_Unwind_Resume@plt>
  c1a5ce:	call   QWORD PTR [rip+0x2330ec]        # e4d6c0 <_DYNAMIC+0x260>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
