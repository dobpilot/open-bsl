
target/release/bsl-cli:     file format elf64-x86-64


Disassembly of section .text:

0000000000c1aea0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold>:
  c1aea0:	push   rbp
  c1aea1:	push   r15
  c1aea3:	push   r14
  c1aea5:	push   r13
  c1aea7:	push   r12
  c1aea9:	push   rbx
  c1aeaa:	sub    rsp,0x388
  c1aeb1:	mov    QWORD PTR [rsp+0x148],r9
  c1aeb9:	mov    QWORD PTR [rsp+0x48],rcx
  c1aebe:	mov    QWORD PTR [rsp+0x50],rdx
  c1aec3:	mov    rbx,rsi
  c1aec6:	mov    QWORD PTR [rsp+0x40],rdi
  c1aecb:	movzx  eax,bl
  c1aece:	add    eax,0xfffffffd
  c1aed1:	cmp    eax,0x34
  c1aed4:	ja     c1b9bf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xb1f>
  c1aeda:	mov    rdx,QWORD PTR [rsp+0x410]
  c1aee2:	mov    rdi,QWORD PTR [rsp+0x408]
  c1aeea:	mov    r15,QWORD PTR [rsp+0x3f0]
  c1aef2:	mov    rsi,QWORD PTR [rsp+0x3e8]
  c1aefa:	mov    r11,QWORD PTR [rsp+0x3d8]
  c1af02:	mov    r9,QWORD PTR [rsp+0x3d0]
  c1af0a:	mov    r10,QWORD PTR [rsp+0x3c8]
  c1af12:	mov    rcx,rbx
  c1af15:	shr    rcx,0x8
  c1af19:	mov    QWORD PTR [rsp+0x108],rcx
  c1af21:	mov    r13,rbx
  c1af24:	shr    r13,0x10
  c1af28:	mov    r12,rbx
  c1af2b:	shr    r12,0x20
  c1af2f:	mov    r14,rbx
  c1af32:	shr    r14,0x30
  c1af36:	lea    rcx,[rip+0xffffffffff6aae5f]        # 2c5d9c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x13db>
  c1af3d:	movsxd rax,DWORD PTR [rcx+rax*4]
  c1af41:	add    rax,rcx
  c1af44:	mov    rbp,rbx
  c1af47:	shr    rbp,0x18
  c1af4b:	shr    rbx,0x28
  c1af4f:	jmp    rax
  c1af51:	lea    rax,[rip+0xffffffffff6aba03]        # 2c695b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x5d8>
  c1af58:	mov    QWORD PTR [rsp+0x78],rax
  c1af5d:	mov    QWORD PTR [rsp+0x80],0x54
  c1af69:	mov    BYTE PTR [rsp+0x70],0x1f
  c1af6e:	test   r15,r15
  c1af71:	je     c1bcc0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe20>
  c1af77:	mov    r12,rsi
  c1af7a:	shl    ebp,0x8
  c1af7d:	movzx  ebx,r13b
  c1af81:	lea    rdi,[rsp+0x70]
  c1af86:	mov    r14,r8
  c1af89:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1af8e:	movzx  eax,bp
  c1af91:	or     rax,rbx
  c1af94:	cmp    rax,QWORD PTR [r14+0xe8]
  c1af9b:	jae    c1bca0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe00>
  c1afa1:	mov    rcx,QWORD PTR [r14+0xe0]
  c1afa8:	cmp    BYTE PTR [rcx+rax*8],0x0
  c1afac:	je     c1bca0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe00>
  c1afb2:	mov    ebx,DWORD PTR [rcx+rax*8+0x4]
  c1afb6:	movzx  r14d,WORD PTR [rcx+rax*8+0x2]
  c1afbc:	lea    rdi,[rsp+0x70]
  c1afc1:	mov    esi,ebx
  c1afc3:	mov    rdx,r15
  c1afc6:	mov    rcx,r12
  c1afc9:	mov    r8,QWORD PTR [rsp+0x50]
  c1afce:	mov    r9,QWORD PTR [rsp+0x48]
  c1afd3:	call   c400e0 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7modules19ensure_module_ready>
  c1afd8:	movzx  ecx,BYTE PTR [rsp+0x70]
  c1afdd:	movzx  eax,BYTE PTR [rsp+0x71]
  c1afe2:	cmp    cl,0xff
  c1afe5:	jne    c1c88a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x19ea>
  c1afeb:	test   al,0x1
  c1afed:	jne    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1aff3:	cmp    QWORD PTR [r12+0x10],rbx
  c1aff8:	jbe    c1e929 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3a89>
  c1affe:	mov    r15,QWORD PTR [r12+0x8]
  c1b003:	shl    rbx,0x5
  c1b007:	lea    rax,[rip+0xffffffffff6ab9a1]        # 2c69af <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x62c>
  c1b00e:	mov    QWORD PTR [rsp+0x78],rax
  c1b013:	mov    QWORD PTR [rsp+0x80],0x3a
  c1b01f:	mov    BYTE PTR [rsp+0x70],0x1f
  c1b024:	lea    rdi,[rsp+0x70]
  c1b029:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1b02e:	cmp    QWORD PTR [r15+rbx*1+0x10],r14
  c1b033:	jbe    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1b039:	add    r15,rbx
  c1b03c:	lea    rsi,[r14+r14*2]
  c1b040:	shl    esi,0x3
  c1b043:	add    rsi,QWORD PTR [r15+0x8]
  c1b047:	lea    rdi,[rsp+0x70]
  c1b04c:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1b051:	mov    rax,QWORD PTR [rsp+0x70]
  c1b056:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1b05c:	mov    QWORD PTR [rsp+0x1a0],rax
  c1b064:	movdqu XMMWORD PTR [rsp+0x1a8],xmm0
  c1b06d:	mov    rax,QWORD PTR [rsp+0x50]
  c1b072:	mov    rsi,QWORD PTR [rax+0x10]
  c1b076:	mov    r15,QWORD PTR [rsp+0x408]
  c1b07e:	cmp    r15,rsi
  c1b081:	jae    c1fc74 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4dd4>
  c1b087:	mov    rsi,QWORD PTR [rax+0x8]
  c1b08b:	imul   rbx,r15,0x78
  c1b08f:	lea    rdx,[rsi+rbx*1]
  c1b093:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1b09b:	mov    rax,rcx
  c1b09e:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1b0a3:	jae    c1effc <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x415c>
  c1b0a9:	mov    rax,QWORD PTR [rdx+0x28]
  c1b0ad:	shl    ecx,0x4
  c1b0b0:	mov    rax,QWORD PTR [rax+rcx*1]
  c1b0b4:	jmp    c1f000 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4160>
  c1b0b9:	mov    r14,QWORD PTR [rsp+0x50]
  c1b0be:	mov    rsi,QWORD PTR [r14+0x10]
  c1b0c2:	cmp    rdi,rsi
  c1b0c5:	jae    c1f98f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4aef>
  c1b0cb:	mov    r9,QWORD PTR [r14+0x8]
  c1b0cf:	mov    rbx,QWORD PTR [rsp+0x48]
  c1b0d4:	mov    rax,QWORD PTR [rbx+0x10]
  c1b0d8:	imul   r15,rdi,0x78
  c1b0dc:	lea    rsi,[r9+r15*1]
  c1b0e0:	movzx  edx,BYTE PTR [rsp+0x108]
  c1b0e8:	mov    rcx,rdx
  c1b0eb:	sub    rcx,QWORD PTR [r9+r15*1+0x30]
  c1b0f0:	jae    c1bd9e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xefe>
  c1b0f6:	mov    rcx,QWORD PTR [rsi+0x28]
  c1b0fa:	shl    edx,0x4
  c1b0fd:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1b101:	cmp    rcx,rax
  c1b104:	jb     c1bdab <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xf0b>
  c1b10a:	jmp    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1b10f:	mov    rax,QWORD PTR [rsp+0x50]
  c1b114:	mov    rsi,QWORD PTR [rax+0x10]
  c1b118:	cmp    rdi,rsi
  c1b11b:	mov    r15,rdi
  c1b11e:	jae    c1f99c <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4afc>
  c1b124:	mov    rdi,QWORD PTR [rax+0x8]
  c1b128:	mov    rax,QWORD PTR [rsp+0x48]
  c1b12d:	mov    rax,QWORD PTR [rax+0x10]
  c1b131:	imul   rbx,r15,0x78
  c1b135:	lea    rsi,[rdi+rbx*1]
  c1b139:	movzx  edx,r13b
  c1b13d:	mov    rcx,rdx
  c1b140:	sub    rcx,QWORD PTR [rdi+rbx*1+0x30]
  c1b145:	jae    c1be11 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xf71>
  c1b14b:	mov    rcx,QWORD PTR [rsi+0x28]
  c1b14f:	shl    edx,0x4
  c1b152:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1b156:	cmp    rcx,rax
  c1b159:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1b15f:	jmp    c1be1e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xf7e>
  c1b164:	movzx  r12d,bpl
  c1b168:	test   r12,r12
  c1b16b:	je     c1c21c <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x137c>
  c1b171:	lea    ebx,[r12*8+0x0]
  c1b179:	call   QWORD PTR [rip+0x232941]        # e4dac0 <_DYNAMIC+0x300>
  c1b17f:	mov    esi,0x8
  c1b184:	mov    rdi,rbx
  c1b187:	call   QWORD PTR [rip+0x23293b]        # e4dac8 <_DYNAMIC+0x308>
  c1b18d:	test   rax,rax
  c1b190:	mov    r15,QWORD PTR [rsp+0x408]
  c1b198:	jne    c1c229 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1389>
  c1b19e:	mov    edi,0x8
  c1b1a3:	mov    rsi,rbx
  c1b1a6:	call   QWORD PTR [rip+0x2328fc]        # e4daa8 <_DYNAMIC+0x2e8>
  c1b1ac:	mov    r14,QWORD PTR [rsp+0x50]
  c1b1b1:	mov    rsi,QWORD PTR [r14+0x10]
  c1b1b5:	cmp    rdi,rsi
  c1b1b8:	mov    r15,rdi
  c1b1bb:	jae    c1f9ac <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b0c>
  c1b1c1:	mov    rbx,rdx
  c1b1c4:	mov    r13,r8
  c1b1c7:	mov    rax,QWORD PTR [rsp+0x48]
  c1b1cc:	mov    rsi,QWORD PTR [rax+0x8]
  c1b1d0:	mov    rdx,QWORD PTR [rax+0x10]
  c1b1d4:	imul   rdi,r15,0x78
  c1b1d8:	mov    rcx,QWORD PTR [r14+0x8]
  c1b1dc:	mov    QWORD PTR [rsp+0x148],rdi
  c1b1e4:	add    rcx,rdi
  c1b1e7:	movzx  r8d,bpl
  c1b1eb:	movzx  r9d,r12b
  c1b1ef:	lea    rdi,[rsp+0x70]
  c1b1f4:	call   c247e0 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs4load>
  c1b1f9:	mov    eax,DWORD PTR [rsp+0x70]
  c1b1fd:	cmp    eax,0xffffffff
  c1b200:	je     c1bcec <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe4c>
  c1b206:	mov    ecx,DWORD PTR [rsp+0xa4]
  c1b20d:	mov    DWORD PTR [rsp+0x180],ecx
  c1b214:	movdqu xmm0,XMMWORD PTR [rsp+0x74]
  c1b21a:	movdqu xmm1,XMMWORD PTR [rsp+0x84]
  c1b223:	movdqu xmm2,XMMWORD PTR [rsp+0x94]
  c1b22c:	movdqa XMMWORD PTR [rsp+0x170],xmm2
  c1b235:	movdqa XMMWORD PTR [rsp+0x160],xmm1
  c1b23e:	movdqa XMMWORD PTR [rsp+0x150],xmm0
  c1b247:	movups xmm3,XMMWORD PTR [rsp+0xa8]
  c1b24f:	movups XMMWORD PTR [rsp+0x1d8],xmm3
  c1b257:	mov    rdx,QWORD PTR [rsp+0xb8]
  c1b25f:	mov    QWORD PTR [rsp+0x1e8],rdx
  c1b267:	movdqu XMMWORD PTR [rsp+0x1a4],xmm0
  c1b270:	movdqu XMMWORD PTR [rsp+0x1b4],xmm1
  c1b279:	movdqu XMMWORD PTR [rsp+0x1c4],xmm2
  c1b282:	mov    DWORD PTR [rsp+0x1d4],ecx
  c1b289:	mov    DWORD PTR [rsp+0x1a0],eax
  c1b290:	mov    rsi,QWORD PTR [r14+0x10]
  c1b294:	cmp    r15,rsi
  c1b297:	jae    c1fa1d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b7d>
  c1b29d:	mov    rcx,QWORD PTR [rsp+0x3c8]
  c1b2a5:	cmp    rbx,QWORD PTR [rcx+0x10]
  c1b2a9:	jae    c1c14e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x12ae>
  c1b2af:	mov    rax,QWORD PTR [r14+0x8]
  c1b2b3:	mov    rdx,QWORD PTR [rsp+0x148]
  c1b2bb:	mov    rax,QWORD PTR [rax+rdx*1+0x58]
  c1b2c0:	mov    rcx,QWORD PTR [rcx+0x8]
  c1b2c4:	lea    rdx,[rbx+rbx*2]
  c1b2c8:	cmp    rax,QWORD PTR [rcx+rdx*8+0x10]
  c1b2cd:	jae    c1c14e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x12ae>
  c1b2d3:	lea    rcx,[rcx+rdx*8]
  c1b2d7:	mov    rcx,QWORD PTR [rcx+0x8]
  c1b2db:	mov    r14,QWORD PTR [rcx+rax*8]
  c1b2df:	lea    rax,[rip+0xffffffffff6ad235]        # 2c851b <anon.0c0210c0485269faeef710294932bddb.7.llvm.14881818243032060321>
  c1b2e6:	mov    QWORD PTR [rsp+0x78],rax
  c1b2eb:	mov    QWORD PTR [rsp+0x80],0x42
  c1b2f7:	mov    BYTE PTR [rsp+0x70],0x1f
  c1b2fc:	test   r14,r14
  c1b2ff:	je     c1c166 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x12c6>
  c1b305:	lea    rdi,[rsp+0x70]
  c1b30a:	call   c367e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.14881818243032060321>
  c1b30f:	mov    r11,QWORD PTR [rsp+0x3d0]
  c1b317:	lea    rax,[r11+0x28]
  c1b31b:	lea    rcx,[r11+0x30]
  c1b31f:	mov    rdx,QWORD PTR [r11+0x20]
  c1b323:	mov    QWORD PTR [rsp+0x110],rax
  c1b32b:	mov    QWORD PTR [rsp+0x118],rcx
  c1b333:	mov    QWORD PTR [rsp+0x120],rdx
  c1b33b:	mov    QWORD PTR [rsp+0x128],r13
  c1b343:	mov    r12,QWORD PTR [rsp+0x3c8]
  c1b34b:	mov    QWORD PTR [rsp+0x130],r12
  c1b353:	mov    rax,QWORD PTR [rsp+0x3e0]
  c1b35b:	mov    QWORD PTR [rsp+0x138],rax
  c1b363:	lea    rdx,[r12+0x48]
  c1b368:	lea    rsi,[r12+0x58]
  c1b36d:	lea    rdi,[r12+0x68]
  c1b372:	lea    r8,[r12+0xf0]
  c1b37a:	mov    rax,QWORD PTR [r12+0xf0]
  c1b382:	mov    r9,QWORD PTR [r12+0x118]
  c1b38a:	test   rax,rax
  c1b38d:	cmove  r8,rax
  c1b391:	lea    rcx,[r12+0x100]
  c1b399:	lea    r10,[r12+0x110]
  c1b3a1:	lea    rax,[r12+0x118]
  c1b3a9:	test   r9,r9
  c1b3ac:	cmove  rax,r9
  c1b3b0:	movq   xmm0,QWORD PTR [r12+0x110]
  c1b3ba:	movq   xmm1,QWORD PTR [r12+0x100]
  c1b3c4:	punpcklqdq xmm1,xmm0
  c1b3c8:	mov    r9,QWORD PTR [rsp+0x3d8]
  c1b3d0:	mov    QWORD PTR [rsp+0x70],r9
  c1b3d5:	mov    r9,QWORD PTR [rip+0x232704]        # e4dae0 <_DYNAMIC+0x320>
  c1b3dc:	mov    QWORD PTR [rsp+0x78],r9
  c1b3e1:	mov    BYTE PTR [rsp+0xf8],0x0
  c1b3e9:	movups xmm0,XMMWORD PTR [r11]
  c1b3ed:	movups XMMWORD PTR [rsp+0x80],xmm0
  c1b3f5:	movdqu xmm0,XMMWORD PTR [r11+0x10]
  c1b3fb:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1b404:	mov    QWORD PTR [rsp+0xa0],rdx
  c1b40c:	mov    QWORD PTR [rsp+0xa8],rsi
  c1b414:	mov    QWORD PTR [rsp+0xb0],rdi
  c1b41c:	mov    QWORD PTR [rsp+0xb8],r8
  c1b424:	mov    QWORD PTR [rsp+0xc0],0x0
  c1b430:	lea    rdx,[rsp+0x110]
  c1b438:	mov    QWORD PTR [rsp+0xd0],rdx
  c1b440:	lea    rdx,[rip+0x21b559]        # e369a0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xda0>
  c1b447:	mov    QWORD PTR [rsp+0xd8],rdx
  c1b44f:	pxor   xmm0,xmm0
  c1b453:	pcmpeqd xmm0,xmm1
  c1b457:	movq   xmm1,r10
  c1b45c:	movq   xmm2,rcx
  c1b461:	punpcklqdq xmm2,xmm1
  c1b465:	pshufd xmm1,xmm0,0xb1
  c1b46a:	pand   xmm1,xmm0
  c1b46e:	pandn  xmm1,xmm2
  c1b472:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1b47b:	mov    QWORD PTR [rsp+0xf0],rax
  c1b483:	lea    rdi,[rsp+0x1a0]
  c1b48b:	call   c25080 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs8as_slice>
  c1b490:	mov    rcx,rdx
  c1b493:	lea    rdi,[rsp+0x150]
  c1b49b:	lea    rsi,[rsp+0x70]
  c1b4a0:	mov    rdx,rax
  c1b4a3:	call   r14
  c1b4a6:	movzx  eax,BYTE PTR [rsp+0x150]
  c1b4ae:	cmp    al,0xff
  c1b4b0:	je     c1de4a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2faa>
  c1b4b6:	movups xmm0,XMMWORD PTR [rsp+0x151]
  c1b4be:	movdqu xmm1,XMMWORD PTR [rsp+0x160]
  c1b4c7:	movdqu xmm2,XMMWORD PTR [rsp+0x170]
  c1b4d0:	movdqu XMMWORD PTR [rsp+0x22f],xmm1
  c1b4d9:	movaps XMMWORD PTR [rsp+0x220],xmm0
  c1b4e1:	mov    rcx,QWORD PTR [rsp+0x40]
  c1b4e6:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1b4eb:	movups xmm0,XMMWORD PTR [rsp+0x22f]
  c1b4f3:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1b4f7:	movdqa xmm0,XMMWORD PTR [rsp+0x220]
  c1b500:	jmp    c1b9b3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xb13>
  c1b505:	lea    rax,[rip+0xffffffffff6ab44f]        # 2c695b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x5d8>
  c1b50c:	mov    QWORD PTR [rsp+0x78],rax
  c1b511:	mov    QWORD PTR [rsp+0x80],0x54
  c1b51d:	mov    BYTE PTR [rsp+0x70],0x1f
  c1b522:	test   r15,r15
  c1b525:	je     c1bcc0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe20>
  c1b52b:	mov    r12,rsi
  c1b52e:	shl    ebp,0x8
  c1b531:	movzx  ebx,r13b
  c1b535:	lea    rdi,[rsp+0x70]
  c1b53a:	mov    r14,r8
  c1b53d:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1b542:	movzx  eax,bp
  c1b545:	or     rax,rbx
  c1b548:	cmp    rax,QWORD PTR [r14+0xe8]
  c1b54f:	jae    c1bca0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe00>
  c1b555:	mov    rcx,QWORD PTR [r14+0xe0]
  c1b55c:	cmp    BYTE PTR [rcx+rax*8],0x0
  c1b560:	je     c1bca0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe00>
  c1b566:	mov    ebx,DWORD PTR [rcx+rax*8+0x4]
  c1b56a:	movzx  r14d,WORD PTR [rcx+rax*8+0x2]
  c1b570:	lea    rdi,[rsp+0x70]
  c1b575:	mov    esi,ebx
  c1b577:	mov    rdx,r15
  c1b57a:	mov    rcx,r12
  c1b57d:	mov    r8,QWORD PTR [rsp+0x50]
  c1b582:	mov    r9,QWORD PTR [rsp+0x48]
  c1b587:	call   c400e0 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7modules19ensure_module_ready>
  c1b58c:	movzx  ecx,BYTE PTR [rsp+0x70]
  c1b591:	movzx  eax,BYTE PTR [rsp+0x71]
  c1b596:	cmp    cl,0xff
  c1b599:	jne    c1c88a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x19ea>
  c1b59f:	test   al,0x1
  c1b5a1:	jne    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1b5a7:	mov    rax,QWORD PTR [rsp+0x50]
  c1b5ac:	mov    rsi,QWORD PTR [rax+0x10]
  c1b5b0:	mov    rdi,QWORD PTR [rsp+0x408]
  c1b5b8:	cmp    rdi,rsi
  c1b5bb:	jae    c1fc28 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4d88>
  c1b5c1:	mov    r8,QWORD PTR [rax+0x8]
  c1b5c5:	mov    rax,QWORD PTR [rsp+0x48]
  c1b5ca:	mov    rax,QWORD PTR [rax+0x10]
  c1b5ce:	imul   r15,rdi,0x78
  c1b5d2:	lea    rsi,[r8+r15*1]
  c1b5d6:	movzx  edx,BYTE PTR [rsp+0x108]
  c1b5de:	mov    rcx,rdx
  c1b5e1:	sub    rcx,QWORD PTR [r8+r15*1+0x30]
  c1b5e6:	jae    c1e993 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3af3>
  c1b5ec:	mov    rcx,QWORD PTR [rsi+0x28]
  c1b5f0:	shl    edx,0x4
  c1b5f3:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1b5f7:	jmp    c1e997 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3af7>
  c1b5fc:	shl    ebx,0x8
  c1b5ff:	movzx  ecx,r12b
  c1b603:	movzx  eax,bx
  c1b606:	or     rax,rcx
  c1b609:	cmp    rax,QWORD PTR [r8+0x58]
  c1b60d:	jae    c1bd37 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe97>
  c1b613:	mov    rcx,QWORD PTR [r8+0x50]
  c1b617:	mov    rbx,QWORD PTR [rcx+rax*8]
  c1b61b:	inc    QWORD PTR [rbx]
  c1b61e:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1b624:	mov    QWORD PTR [rsp+0x110],rbx
  c1b62c:	movzx  r15d,bpl
  c1b630:	test   r15,r15
  c1b633:	je     c1c639 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1799>
  c1b639:	lea    eax,[r15*8+0x0]
  c1b641:	lea    r14,[rax+rax*2]
  c1b645:	call   QWORD PTR [rip+0x232475]        # e4dac0 <_DYNAMIC+0x300>
  c1b64b:	mov    esi,0x8
  c1b650:	mov    rdi,r14
  c1b653:	call   QWORD PTR [rip+0x23246f]        # e4dac8 <_DYNAMIC+0x308>
  c1b659:	test   rax,rax
  c1b65c:	jne    c1c63e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x179e>
  c1b662:	mov    edi,0x8
  c1b667:	mov    rsi,r14
  c1b66a:	call   QWORD PTR [rip+0x232438]        # e4daa8 <_DYNAMIC+0x2e8>
  c1b670:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1b675:	test   BYTE PTR [rsp+0x108],0x1
  c1b67d:	je     c1bd57 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xeb7>
  c1b683:	mov    rax,QWORD PTR [rsp+0x50]
  c1b688:	mov    rsi,QWORD PTR [rax+0x10]
  c1b68c:	cmp    rdi,rsi
  c1b68f:	jae    c1fa47 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4ba7>
  c1b695:	mov    r9,QWORD PTR [rax+0x8]
  c1b699:	mov    r10,QWORD PTR [rsp+0x48]
  c1b69e:	mov    rax,QWORD PTR [r10+0x10]
  c1b6a2:	imul   r8,rdi,0x78
  c1b6a6:	lea    rsi,[r9+r8*1]
  c1b6aa:	movzx  edx,r13b
  c1b6ae:	mov    rcx,rdx
  c1b6b1:	sub    rcx,QWORD PTR [r9+r8*1+0x30]
  c1b6b6:	jae    c1c4a5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1605>
  c1b6bc:	mov    rcx,QWORD PTR [rsi+0x28]
  c1b6c0:	shl    edx,0x4
  c1b6c3:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1b6c7:	jmp    c1c4a9 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1609>
  c1b6cc:	mov    r14,QWORD PTR [rsp+0x50]
  c1b6d1:	mov    rsi,QWORD PTR [r14+0x10]
  c1b6d5:	cmp    rdi,rsi
  c1b6d8:	mov    r15,rdi
  c1b6db:	jae    c1f9bc <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b1c>
  c1b6e1:	mov    r13,rdx
  c1b6e4:	mov    rax,QWORD PTR [rsp+0x48]
  c1b6e9:	mov    rsi,QWORD PTR [rax+0x8]
  c1b6ed:	mov    rdx,QWORD PTR [rax+0x10]
  c1b6f1:	imul   rbx,r15,0x78
  c1b6f5:	mov    rcx,QWORD PTR [r14+0x8]
  c1b6f9:	add    rcx,rbx
  c1b6fc:	movzx  r8d,bpl
  c1b700:	movzx  r9d,r12b
  c1b704:	lea    rdi,[rsp+0x70]
  c1b709:	call   c247e0 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs4load>
  c1b70e:	mov    eax,DWORD PTR [rsp+0x70]
  c1b712:	cmp    eax,0xffffffff
  c1b715:	je     c1bcec <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe4c>
  c1b71b:	mov    ecx,DWORD PTR [rsp+0xa4]
  c1b722:	mov    DWORD PTR [rsp+0x180],ecx
  c1b729:	movdqu xmm0,XMMWORD PTR [rsp+0x74]
  c1b72f:	movdqu xmm1,XMMWORD PTR [rsp+0x84]
  c1b738:	movdqu xmm2,XMMWORD PTR [rsp+0x94]
  c1b741:	movdqa XMMWORD PTR [rsp+0x170],xmm2
  c1b74a:	movdqa XMMWORD PTR [rsp+0x160],xmm1
  c1b753:	movdqa XMMWORD PTR [rsp+0x150],xmm0
  c1b75c:	movups xmm3,XMMWORD PTR [rsp+0xa8]
  c1b764:	movups XMMWORD PTR [rsp+0x1d8],xmm3
  c1b76c:	mov    rdx,QWORD PTR [rsp+0xb8]
  c1b774:	mov    QWORD PTR [rsp+0x1e8],rdx
  c1b77c:	movdqu XMMWORD PTR [rsp+0x1a4],xmm0
  c1b785:	movdqu XMMWORD PTR [rsp+0x1b4],xmm1
  c1b78e:	movdqu XMMWORD PTR [rsp+0x1c4],xmm2
  c1b797:	mov    DWORD PTR [rsp+0x1d4],ecx
  c1b79e:	mov    DWORD PTR [rsp+0x1a0],eax
  c1b7a5:	mov    rsi,QWORD PTR [r14+0x10]
  c1b7a9:	cmp    r15,rsi
  c1b7ac:	jae    c1fa32 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b92>
  c1b7b2:	mov    rcx,QWORD PTR [rsp+0x3c8]
  c1b7ba:	cmp    r13,QWORD PTR [rcx+0x28]
  c1b7be:	jae    c1c1ab <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x130b>
  c1b7c4:	mov    rax,QWORD PTR [r14+0x8]
  c1b7c8:	mov    rax,QWORD PTR [rax+rbx*1+0x58]
  c1b7cd:	mov    rcx,QWORD PTR [rcx+0x20]
  c1b7d1:	lea    rdx,[r13*2+0x0]
  c1b7d9:	add    rdx,r13
  c1b7dc:	cmp    rax,QWORD PTR [rcx+rdx*8+0x10]
  c1b7e1:	jae    c1c1ab <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x130b>
  c1b7e7:	lea    rcx,[rcx+rdx*8]
  c1b7eb:	mov    rcx,QWORD PTR [rcx+0x8]
  c1b7ef:	mov    r14,QWORD PTR [rcx+rax*8]
  c1b7f3:	lea    rax,[rip+0xffffffffff6accd6]        # 2c84d0 <anon.0c0210c0485269faeef710294932bddb.6.llvm.14881818243032060321>
  c1b7fa:	mov    QWORD PTR [rsp+0x78],rax
  c1b7ff:	mov    QWORD PTR [rsp+0x80],0x4b
  c1b80b:	mov    BYTE PTR [rsp+0x70],0x1f
  c1b810:	test   r14,r14
  c1b813:	je     c1c1c3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1323>
  c1b819:	lea    rdi,[rsp+0x70]
  c1b81e:	call   c367e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.14881818243032060321>
  c1b823:	mov    r13,QWORD PTR [rsp+0x3c8]
  c1b82b:	lea    rcx,[r13+0x48]
  c1b82f:	lea    rdx,[r13+0x58]
  c1b833:	lea    rsi,[r13+0x68]
  c1b837:	lea    rdi,[r13+0xf0]
  c1b83e:	mov    rax,QWORD PTR [r13+0xf0]
  c1b845:	mov    r8,QWORD PTR [r13+0x118]
  c1b84c:	test   rax,rax
  c1b84f:	cmove  rdi,rax
  c1b853:	lea    r9,[r13+0x100]
  c1b85a:	lea    rax,[r13+0x118]
  c1b861:	test   r8,r8
  c1b864:	cmove  rax,r8
  c1b868:	lea    r8,[r13+0x110]
  c1b86f:	movq   xmm0,QWORD PTR [r13+0x110]
  c1b878:	movq   xmm1,QWORD PTR [r13+0x100]
  c1b881:	punpcklqdq xmm1,xmm0
  c1b885:	mov    r10,QWORD PTR [rsp+0x3d8]
  c1b88d:	mov    QWORD PTR [rsp+0x70],r10
  c1b892:	mov    r10,QWORD PTR [rip+0x232247]        # e4dae0 <_DYNAMIC+0x320>
  c1b899:	mov    QWORD PTR [rsp+0x78],r10
  c1b89e:	mov    BYTE PTR [rsp+0xf8],0x0
  c1b8a6:	mov    r13,QWORD PTR [rsp+0x3d0]
  c1b8ae:	movups xmm0,XMMWORD PTR [r13+0x0]
  c1b8b3:	movups XMMWORD PTR [rsp+0x80],xmm0
  c1b8bb:	movdqu xmm0,XMMWORD PTR [r13+0x10]
  c1b8c1:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1b8ca:	mov    QWORD PTR [rsp+0xa0],rcx
  c1b8d2:	mov    QWORD PTR [rsp+0xa8],rdx
  c1b8da:	mov    QWORD PTR [rsp+0xb0],rsi
  c1b8e2:	mov    QWORD PTR [rsp+0xb8],rdi
  c1b8ea:	mov    QWORD PTR [rsp+0xc0],0x0
  c1b8f6:	mov    QWORD PTR [rsp+0xd0],0x0
  c1b902:	pxor   xmm0,xmm0
  c1b906:	pcmpeqd xmm0,xmm1
  c1b90a:	movq   xmm1,r8
  c1b90f:	movq   xmm2,r9
  c1b914:	punpcklqdq xmm2,xmm1
  c1b918:	pshufd xmm1,xmm0,0xb1
  c1b91d:	pand   xmm1,xmm0
  c1b921:	pandn  xmm1,xmm2
  c1b925:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1b92e:	mov    QWORD PTR [rsp+0xf0],rax
  c1b936:	lea    rdi,[rsp+0x1a0]
  c1b93e:	call   c25080 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs8as_slice>
  c1b943:	mov    rcx,rdx
  c1b946:	lea    rdi,[rsp+0x150]
  c1b94e:	lea    rsi,[rsp+0x70]
  c1b953:	mov    rdx,rax
  c1b956:	call   r14
  c1b959:	movzx  eax,BYTE PTR [rsp+0x150]
  c1b961:	cmp    al,0xff
  c1b963:	je     c1deb4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3014>
  c1b969:	movups xmm0,XMMWORD PTR [rsp+0x151]
  c1b971:	movdqu xmm1,XMMWORD PTR [rsp+0x160]
  c1b97a:	movdqu xmm2,XMMWORD PTR [rsp+0x170]
  c1b983:	movdqu XMMWORD PTR [rsp+0x11f],xmm1
  c1b98c:	movaps XMMWORD PTR [rsp+0x110],xmm0
  c1b994:	mov    rcx,QWORD PTR [rsp+0x40]
  c1b999:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1b99e:	movups xmm0,XMMWORD PTR [rsp+0x11f]
  c1b9a6:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1b9aa:	movdqa xmm0,XMMWORD PTR [rsp+0x110]
  c1b9b3:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1b9b8:	mov    BYTE PTR [rcx],al
  c1b9ba:	jmp    c1c20a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x136a>
  c1b9bf:	mov    rcx,QWORD PTR [rsp+0x40]
  c1b9c4:	mov    BYTE PTR [rcx],0x1f
  c1b9c7:	lea    rax,[rip+0xffffffffff6ab307]        # 2c6cd5 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x952>
  c1b9ce:	mov    QWORD PTR [rcx+0x8],rax
  c1b9d2:	mov    QWORD PTR [rcx+0x10],0x5e
  c1b9da:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1b9df:	lea    rax,[rip+0xffffffffff6aaf75]        # 2c695b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x5d8>
  c1b9e6:	mov    QWORD PTR [rsp+0x78],rax
  c1b9eb:	lea    rcx,[rsp+0x80]
  c1b9f3:	mov    QWORD PTR [rsp+0x80],0x54
  c1b9ff:	mov    BYTE PTR [rsp+0x70],0x1f
  c1ba04:	test   r15,r15
  c1ba07:	je     c1bcc8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe28>
  c1ba0d:	shl    ebx,0x8
  c1ba10:	movzx  ebp,r12b
  c1ba14:	lea    rdi,[rsp+0x70]
  c1ba19:	mov    r12,r8
  c1ba1c:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1ba21:	mov    rdx,QWORD PTR [r12+0xe8]
  c1ba29:	movzx  eax,bx
  c1ba2c:	or     rax,rbp
  c1ba2f:	cmp    rax,rdx
  c1ba32:	jae    c1ba48 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xba8>
  c1ba34:	mov    r12,QWORD PTR [r12+0xe0]
  c1ba3c:	cmp    WORD PTR [r12+rax*8],0x1
  c1ba42:	jne    c1c843 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x19a3>
  c1ba48:	mov    rcx,QWORD PTR [rsp+0x40]
  c1ba4d:	mov    BYTE PTR [rcx],0x1f
  c1ba50:	lea    rax,[rip+0xffffffffff6ab10c]        # 2c6b63 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x7e0>
  c1ba57:	mov    QWORD PTR [rcx+0x8],rax
  c1ba5b:	mov    QWORD PTR [rcx+0x10],0x5d
  c1ba63:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1ba68:	mov    rax,QWORD PTR [rsp+0x50]
  c1ba6d:	mov    rsi,QWORD PTR [rax+0x10]
  c1ba71:	cmp    rdi,rsi
  c1ba74:	jae    c1f9cc <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b2c>
  c1ba7a:	mov    rdx,QWORD PTR [rax+0x8]
  c1ba7e:	imul   rbx,rdi,0x78
  c1ba82:	lea    rcx,[rdx+rbx*1]
  c1ba86:	movzx  eax,BYTE PTR [rsp+0x108]
  c1ba8e:	mov    r14,rax
  c1ba91:	sub    r14,QWORD PTR [rdx+rbx*1+0x30]
  c1ba96:	jae    c1be64 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xfc4>
  c1ba9c:	mov    r13,rdi
  c1ba9f:	mov    rcx,QWORD PTR [rcx+0x28]
  c1baa3:	shl    eax,0x4
  c1baa6:	mov    r14,QWORD PTR [rcx+rax*1]
  c1baaa:	jmp    c1be6b <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xfcb>
  c1baaf:	mov    r14,QWORD PTR [rsp+0x50]
  c1bab4:	mov    rsi,QWORD PTR [r14+0x10]
  c1bab8:	cmp    rdi,rsi
  c1babb:	mov    r15,rdi
  c1babe:	jae    c1f9d9 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b39>
  c1bac4:	mov    rdi,QWORD PTR [r14+0x8]
  c1bac8:	mov    rax,QWORD PTR [rsp+0x48]
  c1bacd:	mov    rax,QWORD PTR [rax+0x10]
  c1bad1:	imul   rbx,r15,0x78
  c1bad5:	lea    rsi,[rdi+rbx*1]
  c1bad9:	movzx  edx,r13b
  c1badd:	mov    rcx,rdx
  c1bae0:	sub    rcx,QWORD PTR [rdi+rbx*1+0x30]
  c1bae5:	jae    c1bef8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1058>
  c1baeb:	mov    rcx,QWORD PTR [rsi+0x28]
  c1baef:	shl    edx,0x4
  c1baf2:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1baf6:	cmp    rcx,rax
  c1baf9:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1baff:	jmp    c1bf05 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1065>
  c1bb04:	mov    rax,QWORD PTR [rsp+0x3f8]
  c1bb0c:	cmp    QWORD PTR [rax],0x0
  c1bb10:	jne    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1bb16:	mov    rax,QWORD PTR [rsp+0x50]
  c1bb1b:	mov    rsi,QWORD PTR [rax+0x10]
  c1bb1f:	cmp    rdi,rsi
  c1bb22:	jae    c1fa83 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4be3>
  c1bb28:	mov    rcx,QWORD PTR [rax+0x8]
  c1bb2c:	mov    r9,QWORD PTR [rsp+0x48]
  c1bb31:	mov    rdx,QWORD PTR [r9+0x10]
  c1bb35:	imul   r10,rdi,0x78
  c1bb39:	movzx  esi,r13b
  c1bb3d:	mov    rax,QWORD PTR [rcx+r10*1+0x30]
  c1bb42:	add    rcx,r10
  c1bb45:	mov    r13,rsi
  c1bb48:	sub    r13,rax
  c1bb4b:	jae    c1c504 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1664>
  c1bb51:	mov    rdi,QWORD PTR [rcx+0x28]
  c1bb55:	shl    esi,0x4
  c1bb58:	mov    r13,QWORD PTR [rdi+rsi*1]
  c1bb5c:	jmp    c1c508 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1668>
  c1bb61:	mov    r9,QWORD PTR [rsp+0x50]
  c1bb66:	mov    rsi,QWORD PTR [r9+0x10]
  c1bb6a:	cmp    rdi,rsi
  c1bb6d:	jae    c1f9e9 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b49>
  c1bb73:	mov    rbp,rdx
  c1bb76:	mov    r14,r8
  c1bb79:	mov    r8,QWORD PTR [r9+0x8]
  c1bb7d:	mov    rax,QWORD PTR [rsp+0x48]
  c1bb82:	mov    rax,QWORD PTR [rax+0x10]
  c1bb86:	imul   r15,rdi,0x78
  c1bb8a:	lea    rsi,[r8+r15*1]
  c1bb8e:	movzx  edx,r13b
  c1bb92:	mov    rcx,rdx
  c1bb95:	sub    rcx,QWORD PTR [r8+r15*1+0x30]
  c1bb9a:	jae    c1bf4b <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x10ab>
  c1bba0:	mov    rcx,QWORD PTR [rsi+0x28]
  c1bba4:	shl    edx,0x4
  c1bba7:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1bbab:	cmp    rcx,rax
  c1bbae:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1bbb4:	jmp    c1bf58 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x10b8>
  c1bbb9:	mov    rax,QWORD PTR [rsp+0x50]
  c1bbbe:	mov    rsi,QWORD PTR [rax+0x10]
  c1bbc2:	cmp    rdi,rsi
  c1bbc5:	jae    c1f9f6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b56>
  c1bbcb:	mov    rdx,QWORD PTR [rax+0x8]
  c1bbcf:	imul   rbx,rdi,0x78
  c1bbd3:	lea    rcx,[rdx+rbx*1]
  c1bbd7:	movzx  eax,BYTE PTR [rsp+0x108]
  c1bbdf:	mov    r14,rax
  c1bbe2:	sub    r14,QWORD PTR [rdx+rbx*1+0x30]
  c1bbe7:	jae    c1bf9b <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x10fb>
  c1bbed:	mov    r13,rdi
  c1bbf0:	mov    rcx,QWORD PTR [rcx+0x28]
  c1bbf4:	shl    eax,0x4
  c1bbf7:	mov    r14,QWORD PTR [rcx+rax*1]
  c1bbfb:	jmp    c1bfa2 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1102>
  c1bc00:	mov    rax,QWORD PTR [rsp+0x50]
  c1bc05:	mov    rsi,QWORD PTR [rax+0x10]
  c1bc09:	cmp    rdi,rsi
  c1bc0c:	jae    c1fa03 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b63>
  c1bc12:	mov    rdx,QWORD PTR [rax+0x8]
  c1bc16:	imul   rbx,rdi,0x78
  c1bc1a:	lea    rcx,[rdx+rbx*1]
  c1bc1e:	movzx  eax,BYTE PTR [rsp+0x108]
  c1bc26:	mov    r14,rax
  c1bc29:	sub    r14,QWORD PTR [rdx+rbx*1+0x30]
  c1bc2e:	jae    c1c02f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x118f>
  c1bc34:	mov    r13,rdi
  c1bc37:	mov    rcx,QWORD PTR [rcx+0x28]
  c1bc3b:	shl    eax,0x4
  c1bc3e:	mov    r14,QWORD PTR [rcx+rax*1]
  c1bc42:	jmp    c1c036 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1196>
  c1bc47:	mov    rax,QWORD PTR [rsp+0x50]
  c1bc4c:	mov    rsi,QWORD PTR [rax+0x10]
  c1bc50:	cmp    rdi,rsi
  c1bc53:	jae    c1fa10 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4b70>
  c1bc59:	mov    r14,rdx
  c1bc5c:	mov    r9,QWORD PTR [rax+0x8]
  c1bc60:	mov    rax,QWORD PTR [rsp+0x48]
  c1bc65:	mov    rax,QWORD PTR [rax+0x10]
  c1bc69:	imul   r15,rdi,0x78
  c1bc6d:	lea    rsi,[r9+r15*1]
  c1bc71:	movzx  edx,BYTE PTR [rsp+0x108]
  c1bc79:	mov    rcx,rdx
  c1bc7c:	sub    rcx,QWORD PTR [r9+r15*1+0x30]
  c1bc81:	jae    c1c0fb <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x125b>
  c1bc87:	mov    rcx,QWORD PTR [rsi+0x28]
  c1bc8b:	shl    edx,0x4
  c1bc8e:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1bc92:	cmp    rcx,rax
  c1bc95:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1bc9b:	jmp    c1c108 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1268>
  c1bca0:	mov    rcx,QWORD PTR [rsp+0x40]
  c1bca5:	mov    BYTE PTR [rcx],0x1f
  c1bca8:	lea    rax,[rip+0xffffffffff6aad3a]        # 2c69e9 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x666>
  c1bcaf:	mov    QWORD PTR [rcx+0x8],rax
  c1bcb3:	mov    QWORD PTR [rcx+0x10],0x72
  c1bcbb:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1bcc0:	lea    rcx,[rsp+0x80]
  c1bcc8:	movdqu xmm0,XMMWORD PTR [rcx]
  c1bccc:	movdqu xmm1,XMMWORD PTR [rcx+0x10]
  c1bcd1:	mov    rcx,QWORD PTR [rsp+0x40]
  c1bcd6:	movdqu XMMWORD PTR [rcx+0x20],xmm1
  c1bcdb:	movdqu XMMWORD PTR [rcx+0x10],xmm0
  c1bce0:	mov    BYTE PTR [rcx],0x1f
  c1bce3:	mov    QWORD PTR [rcx+0x8],rax
  c1bce7:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1bcec:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1bcf2:	movdqu xmm1,XMMWORD PTR [rsp+0x88]
  c1bcfb:	movdqu xmm2,XMMWORD PTR [rsp+0x98]
  c1bd04:	movdqu XMMWORD PTR [rsp+0x174],xmm2
  c1bd0d:	movdqu XMMWORD PTR [rsp+0x164],xmm1
  c1bd16:	movdqu XMMWORD PTR [rsp+0x154],xmm0
  c1bd1f:	mov    rax,QWORD PTR [rsp+0x40]
  c1bd24:	movdqu XMMWORD PTR [rax+0x20],xmm2
  c1bd29:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1bd2e:	movdqu XMMWORD PTR [rax],xmm0
  c1bd32:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1bd37:	mov    rcx,QWORD PTR [rsp+0x40]
  c1bd3c:	mov    BYTE PTR [rcx],0x1f
  c1bd3f:	lea    rax,[rip+0xffffffffff6aae7a]        # 2c6bc0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x83d>
  c1bd46:	mov    QWORD PTR [rcx+0x8],rax
  c1bd4a:	mov    QWORD PTR [rcx+0x10],0x47
  c1bd52:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1bd57:	mov    rsi,QWORD PTR [rsp+0x3c0]
  c1bd5f:	cmp    DWORD PTR [rsi],0xffffffff
  c1bd62:	je     c1c4e1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1641>
  c1bd68:	lea    rdi,[rsp+0x70]
  c1bd6d:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1bd72:	mov    rbx,QWORD PTR [rsp+0x70]
  c1bd77:	movups xmm0,XMMWORD PTR [rsp+0x78]
  c1bd7c:	movaps XMMWORD PTR [rsp+0x50],xmm0
  c1bd81:	mov    DWORD PTR [rsp+0x70],0x2
  c1bd89:	lea    rdi,[rsp+0x70]
  c1bd8e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1bd93:	movdqa xmm0,XMMWORD PTR [rsp+0x50]
  c1bd99:	jmp    c1c4ee <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x164e>
  c1bd9e:	add    rcx,QWORD PTR [rsi+0x60]
  c1bda2:	cmp    rcx,rax
  c1bda5:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1bdab:	mov    rdx,QWORD PTR [rbx+0x8]
  c1bdaf:	lea    rsi,[rcx+rcx*2]
  c1bdb3:	mov    eax,DWORD PTR [rdx+rsi*8]
  c1bdb6:	lea    edi,[rax-0x2]
  c1bdb9:	cmp    rax,0x2
  c1bdbd:	mov    ecx,0x3
  c1bdc2:	cmovb  edi,ecx
  c1bdc5:	lea    rdx,[rdx+rsi*8]
  c1bdc9:	lea    rsi,[rip+0xffffffffff6aa0f0]        # 2c5ec0 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x14ff>
  c1bdd0:	movsxd rdi,DWORD PTR [rsi+rdi*4]
  c1bdd4:	add    rdi,rsi
  c1bdd7:	jmp    rdi
  c1bdd9:	mov    rcx,QWORD PTR [rdx+0x8]
  c1bddd:	mov    rsi,QWORD PTR [rdx+0x10]
  c1bde1:	mov    edx,DWORD PTR [rdx+0x4]
  c1bde4:	shl    rdx,0x20
  c1bde8:	or     rdx,rax
  c1bdeb:	mov    QWORD PTR [rsp+0x220],rdx
  c1bdf3:	mov    QWORD PTR [rsp+0x228],rcx
  c1bdfb:	mov    QWORD PTR [rsp+0x230],rsi
  c1be03:	cmp    eax,0x6
  c1be06:	jne    c1ce0f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1f6f>
  c1be0c:	jmp    c1ce9d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1ffd>
  c1be11:	add    rcx,QWORD PTR [rsi+0x60]
  c1be15:	cmp    rcx,rax
  c1be18:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1be1e:	mov    rax,QWORD PTR [rsp+0x48]
  c1be23:	mov    rax,QWORD PTR [rax+0x8]
  c1be27:	lea    rcx,[rcx+rcx*2]
  c1be2b:	mov    edi,DWORD PTR [rax+rcx*8]
  c1be2e:	mov    r8d,edi
  c1be31:	sub    r8d,0x2
  c1be35:	mov    edx,0x3
  c1be3a:	cmovb  r8d,edx
  c1be3e:	lea    rsi,[rax+rcx*8]
  c1be42:	lea    rax,[rip+0xffffffffff6aa09f]        # 2c5ee8 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1527>
  c1be49:	movsxd rcx,DWORD PTR [rax+r8*4]
  c1be4d:	add    rcx,rax
  c1be50:	jmp    rcx
  c1be52:	mov    ecx,DWORD PTR [rsi+0x4]
  c1be55:	mov    rax,QWORD PTR [rsi+0x8]
  c1be59:	mov    rsi,QWORD PTR [rsi+0x10]
  c1be5d:	mov    edx,edi
  c1be5f:	jmp    c1d038 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2198>
  c1be64:	mov    r13,rdi
  c1be67:	add    r14,QWORD PTR [rcx+0x60]
  c1be6b:	mov    rax,QWORD PTR [rsp+0x48]
  c1be70:	mov    r15,QWORD PTR [rax+0x8]
  c1be74:	mov    r12,QWORD PTR [rax+0x10]
  c1be78:	lea    rdi,[rsp+0x70]
  c1be7d:	call   QWORD PTR [rip+0x2371ad]        # e53030 <_DYNAMIC+0x5870>
  c1be83:	cmp    r14,r12
  c1be86:	jae    c1c0bf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x121f>
  c1be8c:	lea    rax,[r14+r14*2]
  c1be90:	lea    r14,[r15+rax*8]
  c1be94:	mov    eax,DWORD PTR [r15+rax*8]
  c1be98:	mov    edx,eax
  c1be9a:	sub    edx,0x2
  c1be9d:	mov    ecx,0x3
  c1bea2:	cmovae ecx,edx
  c1bea5:	cmp    ecx,0x8
  c1bea8:	ja     c1dd1b <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2e7b>
  c1beae:	mov    edx,0x1e7
  c1beb3:	bt     edx,ecx
  c1beb6:	mov    r15,r13
  c1beb9:	jae    c1cbe8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1d48>
  c1bebf:	mov    rax,QWORD PTR [rsp+0x80]
  c1bec7:	mov    QWORD PTR [r14+0x10],rax
  c1becb:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1bed1:	movdqu XMMWORD PTR [r14],xmm0
  c1bed6:	mov    rax,QWORD PTR [rsp+0x50]
  c1bedb:	mov    rsi,QWORD PTR [rax+0x10]
  c1bedf:	cmp    r15,rsi
  c1bee2:	jb     c1c9bf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b1f>
  c1bee8:	lea    rdx,[rip+0x21a961]        # e36850 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xc50>
  c1beef:	mov    rdi,r15
  c1bef2:	call   QWORD PTR [rip+0x231be0]        # e4dad8 <_DYNAMIC+0x318>
  c1bef8:	add    rcx,QWORD PTR [rsi+0x60]
  c1befc:	cmp    rcx,rax
  c1beff:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1bf05:	mov    rax,QWORD PTR [rsp+0x48]
  c1bf0a:	mov    rax,QWORD PTR [rax+0x8]
  c1bf0e:	lea    rcx,[rcx+rcx*2]
  c1bf12:	mov    edi,DWORD PTR [rax+rcx*8]
  c1bf15:	mov    r8d,edi
  c1bf18:	sub    r8d,0x2
  c1bf1c:	mov    edx,0x3
  c1bf21:	cmovb  r8d,edx
  c1bf25:	lea    rsi,[rax+rcx*8]
  c1bf29:	lea    rax,[rip+0xffffffffff6a9fe0]        # 2c5f10 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x154f>
  c1bf30:	movsxd rcx,DWORD PTR [rax+r8*4]
  c1bf34:	add    rcx,rax
  c1bf37:	jmp    rcx
  c1bf39:	mov    ecx,DWORD PTR [rsi+0x4]
  c1bf3c:	mov    rax,QWORD PTR [rsi+0x8]
  c1bf40:	mov    rsi,QWORD PTR [rsi+0x10]
  c1bf44:	mov    edx,edi
  c1bf46:	jmp    c1d3b3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2513>
  c1bf4b:	add    rcx,QWORD PTR [rsi+0x60]
  c1bf4f:	cmp    rcx,rax
  c1bf52:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1bf58:	mov    rax,QWORD PTR [rsp+0x48]
  c1bf5d:	mov    rdx,QWORD PTR [rax+0x8]
  c1bf61:	lea    rcx,[rcx+rcx*2]
  c1bf65:	mov    edi,DWORD PTR [rdx+rcx*8]
  c1bf68:	mov    esi,edi
  c1bf6a:	sub    esi,0x2
  c1bf6d:	mov    eax,0x3
  c1bf72:	cmovb  esi,eax
  c1bf75:	lea    rdx,[rdx+rcx*8]
  c1bf79:	lea    rcx,[rip+0xffffffffff6a9f18]        # 2c5e98 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x14d7>
  c1bf80:	movsxd rsi,DWORD PTR [rcx+rsi*4]
  c1bf84:	add    rsi,rcx
  c1bf87:	jmp    rsi
  c1bf89:	mov    ecx,DWORD PTR [rdx+0x4]
  c1bf8c:	mov    rsi,QWORD PTR [rdx+0x8]
  c1bf90:	mov    rdx,QWORD PTR [rdx+0x10]
  c1bf94:	mov    eax,edi
  c1bf96:	jmp    c1d5f0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2750>
  c1bf9b:	mov    r13,rdi
  c1bf9e:	add    r14,QWORD PTR [rcx+0x60]
  c1bfa2:	mov    rax,QWORD PTR [rsp+0x48]
  c1bfa7:	mov    r15,QWORD PTR [rax+0x8]
  c1bfab:	mov    r12,QWORD PTR [rax+0x10]
  c1bfaf:	lea    rdi,[rsp+0x70]
  c1bfb4:	call   QWORD PTR [rip+0x233a3e]        # e4f9f8 <_DYNAMIC+0x2238>
  c1bfba:	cmp    r14,r12
  c1bfbd:	jae    c1c0bf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x121f>
  c1bfc3:	lea    rax,[r14+r14*2]
  c1bfc7:	lea    r14,[r15+rax*8]
  c1bfcb:	mov    eax,DWORD PTR [r15+rax*8]
  c1bfcf:	mov    edx,eax
  c1bfd1:	sub    edx,0x2
  c1bfd4:	mov    ecx,0x3
  c1bfd9:	cmovae ecx,edx
  c1bfdc:	cmp    ecx,0x8
  c1bfdf:	ja     c1dd3a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2e9a>
  c1bfe5:	mov    edx,0x1e7
  c1bfea:	bt     edx,ecx
  c1bfed:	mov    r15,r13
  c1bff0:	jae    c1cc15 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1d75>
  c1bff6:	mov    rax,QWORD PTR [rsp+0x80]
  c1bffe:	mov    QWORD PTR [r14+0x10],rax
  c1c002:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1c008:	movdqu XMMWORD PTR [r14],xmm0
  c1c00d:	mov    rax,QWORD PTR [rsp+0x50]
  c1c012:	mov    rsi,QWORD PTR [rax+0x10]
  c1c016:	cmp    r15,rsi
  c1c019:	jb     c1c9bf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b1f>
  c1c01f:	lea    rdx,[rip+0x21a8d2]        # e368f8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xcf8>
  c1c026:	mov    rdi,r15
  c1c029:	call   QWORD PTR [rip+0x231aa9]        # e4dad8 <_DYNAMIC+0x318>
  c1c02f:	mov    r13,rdi
  c1c032:	add    r14,QWORD PTR [rcx+0x60]
  c1c036:	mov    rax,QWORD PTR [rsp+0x48]
  c1c03b:	mov    r15,QWORD PTR [rax+0x8]
  c1c03f:	mov    r12,QWORD PTR [rax+0x10]
  c1c043:	lea    rdi,[rsp+0x70]
  c1c048:	call   QWORD PTR [rip+0x236fea]        # e53038 <_DYNAMIC+0x5878>
  c1c04e:	cmp    r14,r12
  c1c051:	jae    c1c0bf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x121f>
  c1c053:	lea    rax,[r14+r14*2]
  c1c057:	lea    r14,[r15+rax*8]
  c1c05b:	mov    eax,DWORD PTR [r15+rax*8]
  c1c05f:	mov    edx,eax
  c1c061:	sub    edx,0x2
  c1c064:	mov    ecx,0x3
  c1c069:	cmovae ecx,edx
  c1c06c:	cmp    ecx,0x8
  c1c06f:	ja     c1dd59 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2eb9>
  c1c075:	mov    edx,0x1e7
  c1c07a:	bt     edx,ecx
  c1c07d:	mov    r15,r13
  c1c080:	jae    c1cc42 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1da2>
  c1c086:	mov    rax,QWORD PTR [rsp+0x80]
  c1c08e:	mov    QWORD PTR [r14+0x10],rax
  c1c092:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1c098:	movdqu XMMWORD PTR [r14],xmm0
  c1c09d:	mov    rax,QWORD PTR [rsp+0x50]
  c1c0a2:	mov    rsi,QWORD PTR [rax+0x10]
  c1c0a6:	cmp    r15,rsi
  c1c0a9:	jb     c1c9bf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b1f>
  c1c0af:	lea    rdx,[rip+0x21a812]        # e368c8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xcc8>
  c1c0b6:	mov    rdi,r15
  c1c0b9:	call   QWORD PTR [rip+0x231a19]        # e4dad8 <_DYNAMIC+0x318>
  c1c0bf:	mov    eax,DWORD PTR [rsp+0x70]
  c1c0c3:	mov    edx,eax
  c1c0c5:	sub    edx,0x2
  c1c0c8:	mov    ecx,0x3
  c1c0cd:	cmovae ecx,edx
  c1c0d0:	cmp    ecx,0x8
  c1c0d3:	ja     c1c9f3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b53>
  c1c0d9:	mov    edx,0x1e7
  c1c0de:	bt     edx,ecx
  c1c0e1:	jae    c1c476 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x15d6>
  c1c0e7:	mov    rcx,QWORD PTR [rsp+0x40]
  c1c0ec:	mov    BYTE PTR [rcx],0x1f
  c1c0ef:	lea    rax,[rip+0xffffffffff6aa816]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1c0f6:	jmp    c1eac2 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c22>
  c1c0fb:	add    rcx,QWORD PTR [rsi+0x60]
  c1c0ff:	cmp    rcx,rax
  c1c102:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1c108:	mov    rax,QWORD PTR [rsp+0x48]
  c1c10d:	mov    rax,QWORD PTR [rax+0x8]
  c1c111:	lea    rcx,[rcx+rcx*2]
  c1c115:	mov    edi,DWORD PTR [rax+rcx*8]
  c1c118:	mov    r9d,edi
  c1c11b:	sub    r9d,0x2
  c1c11f:	mov    edx,0x3
  c1c124:	cmovb  r9d,edx
  c1c128:	lea    rsi,[rax+rcx*8]
  c1c12c:	lea    rax,[rip+0xffffffffff6a9d3d]        # 2c5e70 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x14af>
  c1c133:	movsxd rcx,DWORD PTR [rax+r9*4]
  c1c137:	add    rcx,rax
  c1c13a:	jmp    rcx
  c1c13c:	mov    ecx,DWORD PTR [rsi+0x4]
  c1c13f:	mov    rax,QWORD PTR [rsi+0x8]
  c1c143:	mov    rsi,QWORD PTR [rsi+0x10]
  c1c147:	mov    edx,edi
  c1c149:	jmp    c1d996 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2af6>
  c1c14e:	lea    rax,[rip+0xffffffffff6ac3c6]        # 2c851b <anon.0c0210c0485269faeef710294932bddb.7.llvm.14881818243032060321>
  c1c155:	mov    QWORD PTR [rsp+0x78],rax
  c1c15a:	mov    QWORD PTR [rsp+0x80],0x42
  c1c166:	mov    eax,DWORD PTR [rsp+0x71]
  c1c16a:	mov    ecx,DWORD PTR [rsp+0x74]
  c1c16e:	mov    rdx,QWORD PTR [rsp+0x40]
  c1c173:	mov    DWORD PTR [rdx+0x4],ecx
  c1c176:	mov    DWORD PTR [rdx+0x1],eax
  c1c179:	mov    rax,QWORD PTR [rsp+0x80]
  c1c181:	mov    rcx,QWORD PTR [rsp+0x88]
  c1c189:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1c192:	mov    QWORD PTR [rdx+0x10],rax
  c1c196:	mov    QWORD PTR [rdx+0x18],rcx
  c1c19a:	movdqu XMMWORD PTR [rdx+0x20],xmm0
  c1c19f:	mov    BYTE PTR [rdx],0x1f
  c1c1a2:	lea    rax,[rip+0xffffffffff6ac372]        # 2c851b <anon.0c0210c0485269faeef710294932bddb.7.llvm.14881818243032060321>
  c1c1a9:	jmp    c1c206 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1366>
  c1c1ab:	lea    rax,[rip+0xffffffffff6ac31e]        # 2c84d0 <anon.0c0210c0485269faeef710294932bddb.6.llvm.14881818243032060321>
  c1c1b2:	mov    QWORD PTR [rsp+0x78],rax
  c1c1b7:	mov    QWORD PTR [rsp+0x80],0x4b
  c1c1c3:	mov    eax,DWORD PTR [rsp+0x71]
  c1c1c7:	mov    ecx,DWORD PTR [rsp+0x74]
  c1c1cb:	mov    rdx,QWORD PTR [rsp+0x40]
  c1c1d0:	mov    DWORD PTR [rdx+0x4],ecx
  c1c1d3:	mov    DWORD PTR [rdx+0x1],eax
  c1c1d6:	mov    rax,QWORD PTR [rsp+0x80]
  c1c1de:	mov    rcx,QWORD PTR [rsp+0x88]
  c1c1e6:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1c1ef:	mov    QWORD PTR [rdx+0x10],rax
  c1c1f3:	mov    QWORD PTR [rdx+0x18],rcx
  c1c1f7:	movdqu XMMWORD PTR [rdx+0x20],xmm0
  c1c1fc:	mov    BYTE PTR [rdx],0x1f
  c1c1ff:	lea    rax,[rip+0xffffffffff6ac2ca]        # 2c84d0 <anon.0c0210c0485269faeef710294932bddb.6.llvm.14881818243032060321>
  c1c206:	mov    QWORD PTR [rdx+0x8],rax
  c1c20a:	lea    rdi,[rsp+0x1a0]
  c1c212:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1c217:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1c21c:	mov    eax,0x8
  c1c221:	mov    r15,QWORD PTR [rsp+0x408]
  c1c229:	mov    QWORD PTR [rsp+0x110],r12
  c1c231:	mov    QWORD PTR [rsp+0x118],rax
  c1c239:	mov    QWORD PTR [rsp+0x120],0x0
  c1c245:	test   bpl,bpl
  c1c248:	je     c1caa4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1c04>
  c1c24e:	imul   rax,r15,0x78
  c1c252:	mov    QWORD PTR [rsp+0x148],rax
  c1c25a:	jmp    c1c279 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x13d9>
  c1c25c:	mov    rax,QWORD PTR [rsp+0x1a8]
  c1c264:	dec    QWORD PTR [rax]
  c1c267:	je     c1c463 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x15c3>
  c1c26d:	inc    r13
  c1c270:	dec    r12
  c1c273:	je     c1ca3d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b9d>
  c1c279:	mov    rax,QWORD PTR [rsp+0x50]
  c1c27e:	mov    rsi,QWORD PTR [rax+0x10]
  c1c282:	cmp    r15,rsi
  c1c285:	jae    c1f97a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4ada>
  c1c28b:	mov    rsi,QWORD PTR [rax+0x8]
  c1c28f:	mov    rdi,QWORD PTR [rsp+0x148]
  c1c297:	lea    rdx,[rsi+rdi*1]
  c1c29b:	movzx  ecx,r13b
  c1c29f:	mov    rax,rcx
  c1c2a2:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c1c2a7:	jae    c1c2b6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1416>
  c1c2a9:	mov    rax,QWORD PTR [rdx+0x28]
  c1c2ad:	shl    ecx,0x4
  c1c2b0:	mov    rax,QWORD PTR [rax+rcx*1]
  c1c2b4:	jmp    c1c2ba <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x141a>
  c1c2b6:	add    rax,QWORD PTR [rdx+0x60]
  c1c2ba:	mov    rcx,QWORD PTR [rsp+0x48]
  c1c2bf:	cmp    rax,QWORD PTR [rcx+0x10]
  c1c2c3:	jae    c1ca11 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b71>
  c1c2c9:	mov    rdx,QWORD PTR [rcx+0x8]
  c1c2cd:	lea    rax,[rax+rax*2]
  c1c2d1:	lea    rcx,[rdx+rax*8]
  c1c2d5:	mov    eax,DWORD PTR [rdx+rax*8]
  c1c2d8:	lea    edx,[rax-0x2]
  c1c2db:	cmp    rax,0x2
  c1c2df:	mov    esi,0x3
  c1c2e4:	cmovb  edx,esi
  c1c2e7:	lea    rsi,[rip+0xffffffffff6a9c72]        # 2c5f60 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x159f>
  c1c2ee:	movsxd rdx,DWORD PTR [rsi+rdx*4]
  c1c2f2:	add    rdx,rsi
  c1c2f5:	jmp    rdx
  c1c2f7:	mov    r14d,DWORD PTR [rcx+0x4]
  c1c2fb:	mov    rbx,QWORD PTR [rcx+0x8]
  c1c2ff:	mov    rdx,QWORD PTR [rcx+0x10]
  c1c303:	mov    rcx,r14
  c1c306:	shl    rcx,0x20
  c1c30a:	or     rcx,rax
  c1c30d:	mov    QWORD PTR [rsp+0x1a0],rcx
  c1c315:	mov    QWORD PTR [rsp+0x1a8],rbx
  c1c31d:	mov    QWORD PTR [rsp+0x268],rdx
  c1c325:	mov    QWORD PTR [rsp+0x1b0],rdx
  c1c32d:	cmp    eax,0x1
  c1c330:	ja     c1e6c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3828>
  c1c336:	lea    rdi,[rsp+0x1a0]
  c1c33e:	call   QWORD PTR [rip+0x232e94]        # e4f1d8 <_DYNAMIC+0x1a18>
  c1c344:	mov    BYTE PTR [rsp+0x70],0x4
  c1c349:	cmp    rax,0x1
  c1c34d:	jne    c1c4d5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1635>
  c1c353:	mov    rbp,rdx
  c1c356:	lea    rdi,[rsp+0x70]
  c1c35b:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1c360:	test   rbp,rbp
  c1c363:	js     c1c4d5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1635>
  c1c369:	mov    r15,QWORD PTR [rsp+0x120]
  c1c371:	cmp    r15,QWORD PTR [rsp+0x110]
  c1c379:	jne    c1c389 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x14e9>
  c1c37b:	lea    rdi,[rsp+0x110]
  c1c383:	call   QWORD PTR [rip+0x23251f]        # e4e8a8 <_DYNAMIC+0x10e8>
  c1c389:	mov    rax,QWORD PTR [rsp+0x118]
  c1c391:	mov    QWORD PTR [rsp+0x68],rbp
  c1c396:	mov    QWORD PTR [rax+r15*8],rbp
  c1c39a:	inc    r15
  c1c39d:	mov    QWORD PTR [rsp+0x120],r15
  c1c3a5:	mov    eax,DWORD PTR [rsp+0x1a0]
  c1c3ac:	mov    ecx,eax
  c1c3ae:	sub    ecx,0x2
  c1c3b1:	mov    edx,0x3
  c1c3b6:	cmovb  ecx,edx
  c1c3b9:	cmp    ecx,0x8
  c1c3bc:	ja     c1c437 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1597>
  c1c3be:	mov    edx,0x1e7
  c1c3c3:	bt     edx,ecx
  c1c3c6:	mov    r15,QWORD PTR [rsp+0x408]
  c1c3ce:	jb     c1c26d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x13cd>
  c1c3d4:	cmp    ecx,0x3
  c1c3d7:	jne    c1c25c <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x13bc>
  c1c3dd:	test   eax,eax
  c1c3df:	je     c1c26d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x13cd>
  c1c3e5:	mov    rax,QWORD PTR [rsp+0x1a8]
  c1c3ed:	dec    QWORD PTR [rax]
  c1c3f0:	jne    c1c26d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x13cd>
  c1c3f6:	lea    rdi,[rsp+0x1a8]
  c1c3fe:	call   QWORD PTR [rip+0x231604]        # e4da08 <_DYNAMIC+0x248>
  c1c404:	jmp    c1c26d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x13cd>
  c1c409:	test   al,0x1
  c1c40b:	je     c1c2f7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1457>
  c1c411:	mov    rbx,QWORD PTR [rcx+0x8]
  c1c415:	inc    QWORD PTR [rbx]
  c1c418:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1c41e:	mov    QWORD PTR [rsp+0x1a0],0x1
  c1c42a:	mov    QWORD PTR [rsp+0x1a8],rbx
  c1c432:	jmp    c1c336 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1496>
  c1c437:	mov    rax,QWORD PTR [rsp+0x1a8]
  c1c43f:	dec    QWORD PTR [rax]
  c1c442:	mov    r15,QWORD PTR [rsp+0x408]
  c1c44a:	jne    c1c26d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x13cd>
  c1c450:	lea    rdi,[rsp+0x1a8]
  c1c458:	call   QWORD PTR [rip+0x2315ba]        # e4da18 <_DYNAMIC+0x258>
  c1c45e:	jmp    c1c26d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x13cd>
  c1c463:	lea    rdi,[rsp+0x1a8]
  c1c46b:	call   QWORD PTR [rip+0x23159f]        # e4da10 <_DYNAMIC+0x250>
  c1c471:	jmp    c1c26d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x13cd>
  c1c476:	cmp    ecx,0x3
  c1c479:	jne    c1c9d5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b35>
  c1c47f:	test   eax,eax
  c1c481:	je     c1c0e7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1247>
  c1c487:	mov    rax,QWORD PTR [rsp+0x78]
  c1c48c:	dec    QWORD PTR [rax]
  c1c48f:	jne    c1c0e7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1247>
  c1c495:	lea    rdi,[rsp+0x78]
  c1c49a:	call   QWORD PTR [rip+0x231568]        # e4da08 <_DYNAMIC+0x248>
  c1c4a0:	jmp    c1c0e7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1247>
  c1c4a5:	add    rcx,QWORD PTR [rsi+0x60]
  c1c4a9:	cmp    rcx,rax
  c1c4ac:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1c4b2:	mov    rax,QWORD PTR [r10+0x8]
  c1c4b6:	lea    rcx,[rcx+rcx*2]
  c1c4ba:	lea    rsi,[rax+rcx*8]
  c1c4be:	lea    rdi,[rsp+0x70]
  c1c4c3:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1c4c8:	mov    rbx,QWORD PTR [rsp+0x70]
  c1c4cd:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1c4d3:	jmp    c1c4ee <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x164e>
  c1c4d5:	mov    al,0x4
  c1c4d7:	mov    rdx,QWORD PTR [rsp+0x68]
  c1c4dc:	jmp    c1e6d1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3831>
  c1c4e1:	mov    DWORD PTR [rsp+0x70],0x2
  c1c4e9:	mov    rbx,QWORD PTR [rsp+0x70]
  c1c4ee:	mov    rax,QWORD PTR [rsp+0x40]
  c1c4f3:	mov    BYTE PTR [rax],0x7
  c1c4f6:	mov    QWORD PTR [rax+0x8],rbx
  c1c4fa:	movdqu XMMWORD PTR [rax+0x10],xmm0
  c1c4ff:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1c504:	add    r13,QWORD PTR [rcx+0x60]
  c1c508:	cmp    r13,rdx
  c1c50b:	jae    c1c619 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1779>
  c1c511:	mov    QWORD PTR [rsp+0x268],r10
  c1c519:	mov    r15,QWORD PTR [r9+0x8]
  c1c51d:	test   r12b,r12b
  c1c520:	je     c1cc6f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1dcf>
  c1c526:	movzx  ebx,bpl
  c1c52a:	sub    rbx,rax
  c1c52d:	jae    c1cd77 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1ed7>
  c1c533:	mov    rbx,r8
  c1c536:	mov    DWORD PTR [rsp+0x68],0x0
  c1c53e:	movzx  r8d,bpl
  c1c542:	movzx  r9d,r12b
  c1c546:	lea    rdi,[rsp+0x70]
  c1c54b:	mov    rsi,r15
  c1c54e:	call   c247e0 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs4load>
  c1c553:	mov    eax,DWORD PTR [rsp+0x70]
  c1c557:	cmp    eax,0xffffffff
  c1c55a:	je     c1e642 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37a2>
  c1c560:	mov    ecx,DWORD PTR [rsp+0xa4]
  c1c567:	mov    DWORD PTR [rsp+0x1d0],ecx
  c1c56e:	movdqu xmm0,XMMWORD PTR [rsp+0x74]
  c1c574:	movdqu xmm1,XMMWORD PTR [rsp+0x84]
  c1c57d:	movdqu xmm2,XMMWORD PTR [rsp+0x94]
  c1c586:	movdqa XMMWORD PTR [rsp+0x1c0],xmm2
  c1c58f:	movdqa XMMWORD PTR [rsp+0x1b0],xmm1
  c1c598:	movdqa XMMWORD PTR [rsp+0x1a0],xmm0
  c1c5a1:	movups xmm3,XMMWORD PTR [rsp+0xa8]
  c1c5a9:	movups XMMWORD PTR [rsp+0x188],xmm3
  c1c5b1:	mov    rdx,QWORD PTR [rsp+0xb8]
  c1c5b9:	mov    QWORD PTR [rsp+0x198],rdx
  c1c5c1:	movdqu XMMWORD PTR [rsp+0x154],xmm0
  c1c5ca:	movdqu XMMWORD PTR [rsp+0x164],xmm1
  c1c5d3:	movdqu XMMWORD PTR [rsp+0x174],xmm2
  c1c5dc:	mov    DWORD PTR [rsp+0x184],ecx
  c1c5e3:	mov    DWORD PTR [rsp+0x150],eax
  c1c5ea:	mov    al,0x1
  c1c5ec:	mov    DWORD PTR [rsp+0x68],eax
  c1c5f0:	lea    rdi,[rsp+0x150]
  c1c5f8:	call   c25080 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs8as_slice>
  c1c5fd:	mov    rcx,rax
  c1c600:	mov    al,0x1
  c1c602:	mov    DWORD PTR [rsp+0x68],eax
  c1c606:	mov    r8,rbx
  c1c609:	mov    r11,QWORD PTR [rsp+0x3d8]
  c1c611:	mov    rbp,rdx
  c1c614:	jmp    c1e1c4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3324>
  c1c619:	mov    rcx,QWORD PTR [rsp+0x40]
  c1c61e:	mov    BYTE PTR [rcx],0x1f
  c1c621:	lea    rax,[rip+0xffffffffff6aa603]        # 2c6c2b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x8a8>
  c1c628:	mov    QWORD PTR [rcx+0x8],rax
  c1c62c:	mov    QWORD PTR [rcx+0x10],0x4d
  c1c634:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1c639:	mov    eax,0x8
  c1c63e:	mov    QWORD PTR [rsp+0x150],r15
  c1c646:	mov    QWORD PTR [rsp+0x158],rax
  c1c64e:	mov    QWORD PTR [rsp+0x160],0x0
  c1c65a:	test   bpl,bpl
  c1c65d:	je     c1c8c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1a28>
  c1c663:	imul   rax,QWORD PTR [rsp+0x408],0x78
  c1c66c:	mov    QWORD PTR [rsp+0x148],rax
  c1c674:	jmp    c1c6c4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1824>
  c1c676:	cs nop WORD PTR [rax+rax*1+0x0]
  c1c680:	mov    rax,QWORD PTR [rsp+0x158]
  c1c688:	lea    rcx,[rbx+rbx*2]
  c1c68c:	mov    rdx,QWORD PTR [rsp+0x2d8]
  c1c694:	mov    QWORD PTR [rax+rcx*8+0x10],rdx
  c1c699:	movdqu xmm0,XMMWORD PTR [rsp+0x2c8]
  c1c6a2:	movdqu XMMWORD PTR [rax+rcx*8],xmm0
  c1c6a7:	inc    rbx
  c1c6aa:	mov    QWORD PTR [rsp+0x160],rbx
  c1c6b2:	inc    r13
  c1c6b5:	dec    r15
  c1c6b8:	mov    rdi,r12
  c1c6bb:	mov    r8,r14
  c1c6be:	je     c1c8c0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1a20>
  c1c6c4:	mov    rax,QWORD PTR [rsp+0x50]
  c1c6c9:	mov    rsi,QWORD PTR [rax+0x10]
  c1c6cd:	cmp    QWORD PTR [rsp+0x408],rsi
  c1c6d5:	jae    c1f960 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4ac0>
  c1c6db:	mov    rsi,QWORD PTR [rax+0x8]
  c1c6df:	mov    r9,QWORD PTR [rsp+0x148]
  c1c6e7:	lea    rdx,[rsi+r9*1]
  c1c6eb:	movzx  ecx,r13b
  c1c6ef:	mov    rax,rcx
  c1c6f2:	sub    rax,QWORD PTR [rsi+r9*1+0x30]
  c1c6f7:	mov    rsi,QWORD PTR [rsp+0x48]
  c1c6fc:	jae    c1c70b <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x186b>
  c1c6fe:	mov    rax,QWORD PTR [rdx+0x28]
  c1c702:	shl    ecx,0x4
  c1c705:	mov    rax,QWORD PTR [rax+rcx*1]
  c1c709:	jmp    c1c70f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x186f>
  c1c70b:	add    rax,QWORD PTR [rdx+0x60]
  c1c70f:	cmp    rax,QWORD PTR [rsi+0x10]
  c1c713:	jae    c1c7f3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1953>
  c1c719:	mov    rdx,QWORD PTR [rsi+0x8]
  c1c71d:	lea    rax,[rax+rax*2]
  c1c721:	lea    rcx,[rdx+rax*8]
  c1c725:	mov    eax,DWORD PTR [rdx+rax*8]
  c1c728:	mov    edx,eax
  c1c72a:	sub    edx,0x2
  c1c72d:	mov    esi,0x3
  c1c732:	cmovb  edx,esi
  c1c735:	lea    rsi,[rip+0xffffffffff6a97fc]        # 2c5f38 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1577>
  c1c73c:	movsxd rdx,DWORD PTR [rsi+rdx*4]
  c1c740:	add    rdx,rsi
  c1c743:	jmp    rdx
  c1c745:	mov    edi,DWORD PTR [rcx+0x4]
  c1c748:	mov    rbp,QWORD PTR [rcx+0x8]
  c1c74c:	mov    r8,QWORD PTR [rcx+0x10]
  c1c750:	jmp    c1c7a0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1900>
  c1c752:	mov    rbp,QWORD PTR [rcx+0x8]
  c1c756:	mov    eax,0xb
  c1c75b:	jmp    c1c78c <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x18ec>
  c1c75d:	mov    eax,0x2
  c1c762:	jmp    c1c7a0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1900>
  c1c764:	mov    eax,0x3
  c1c769:	jmp    c1c7a0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1900>
  c1c76b:	test   al,0x1
  c1c76d:	je     c1c745 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x18a5>
  c1c76f:	mov    rbp,QWORD PTR [rcx+0x8]
  c1c773:	mov    eax,0x1
  c1c778:	inc    QWORD PTR [rbp+0x0]
  c1c77c:	jne    c1c7a0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1900>
  c1c77e:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1c783:	mov    rbp,QWORD PTR [rcx+0x8]
  c1c787:	mov    eax,0x6
  c1c78c:	inc    QWORD PTR [rbp+0x0]
  c1c790:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1c796:	cs nop WORD PTR [rax+rax*1+0x0]
  c1c7a0:	mov    eax,eax
  c1c7a2:	mov    r12,rdi
  c1c7a5:	mov    rcx,rdi
  c1c7a8:	shl    rcx,0x20
  c1c7ac:	or     rcx,rax
  c1c7af:	mov    QWORD PTR [rsp+0x2c8],rcx
  c1c7b7:	mov    QWORD PTR [rsp+0x2d0],rbp
  c1c7bf:	mov    r14,r8
  c1c7c2:	mov    QWORD PTR [rsp+0x2d8],r8
  c1c7ca:	mov    rbx,QWORD PTR [rsp+0x160]
  c1c7d2:	cmp    rbx,QWORD PTR [rsp+0x150]
  c1c7da:	jne    c1c680 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x17e0>
  c1c7e0:	lea    rdi,[rsp+0x150]
  c1c7e8:	call   QWORD PTR [rip+0x232dda]        # e4f5c8 <_DYNAMIC+0x1e08>
  c1c7ee:	jmp    c1c680 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x17e0>
  c1c7f3:	mov    rcx,QWORD PTR [rsp+0x40]
  c1c7f8:	mov    BYTE PTR [rcx],0x1f
  c1c7fb:	lea    rax,[rip+0xffffffffff6a9916]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1c802:	mov    QWORD PTR [rcx+0x8],rax
  c1c806:	mov    QWORD PTR [rcx+0x10],0x4f
  c1c80e:	mov    QWORD PTR [rcx+0x18],r8
  c1c812:	lea    rdi,[rsp+0x150]
  c1c81a:	call   c0a040 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueEECsbxgXiyEKxkX_6bsl_vm>
  c1c81f:	mov    rax,QWORD PTR [rsp+0x110]
  c1c827:	dec    QWORD PTR [rax]
  c1c82a:	jne    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1c830:	lea    rdi,[rsp+0x110]
  c1c838:	call   QWORD PTR [rip+0x2311f2]        # e4da30 <_DYNAMIC+0x270>
  c1c83e:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1c843:	mov    QWORD PTR [rsp+0x148],rdx
  c1c84b:	mov    ebx,DWORD PTR [r12+rax*8+0x4]
  c1c850:	movzx  ebp,WORD PTR [r12+rax*8+0x2]
  c1c856:	lea    rdi,[rsp+0x70]
  c1c85b:	mov    esi,ebx
  c1c85d:	mov    rdx,r15
  c1c860:	mov    rcx,QWORD PTR [rsp+0x3e8]
  c1c868:	mov    r8,QWORD PTR [rsp+0x50]
  c1c86d:	mov    r9,QWORD PTR [rsp+0x48]
  c1c872:	call   c400e0 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7modules19ensure_module_ready>
  c1c877:	movzx  ecx,BYTE PTR [rsp+0x70]
  c1c87c:	movzx  eax,BYTE PTR [rsp+0x71]
  c1c881:	cmp    cl,0xff
  c1c884:	je     c1cc83 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1de3>
  c1c88a:	movdqu xmm0,XMMWORD PTR [rsp+0x72]
  c1c890:	movdqu xmm1,XMMWORD PTR [rsp+0x82]
  c1c899:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1c8a2:	mov    rdx,QWORD PTR [rsp+0x40]
  c1c8a7:	movdqu XMMWORD PTR [rdx+0x20],xmm2
  c1c8ac:	movdqu XMMWORD PTR [rdx+0x12],xmm1
  c1c8b1:	movdqu XMMWORD PTR [rdx+0x2],xmm0
  c1c8b6:	mov    BYTE PTR [rdx],cl
  c1c8b8:	mov    BYTE PTR [rdx+0x1],al
  c1c8bb:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1c8c0:	mov    rbx,QWORD PTR [rsp+0x110]
  c1c8c8:	mov    rax,QWORD PTR [rsp+0x160]
  c1c8d0:	mov    QWORD PTR [rsp+0x80],rax
  c1c8d8:	mov    rax,QWORD PTR [rsp+0x150]
  c1c8e0:	mov    QWORD PTR [rsp+0x70],rax
  c1c8e5:	mov    rax,QWORD PTR [rsp+0x158]
  c1c8ed:	mov    QWORD PTR [rsp+0x78],rax
  c1c8f2:	lea    rdi,[rsp+0x1a0]
  c1c8fa:	lea    rdx,[rsp+0x70]
  c1c8ff:	mov    rsi,rbx
  c1c902:	call   QWORD PTR [rip+0x2356f8]        # e52000 <_DYNAMIC+0x4840>
  c1c908:	mov    rax,QWORD PTR [rsp+0x50]
  c1c90d:	mov    rsi,QWORD PTR [rax+0x10]
  c1c911:	mov    r15,QWORD PTR [rsp+0x408]
  c1c919:	cmp    r15,rsi
  c1c91c:	jae    c1faaa <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4c0a>
  c1c922:	mov    rsi,QWORD PTR [rax+0x8]
  c1c926:	imul   rbx,r15,0x78
  c1c92a:	lea    rdx,[rsi+rbx*1]
  c1c92e:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1c936:	mov    rax,rcx
  c1c939:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1c93e:	jae    c1c94d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1aad>
  c1c940:	mov    rax,QWORD PTR [rdx+0x28]
  c1c944:	shl    ecx,0x4
  c1c947:	mov    rax,QWORD PTR [rax+rcx*1]
  c1c94b:	jmp    c1c951 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1ab1>
  c1c94d:	add    rax,QWORD PTR [rdx+0x60]
  c1c951:	mov    rsi,QWORD PTR [rsp+0x48]
  c1c956:	mov    rcx,QWORD PTR [rsi+0x8]
  c1c95a:	mov    rdx,QWORD PTR [rsp+0x1b0]
  c1c962:	mov    QWORD PTR [rsp+0x80],rdx
  c1c96a:	movdqu xmm0,XMMWORD PTR [rsp+0x1a0]
  c1c973:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c1c979:	cmp    rax,QWORD PTR [rsi+0x10]
  c1c97d:	jae    c1f07a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x41da>
  c1c983:	lea    rax,[rax+rax*2]
  c1c987:	lea    r14,[rcx+rax*8]
  c1c98b:	mov    rdi,r14
  c1c98e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1c993:	mov    rax,QWORD PTR [rsp+0x1b0]
  c1c99b:	mov    QWORD PTR [r14+0x10],rax
  c1c99f:	movdqu xmm0,XMMWORD PTR [rsp+0x1a0]
  c1c9a8:	movdqu XMMWORD PTR [r14],xmm0
  c1c9ad:	mov    rax,QWORD PTR [rsp+0x50]
  c1c9b2:	mov    rsi,QWORD PTR [rax+0x10]
  c1c9b6:	cmp    r15,rsi
  c1c9b9:	jae    c1fb2b <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4c8b>
  c1c9bf:	mov    rax,QWORD PTR [rax+0x8]
  c1c9c3:	inc    QWORD PTR [rax+rbx*1+0x58]
  c1c9c8:	mov    rax,QWORD PTR [rsp+0x40]
  c1c9cd:	mov    BYTE PTR [rax],0xff
  c1c9d0:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1c9d5:	mov    rax,QWORD PTR [rsp+0x78]
  c1c9da:	dec    QWORD PTR [rax]
  c1c9dd:	jne    c1c0e7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1247>
  c1c9e3:	lea    rdi,[rsp+0x78]
  c1c9e8:	call   QWORD PTR [rip+0x231022]        # e4da10 <_DYNAMIC+0x250>
  c1c9ee:	jmp    c1c0e7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1247>
  c1c9f3:	mov    rax,QWORD PTR [rsp+0x78]
  c1c9f8:	dec    QWORD PTR [rax]
  c1c9fb:	jne    c1c0e7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1247>
  c1ca01:	lea    rdi,[rsp+0x78]
  c1ca06:	call   QWORD PTR [rip+0x23100c]        # e4da18 <_DYNAMIC+0x258>
  c1ca0c:	jmp    c1c0e7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1247>
  c1ca11:	mov    rcx,QWORD PTR [rsp+0x40]
  c1ca16:	mov    BYTE PTR [rcx],0x1f
  c1ca19:	lea    rax,[rip+0xffffffffff6a96f8]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1ca20:	mov    QWORD PTR [rcx+0x8],rax
  c1ca24:	mov    QWORD PTR [rcx+0x10],0x4f
  c1ca2c:	mov    rax,QWORD PTR [rsp+0x268]
  c1ca34:	mov    QWORD PTR [rcx+0x18],rax
  c1ca38:	jmp    c1e71a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x387a>
  c1ca3d:	mov    rax,QWORD PTR [rsp+0x120]
  c1ca45:	test   rax,rax
  c1ca48:	je     c1caa4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1c04>
  c1ca4a:	mov    rcx,QWORD PTR [rsp+0x118]
  c1ca52:	dec    rax
  c1ca55:	mov    rdx,QWORD PTR [rcx]
  c1ca58:	add    rcx,0x8
  c1ca5c:	mov    QWORD PTR [rsp+0x80],0x0
  c1ca68:	mov    QWORD PTR [rsp+0x88],rdx
  c1ca70:	mov    QWORD PTR [rsp+0x70],rcx
  c1ca75:	mov    QWORD PTR [rsp+0x78],rax
  c1ca7a:	lea    rdi,[rsp+0x1a0]
  c1ca82:	lea    rsi,[rsp+0x70]
  c1ca87:	call   c34880 <_RNvXs_NtNtCscdodAO9FK5_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueEINtB4_18SpecFromIterNestedB12_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3map3MapINtNtNtB2k_3ops5range5RangejENCNvCsbxgXiyEKxkX_6bsl_vm18build_nested_array0EE9from_iterB3w_>
  c1ca8c:	lea    rdi,[rsp+0x150]
  c1ca94:	lea    rsi,[rsp+0x1a0]
  c1ca9c:	call   QWORD PTR [rip+0x232b2e]        # e4f5d0 <_DYNAMIC+0x1e10>
  c1caa2:	jmp    c1cad5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1c35>
  c1caa4:	mov    QWORD PTR [rsp+0x70],0x0
  c1caad:	mov    QWORD PTR [rsp+0x78],0x8
  c1cab6:	mov    QWORD PTR [rsp+0x80],0x0
  c1cac2:	lea    rdi,[rsp+0x150]
  c1caca:	lea    rsi,[rsp+0x70]
  c1cacf:	call   QWORD PTR [rip+0x232afb]        # e4f5d0 <_DYNAMIC+0x1e10>
  c1cad5:	mov    rax,QWORD PTR [rsp+0x50]
  c1cada:	mov    rsi,QWORD PTR [rax+0x10]
  c1cade:	mov    r15,QWORD PTR [rsp+0x408]
  c1cae6:	cmp    r15,rsi
  c1cae9:	jae    c1fa6e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4bce>
  c1caef:	mov    rsi,QWORD PTR [rax+0x8]
  c1caf3:	imul   rbx,r15,0x78
  c1caf7:	lea    rdx,[rsi+rbx*1]
  c1cafb:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1cb03:	mov    rax,rcx
  c1cb06:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1cb0b:	jae    c1cb1a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1c7a>
  c1cb0d:	mov    rax,QWORD PTR [rdx+0x28]
  c1cb11:	shl    ecx,0x4
  c1cb14:	mov    rax,QWORD PTR [rax+rcx*1]
  c1cb18:	jmp    c1cb1e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1c7e>
  c1cb1a:	add    rax,QWORD PTR [rdx+0x60]
  c1cb1e:	mov    rsi,QWORD PTR [rsp+0x48]
  c1cb23:	mov    rcx,QWORD PTR [rsi+0x8]
  c1cb27:	mov    rdx,QWORD PTR [rsp+0x160]
  c1cb2f:	mov    QWORD PTR [rsp+0x80],rdx
  c1cb37:	movdqu xmm0,XMMWORD PTR [rsp+0x150]
  c1cb40:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c1cb46:	cmp    rax,QWORD PTR [rsi+0x10]
  c1cb4a:	jae    c1cbbe <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1d1e>
  c1cb4c:	lea    rax,[rax+rax*2]
  c1cb50:	lea    r14,[rcx+rax*8]
  c1cb54:	mov    rdi,r14
  c1cb57:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1cb5c:	mov    rax,QWORD PTR [rsp+0x160]
  c1cb64:	mov    QWORD PTR [r14+0x10],rax
  c1cb68:	movdqu xmm0,XMMWORD PTR [rsp+0x150]
  c1cb71:	movdqu XMMWORD PTR [r14],xmm0
  c1cb76:	mov    rax,QWORD PTR [rsp+0x50]
  c1cb7b:	mov    rsi,QWORD PTR [rax+0x10]
  c1cb7f:	cmp    r15,rsi
  c1cb82:	jae    c1fabf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4c1f>
  c1cb88:	mov    rax,QWORD PTR [rax+0x8]
  c1cb8c:	inc    QWORD PTR [rax+rbx*1+0x58]
  c1cb91:	mov    rsi,QWORD PTR [rsp+0x110]
  c1cb99:	test   rsi,rsi
  c1cb9c:	je     c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1cba2:	mov    rdi,QWORD PTR [rsp+0x118]
  c1cbaa:	shl    rsi,0x3
  c1cbae:	mov    edx,0x8
  c1cbb3:	call   QWORD PTR [rip+0x230e47]        # e4da00 <_DYNAMIC+0x240>
  c1cbb9:	jmp    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1cbbe:	lea    rdi,[rsp+0x70]
  c1cbc3:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1cbc8:	mov    rcx,QWORD PTR [rsp+0x40]
  c1cbcd:	mov    BYTE PTR [rcx],0x1f
  c1cbd0:	lea    rax,[rip+0xffffffffff6a9d35]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1cbd7:	mov    QWORD PTR [rcx+0x8],rax
  c1cbdb:	mov    QWORD PTR [rcx+0x10],0x4f
  c1cbe3:	jmp    c1e71a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x387a>
  c1cbe8:	cmp    ecx,0x3
  c1cbeb:	jne    c1d32a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x248a>
  c1cbf1:	test   eax,eax
  c1cbf3:	je     c1bebf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x101f>
  c1cbf9:	mov    rax,QWORD PTR [r14+0x8]
  c1cbfd:	dec    QWORD PTR [rax]
  c1cc00:	jne    c1bebf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x101f>
  c1cc06:	lea    rdi,[r14+0x8]
  c1cc0a:	call   QWORD PTR [rip+0x230df8]        # e4da08 <_DYNAMIC+0x248>
  c1cc10:	jmp    c1bebf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x101f>
  c1cc15:	cmp    ecx,0x3
  c1cc18:	jne    c1d385 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x24e5>
  c1cc1e:	test   eax,eax
  c1cc20:	je     c1bff6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1156>
  c1cc26:	mov    rax,QWORD PTR [r14+0x8]
  c1cc2a:	dec    QWORD PTR [rax]
  c1cc2d:	jne    c1bff6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1156>
  c1cc33:	lea    rdi,[r14+0x8]
  c1cc37:	call   QWORD PTR [rip+0x230dcb]        # e4da08 <_DYNAMIC+0x248>
  c1cc3d:	jmp    c1bff6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1156>
  c1cc42:	cmp    ecx,0x3
  c1cc45:	jne    c1d5c2 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2722>
  c1cc4b:	test   eax,eax
  c1cc4d:	je     c1c086 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x11e6>
  c1cc53:	mov    rax,QWORD PTR [r14+0x8]
  c1cc57:	dec    QWORD PTR [rax]
  c1cc5a:	jne    c1c086 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x11e6>
  c1cc60:	lea    rdi,[r14+0x8]
  c1cc64:	call   QWORD PTR [rip+0x230d9e]        # e4da08 <_DYNAMIC+0x248>
  c1cc6a:	jmp    c1c086 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x11e6>
  c1cc6f:	mov    ecx,0x8
  c1cc74:	xor    ebp,ebp
  c1cc76:	mov    DWORD PTR [rsp+0x68],0x0
  c1cc7e:	jmp    c1e1c4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3324>
  c1cc83:	mov    QWORD PTR [rsp+0x68],r12
  c1cc88:	mov    DWORD PTR [rsp+0x268],ebx
  c1cc8f:	mov    QWORD PTR [rsp+0x260],rbp
  c1cc97:	test   al,0x1
  c1cc99:	jne    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1cc9f:	mov    rax,QWORD PTR [rsp+0x418]
  c1cca7:	cmp    r14,QWORD PTR [rax+0x40]
  c1ccab:	jae    c1e973 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3ad3>
  c1ccb1:	mov    rax,QWORD PTR [rax+0x38]
  c1ccb5:	lea    rcx,[r14+r14*2]
  c1ccb9:	mov    rsi,QWORD PTR [rax+rcx*8+0x8]
  c1ccbe:	mov    rdx,QWORD PTR [rax+rcx*8+0x10]
  c1ccc3:	lea    rax,[rdx*4+0x0]
  c1cccb:	mov    QWORD PTR [rsp+0x298],rax
  c1ccd3:	test   rdx,rdx
  c1ccd6:	mov    rbp,QWORD PTR [rsp+0x68]
  c1ccdb:	mov    rcx,QWORD PTR [rsp+0x148]
  c1cce3:	mov    r12,rdx
  c1cce6:	mov    rbx,rsi
  c1cce9:	je     c1ed71 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3ed1>
  c1ccef:	xor    r14d,r14d
  c1ccf2:	jmp    c1cd09 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1e69>
  c1ccf4:	add    r14,0x4
  c1ccf8:	lea    rax,[rdx*4+0x0]
  c1cd00:	cmp    rax,r14
  c1cd03:	je     c1ed71 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3ed1>
  c1cd09:	cmp    BYTE PTR [rsi+r14*1],0x4
  c1cd0e:	jne    c1ccf4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1e54>
  c1cd10:	movzx  eax,WORD PTR [rsi+r14*1+0x2]
  c1cd16:	cmp    rcx,rax
  c1cd19:	jbe    c1f165 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x42c5>
  c1cd1f:	cmp    BYTE PTR [rbp+rax*8+0x0],0x0
  c1cd24:	je     c1f165 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x42c5>
  c1cd2a:	mov    esi,DWORD PTR [rbp+rax*8+0x4]
  c1cd2e:	lea    rdi,[rsp+0x70]
  c1cd33:	mov    rdx,r15
  c1cd36:	mov    rcx,QWORD PTR [rsp+0x3e8]
  c1cd3e:	mov    r8,QWORD PTR [rsp+0x50]
  c1cd43:	mov    r9,QWORD PTR [rsp+0x48]
  c1cd48:	call   c400e0 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7modules19ensure_module_ready>
  c1cd4d:	movzx  ecx,BYTE PTR [rsp+0x70]
  c1cd52:	movzx  eax,BYTE PTR [rsp+0x71]
  c1cd57:	cmp    cl,0xff
  c1cd5a:	jne    c1c88a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x19ea>
  c1cd60:	cmp    al,0x1
  c1cd62:	mov    rcx,QWORD PTR [rsp+0x148]
  c1cd6a:	mov    rdx,r12
  c1cd6d:	mov    rsi,rbx
  c1cd70:	jne    c1ccf4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1e54>
  c1cd72:	jmp    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1cd77:	add    rbx,QWORD PTR [rcx+0x60]
  c1cd7b:	movzx  esi,r12b
  c1cd7f:	mov    rax,rbx
  c1cd82:	add    rax,rsi
  c1cd85:	setb   cl
  c1cd88:	not    cl
  c1cd8a:	cmp    rax,rdx
  c1cd8d:	setbe  al
  c1cd90:	test   cl,al
  c1cd92:	jne    c1e167 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x32c7>
  c1cd98:	mov    rcx,QWORD PTR [rsp+0x40]
  c1cd9d:	mov    BYTE PTR [rcx],0x1f
  c1cda0:	lea    rax,[rip+0xffffffffff6a9ed1]        # 2c6c78 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x8f5>
  c1cda7:	mov    QWORD PTR [rcx+0x8],rax
  c1cdab:	mov    QWORD PTR [rcx+0x10],0x53
  c1cdb3:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1cdb8:	mov    rax,QWORD PTR [rdx+0x8]
  c1cdbc:	mov    ecx,0xb
  c1cdc1:	jmp    c1cdf2 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1f52>
  c1cdc3:	mov    ecx,0x2
  c1cdc8:	jmp    c1cdfb <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1f5b>
  c1cdca:	mov    rax,QWORD PTR [rsi+0x8]
  c1cdce:	inc    QWORD PTR [rax]
  c1cdd1:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1cdd7:	mov    edx,0xb
  c1cddc:	jmp    c1d038 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2198>
  c1cde1:	test   al,0x1
  c1cde3:	je     c1bdd9 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xf39>
  c1cde9:	mov    rax,QWORD PTR [rdx+0x8]
  c1cded:	mov    ecx,0x1
  c1cdf2:	inc    QWORD PTR [rax]
  c1cdf5:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1cdfb:	mov    edx,ecx
  c1cdfd:	mov    QWORD PTR [rsp+0x220],rdx
  c1ce05:	mov    QWORD PTR [rsp+0x228],rax
  c1ce0d:	mov    eax,ecx
  c1ce0f:	lea    rcx,[rip+0xffffffffff6a9e03]        # 2c6c19 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x896>
  c1ce16:	lea    rdx,[rip+0xffffffffff6a9dea]        # 2c6c07 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x884>
  c1ce1d:	test   bpl,0x1
  c1ce21:	cmovne rdx,rcx
  c1ce25:	mov    rsi,QWORD PTR [rsp+0x40]
  c1ce2a:	mov    BYTE PTR [rsi],0x1
  c1ce2d:	lea    rcx,[rip+0xffffffffff6a97b4]        # 2c65e8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x265>
  c1ce34:	mov    QWORD PTR [rsi+0x8],rcx
  c1ce38:	mov    QWORD PTR [rsi+0x10],0xc
  c1ce40:	mov    QWORD PTR [rsi+0x18],rdx
  c1ce44:	mov    QWORD PTR [rsi+0x20],0x12
  c1ce4c:	jmp    c1e00a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x316a>
  c1ce51:	mov    edx,0x2
  c1ce56:	jmp    c1d038 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2198>
  c1ce5b:	test   dil,0x1
  c1ce5f:	je     c1be52 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xfb2>
  c1ce65:	mov    rax,QWORD PTR [rsi+0x8]
  c1ce69:	inc    QWORD PTR [rax]
  c1ce6c:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1ce72:	mov    edx,0x1
  c1ce77:	jmp    c1d038 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2198>
  c1ce7c:	mov    rcx,QWORD PTR [rdx+0x8]
  c1ce80:	inc    QWORD PTR [rcx]
  c1ce83:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1ce89:	mov    QWORD PTR [rsp+0x220],0x6
  c1ce95:	mov    QWORD PTR [rsp+0x228],rcx
  c1ce9d:	mov    r12,r8
  c1cea0:	mov    QWORD PTR [rsp+0x70],rcx
  c1cea5:	lea    rdi,[rsp+0x110]
  c1cead:	lea    rsi,[rsp+0x70]
  c1ceb2:	call   c25720 <_RNvXsC_NtCscdodAO9FK5_5alloc6stringNtNtCs54fMbAdz0qV_6bsl_rt6string9BslStringNtB5_12SpecToString14spec_to_stringCsbxgXiyEKxkX_6bsl_vm>
  c1ceb7:	mov    rax,QWORD PTR [rsp+0x70]
  c1cebc:	dec    QWORD PTR [rax]
  c1cebf:	jne    c1cecc <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x202c>
  c1cec1:	lea    rdi,[rsp+0x70]
  c1cec6:	call   QWORD PTR [rip+0x230b44]        # e4da10 <_DYNAMIC+0x250>
  c1cecc:	mov    rsi,QWORD PTR [r14+0x10]
  c1ced0:	cmp    QWORD PTR [rsp+0x408],rsi
  c1ced8:	jae    c1fb11 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4c71>
  c1cede:	movdqu xmm0,XMMWORD PTR [rbx+0x8]
  c1cee3:	mov    rax,QWORD PTR [rsp+0x418]
  c1ceeb:	mov    r9,QWORD PTR [rax+0x98]
  c1cef2:	mov    rax,QWORD PTR [rax+0xa0]
  c1cef9:	mov    rbx,QWORD PTR [rsp+0x118]
  c1cf01:	mov    rdx,QWORD PTR [rsp+0x120]
  c1cf09:	mov    rcx,QWORD PTR [r14+0x8]
  c1cf0d:	add    rcx,r15
  c1cf10:	mov    rsi,QWORD PTR [rsp+0x3e0]
  c1cf18:	mov    QWORD PTR [rsp+0x38],rsi
  c1cf1d:	mov    rsi,QWORD PTR [rsp+0x3d0]
  c1cf25:	mov    QWORD PTR [rsp+0x30],rsi
  c1cf2a:	mov    rsi,QWORD PTR [rsp+0x3c8]
  c1cf32:	mov    QWORD PTR [rsp+0x28],rsi
  c1cf37:	mov    QWORD PTR [rsp+0x20],rcx
  c1cf3c:	movdqu XMMWORD PTR [rsp+0x10],xmm0
  c1cf42:	mov    rcx,QWORD PTR [rsp+0x410]
  c1cf4a:	mov    QWORD PTR [rsp+0x8],rcx
  c1cf4f:	mov    QWORD PTR [rsp],rax
  c1cf53:	movzx  ecx,bpl
  c1cf57:	and    ecx,0x1
  c1cf5a:	lea    rdi,[rsp+0x70]
  c1cf5f:	mov    rsi,rbx
  c1cf62:	mov    r8,r12
  c1cf65:	call   c40400 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7snippet19run_dynamic_snippet>
  c1cf6a:	movzx  eax,BYTE PTR [rsp+0x70]
  c1cf6f:	cmp    al,0xff
  c1cf71:	je     c1cfc6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2126>
  c1cf73:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1cf78:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1cf81:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1cf8a:	movdqu XMMWORD PTR [rsp+0x1af],xmm1
  c1cf93:	movaps XMMWORD PTR [rsp+0x1a0],xmm0
  c1cf9b:	mov    rcx,QWORD PTR [rsp+0x40]
  c1cfa0:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1cfa5:	movups xmm0,XMMWORD PTR [rsp+0x1af]
  c1cfad:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1cfb1:	movdqa xmm0,XMMWORD PTR [rsp+0x1a0]
  c1cfba:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1cfbf:	mov    BYTE PTR [rcx],al
  c1cfc1:	jmp    c1dfe8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3148>
  c1cfc6:	mov    rax,QWORD PTR [rsp+0x88]
  c1cfce:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1cfd4:	movdqa XMMWORD PTR [rsp+0x150],xmm0
  c1cfdd:	mov    QWORD PTR [rsp+0x160],rax
  c1cfe5:	mov    rax,QWORD PTR [rsp+0x50]
  c1cfea:	mov    rsi,QWORD PTR [rax+0x10]
  c1cfee:	cmp    QWORD PTR [rsp+0x408],rsi
  c1cff6:	jae    c1fb7f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4cdf>
  c1cffc:	mov    rsi,QWORD PTR [rax+0x8]
  c1d000:	lea    rdx,[rsi+r15*1]
  c1d004:	movzx  ecx,r13b
  c1d008:	mov    rax,rcx
  c1d00b:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c1d010:	jae    c1df16 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3076>
  c1d016:	mov    rax,QWORD PTR [rdx+0x28]
  c1d01a:	shl    ecx,0x4
  c1d01d:	mov    rax,QWORD PTR [rax+rcx*1]
  c1d021:	jmp    c1df1a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x307a>
  c1d026:	mov    rax,QWORD PTR [rsi+0x8]
  c1d02a:	inc    QWORD PTR [rax]
  c1d02d:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d033:	mov    edx,0x6
  c1d038:	mov    edx,edx
  c1d03a:	shl    rcx,0x20
  c1d03e:	or     rcx,rdx
  c1d041:	mov    QWORD PTR [rsp+0x110],rcx
  c1d049:	mov    QWORD PTR [rsp+0x118],rax
  c1d051:	mov    QWORD PTR [rsp+0x120],rsi
  c1d059:	mov    r14,QWORD PTR [r9+0x28]
  c1d05d:	lea    rax,[rip+0xffffffffff6ab36b]        # 2c83cf <anon.0c0210c0485269faeef710294932bddb.4.llvm.14881818243032060321>
  c1d064:	mov    QWORD PTR [rsp+0x78],rax
  c1d069:	mov    QWORD PTR [rsp+0x80],0x68
  c1d075:	mov    BYTE PTR [rsp+0x70],0x1f
  c1d07a:	test   r14,r14
  c1d07d:	je     c1d134 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2294>
  c1d083:	lea    rdi,[rsp+0x70]
  c1d088:	call   c367e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.14881818243032060321>
  c1d08d:	mov    rax,QWORD PTR [r14+0x40]
  c1d091:	mov    rcx,QWORD PTR [r14+0x48]
  c1d095:	inc    QWORD PTR [rax]
  c1d098:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d09e:	mov    QWORD PTR [rsp+0x220],rax
  c1d0a6:	mov    QWORD PTR [rsp+0x228],rcx
  c1d0ae:	mov    rdx,QWORD PTR [rcx+0x10]
  c1d0b2:	dec    rdx
  c1d0b5:	and    rdx,0xfffffffffffffff0
  c1d0b9:	add    rdx,rax
  c1d0bc:	add    rdx,0x10
  c1d0c0:	lea    rdi,[rsp+0x70]
  c1d0c5:	lea    rsi,[rsp+0x110]
  c1d0cd:	call   QWORD PTR [rip+0x235f6d]        # e53040 <_DYNAMIC+0x5880>
  c1d0d3:	mov    rcx,QWORD PTR [rsp+0x50]
  c1d0d8:	movzx  eax,BYTE PTR [rsp+0x70]
  c1d0dd:	cmp    al,0xff
  c1d0df:	je     c1d160 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x22c0>
  c1d0e1:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1d0e6:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1d0ef:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1d0f8:	movdqu XMMWORD PTR [rsp+0x1af],xmm1
  c1d101:	movaps XMMWORD PTR [rsp+0x1a0],xmm0
  c1d109:	mov    rcx,QWORD PTR [rsp+0x40]
  c1d10e:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1d113:	movups xmm0,XMMWORD PTR [rsp+0x1af]
  c1d11b:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1d11f:	movdqa xmm0,XMMWORD PTR [rsp+0x1a0]
  c1d128:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1d12d:	mov    BYTE PTR [rcx],al
  c1d12f:	jmp    c1d273 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x23d3>
  c1d134:	lea    rcx,[rsp+0x80]
  c1d13c:	movdqu xmm0,XMMWORD PTR [rcx]
  c1d140:	movdqu xmm1,XMMWORD PTR [rcx+0x10]
  c1d145:	mov    rcx,QWORD PTR [rsp+0x40]
  c1d14a:	movdqu XMMWORD PTR [rcx+0x20],xmm1
  c1d14f:	movdqu XMMWORD PTR [rcx+0x10],xmm0
  c1d154:	mov    BYTE PTR [rcx],0x1f
  c1d157:	mov    QWORD PTR [rcx+0x8],rax
  c1d15b:	jmp    c1d28e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x23ee>
  c1d160:	mov    rax,QWORD PTR [rsp+0x88]
  c1d168:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1d16e:	movdqa XMMWORD PTR [rsp+0x150],xmm0
  c1d177:	mov    QWORD PTR [rsp+0x160],rax
  c1d17f:	mov    rsi,QWORD PTR [rcx+0x10]
  c1d183:	cmp    r15,rsi
  c1d186:	jae    c1fb3b <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4c9b>
  c1d18c:	mov    rsi,QWORD PTR [rcx+0x8]
  c1d190:	lea    rdx,[rsi+rbx*1]
  c1d194:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1d19c:	mov    rax,rcx
  c1d19f:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1d1a4:	jae    c1d1b3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2313>
  c1d1a6:	mov    rax,QWORD PTR [rdx+0x28]
  c1d1aa:	shl    ecx,0x4
  c1d1ad:	mov    rax,QWORD PTR [rax+rcx*1]
  c1d1b1:	jmp    c1d1b7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2317>
  c1d1b3:	add    rax,QWORD PTR [rdx+0x60]
  c1d1b7:	mov    rsi,QWORD PTR [rsp+0x48]
  c1d1bc:	mov    rcx,QWORD PTR [rsi+0x8]
  c1d1c0:	mov    rdx,QWORD PTR [rsp+0x160]
  c1d1c8:	mov    QWORD PTR [rsp+0x80],rdx
  c1d1d0:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1d1d9:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c1d1df:	cmp    rax,QWORD PTR [rsi+0x10]
  c1d1e3:	jae    c1d24e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x23ae>
  c1d1e5:	lea    rax,[rax+rax*2]
  c1d1e9:	lea    r14,[rcx+rax*8]
  c1d1ed:	mov    rdi,r14
  c1d1f0:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1d1f5:	mov    rax,QWORD PTR [rsp+0x160]
  c1d1fd:	mov    QWORD PTR [r14+0x10],rax
  c1d201:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1d20a:	movdqu XMMWORD PTR [r14],xmm0
  c1d20f:	mov    rax,QWORD PTR [rsp+0x50]
  c1d214:	mov    rsi,QWORD PTR [rax+0x10]
  c1d218:	cmp    r15,rsi
  c1d21b:	jae    c1fb99 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4cf9>
  c1d221:	mov    rax,QWORD PTR [rax+0x8]
  c1d225:	inc    QWORD PTR [rax+rbx*1+0x58]
  c1d22a:	mov    rax,QWORD PTR [rsp+0x220]
  c1d232:	dec    QWORD PTR [rax]
  c1d235:	jne    c1d510 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2670>
  c1d23b:	lea    rdi,[rsp+0x220]
  c1d243:	call   QWORD PTR [rip+0x230807]        # e4da50 <_DYNAMIC+0x290>
  c1d249:	jmp    c1d510 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2670>
  c1d24e:	lea    rdi,[rsp+0x70]
  c1d253:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1d258:	mov    rcx,QWORD PTR [rsp+0x40]
  c1d25d:	mov    BYTE PTR [rcx],0x1f
  c1d260:	lea    rax,[rip+0xffffffffff6a96a5]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1d267:	mov    QWORD PTR [rcx+0x8],rax
  c1d26b:	mov    QWORD PTR [rcx+0x10],0x4f
  c1d273:	mov    rax,QWORD PTR [rsp+0x220]
  c1d27b:	dec    QWORD PTR [rax]
  c1d27e:	jne    c1d28e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x23ee>
  c1d280:	lea    rdi,[rsp+0x220]
  c1d288:	call   QWORD PTR [rip+0x2307c2]        # e4da50 <_DYNAMIC+0x290>
  c1d28e:	lea    rdi,[rsp+0x118]
  c1d296:	mov    eax,DWORD PTR [rsp+0x110]
  c1d29d:	mov    edx,eax
  c1d29f:	sub    edx,0x2
  c1d2a2:	mov    ecx,0x3
  c1d2a7:	cmovae ecx,edx
  c1d2aa:	cmp    ecx,0x8
  c1d2ad:	ja     c1d595 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x26f5>
  c1d2b3:	mov    edx,0x1e7
  c1d2b8:	bt     edx,ecx
  c1d2bb:	jb     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1d2c1:	cmp    ecx,0x3
  c1d2c4:	jne    c1d57f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x26df>
  c1d2ca:	test   eax,eax
  c1d2cc:	je     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1d2d2:	mov    rax,QWORD PTR [rsp+0x118]
  c1d2da:	dec    QWORD PTR [rax]
  c1d2dd:	jne    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1d2e3:	jmp    c1de23 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f83>
  c1d2e8:	mov    rax,QWORD PTR [rsi+0x8]
  c1d2ec:	inc    QWORD PTR [rax]
  c1d2ef:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d2f5:	mov    edx,0xb
  c1d2fa:	jmp    c1d3b3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2513>
  c1d2ff:	mov    edx,0x2
  c1d304:	jmp    c1d3b3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2513>
  c1d309:	mov    rsi,QWORD PTR [rdx+0x8]
  c1d30d:	inc    QWORD PTR [rsi]
  c1d310:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d316:	mov    eax,0xb
  c1d31b:	jmp    c1d5f0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2750>
  c1d320:	mov    eax,0x2
  c1d325:	jmp    c1d5f0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2750>
  c1d32a:	mov    rax,QWORD PTR [r14+0x8]
  c1d32e:	dec    QWORD PTR [rax]
  c1d331:	jne    c1bebf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x101f>
  c1d337:	lea    rdi,[r14+0x8]
  c1d33b:	call   QWORD PTR [rip+0x2306cf]        # e4da10 <_DYNAMIC+0x250>
  c1d341:	jmp    c1bebf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x101f>
  c1d346:	test   dil,0x1
  c1d34a:	je     c1bf39 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1099>
  c1d350:	mov    rax,QWORD PTR [rsi+0x8]
  c1d354:	inc    QWORD PTR [rax]
  c1d357:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d35d:	mov    edx,0x1
  c1d362:	jmp    c1d3b3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2513>
  c1d364:	test   dil,0x1
  c1d368:	je     c1bf89 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x10e9>
  c1d36e:	mov    rsi,QWORD PTR [rdx+0x8]
  c1d372:	inc    QWORD PTR [rsi]
  c1d375:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d37b:	mov    eax,0x1
  c1d380:	jmp    c1d5f0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2750>
  c1d385:	mov    rax,QWORD PTR [r14+0x8]
  c1d389:	dec    QWORD PTR [rax]
  c1d38c:	jne    c1bff6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1156>
  c1d392:	lea    rdi,[r14+0x8]
  c1d396:	call   QWORD PTR [rip+0x230674]        # e4da10 <_DYNAMIC+0x250>
  c1d39c:	jmp    c1bff6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1156>
  c1d3a1:	mov    rax,QWORD PTR [rsi+0x8]
  c1d3a5:	inc    QWORD PTR [rax]
  c1d3a8:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d3ae:	mov    edx,0x6
  c1d3b3:	mov    edx,edx
  c1d3b5:	shl    rcx,0x20
  c1d3b9:	or     rcx,rdx
  c1d3bc:	mov    QWORD PTR [rsp+0x110],rcx
  c1d3c4:	mov    QWORD PTR [rsp+0x118],rax
  c1d3cc:	mov    QWORD PTR [rsp+0x120],rsi
  c1d3d4:	lea    rdi,[rsp+0x70]
  c1d3d9:	lea    rsi,[rsp+0x110]
  c1d3e1:	mov    rdx,r11
  c1d3e4:	call   QWORD PTR [rip+0x235c5e]        # e53048 <_DYNAMIC+0x5888>
  c1d3ea:	movzx  eax,BYTE PTR [rsp+0x70]
  c1d3ef:	cmp    al,0xff
  c1d3f1:	je     c1d446 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x25a6>
  c1d3f3:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1d3f8:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1d401:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1d40a:	movdqu XMMWORD PTR [rsp+0x1af],xmm1
  c1d413:	movaps XMMWORD PTR [rsp+0x1a0],xmm0
  c1d41b:	mov    rcx,QWORD PTR [rsp+0x40]
  c1d420:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1d425:	movups xmm0,XMMWORD PTR [rsp+0x1af]
  c1d42d:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1d431:	movdqa xmm0,XMMWORD PTR [rsp+0x1a0]
  c1d43a:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1d43f:	mov    BYTE PTR [rcx],al
  c1d441:	jmp    c1d547 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x26a7>
  c1d446:	mov    rax,QWORD PTR [rsp+0x88]
  c1d44e:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1d454:	movdqa XMMWORD PTR [rsp+0x150],xmm0
  c1d45d:	mov    QWORD PTR [rsp+0x160],rax
  c1d465:	mov    rsi,QWORD PTR [r14+0x10]
  c1d469:	cmp    r15,rsi
  c1d46c:	jae    c1fae2 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4c42>
  c1d472:	mov    rsi,QWORD PTR [r14+0x8]
  c1d476:	lea    rdx,[rsi+rbx*1]
  c1d47a:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1d482:	mov    rax,rcx
  c1d485:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1d48a:	jae    c1d499 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x25f9>
  c1d48c:	mov    rax,QWORD PTR [rdx+0x28]
  c1d490:	shl    ecx,0x4
  c1d493:	mov    rax,QWORD PTR [rax+rcx*1]
  c1d497:	jmp    c1d49d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x25fd>
  c1d499:	add    rax,QWORD PTR [rdx+0x60]
  c1d49d:	mov    rsi,QWORD PTR [rsp+0x48]
  c1d4a2:	mov    rcx,QWORD PTR [rsi+0x8]
  c1d4a6:	mov    rdx,QWORD PTR [rsp+0x160]
  c1d4ae:	mov    QWORD PTR [rsp+0x80],rdx
  c1d4b6:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1d4bf:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c1d4c5:	cmp    rax,QWORD PTR [rsi+0x10]
  c1d4c9:	jae    c1d522 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2682>
  c1d4cb:	lea    rax,[rax+rax*2]
  c1d4cf:	lea    r14,[rcx+rax*8]
  c1d4d3:	mov    rdi,r14
  c1d4d6:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1d4db:	mov    rax,QWORD PTR [rsp+0x160]
  c1d4e3:	mov    QWORD PTR [r14+0x10],rax
  c1d4e7:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1d4f0:	movdqu XMMWORD PTR [r14],xmm0
  c1d4f5:	mov    rax,QWORD PTR [rsp+0x50]
  c1d4fa:	mov    rsi,QWORD PTR [rax+0x10]
  c1d4fe:	cmp    r15,rsi
  c1d501:	jae    c1fb50 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4cb0>
  c1d507:	mov    rax,QWORD PTR [rax+0x8]
  c1d50b:	inc    QWORD PTR [rax+rbx*1+0x58]
  c1d510:	lea    rdi,[rsp+0x110]
  c1d518:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1d51d:	jmp    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1d522:	lea    rdi,[rsp+0x70]
  c1d527:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1d52c:	mov    rcx,QWORD PTR [rsp+0x40]
  c1d531:	mov    BYTE PTR [rcx],0x1f
  c1d534:	lea    rax,[rip+0xffffffffff6a93d1]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1d53b:	mov    QWORD PTR [rcx+0x8],rax
  c1d53f:	mov    QWORD PTR [rcx+0x10],0x4f
  c1d547:	lea    rdi,[rsp+0x118]
  c1d54f:	mov    eax,DWORD PTR [rsp+0x110]
  c1d556:	mov    edx,eax
  c1d558:	sub    edx,0x2
  c1d55b:	mov    ecx,0x3
  c1d560:	cmovae ecx,edx
  c1d563:	cmp    ecx,0x8
  c1d566:	ja     c1d595 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x26f5>
  c1d568:	mov    edx,0x1e7
  c1d56d:	bt     edx,ecx
  c1d570:	jb     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1d576:	cmp    ecx,0x3
  c1d579:	je     c1d2ca <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x242a>
  c1d57f:	mov    rax,QWORD PTR [rsp+0x118]
  c1d587:	dec    QWORD PTR [rax]
  c1d58a:	jne    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1d590:	jmp    c1d954 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2ab4>
  c1d595:	mov    rax,QWORD PTR [rsp+0x118]
  c1d59d:	dec    QWORD PTR [rax]
  c1d5a0:	jne    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1d5a6:	jmp    c1de3f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f9f>
  c1d5ab:	mov    rax,QWORD PTR [rsi+0x8]
  c1d5af:	inc    QWORD PTR [rax]
  c1d5b2:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d5b8:	mov    edx,0xb
  c1d5bd:	jmp    c1d996 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2af6>
  c1d5c2:	mov    rax,QWORD PTR [r14+0x8]
  c1d5c6:	dec    QWORD PTR [rax]
  c1d5c9:	jne    c1c086 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x11e6>
  c1d5cf:	lea    rdi,[r14+0x8]
  c1d5d3:	call   QWORD PTR [rip+0x230437]        # e4da10 <_DYNAMIC+0x250>
  c1d5d9:	jmp    c1c086 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x11e6>
  c1d5de:	mov    rsi,QWORD PTR [rdx+0x8]
  c1d5e2:	inc    QWORD PTR [rsi]
  c1d5e5:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d5eb:	mov    eax,0x6
  c1d5f0:	shl    ebx,0x8
  c1d5f3:	movzx  edi,r12b
  c1d5f7:	mov    r8d,eax
  c1d5fa:	shl    rcx,0x20
  c1d5fe:	or     rcx,r8
  c1d601:	mov    QWORD PTR [rsp+0x220],rcx
  c1d609:	mov    QWORD PTR [rsp+0x228],rsi
  c1d611:	mov    QWORD PTR [rsp+0x230],rdx
  c1d619:	and    ebx,0xff00
  c1d61f:	or     ebx,edi
  c1d621:	cmp    eax,0xb
  c1d624:	jne    c1d7c1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2921>
  c1d62a:	cmp    BYTE PTR [rsi+0x10],0xf
  c1d62e:	jne    c1d7c1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2921>
  c1d634:	add    rsi,0x18
  c1d638:	mov    rdx,r10
  c1d63b:	lea    rcx,[r10+0x48]
  c1d63f:	lea    r12,[r10+0x58]
  c1d643:	lea    rdi,[r10+0x68]
  c1d647:	lea    r8,[r10+0xf0]
  c1d64e:	mov    rax,QWORD PTR [r10+0xf0]
  c1d655:	mov    r9,QWORD PTR [r10+0x118]
  c1d65c:	test   rax,rax
  c1d65f:	cmove  r8,rax
  c1d663:	add    r10,0x100
  c1d66a:	mov    r13,r11
  c1d66d:	lea    r11,[rdx+0x110]
  c1d674:	lea    rax,[rdx+0x118]
  c1d67b:	test   r9,r9
  c1d67e:	cmove  rax,r9
  c1d682:	movq   xmm0,QWORD PTR [rdx+0x110]
  c1d68a:	movq   xmm1,QWORD PTR [rdx+0x100]
  c1d692:	punpcklqdq xmm1,xmm0
  c1d696:	mov    QWORD PTR [rsp+0x70],r13
  c1d69b:	mov    r9,QWORD PTR [rip+0x23043e]        # e4dae0 <_DYNAMIC+0x320>
  c1d6a2:	mov    QWORD PTR [rsp+0x78],r9
  c1d6a7:	mov    BYTE PTR [rsp+0xf8],0x0
  c1d6af:	mov    rbp,QWORD PTR [rsp+0x3d0]
  c1d6b7:	movups xmm0,XMMWORD PTR [rbp+0x0]
  c1d6bb:	movups XMMWORD PTR [rsp+0x80],xmm0
  c1d6c3:	movdqu xmm0,XMMWORD PTR [rbp+0x10]
  c1d6c8:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1d6d1:	mov    QWORD PTR [rsp+0xa0],rcx
  c1d6d9:	mov    QWORD PTR [rsp+0xa8],r12
  c1d6e1:	mov    QWORD PTR [rsp+0xb0],rdi
  c1d6e9:	mov    QWORD PTR [rsp+0xb8],r8
  c1d6f1:	mov    QWORD PTR [rsp+0xc0],0x0
  c1d6fd:	mov    QWORD PTR [rsp+0xd0],0x0
  c1d709:	pxor   xmm0,xmm0
  c1d70d:	pcmpeqd xmm0,xmm1
  c1d711:	movq   xmm1,r11
  c1d716:	movq   xmm2,r10
  c1d71b:	punpcklqdq xmm2,xmm1
  c1d71f:	pshufd xmm1,xmm0,0xb1
  c1d724:	pand   xmm1,xmm0
  c1d728:	pandn  xmm1,xmm2
  c1d72c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1d735:	mov    QWORD PTR [rsp+0xf0],rax
  c1d73d:	add    rdx,0xb8
  c1d744:	lea    rdi,[rsp+0x1a0]
  c1d74c:	lea    r9,[rsp+0x70]
  c1d751:	mov    ecx,ebx
  c1d753:	mov    r8,r14
  c1d756:	call   c37e00 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7linking18component_prop_get>
  c1d75b:	movzx  eax,BYTE PTR [rsp+0x1a0]
  c1d763:	cmp    al,0xff
  c1d765:	je     c1dd78 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2ed8>
  c1d76b:	movups xmm0,XMMWORD PTR [rsp+0x1a1]
  c1d773:	movdqu xmm1,XMMWORD PTR [rsp+0x1b0]
  c1d77c:	movdqu xmm2,XMMWORD PTR [rsp+0x1c0]
  c1d785:	movdqu XMMWORD PTR [rsp+0x15f],xmm1
  c1d78e:	movaps XMMWORD PTR [rsp+0x150],xmm0
  c1d796:	mov    rcx,QWORD PTR [rsp+0x40]
  c1d79b:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1d7a0:	movups xmm0,XMMWORD PTR [rsp+0x15f]
  c1d7a8:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1d7ac:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1d7b5:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1d7ba:	mov    BYTE PTR [rcx],al
  c1d7bc:	jmp    c1d907 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2a67>
  c1d7c1:	mov    rsi,QWORD PTR [r9+0x10]
  c1d7c5:	cmp    QWORD PTR [rsp+0x408],rsi
  c1d7cd:	jae    c1fa90 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4bf0>
  c1d7d3:	mov    rcx,QWORD PTR [rsp+0x148]
  c1d7db:	cmp    rbp,QWORD PTR [rcx+0x10]
  c1d7df:	jae    c1d8dd <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2a3d>
  c1d7e5:	mov    rax,QWORD PTR [r9+0x8]
  c1d7e9:	mov    rax,QWORD PTR [rax+r15*1+0x58]
  c1d7ee:	mov    rcx,QWORD PTR [rcx+0x8]
  c1d7f2:	lea    rdx,[rbp*2+0x0]
  c1d7fa:	add    rdx,rbp
  c1d7fd:	cmp    rax,QWORD PTR [rcx+rdx*8+0x10]
  c1d802:	jae    c1d8eb <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2a4b>
  c1d808:	lea    rdx,[rcx+rdx*8]
  c1d80c:	lea    rcx,[rax+rax*2]
  c1d810:	shl    rcx,0x3
  c1d814:	add    rcx,QWORD PTR [rdx+0x8]
  c1d818:	lea    rdi,[rsp+0x1a0]
  c1d820:	lea    rsi,[rsp+0x220]
  c1d828:	mov    edx,ebx
  c1d82a:	call   QWORD PTR [rip+0x235790]        # e52fc0 <_DYNAMIC+0x5800>
  c1d830:	movzx  eax,BYTE PTR [rsp+0x1a0]
  c1d838:	cmp    eax,0xff
  c1d83d:	je     c1e025 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3185>
  c1d843:	cmp    eax,0x5
  c1d846:	jne    c1e133 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3293>
  c1d84c:	mov    eax,ebx
  c1d84e:	cmp    QWORD PTR [r14+0x40],rax
  c1d852:	jbe    c1e8fc <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3a5c>
  c1d858:	mov    rcx,QWORD PTR [r14+0x38]
  c1d85c:	lea    rax,[rax+rax*2]
  c1d860:	mov    rdx,QWORD PTR [rcx+rax*8+0x8]
  c1d865:	mov    rcx,QWORD PTR [rcx+rax*8+0x10]
  c1d86a:	lea    rdi,[rsp+0x70]
  c1d86f:	lea    rsi,[rsp+0x220]
  c1d877:	call   QWORD PTR [rip+0x23574b]        # e52fc8 <_DYNAMIC+0x5808>
  c1d87d:	movzx  eax,BYTE PTR [rsp+0x70]
  c1d882:	cmp    al,0xff
  c1d884:	je     c1eee4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4044>
  c1d88a:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1d88f:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1d898:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1d8a1:	movdqu XMMWORD PTR [rsp+0x15f],xmm1
  c1d8aa:	movaps XMMWORD PTR [rsp+0x150],xmm0
  c1d8b2:	mov    rcx,QWORD PTR [rsp+0x40]
  c1d8b7:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1d8bc:	movups xmm0,XMMWORD PTR [rsp+0x15f]
  c1d8c4:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1d8c8:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1d8d1:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1d8d6:	mov    BYTE PTR [rcx],al
  c1d8d8:	jmp    c1e917 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3a77>
  c1d8dd:	lea    rax,[rip+0xffffffffff6a8929]        # 2c620d <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x184c>
  c1d8e4:	mov    ecx,0x41
  c1d8e9:	jmp    c1d8f7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2a57>
  c1d8eb:	lea    rax,[rip+0xffffffffff6a895c]        # 2c624e <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x188d>
  c1d8f2:	mov    ecx,0x45
  c1d8f7:	mov    rdx,QWORD PTR [rsp+0x40]
  c1d8fc:	mov    BYTE PTR [rdx],0x1f
  c1d8ff:	mov    QWORD PTR [rdx+0x8],rax
  c1d903:	mov    QWORD PTR [rdx+0x10],rcx
  c1d907:	lea    rdi,[rsp+0x228]
  c1d90f:	mov    eax,DWORD PTR [rsp+0x220]
  c1d916:	mov    edx,eax
  c1d918:	sub    edx,0x2
  c1d91b:	mov    ecx,0x3
  c1d920:	cmovae ecx,edx
  c1d923:	cmp    ecx,0x8
  c1d926:	ja     c1de2e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f8e>
  c1d92c:	mov    edx,0x1e7
  c1d931:	bt     edx,ecx
  c1d934:	jb     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1d93a:	cmp    ecx,0x3
  c1d93d:	je     c1de0a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f6a>
  c1d943:	mov    rax,QWORD PTR [rsp+0x228]
  c1d94b:	dec    QWORD PTR [rax]
  c1d94e:	jne    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1d954:	call   QWORD PTR [rip+0x2300b6]        # e4da10 <_DYNAMIC+0x250>
  c1d95a:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1d95f:	mov    edx,0x2
  c1d964:	jmp    c1d996 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2af6>
  c1d966:	test   dil,0x1
  c1d96a:	je     c1c13c <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x129c>
  c1d970:	mov    rax,QWORD PTR [rsi+0x8]
  c1d974:	inc    QWORD PTR [rax]
  c1d977:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d97d:	mov    edx,0x1
  c1d982:	jmp    c1d996 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2af6>
  c1d984:	mov    rax,QWORD PTR [rsi+0x8]
  c1d988:	inc    QWORD PTR [rax]
  c1d98b:	je     c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1d991:	mov    edx,0x6
  c1d996:	mov    edx,edx
  c1d998:	shl    rcx,0x20
  c1d99c:	or     rcx,rdx
  c1d99f:	mov    QWORD PTR [rsp+0x220],rcx
  c1d9a7:	mov    QWORD PTR [rsp+0x228],rax
  c1d9af:	mov    QWORD PTR [rsp+0x230],rsi
  c1d9b7:	mov    rcx,QWORD PTR [rsp+0x50]
  c1d9bc:	mov    rsi,QWORD PTR [rcx+0x10]
  c1d9c0:	cmp    QWORD PTR [rsp+0x408],rsi
  c1d9c8:	jae    c1fa54 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4bb4>
  c1d9ce:	mov    rax,QWORD PTR [rsp+0x48]
  c1d9d3:	mov    rax,QWORD PTR [rax+0x10]
  c1d9d7:	mov    rdi,QWORD PTR [rcx+0x8]
  c1d9db:	lea    rsi,[rdi+r15*1]
  c1d9df:	movzx  edx,r13b
  c1d9e3:	mov    rcx,rdx
  c1d9e6:	sub    rcx,QWORD PTR [rdi+r15*1+0x30]
  c1d9eb:	jae    c1d9fa <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2b5a>
  c1d9ed:	mov    rcx,QWORD PTR [rsi+0x28]
  c1d9f1:	shl    edx,0x4
  c1d9f4:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1d9f8:	jmp    c1d9fe <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2b5e>
  c1d9fa:	add    rcx,QWORD PTR [rsi+0x60]
  c1d9fe:	cmp    rcx,rax
  c1da01:	jae    c1dc0f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2d6f>
  c1da07:	mov    r13,r8
  c1da0a:	shl    ebx,0x8
  c1da0d:	movzx  ebp,r12b
  c1da11:	mov    rax,QWORD PTR [rsp+0x48]
  c1da16:	mov    rax,QWORD PTR [rax+0x8]
  c1da1a:	lea    rcx,[rcx+rcx*2]
  c1da1e:	lea    rsi,[rax+rcx*8]
  c1da22:	lea    r12,[rsp+0x70]
  c1da27:	mov    rdi,r12
  c1da2a:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1da2f:	mov    rax,QWORD PTR [rsp+0x70]
  c1da34:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1da3a:	mov    QWORD PTR [rsp+0x110],rax
  c1da42:	movdqu XMMWORD PTR [rsp+0x118],xmm0
  c1da4b:	and    ebx,0xff00
  c1da51:	or     ebx,ebp
  c1da53:	cmp    DWORD PTR [rsp+0x220],0xb
  c1da5b:	jne    c1dc2f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2d8f>
  c1da61:	mov    rsi,QWORD PTR [rsp+0x228]
  c1da69:	cmp    BYTE PTR [rsi+0x10],0xf
  c1da6d:	jne    c1dc2f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2d8f>
  c1da73:	add    rsi,0x18
  c1da77:	mov    rdx,QWORD PTR [rsp+0x3c8]
  c1da7f:	lea    rcx,[rdx+0x48]
  c1da83:	lea    r14,[rdx+0x58]
  c1da87:	lea    rdi,[rdx+0x68]
  c1da8b:	lea    r8,[rdx+0xf0]
  c1da92:	mov    rax,QWORD PTR [rdx+0xf0]
  c1da99:	mov    r9,QWORD PTR [rdx+0x118]
  c1daa0:	test   rax,rax
  c1daa3:	cmove  r8,rax
  c1daa7:	lea    r10,[rdx+0x100]
  c1daae:	lea    r11,[rdx+0x110]
  c1dab5:	lea    rax,[rdx+0x118]
  c1dabc:	test   r9,r9
  c1dabf:	cmove  rax,r9
  c1dac3:	movq   xmm0,QWORD PTR [rdx+0x110]
  c1dacb:	movq   xmm1,QWORD PTR [rdx+0x100]
  c1dad3:	punpcklqdq xmm1,xmm0
  c1dad7:	mov    r9,QWORD PTR [rsp+0x3d8]
  c1dadf:	mov    QWORD PTR [rsp+0x70],r9
  c1dae4:	mov    r9,QWORD PTR [rip+0x22fff5]        # e4dae0 <_DYNAMIC+0x320>
  c1daeb:	mov    QWORD PTR [rsp+0x78],r9
  c1daf0:	mov    BYTE PTR [rsp+0xf8],0x0
  c1daf8:	mov    r9,QWORD PTR [rsp+0x3d0]
  c1db00:	movups xmm0,XMMWORD PTR [r9]
  c1db04:	movups XMMWORD PTR [rsp+0x80],xmm0
  c1db0c:	movdqu xmm0,XMMWORD PTR [r9+0x10]
  c1db12:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1db1b:	mov    QWORD PTR [rsp+0xa0],rcx
  c1db23:	mov    QWORD PTR [rsp+0xa8],r14
  c1db2b:	mov    QWORD PTR [rsp+0xb0],rdi
  c1db33:	mov    QWORD PTR [rsp+0xb8],r8
  c1db3b:	mov    QWORD PTR [rsp+0xc0],0x0
  c1db47:	mov    QWORD PTR [rsp+0xd0],0x0
  c1db53:	pxor   xmm0,xmm0
  c1db57:	pcmpeqd xmm0,xmm1
  c1db5b:	movq   xmm1,r11
  c1db60:	movq   xmm2,r10
  c1db65:	punpcklqdq xmm2,xmm1
  c1db69:	pshufd xmm1,xmm0,0xb1
  c1db6e:	pand   xmm1,xmm0
  c1db72:	pandn  xmm1,xmm2
  c1db76:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1db7f:	mov    QWORD PTR [rsp+0xf0],rax
  c1db87:	add    rdx,0xb8
  c1db8e:	mov    rax,QWORD PTR [rsp+0x120]
  c1db96:	mov    QWORD PTR [rsp+0x160],rax
  c1db9e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c1dba7:	movdqa XMMWORD PTR [rsp+0x150],xmm0
  c1dbb0:	mov    QWORD PTR [rsp],r12
  c1dbb4:	lea    rdi,[rsp+0x1a0]
  c1dbbc:	lea    r8,[rsp+0x150]
  c1dbc4:	mov    ecx,ebx
  c1dbc6:	mov    r9,r13
  c1dbc9:	call   c37f20 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7linking18component_prop_set>
  c1dbce:	cmp    BYTE PTR [rsp+0x1a0],0xff
  c1dbd6:	je     c1e548 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x36a8>
  c1dbdc:	movdqu xmm0,XMMWORD PTR [rsp+0x1a0]
  c1dbe5:	movdqu xmm1,XMMWORD PTR [rsp+0x1b0]
  c1dbee:	movdqu xmm2,XMMWORD PTR [rsp+0x1c0]
  c1dbf7:	mov    rax,QWORD PTR [rsp+0x40]
  c1dbfc:	movdqu XMMWORD PTR [rax+0x20],xmm2
  c1dc01:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1dc06:	movdqu XMMWORD PTR [rax],xmm0
  c1dc0a:	jmp    c1ddd2 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f32>
  c1dc0f:	mov    rcx,QWORD PTR [rsp+0x40]
  c1dc14:	mov    BYTE PTR [rcx],0x1f
  c1dc17:	lea    rax,[rip+0xffffffffff6a84fa]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1dc1e:	mov    QWORD PTR [rcx+0x8],rax
  c1dc22:	mov    QWORD PTR [rcx+0x10],0x4f
  c1dc2a:	jmp    c1ddd2 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f32>
  c1dc2f:	lea    rdi,[rsp+0x70]
  c1dc34:	lea    rsi,[rsp+0x110]
  c1dc3c:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1dc41:	mov    rax,QWORD PTR [rsp+0x50]
  c1dc46:	mov    rsi,QWORD PTR [rax+0x10]
  c1dc4a:	cmp    QWORD PTR [rsp+0x408],rsi
  c1dc52:	jae    c1faf7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4c57>
  c1dc58:	mov    rcx,QWORD PTR [rsp+0x148]
  c1dc60:	cmp    r14,QWORD PTR [rcx+0x10]
  c1dc64:	jae    c1dd0a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2e6a>
  c1dc6a:	mov    rax,QWORD PTR [rsp+0x50]
  c1dc6f:	mov    rax,QWORD PTR [rax+0x8]
  c1dc73:	mov    rax,QWORD PTR [rax+r15*1+0x58]
  c1dc78:	mov    rcx,QWORD PTR [rcx+0x8]
  c1dc7c:	lea    rdx,[r14+r14*2]
  c1dc80:	cmp    rax,QWORD PTR [rcx+rdx*8+0x10]
  c1dc85:	jae    c1dd9f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2eff>
  c1dc8b:	lea    rcx,[rcx+rdx*8]
  c1dc8f:	lea    r8,[rax+rax*2]
  c1dc93:	shl    r8,0x3
  c1dc97:	add    r8,QWORD PTR [rcx+0x8]
  c1dc9b:	lea    rdi,[rsp+0x1a0]
  c1dca3:	lea    rsi,[rsp+0x220]
  c1dcab:	lea    rcx,[rsp+0x70]
  c1dcb0:	mov    edx,ebx
  c1dcb2:	call   QWORD PTR [rip+0x235330]        # e52fe8 <_DYNAMIC+0x5828>
  c1dcb8:	movzx  eax,BYTE PTR [rsp+0x1a0]
  c1dcc0:	cmp    al,0x5
  c1dcc2:	setne  bpl
  c1dcc6:	je     c1e591 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x36f1>
  c1dccc:	cmp    al,0xff
  c1dcce:	je     c1e54a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x36aa>
  c1dcd4:	movdqu xmm0,XMMWORD PTR [rsp+0x1a1]
  c1dcdd:	movdqu xmm1,XMMWORD PTR [rsp+0x1b1]
  c1dce6:	movdqu xmm2,XMMWORD PTR [rsp+0x1c0]
  c1dcef:	mov    rcx,QWORD PTR [rsp+0x40]
  c1dcf4:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1dcf9:	movdqu XMMWORD PTR [rcx+0x11],xmm1
  c1dcfe:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1dd03:	mov    BYTE PTR [rcx],al
  c1dd05:	jmp    c1ddc5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f25>
  c1dd0a:	lea    rax,[rip+0xffffffffff6a84fc]        # 2c620d <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x184c>
  c1dd11:	mov    ecx,0x41
  c1dd16:	jmp    c1ddab <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f0b>
  c1dd1b:	mov    rax,QWORD PTR [r14+0x8]
  c1dd1f:	dec    QWORD PTR [rax]
  c1dd22:	mov    r15,r13
  c1dd25:	jne    c1bebf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x101f>
  c1dd2b:	lea    rdi,[r14+0x8]
  c1dd2f:	call   QWORD PTR [rip+0x22fce3]        # e4da18 <_DYNAMIC+0x258>
  c1dd35:	jmp    c1bebf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x101f>
  c1dd3a:	mov    rax,QWORD PTR [r14+0x8]
  c1dd3e:	dec    QWORD PTR [rax]
  c1dd41:	mov    r15,r13
  c1dd44:	jne    c1bff6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1156>
  c1dd4a:	lea    rdi,[r14+0x8]
  c1dd4e:	call   QWORD PTR [rip+0x22fcc4]        # e4da18 <_DYNAMIC+0x258>
  c1dd54:	jmp    c1bff6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1156>
  c1dd59:	mov    rax,QWORD PTR [r14+0x8]
  c1dd5d:	dec    QWORD PTR [rax]
  c1dd60:	mov    r15,r13
  c1dd63:	jne    c1c086 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x11e6>
  c1dd69:	lea    rdi,[r14+0x8]
  c1dd6d:	call   QWORD PTR [rip+0x22fca5]        # e4da18 <_DYNAMIC+0x258>
  c1dd73:	jmp    c1c086 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x11e6>
  c1dd78:	mov    rax,QWORD PTR [rsp+0x1b8]
  c1dd80:	movdqu xmm0,XMMWORD PTR [rsp+0x1a8]
  c1dd89:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c1dd92:	mov    QWORD PTR [rsp+0x120],rax
  c1dd9a:	jmp    c1e047 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x31a7>
  c1dd9f:	lea    rax,[rip+0xffffffffff6a84a8]        # 2c624e <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x188d>
  c1dda6:	mov    ecx,0x45
  c1ddab:	mov    rdx,QWORD PTR [rsp+0x40]
  c1ddb0:	mov    BYTE PTR [rdx],0x1f
  c1ddb3:	mov    QWORD PTR [rdx+0x8],rax
  c1ddb7:	mov    QWORD PTR [rdx+0x10],rcx
  c1ddbb:	lea    rdi,[rsp+0x70]
  c1ddc0:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1ddc5:	lea    rdi,[rsp+0x110]
  c1ddcd:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1ddd2:	lea    rdi,[rsp+0x228]
  c1ddda:	mov    eax,DWORD PTR [rsp+0x220]
  c1dde1:	mov    edx,eax
  c1dde3:	sub    edx,0x2
  c1dde6:	mov    ecx,0x3
  c1ddeb:	cmovae ecx,edx
  c1ddee:	cmp    ecx,0x8
  c1ddf1:	ja     c1de2e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f8e>
  c1ddf3:	mov    edx,0x1e7
  c1ddf8:	bt     edx,ecx
  c1ddfb:	jb     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1de01:	cmp    ecx,0x3
  c1de04:	jne    c1d943 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2aa3>
  c1de0a:	test   eax,eax
  c1de0c:	je     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1de12:	mov    rax,QWORD PTR [rsp+0x228]
  c1de1a:	dec    QWORD PTR [rax]
  c1de1d:	jne    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1de23:	call   QWORD PTR [rip+0x22fbdf]        # e4da08 <_DYNAMIC+0x248>
  c1de29:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1de2e:	mov    rax,QWORD PTR [rsp+0x228]
  c1de36:	dec    QWORD PTR [rax]
  c1de39:	jne    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1de3f:	call   QWORD PTR [rip+0x22fbd3]        # e4da18 <_DYNAMIC+0x258>
  c1de45:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1de4a:	mov    rax,QWORD PTR [rsp+0x168]
  c1de52:	movdqu xmm0,XMMWORD PTR [rsp+0x158]
  c1de5b:	movdqa XMMWORD PTR [rsp+0x270],xmm0
  c1de64:	mov    QWORD PTR [rsp+0x280],rax
  c1de6c:	mov    rax,QWORD PTR [rsp+0x50]
  c1de71:	mov    rsi,QWORD PTR [rax+0x10]
  c1de75:	cmp    r15,rsi
  c1de78:	jae    c1fbc0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4d20>
  c1de7e:	mov    rsi,QWORD PTR [rax+0x8]
  c1de82:	mov    rdi,QWORD PTR [rsp+0x148]
  c1de8a:	lea    rdx,[rsi+rdi*1]
  c1de8e:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1de96:	mov    rax,rcx
  c1de99:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c1de9e:	jae    c1e7aa <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x390a>
  c1dea4:	mov    rax,QWORD PTR [rdx+0x28]
  c1dea8:	shl    ecx,0x4
  c1deab:	mov    rax,QWORD PTR [rax+rcx*1]
  c1deaf:	jmp    c1e7ae <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x390e>
  c1deb4:	mov    rax,QWORD PTR [rsp+0x168]
  c1debc:	movdqu xmm0,XMMWORD PTR [rsp+0x158]
  c1dec5:	movdqa XMMWORD PTR [rsp+0x220],xmm0
  c1dece:	mov    QWORD PTR [rsp+0x230],rax
  c1ded6:	mov    rax,QWORD PTR [rsp+0x50]
  c1dedb:	mov    rsi,QWORD PTR [rax+0x10]
  c1dedf:	cmp    r15,rsi
  c1dee2:	jae    c1fbd5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4d35>
  c1dee8:	mov    rsi,QWORD PTR [rax+0x8]
  c1deec:	lea    rdx,[rsi+rbx*1]
  c1def0:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1def8:	mov    rax,rcx
  c1defb:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1df00:	jae    c1e843 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x39a3>
  c1df06:	mov    rax,QWORD PTR [rdx+0x28]
  c1df0a:	shl    ecx,0x4
  c1df0d:	mov    rax,QWORD PTR [rax+rcx*1]
  c1df11:	jmp    c1e847 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x39a7>
  c1df16:	add    rax,QWORD PTR [rdx+0x60]
  c1df1a:	mov    rsi,QWORD PTR [rsp+0x48]
  c1df1f:	mov    rcx,QWORD PTR [rsi+0x8]
  c1df23:	mov    rdx,QWORD PTR [rsp+0x160]
  c1df2b:	mov    QWORD PTR [rsp+0x80],rdx
  c1df33:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1df3c:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c1df42:	cmp    rax,QWORD PTR [rsi+0x10]
  c1df46:	jae    c1dfc3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3123>
  c1df48:	lea    rax,[rax+rax*2]
  c1df4c:	lea    r14,[rcx+rax*8]
  c1df50:	mov    rdi,r14
  c1df53:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1df58:	mov    rax,QWORD PTR [rsp+0x160]
  c1df60:	mov    QWORD PTR [r14+0x10],rax
  c1df64:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1df6d:	movdqu XMMWORD PTR [r14],xmm0
  c1df72:	mov    rax,QWORD PTR [rsp+0x50]
  c1df77:	mov    rsi,QWORD PTR [rax+0x10]
  c1df7b:	mov    rdi,QWORD PTR [rsp+0x408]
  c1df83:	cmp    rdi,rsi
  c1df86:	jae    c1fbfc <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4d5c>
  c1df8c:	mov    rax,QWORD PTR [rax+0x8]
  c1df90:	inc    QWORD PTR [rax+r15*1+0x58]
  c1df95:	mov    rsi,QWORD PTR [rsp+0x110]
  c1df9d:	test   rsi,rsi
  c1dfa0:	je     c1dfb0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3110>
  c1dfa2:	mov    edx,0x1
  c1dfa7:	mov    rdi,rbx
  c1dfaa:	call   QWORD PTR [rip+0x22fa50]        # e4da00 <_DYNAMIC+0x240>
  c1dfb0:	cmp    DWORD PTR [rsp+0x220],0x6
  c1dfb8:	je     c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1dfbe:	jmp    c1e57f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x36df>
  c1dfc3:	lea    rdi,[rsp+0x70]
  c1dfc8:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1dfcd:	mov    rcx,QWORD PTR [rsp+0x40]
  c1dfd2:	mov    BYTE PTR [rcx],0x1f
  c1dfd5:	lea    rax,[rip+0xffffffffff6a8930]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1dfdc:	mov    QWORD PTR [rcx+0x8],rax
  c1dfe0:	mov    QWORD PTR [rcx+0x10],0x4f
  c1dfe8:	mov    rsi,QWORD PTR [rsp+0x110]
  c1dff0:	test   rsi,rsi
  c1dff3:	je     c1e003 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3163>
  c1dff5:	mov    edx,0x1
  c1dffa:	mov    rdi,rbx
  c1dffd:	call   QWORD PTR [rip+0x22f9fd]        # e4da00 <_DYNAMIC+0x240>
  c1e003:	mov    eax,DWORD PTR [rsp+0x220]
  c1e00a:	cmp    eax,0x6
  c1e00d:	je     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1e013:	lea    rdi,[rsp+0x220]
  c1e01b:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1e020:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1e025:	mov    rax,QWORD PTR [rsp+0x1b8]
  c1e02d:	mov    QWORD PTR [rsp+0x120],rax
  c1e035:	movdqu xmm0,XMMWORD PTR [rsp+0x1a8]
  c1e03e:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c1e047:	mov    rax,QWORD PTR [rsp+0x50]
  c1e04c:	mov    rsi,QWORD PTR [rax+0x10]
  c1e050:	cmp    QWORD PTR [rsp+0x408],rsi
  c1e058:	mov    rdi,QWORD PTR [rsp+0x48]
  c1e05d:	jae    c1fb65 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4cc5>
  c1e063:	mov    rsi,QWORD PTR [rax+0x8]
  c1e067:	lea    rdx,[rsi+r15*1]
  c1e06b:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1e073:	mov    rax,rcx
  c1e076:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c1e07b:	jae    c1e08a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x31ea>
  c1e07d:	mov    rax,QWORD PTR [rdx+0x28]
  c1e081:	shl    ecx,0x4
  c1e084:	mov    rax,QWORD PTR [rax+rcx*1]
  c1e088:	jmp    c1e08e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x31ee>
  c1e08a:	add    rax,QWORD PTR [rdx+0x60]
  c1e08e:	mov    rcx,QWORD PTR [rdi+0x8]
  c1e092:	mov    rdx,QWORD PTR [rsp+0x120]
  c1e09a:	mov    QWORD PTR [rsp+0x80],rdx
  c1e0a2:	movdqa xmm0,XMMWORD PTR [rsp+0x110]
  c1e0ab:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c1e0b1:	cmp    rax,QWORD PTR [rdi+0x10]
  c1e0b5:	jae    c1e109 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3269>
  c1e0b7:	lea    rax,[rax+rax*2]
  c1e0bb:	lea    r14,[rcx+rax*8]
  c1e0bf:	mov    rdi,r14
  c1e0c2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1e0c7:	mov    rax,QWORD PTR [rsp+0x120]
  c1e0cf:	mov    QWORD PTR [r14+0x10],rax
  c1e0d3:	movdqa xmm0,XMMWORD PTR [rsp+0x110]
  c1e0dc:	movdqu XMMWORD PTR [r14],xmm0
  c1e0e1:	mov    rax,QWORD PTR [rsp+0x50]
  c1e0e6:	mov    rsi,QWORD PTR [rax+0x10]
  c1e0ea:	mov    rdi,QWORD PTR [rsp+0x408]
  c1e0f2:	cmp    rdi,rsi
  c1e0f5:	jae    c1fbae <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4d0e>
  c1e0fb:	mov    rax,QWORD PTR [rax+0x8]
  c1e0ff:	inc    QWORD PTR [rax+r15*1+0x58]
  c1e104:	jmp    c1e57f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x36df>
  c1e109:	lea    rdi,[rsp+0x70]
  c1e10e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1e113:	mov    rcx,QWORD PTR [rsp+0x40]
  c1e118:	mov    BYTE PTR [rcx],0x1f
  c1e11b:	lea    rax,[rip+0xffffffffff6a87ea]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1e122:	mov    QWORD PTR [rcx+0x8],rax
  c1e126:	mov    QWORD PTR [rcx+0x10],0x4f
  c1e12e:	jmp    c1d907 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2a67>
  c1e133:	movups xmm0,XMMWORD PTR [rsp+0x1c0]
  c1e13b:	mov    rcx,QWORD PTR [rsp+0x40]
  c1e140:	movups XMMWORD PTR [rcx+0x20],xmm0
  c1e144:	movdqu xmm0,XMMWORD PTR [rsp+0x1a1]
  c1e14d:	movdqu xmm1,XMMWORD PTR [rsp+0x1b0]
  c1e156:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1e15b:	movdqu XMMWORD PTR [rcx+0x10],xmm1
  c1e160:	mov    BYTE PTR [rcx],al
  c1e162:	jmp    c1d907 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2a67>
  c1e167:	mov    QWORD PTR [rsp+0x260],rsi
  c1e16f:	mov    rbp,r8
  c1e172:	lea    rax,[rip+0xffffffffff6a8aff]        # 2c6c78 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x8f5>
  c1e179:	mov    QWORD PTR [rsp+0x78],rax
  c1e17e:	mov    QWORD PTR [rsp+0x80],0x53
  c1e18a:	mov    BYTE PTR [rsp+0x70],0x1f
  c1e18f:	mov    DWORD PTR [rsp+0x68],0x0
  c1e197:	lea    rdi,[rsp+0x70]
  c1e19c:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1e1a1:	lea    rax,[rbx+rbx*2]
  c1e1a5:	lea    rcx,[r15+rax*8]
  c1e1a9:	mov    DWORD PTR [rsp+0x68],0x0
  c1e1b1:	mov    r8,rbp
  c1e1b4:	mov    r11,QWORD PTR [rsp+0x3d8]
  c1e1bc:	mov    rbp,QWORD PTR [rsp+0x260]
  c1e1c4:	lea    rax,[r13*2+0x0]
  c1e1cc:	add    rax,r13
  c1e1cf:	lea    rdx,[r15+rax*8]
  c1e1d3:	mov    DWORD PTR [rsp+0x25c],r14d
  c1e1db:	cmp    DWORD PTR [rdx],0xb
  c1e1de:	jne    c1e3f1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3551>
  c1e1e4:	mov    r13,QWORD PTR [rdx+0x8]
  c1e1e8:	cmp    BYTE PTR [r13+0x10],0xf
  c1e1ed:	jne    c1e3f1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3551>
  c1e1f3:	mov    QWORD PTR [rsp+0x298],rcx
  c1e1fb:	mov    QWORD PTR [rsp+0x260],rbp
  c1e203:	mov    rbx,r8
  c1e206:	mov    r10,QWORD PTR [rsp+0x3c8]
  c1e20e:	lea    rdx,[r10+0x48]
  c1e212:	lea    rsi,[r10+0x58]
  c1e216:	lea    rdi,[r10+0x68]
  c1e21a:	lea    r8,[r10+0xf0]
  c1e221:	mov    rax,QWORD PTR [r10+0xf0]
  c1e228:	mov    r9,QWORD PTR [r10+0x118]
  c1e22f:	test   rax,rax
  c1e232:	cmove  r8,rax
  c1e236:	lea    rcx,[r10+0x100]
  c1e23d:	lea    rax,[r10+0x118]
  c1e244:	test   r9,r9
  c1e247:	cmove  rax,r9
  c1e24b:	lea    r9,[r10+0x110]
  c1e252:	movq   xmm0,QWORD PTR [r10+0x110]
  c1e25b:	movq   xmm1,QWORD PTR [r10+0x100]
  c1e264:	punpcklqdq xmm1,xmm0
  c1e268:	mov    QWORD PTR [rsp+0x70],r11
  c1e26d:	mov    r10,QWORD PTR [rip+0x22f86c]        # e4dae0 <_DYNAMIC+0x320>
  c1e274:	mov    QWORD PTR [rsp+0x78],r10
  c1e279:	mov    BYTE PTR [rsp+0xf8],0x0
  c1e281:	mov    r10,QWORD PTR [rsp+0x3d0]
  c1e289:	movups xmm0,XMMWORD PTR [r10]
  c1e28d:	movups XMMWORD PTR [rsp+0x80],xmm0
  c1e295:	movdqu xmm0,XMMWORD PTR [r10+0x10]
  c1e29b:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1e2a4:	mov    QWORD PTR [rsp+0xa0],rdx
  c1e2ac:	mov    QWORD PTR [rsp+0xa8],rsi
  c1e2b4:	mov    QWORD PTR [rsp+0xb0],rdi
  c1e2bc:	mov    QWORD PTR [rsp+0xb8],r8
  c1e2c4:	mov    rdx,QWORD PTR [rsp+0x3f8]
  c1e2cc:	mov    QWORD PTR [rsp+0xc0],rdx
  c1e2d4:	lea    rdx,[rip+0x218315]        # e365f0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x9f0>
  c1e2db:	mov    QWORD PTR [rsp+0xc8],rdx
  c1e2e3:	mov    QWORD PTR [rsp+0xd0],0x0
  c1e2ef:	pxor   xmm0,xmm0
  c1e2f3:	pcmpeqd xmm0,xmm1
  c1e2f7:	movq   xmm1,r9
  c1e2fc:	movq   xmm2,rcx
  c1e301:	punpcklqdq xmm2,xmm1
  c1e305:	pshufd xmm1,xmm0,0xb1
  c1e30a:	pand   xmm1,xmm0
  c1e30e:	pandn  xmm1,xmm2
  c1e312:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1e31b:	mov    QWORD PTR [rsp+0xf0],rax
  c1e323:	mov    rax,QWORD PTR [rsp+0x50]
  c1e328:	mov    rsi,QWORD PTR [rax+0x10]
  c1e32c:	cmp    QWORD PTR [rsp+0x408],rsi
  c1e334:	mov    rcx,QWORD PTR [rsp+0x268]
  c1e33c:	jae    c1fc0e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4d6e>
  c1e342:	lea    rdi,[r13+0x18]
  c1e346:	mov    rax,QWORD PTR [rax+0x8]
  c1e34a:	mov    r15,QWORD PTR [rax+rcx*1+0x58]
  c1e34f:	mov    rbp,rdi
  c1e352:	call   QWORD PTR [rip+0x234cf8]        # e53050 <_DYNAMIC+0x5890>
  c1e358:	mov    r8,QWORD PTR [rsp+0x3c8]
  c1e360:	sub    r8,0xffffffffffffff80
  c1e364:	mov    ecx,DWORD PTR [rsp+0x25c]
  c1e36b:	mov    QWORD PTR [rsp+0x10],rbx
  c1e370:	mov    DWORD PTR [rsp+0x8],ecx
  c1e374:	mov    QWORD PTR [rsp],rdx
  c1e378:	lea    rdi,[rsp+0x1a0]
  c1e380:	mov    rsi,QWORD PTR [rsp+0x148]
  c1e388:	mov    rdx,QWORD PTR [rsp+0x410]
  c1e390:	mov    rcx,r15
  c1e393:	mov    r9,rax
  c1e396:	call   c0ea40 <_RNvCsbxgXiyEKxkX_6bsl_vm23cached_component_method>
  c1e39b:	movzx  eax,BYTE PTR [rsp+0x1a0]
  c1e3a3:	cmp    al,0xff
  c1e3a5:	je     c1eae0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c40>
  c1e3ab:	mov    ecx,DWORD PTR [rsp+0x1a1]
  c1e3b2:	mov    edx,DWORD PTR [rsp+0x1a4]
  c1e3b9:	mov    rsi,QWORD PTR [rsp+0x40]
  c1e3be:	mov    DWORD PTR [rsi+0x4],edx
  c1e3c1:	mov    DWORD PTR [rsi+0x1],ecx
  c1e3c4:	mov    rcx,QWORD PTR [rsp+0x1a8]
  c1e3cc:	movups xmm0,XMMWORD PTR [rsp+0x1c0]
  c1e3d4:	movups XMMWORD PTR [rsi+0x20],xmm0
  c1e3d8:	movdqu xmm0,XMMWORD PTR [rsp+0x1b0]
  c1e3e1:	movdqu XMMWORD PTR [rsi+0x10],xmm0
  c1e3e6:	mov    BYTE PTR [rsi],al
  c1e3e8:	mov    QWORD PTR [rsi+0x8],rcx
  c1e3ec:	jmp    c1e52a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x368a>
  c1e3f1:	mov    rsi,QWORD PTR [rsp+0x3c8]
  c1e3f9:	cmp    QWORD PTR [rsi+0x40],r14
  c1e3fd:	jbe    c1e4c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3628>
  c1e403:	mov    rax,QWORD PTR [rsi+0x38]
  c1e407:	movzx  eax,BYTE PTR [rax+r14*1]
  c1e40c:	mov    QWORD PTR [rsp+0x1a0],r8
  c1e414:	lea    rdi,[rsp+0x25c]
  c1e41c:	mov    QWORD PTR [rsp+0x1a8],rdi
  c1e424:	mov    QWORD PTR [rsp+0x1b0],rdx
  c1e42c:	cmp    al,0xff
  c1e42e:	je     c1e4e8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3648>
  c1e434:	mov    r8,QWORD PTR [rsi+0x58]
  c1e438:	mov    rsi,QWORD PTR [rsi+0x60]
  c1e43c:	mov    rdi,QWORD PTR [rsi+0x10]
  c1e440:	dec    rdi
  c1e443:	and    rdi,0xfffffffffffffff0
  c1e447:	add    rdi,r8
  c1e44a:	add    rdi,0x10
  c1e44e:	mov    QWORD PTR [rsp+0x8],rsi
  c1e453:	mov    QWORD PTR [rsp],rdi
  c1e457:	movzx  esi,al
  c1e45a:	lea    rdi,[rsp+0x70]
  c1e45f:	mov    r8,rbp
  c1e462:	mov    r9,r11
  c1e465:	call   QWORD PTR [rip+0x234b75]        # e52fe0 <_DYNAMIC+0x5820>
  c1e46b:	movzx  eax,BYTE PTR [rsp+0x70]
  c1e470:	cmp    al,0xff
  c1e472:	je     c1ecd5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3e35>
  c1e478:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1e47d:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1e486:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1e48f:	movdqu XMMWORD PTR [rsp+0x1af],xmm1
  c1e498:	movaps XMMWORD PTR [rsp+0x1a0],xmm0
  c1e4a0:	mov    rcx,QWORD PTR [rsp+0x40]
  c1e4a5:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1e4aa:	movups xmm0,XMMWORD PTR [rsp+0x1af]
  c1e4b2:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1e4b6:	movdqa xmm0,XMMWORD PTR [rsp+0x1a0]
  c1e4bf:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1e4c4:	mov    BYTE PTR [rcx],al
  c1e4c6:	jmp    c1e52a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x368a>
  c1e4c8:	mov    QWORD PTR [rsp+0x1a0],r8
  c1e4d0:	lea    rax,[rsp+0x25c]
  c1e4d8:	mov    QWORD PTR [rsp+0x1a8],rax
  c1e4e0:	mov    QWORD PTR [rsp+0x1b0],rdx
  c1e4e8:	lea    rdi,[rsp+0x70]
  c1e4ed:	lea    rsi,[rsp+0x1a0]
  c1e4f5:	call   c0b960 <_RNCNvCsbxgXiyEKxkX_6bsl_vm9step_colds_0B3_>
  c1e4fa:	movzx  eax,WORD PTR [rsp+0x70]
  c1e4ff:	movups xmm0,XMMWORD PTR [rsp+0x72]
  c1e504:	mov    rcx,QWORD PTR [rsp+0x40]
  c1e509:	movups XMMWORD PTR [rcx+0x2],xmm0
  c1e50d:	movups xmm0,XMMWORD PTR [rsp+0x82]
  c1e515:	movups XMMWORD PTR [rcx+0x12],xmm0
  c1e519:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1e522:	movdqu XMMWORD PTR [rcx+0x20],xmm0
  c1e527:	mov    WORD PTR [rcx],ax
  c1e52a:	mov    eax,DWORD PTR [rsp+0x68]
  c1e52e:	test   al,al
  c1e530:	je     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1e536:	lea    rdi,[rsp+0x150]
  c1e53e:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1e543:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1e548:	xor    ebp,ebp
  c1e54a:	mov    rax,QWORD PTR [rsp+0x50]
  c1e54f:	mov    rsi,QWORD PTR [rax+0x10]
  c1e553:	mov    rdi,QWORD PTR [rsp+0x408]
  c1e55b:	cmp    rdi,rsi
  c1e55e:	jae    c1fbea <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4d4a>
  c1e564:	mov    rax,QWORD PTR [rax+0x8]
  c1e568:	inc    QWORD PTR [rax+r15*1+0x58]
  c1e56d:	test   bpl,bpl
  c1e570:	je     c1e57f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x36df>
  c1e572:	lea    rdi,[rsp+0x110]
  c1e57a:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1e57f:	lea    rdi,[rsp+0x220]
  c1e587:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1e58c:	jmp    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1e591:	mov    eax,ebx
  c1e593:	cmp    QWORD PTR [r13+0x40],rax
  c1e597:	jbe    c1ed44 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3ea4>
  c1e59d:	mov    rcx,QWORD PTR [r13+0x38]
  c1e5a1:	lea    rax,[rax+rax*2]
  c1e5a5:	mov    rdx,QWORD PTR [rcx+rax*8+0x8]
  c1e5aa:	mov    rcx,QWORD PTR [rcx+rax*8+0x10]
  c1e5af:	mov    rax,QWORD PTR [rsp+0x120]
  c1e5b7:	mov    QWORD PTR [rsp+0x160],rax
  c1e5bf:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c1e5c8:	movdqa XMMWORD PTR [rsp+0x150],xmm0
  c1e5d1:	lea    rdi,[rsp+0x70]
  c1e5d6:	lea    rsi,[rsp+0x220]
  c1e5de:	lea    r8,[rsp+0x150]
  c1e5e6:	call   QWORD PTR [rip+0x234a04]        # e52ff0 <_DYNAMIC+0x5830>
  c1e5ec:	cmp    BYTE PTR [rsp+0x70],0xff
  c1e5f1:	je     c1efc1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4121>
  c1e5f7:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1e5fd:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1e606:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1e60f:	mov    rax,QWORD PTR [rsp+0x40]
  c1e614:	movdqu XMMWORD PTR [rax+0x20],xmm2
  c1e619:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1e61e:	movdqu XMMWORD PTR [rax],xmm0
  c1e622:	cmp    BYTE PTR [rsp+0x1a0],0xff
  c1e62a:	je     c1ddd2 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f32>
  c1e630:	lea    rdi,[rsp+0x1a0]
  c1e638:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1e63d:	jmp    c1ddd2 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f32>
  c1e642:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1e648:	movdqu xmm1,XMMWORD PTR [rsp+0x88]
  c1e651:	movdqu xmm2,XMMWORD PTR [rsp+0x98]
  c1e65a:	movdqu XMMWORD PTR [rsp+0x1c4],xmm2
  c1e663:	movdqu XMMWORD PTR [rsp+0x1b4],xmm1
  c1e66c:	movdqu XMMWORD PTR [rsp+0x1a4],xmm0
  c1e675:	jmp    c1bd1f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0xe7f>
  c1e67a:	mov    rbx,QWORD PTR [rcx+0x8]
  c1e67e:	mov    eax,0x6
  c1e683:	jmp    c1e68e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37ee>
  c1e685:	mov    rbx,QWORD PTR [rcx+0x8]
  c1e689:	mov    eax,0xb
  c1e68e:	inc    QWORD PTR [rbx]
  c1e691:	jne    c1e6a1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3801>
  c1e693:	ud2
  c1e695:	mov    eax,0x2
  c1e69a:	jmp    c1e6a1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3801>
  c1e69c:	mov    eax,0x3
  c1e6a1:	shl    r14,0x20
  c1e6a5:	or     r14,rax
  c1e6a8:	mov    QWORD PTR [rsp+0x1a0],r14
  c1e6b0:	mov    QWORD PTR [rsp+0x1a8],rbx
  c1e6b8:	mov    rax,QWORD PTR [rsp+0x268]
  c1e6c0:	mov    QWORD PTR [rsp+0x1b0],rax
  c1e6c8:	mov    al,0x1
  c1e6ca:	lea    rdx,[rip+0xffffffffff6a7c4b]        # 2c631c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x195b>
  c1e6d1:	mov    rcx,QWORD PTR [rsp+0x40]
  c1e6d6:	mov    BYTE PTR [rcx],al
  c1e6d8:	mov    QWORD PTR [rcx+0x8],rdx
  c1e6dc:	mov    QWORD PTR [rcx+0x10],0xa
  c1e6e4:	lea    rax,[rip+0xffffffffff6a7c3b]        # 2c6326 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1965>
  c1e6eb:	mov    QWORD PTR [rcx+0x18],rax
  c1e6ef:	mov    QWORD PTR [rcx+0x20],0x1c
  c1e6f7:	mov    eax,DWORD PTR [rsp+0x1a0]
  c1e6fe:	mov    edx,eax
  c1e700:	sub    edx,0x2
  c1e703:	mov    ecx,0x3
  c1e708:	cmovae ecx,edx
  c1e70b:	cmp    ecx,0x8
  c1e70e:	ja     c1e78a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x38ea>
  c1e710:	mov    edx,0x1e7
  c1e715:	bt     edx,ecx
  c1e718:	jae    c1e747 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x38a7>
  c1e71a:	mov    rsi,QWORD PTR [rsp+0x110]
  c1e722:	test   rsi,rsi
  c1e725:	je     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1e72b:	mov    rdi,QWORD PTR [rsp+0x118]
  c1e733:	shl    rsi,0x3
  c1e737:	mov    edx,0x8
  c1e73c:	call   QWORD PTR [rip+0x22f2be]        # e4da00 <_DYNAMIC+0x240>
  c1e742:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1e747:	cmp    ecx,0x3
  c1e74a:	jne    c1e76d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x38cd>
  c1e74c:	test   eax,eax
  c1e74e:	je     c1e71a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x387a>
  c1e750:	mov    rax,QWORD PTR [rsp+0x1a8]
  c1e758:	dec    QWORD PTR [rax]
  c1e75b:	jne    c1e71a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x387a>
  c1e75d:	lea    rdi,[rsp+0x1a8]
  c1e765:	call   QWORD PTR [rip+0x22f29d]        # e4da08 <_DYNAMIC+0x248>
  c1e76b:	jmp    c1e71a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x387a>
  c1e76d:	mov    rax,QWORD PTR [rsp+0x1a8]
  c1e775:	dec    QWORD PTR [rax]
  c1e778:	jne    c1e71a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x387a>
  c1e77a:	lea    rdi,[rsp+0x1a8]
  c1e782:	call   QWORD PTR [rip+0x22f288]        # e4da10 <_DYNAMIC+0x250>
  c1e788:	jmp    c1e71a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x387a>
  c1e78a:	mov    rax,QWORD PTR [rsp+0x1a8]
  c1e792:	dec    QWORD PTR [rax]
  c1e795:	jne    c1e71a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x387a>
  c1e797:	lea    rdi,[rsp+0x1a8]
  c1e79f:	call   QWORD PTR [rip+0x22f273]        # e4da18 <_DYNAMIC+0x258>
  c1e7a5:	jmp    c1e71a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x387a>
  c1e7aa:	add    rax,QWORD PTR [rdx+0x60]
  c1e7ae:	mov    rsi,QWORD PTR [rsp+0x48]
  c1e7b3:	mov    rcx,QWORD PTR [rsi+0x8]
  c1e7b7:	mov    rdx,QWORD PTR [rsp+0x280]
  c1e7bf:	mov    QWORD PTR [rsp+0x160],rdx
  c1e7c7:	movdqa xmm0,XMMWORD PTR [rsp+0x270]
  c1e7d0:	movdqa XMMWORD PTR [rsp+0x150],xmm0
  c1e7d9:	cmp    rax,QWORD PTR [rsi+0x10]
  c1e7dd:	jae    c1e831 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3991>
  c1e7df:	lea    rax,[rax+rax*2]
  c1e7e3:	lea    r14,[rcx+rax*8]
  c1e7e7:	mov    rdi,r14
  c1e7ea:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1e7ef:	mov    rax,QWORD PTR [rsp+0x280]
  c1e7f7:	mov    QWORD PTR [r14+0x10],rax
  c1e7fb:	movdqa xmm0,XMMWORD PTR [rsp+0x270]
  c1e804:	movdqu XMMWORD PTR [r14],xmm0
  c1e809:	mov    rax,QWORD PTR [rsp+0x50]
  c1e80e:	mov    rsi,QWORD PTR [rax+0x10]
  c1e812:	cmp    r15,rsi
  c1e815:	jae    c1fc35 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4d95>
  c1e81b:	mov    rax,QWORD PTR [rax+0x8]
  c1e81f:	mov    rcx,QWORD PTR [rsp+0x148]
  c1e827:	inc    QWORD PTR [rax+rcx*1+0x58]
  c1e82c:	jmp    c1e8bd <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3a1d>
  c1e831:	lea    rdi,[rsp+0x150]
  c1e839:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1e83e:	jmp    c1e8dc <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3a3c>
  c1e843:	add    rax,QWORD PTR [rdx+0x60]
  c1e847:	mov    rsi,QWORD PTR [rsp+0x48]
  c1e84c:	mov    rcx,QWORD PTR [rsi+0x8]
  c1e850:	mov    rdx,QWORD PTR [rsp+0x230]
  c1e858:	mov    QWORD PTR [rsp+0x160],rdx
  c1e860:	movdqa xmm0,XMMWORD PTR [rsp+0x220]
  c1e869:	movdqa XMMWORD PTR [rsp+0x150],xmm0
  c1e872:	cmp    rax,QWORD PTR [rsi+0x10]
  c1e876:	jae    c1e8cf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3a2f>
  c1e878:	lea    rax,[rax+rax*2]
  c1e87c:	lea    r14,[rcx+rax*8]
  c1e880:	mov    rdi,r14
  c1e883:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1e888:	mov    rax,QWORD PTR [rsp+0x230]
  c1e890:	mov    QWORD PTR [r14+0x10],rax
  c1e894:	movdqa xmm0,XMMWORD PTR [rsp+0x220]
  c1e89d:	movdqu XMMWORD PTR [r14],xmm0
  c1e8a2:	mov    rax,QWORD PTR [rsp+0x50]
  c1e8a7:	mov    rsi,QWORD PTR [rax+0x10]
  c1e8ab:	cmp    r15,rsi
  c1e8ae:	jae    c1fc4a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4daa>
  c1e8b4:	mov    rax,QWORD PTR [rax+0x8]
  c1e8b8:	inc    QWORD PTR [rax+rbx*1+0x58]
  c1e8bd:	lea    rdi,[rsp+0x1a0]
  c1e8c5:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1e8ca:	jmp    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1e8cf:	lea    rdi,[rsp+0x150]
  c1e8d7:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1e8dc:	mov    rcx,QWORD PTR [rsp+0x40]
  c1e8e1:	mov    BYTE PTR [rcx],0x1f
  c1e8e4:	lea    rax,[rip+0xffffffffff6a8021]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1e8eb:	mov    QWORD PTR [rcx+0x8],rax
  c1e8ef:	mov    QWORD PTR [rcx+0x10],0x4f
  c1e8f7:	jmp    c1c20a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x136a>
  c1e8fc:	mov    rcx,QWORD PTR [rsp+0x40]
  c1e901:	mov    BYTE PTR [rcx],0x1f
  c1e904:	lea    rax,[rip+0xffffffffff6a78ab]        # 2c61b6 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x17f5>
  c1e90b:	mov    QWORD PTR [rcx+0x8],rax
  c1e90f:	mov    QWORD PTR [rcx+0x10],0x57
  c1e917:	lea    rdi,[rsp+0x1a0]
  c1e91f:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c1e924:	jmp    c1d907 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2a67>
  c1e929:	mov    QWORD PTR [rsp+0x80],0x3a
  c1e935:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1e93e:	mov    rcx,QWORD PTR [rsp+0x40]
  c1e943:	movdqu XMMWORD PTR [rcx+0x20],xmm0
  c1e948:	mov    rax,QWORD PTR [rsp+0x80]
  c1e950:	mov    QWORD PTR [rcx+0x10],rax
  c1e954:	mov    rax,QWORD PTR [rsp+0x88]
  c1e95c:	mov    QWORD PTR [rcx+0x18],rax
  c1e960:	mov    BYTE PTR [rcx],0x1f
  c1e963:	lea    rax,[rip+0xffffffffff6a8045]        # 2c69af <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x62c>
  c1e96a:	mov    QWORD PTR [rcx+0x8],rax
  c1e96e:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1e973:	mov    rcx,QWORD PTR [rsp+0x40]
  c1e978:	mov    BYTE PTR [rcx],0x1f
  c1e97b:	lea    rax,[rip+0xffffffffff6a7dd5]        # 2c6757 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x3d4>
  c1e982:	mov    QWORD PTR [rcx+0x8],rax
  c1e986:	mov    QWORD PTR [rcx+0x10],0x5c
  c1e98e:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1e993:	add    rcx,QWORD PTR [rsi+0x60]
  c1e997:	cmp    rcx,rax
  c1e99a:	jae    c1eab3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c13>
  c1e9a0:	mov    rax,QWORD PTR [rsp+0x48]
  c1e9a5:	mov    rax,QWORD PTR [rax+0x8]
  c1e9a9:	lea    rcx,[rcx+rcx*2]
  c1e9ad:	lea    rsi,[rax+rcx*8]
  c1e9b1:	lea    rdi,[rsp+0x70]
  c1e9b6:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1e9bb:	mov    rax,QWORD PTR [rsp+0x70]
  c1e9c0:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1e9c6:	mov    QWORD PTR [rsp+0x150],rax
  c1e9ce:	movdqu XMMWORD PTR [rsp+0x158],xmm0
  c1e9d7:	cmp    QWORD PTR [r12+0x10],rbx
  c1e9dc:	jbe    c1edcf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3f2f>
  c1e9e2:	mov    r13,QWORD PTR [r12+0x8]
  c1e9e7:	lea    rax,[rip+0xffffffffff6a7fc1]        # 2c69af <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x62c>
  c1e9ee:	mov    QWORD PTR [rsp+0x78],rax
  c1e9f3:	mov    QWORD PTR [rsp+0x80],0x3a
  c1e9ff:	mov    BYTE PTR [rsp+0x70],0x1f
  c1ea04:	lea    rdi,[rsp+0x70]
  c1ea09:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1ea0e:	shl    rbx,0x5
  c1ea12:	mov    rax,QWORD PTR [r13+rbx*1+0x8]
  c1ea17:	mov    rcx,QWORD PTR [r13+rbx*1+0x10]
  c1ea1c:	mov    rdx,QWORD PTR [rsp+0x160]
  c1ea24:	mov    QWORD PTR [rsp+0x1b0],rdx
  c1ea2c:	movdqu xmm0,XMMWORD PTR [rsp+0x150]
  c1ea35:	movdqa XMMWORD PTR [rsp+0x1a0],xmm0
  c1ea3e:	cmp    rcx,r14
  c1ea41:	jbe    c1f089 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x41e9>
  c1ea47:	lea    rcx,[r14+r14*2]
  c1ea4b:	lea    r14,[rax+rcx*8]
  c1ea4f:	mov    rax,QWORD PTR [rsp+0x160]
  c1ea57:	mov    QWORD PTR [rsp+0x80],rax
  c1ea5f:	movups xmm0,XMMWORD PTR [rsp+0x150]
  c1ea67:	movaps XMMWORD PTR [rsp+0x70],xmm0
  c1ea6c:	mov    rdi,r14
  c1ea6f:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1ea74:	mov    rax,QWORD PTR [rsp+0x80]
  c1ea7c:	mov    QWORD PTR [r14+0x10],rax
  c1ea80:	movdqa xmm0,XMMWORD PTR [rsp+0x70]
  c1ea86:	movdqu XMMWORD PTR [r14],xmm0
  c1ea8b:	mov    rax,QWORD PTR [rsp+0x50]
  c1ea90:	mov    rsi,QWORD PTR [rax+0x10]
  c1ea94:	mov    rdi,QWORD PTR [rsp+0x408]
  c1ea9c:	cmp    rdi,rsi
  c1ea9f:	jae    c1fc9e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4dfe>
  c1eaa5:	mov    rax,QWORD PTR [rax+0x8]
  c1eaa9:	inc    QWORD PTR [rax+r15*1+0x58]
  c1eaae:	jmp    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1eab3:	mov    rcx,QWORD PTR [rsp+0x40]
  c1eab8:	mov    BYTE PTR [rcx],0x1f
  c1eabb:	lea    rax,[rip+0xffffffffff6a7656]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1eac2:	mov    QWORD PTR [rcx+0x8],rax
  c1eac6:	mov    QWORD PTR [rcx+0x10],0x4f
  c1eace:	add    rsp,0x388
  c1ead5:	pop    rbx
  c1ead6:	pop    r12
  c1ead8:	pop    r13
  c1eada:	pop    r14
  c1eadc:	pop    r15
  c1eade:	pop    rbp
  c1eadf:	ret
  c1eae0:	mov    r14,QWORD PTR [rsp+0x1a8]
  c1eae8:	test   r14,r14
  c1eaeb:	je     c1ef15 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4075>
  c1eaf1:	mov    rdi,rbp
  c1eaf4:	call   QWORD PTR [rip+0x23455e]        # e53058 <_DYNAMIC+0x5898>
  c1eafa:	mov    rcx,QWORD PTR [rax+0x10]
  c1eafe:	mov    rax,QWORD PTR [rax+0x18]
  c1eb02:	cmp    BYTE PTR [r14+0x20],r12b
  c1eb06:	ja     c1efe1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4141>
  c1eb0c:	cmp    BYTE PTR [r14+0x21],r12b
  c1eb10:	jb     c1efe1 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4141>
  c1eb16:	mov    rax,QWORD PTR [r13+0x18]
  c1eb1a:	mov    rdx,QWORD PTR [r13+0x20]
  c1eb1e:	mov    rcx,QWORD PTR [rdx+0x10]
  c1eb22:	dec    rcx
  c1eb25:	and    rcx,0xfffffffffffffff0
  c1eb29:	lea    rsi,[rax+rcx*1]
  c1eb2d:	add    rsi,0x10
  c1eb31:	mov    rax,QWORD PTR [r14+0x8]
  c1eb35:	cmp    BYTE PTR [r14],0x0
  c1eb39:	je     c1f199 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x42f9>
  c1eb3f:	lea    rdi,[rsp+0x1a0]
  c1eb47:	lea    r9,[rsp+0x70]
  c1eb4c:	mov    rcx,QWORD PTR [rsp+0x298]
  c1eb54:	mov    r8,QWORD PTR [rsp+0x260]
  c1eb5c:	call   rax
  c1eb5e:	mov    rax,QWORD PTR [rsp+0x1a0]
  c1eb66:	cmp    rax,0xfffffffffffffffe
  c1eb6a:	je     c1f1fc <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x435c>
  c1eb70:	mov    rcx,QWORD PTR [rsp+0x218]
  c1eb78:	mov    QWORD PTR [rsp+0x350],rcx
  c1eb80:	movups xmm0,XMMWORD PTR [rsp+0x208]
  c1eb88:	movaps XMMWORD PTR [rsp+0x340],xmm0
  c1eb90:	movups xmm0,XMMWORD PTR [rsp+0x1f8]
  c1eb98:	movaps XMMWORD PTR [rsp+0x330],xmm0
  c1eba0:	movups xmm0,XMMWORD PTR [rsp+0x1e8]
  c1eba8:	movaps XMMWORD PTR [rsp+0x320],xmm0
  c1ebb0:	movups xmm0,XMMWORD PTR [rsp+0x1a8]
  c1ebb8:	movdqu xmm1,XMMWORD PTR [rsp+0x1b8]
  c1ebc1:	movdqu xmm2,XMMWORD PTR [rsp+0x1c8]
  c1ebca:	movups xmm3,XMMWORD PTR [rsp+0x1d8]
  c1ebd2:	movaps XMMWORD PTR [rsp+0x310],xmm3
  c1ebda:	movaps XMMWORD PTR [rsp+0x220],xmm0
  c1ebe2:	movdqa XMMWORD PTR [rsp+0x230],xmm1
  c1ebeb:	movdqa XMMWORD PTR [rsp+0x240],xmm2
  c1ebf4:	movdqa XMMWORD PTR [rsp+0x300],xmm2
  c1ebfd:	movdqa XMMWORD PTR [rsp+0x2f0],xmm1
  c1ec06:	movaps XMMWORD PTR [rsp+0x2e0],xmm0
  c1ec0e:	cmp    rax,0xffffffffffffffff
  c1ec12:	je     c1f331 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4491>
  c1ec18:	mov    rdx,QWORD PTR [rsp+0x400]
  c1ec20:	mov    QWORD PTR [rsp+0x1a0],rax
  c1ec28:	movaps xmm0,XMMWORD PTR [rsp+0x220]
  c1ec30:	movaps xmm1,XMMWORD PTR [rsp+0x230]
  c1ec38:	movaps xmm2,XMMWORD PTR [rsp+0x240]
  c1ec40:	movups XMMWORD PTR [rsp+0x1a8],xmm0
  c1ec48:	movups XMMWORD PTR [rsp+0x1b8],xmm1
  c1ec50:	movups XMMWORD PTR [rsp+0x1c8],xmm2
  c1ec58:	movdqa xmm0,XMMWORD PTR [rsp+0x310]
  c1ec61:	movdqa xmm1,XMMWORD PTR [rsp+0x320]
  c1ec6a:	movdqa xmm2,XMMWORD PTR [rsp+0x330]
  c1ec73:	movaps xmm3,XMMWORD PTR [rsp+0x340]
  c1ec7b:	movdqu XMMWORD PTR [rsp+0x1d8],xmm0
  c1ec84:	movdqu XMMWORD PTR [rsp+0x1e8],xmm1
  c1ec8d:	movdqu XMMWORD PTR [rsp+0x1f8],xmm2
  c1ec96:	movups XMMWORD PTR [rsp+0x208],xmm3
  c1ec9e:	mov    rax,QWORD PTR [rsp+0x350]
  c1eca6:	mov    QWORD PTR [rsp+0x218],rax
  c1ecae:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1ecb6:	lea    r8,[rsp+0x1a0]
  c1ecbe:	mov    rdi,QWORD PTR [rsp+0x40]
  c1ecc3:	mov    rsi,QWORD PTR [rsp+0x3f8]
  c1eccb:	call   c49ea0 <_RNvMs1_NtCsbxgXiyEKxkX_6bsl_vm9schedulerNtB5_10AsyncState20begin_sync_host_call>
  c1ecd0:	jmp    c1e52a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x368a>
  c1ecd5:	mov    rax,QWORD PTR [rsp+0x88]
  c1ecdd:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1ece3:	movdqa XMMWORD PTR [rsp+0x270],xmm0
  c1ecec:	mov    QWORD PTR [rsp+0x280],rax
  c1ecf4:	mov    rax,QWORD PTR [rsp+0x50]
  c1ecf9:	mov    rsi,QWORD PTR [rax+0x10]
  c1ecfd:	mov    rbx,QWORD PTR [rsp+0x408]
  c1ed05:	cmp    rbx,rsi
  c1ed08:	mov    r15,QWORD PTR [rsp+0x268]
  c1ed10:	jae    c1fc5f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4dbf>
  c1ed16:	mov    rsi,QWORD PTR [rax+0x8]
  c1ed1a:	lea    rdx,[rsi+r15*1]
  c1ed1e:	movzx  ecx,BYTE PTR [rsp+0x108]
  c1ed26:	mov    rax,rcx
  c1ed29:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c1ed2e:	jae    c1ee26 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3f86>
  c1ed34:	mov    rax,QWORD PTR [rdx+0x28]
  c1ed38:	shl    ecx,0x4
  c1ed3b:	mov    rax,QWORD PTR [rax+rcx*1]
  c1ed3f:	jmp    c1ee2a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3f8a>
  c1ed44:	mov    rcx,QWORD PTR [rsp+0x40]
  c1ed49:	mov    BYTE PTR [rcx],0x1f
  c1ed4c:	lea    rax,[rip+0xffffffffff6a7463]        # 2c61b6 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x17f5>
  c1ed53:	mov    QWORD PTR [rcx+0x8],rax
  c1ed57:	mov    QWORD PTR [rcx+0x10],0x57
  c1ed5f:	lea    rdi,[rsp+0x1a0]
  c1ed67:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1ed6c:	jmp    c1ddc5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x2f25>
  c1ed71:	lea    rdi,[rsp+0x70]
  c1ed76:	mov    rsi,r15
  c1ed79:	mov    edx,DWORD PTR [rsp+0x268]
  c1ed80:	call   c3ff20 <_RNvMs0_NtCsbxgXiyEKxkX_6bsl_vm7modulesNtB5_14CatalogContext7program>
  c1ed85:	movzx  eax,BYTE PTR [rsp+0x70]
  c1ed8a:	cmp    al,0xff
  c1ed8c:	je     c1f09b <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x41fb>
  c1ed92:	mov    ecx,DWORD PTR [rsp+0x71]
  c1ed96:	mov    edx,DWORD PTR [rsp+0x74]
  c1ed9a:	mov    rsi,QWORD PTR [rsp+0x40]
  c1ed9f:	mov    DWORD PTR [rsi+0x4],edx
  c1eda2:	mov    DWORD PTR [rsi+0x1],ecx
  c1eda5:	mov    rcx,QWORD PTR [rsp+0x78]
  c1edaa:	movups xmm0,XMMWORD PTR [rsp+0x90]
  c1edb2:	movups XMMWORD PTR [rsi+0x20],xmm0
  c1edb6:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c1edbf:	movdqu XMMWORD PTR [rsi+0x10],xmm0
  c1edc4:	mov    BYTE PTR [rsi],al
  c1edc6:	mov    QWORD PTR [rsi+0x8],rcx
  c1edca:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1edcf:	mov    QWORD PTR [rsp+0x80],0x3a
  c1eddb:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1ede4:	mov    rcx,QWORD PTR [rsp+0x40]
  c1ede9:	movdqu XMMWORD PTR [rcx+0x20],xmm0
  c1edee:	mov    rax,QWORD PTR [rsp+0x80]
  c1edf6:	mov    QWORD PTR [rcx+0x10],rax
  c1edfa:	mov    rax,QWORD PTR [rsp+0x88]
  c1ee02:	mov    QWORD PTR [rcx+0x18],rax
  c1ee06:	mov    BYTE PTR [rcx],0x1f
  c1ee09:	lea    rax,[rip+0xffffffffff6a7b9f]        # 2c69af <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x62c>
  c1ee10:	mov    QWORD PTR [rcx+0x8],rax
  c1ee14:	lea    rdi,[rsp+0x150]
  c1ee1c:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1ee21:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1ee26:	add    rax,QWORD PTR [rdx+0x60]
  c1ee2a:	mov    rsi,QWORD PTR [rsp+0x48]
  c1ee2f:	mov    rcx,QWORD PTR [rsi+0x8]
  c1ee33:	mov    rdx,QWORD PTR [rsp+0x280]
  c1ee3b:	mov    QWORD PTR [rsp+0x80],rdx
  c1ee43:	movdqa xmm0,XMMWORD PTR [rsp+0x270]
  c1ee4c:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c1ee52:	cmp    rax,QWORD PTR [rsi+0x10]
  c1ee56:	jae    c1eeba <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x401a>
  c1ee58:	lea    rax,[rax+rax*2]
  c1ee5c:	lea    r14,[rcx+rax*8]
  c1ee60:	mov    rdi,r14
  c1ee63:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1ee68:	mov    rax,QWORD PTR [rsp+0x280]
  c1ee70:	mov    QWORD PTR [r14+0x10],rax
  c1ee74:	movdqa xmm0,XMMWORD PTR [rsp+0x270]
  c1ee7d:	movdqu XMMWORD PTR [r14],xmm0
  c1ee82:	mov    rax,QWORD PTR [rsp+0x50]
  c1ee87:	mov    rsi,QWORD PTR [rax+0x10]
  c1ee8b:	cmp    rbx,rsi
  c1ee8e:	jae    c1fc89 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4de9>
  c1ee94:	mov    rax,QWORD PTR [rax+0x8]
  c1ee98:	inc    QWORD PTR [rax+r15*1+0x58]
  c1ee9d:	cmp    BYTE PTR [rsp+0x68],0x0
  c1eea2:	je     c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1eea8:	lea    rdi,[rsp+0x150]
  c1eeb0:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1eeb5:	jmp    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1eeba:	lea    rdi,[rsp+0x70]
  c1eebf:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1eec4:	mov    rcx,QWORD PTR [rsp+0x40]
  c1eec9:	mov    BYTE PTR [rcx],0x1f
  c1eecc:	lea    rax,[rip+0xffffffffff6a7a39]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1eed3:	mov    QWORD PTR [rcx+0x8],rax
  c1eed7:	mov    QWORD PTR [rcx+0x10],0x4f
  c1eedf:	jmp    c1e52a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x368a>
  c1eee4:	mov    rax,QWORD PTR [rsp+0x88]
  c1eeec:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1eef2:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c1eefb:	mov    QWORD PTR [rsp+0x120],rax
  c1ef03:	lea    rdi,[rsp+0x1a0]
  c1ef0b:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c1ef10:	jmp    c1e047 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x31a7>
  c1ef15:	mov    eax,DWORD PTR [rsp+0x25c]
  c1ef1c:	cmp    QWORD PTR [rbx+0x40],rax
  c1ef20:	jbe    c1f179 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x42d9>
  c1ef26:	mov    rcx,QWORD PTR [rbx+0x38]
  c1ef2a:	lea    rax,[rax+rax*2]
  c1ef2e:	mov    rdx,QWORD PTR [rcx+rax*8+0x8]
  c1ef33:	mov    rcx,QWORD PTR [rcx+rax*8+0x10]
  c1ef38:	lea    rax,[rsp+0x70]
  c1ef3d:	mov    QWORD PTR [rsp],rax
  c1ef41:	lea    rdi,[rsp+0x1a0]
  c1ef49:	mov    rsi,rbp
  c1ef4c:	mov    r8,QWORD PTR [rsp+0x298]
  c1ef54:	mov    r9,QWORD PTR [rsp+0x260]
  c1ef5c:	call   QWORD PTR [rip+0x234076]        # e52fd8 <_DYNAMIC+0x5818>
  c1ef62:	movzx  eax,BYTE PTR [rsp+0x1a0]
  c1ef6a:	cmp    al,0xff
  c1ef6c:	je     c1f287 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x43e7>
  c1ef72:	movups xmm0,XMMWORD PTR [rsp+0x1a1]
  c1ef7a:	movdqu xmm1,XMMWORD PTR [rsp+0x1b0]
  c1ef83:	movdqu xmm2,XMMWORD PTR [rsp+0x1c0]
  c1ef8c:	movdqu XMMWORD PTR [rsp+0x11f],xmm1
  c1ef95:	movaps XMMWORD PTR [rsp+0x110],xmm0
  c1ef9d:	mov    rcx,QWORD PTR [rsp+0x40]
  c1efa2:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1efa7:	movups xmm0,XMMWORD PTR [rsp+0x11f]
  c1efaf:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1efb3:	movdqa xmm0,XMMWORD PTR [rsp+0x110]
  c1efbc:	jmp    c1e4bf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x361f>
  c1efc1:	cmp    BYTE PTR [rsp+0x1a0],0xff
  c1efc9:	je     c1e54a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x36aa>
  c1efcf:	lea    rdi,[rsp+0x1a0]
  c1efd7:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1efdc:	jmp    c1e54a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x36aa>
  c1efe1:	cmp    QWORD PTR [r14+0x18],0x0
  c1efe6:	je     c1f25e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x43be>
  c1efec:	mov    rdx,QWORD PTR [r14+0x10]
  c1eff0:	mov    rsi,QWORD PTR [rdx]
  c1eff3:	mov    rdx,QWORD PTR [rdx+0x8]
  c1eff7:	jmp    c1f26a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x43ca>
  c1effc:	add    rax,QWORD PTR [rdx+0x60]
  c1f000:	mov    rsi,QWORD PTR [rsp+0x48]
  c1f005:	mov    rcx,QWORD PTR [rsi+0x8]
  c1f009:	mov    rdx,QWORD PTR [rsp+0x1b0]
  c1f011:	mov    QWORD PTR [rsp+0x80],rdx
  c1f019:	movdqu xmm0,XMMWORD PTR [rsp+0x1a0]
  c1f022:	movdqa XMMWORD PTR [rsp+0x70],xmm0
  c1f028:	cmp    rax,QWORD PTR [rsi+0x10]
  c1f02c:	jae    c1f07a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x41da>
  c1f02e:	lea    rax,[rax+rax*2]
  c1f032:	lea    r14,[rcx+rax*8]
  c1f036:	mov    rdi,r14
  c1f039:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1f03e:	mov    rax,QWORD PTR [rsp+0x1b0]
  c1f046:	mov    QWORD PTR [r14+0x10],rax
  c1f04a:	movdqu xmm0,XMMWORD PTR [rsp+0x1a0]
  c1f053:	movdqu XMMWORD PTR [r14],xmm0
  c1f058:	mov    rax,QWORD PTR [rsp+0x50]
  c1f05d:	mov    rsi,QWORD PTR [rax+0x10]
  c1f061:	cmp    r15,rsi
  c1f064:	jb     c1c9bf <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b1f>
  c1f06a:	lea    rdx,[rip+0x217617]        # e36688 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xa88>
  c1f071:	mov    rdi,r15
  c1f074:	call   QWORD PTR [rip+0x22ea5e]        # e4dad8 <_DYNAMIC+0x318>
  c1f07a:	lea    rdi,[rsp+0x70]
  c1f07f:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1f084:	jmp    c1c0e7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1247>
  c1f089:	lea    rdi,[rsp+0x1a0]
  c1f091:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1f096:	jmp    c1c0e7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1247>
  c1f09b:	mov    rax,QWORD PTR [rsp+0x78]
  c1f0a0:	mov    rcx,QWORD PTR [rsp+0x260]
  c1f0a8:	cmp    QWORD PTR [rax+0x28],rcx
  c1f0ac:	jbe    c1f24a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x43aa>
  c1f0b2:	mov    rax,QWORD PTR [rax+0x20]
  c1f0b6:	imul   r14,rcx,0xc8
  c1f0bd:	mov    QWORD PTR [rsp+0x2b0],rax
  c1f0c5:	cmp    BYTE PTR [rax+r14*1+0xc1],0x0
  c1f0ce:	je     c1f29d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x43fd>
  c1f0d4:	call   QWORD PTR [rip+0x22e9e6]        # e4dac0 <_DYNAMIC+0x300>
  c1f0da:	mov    edi,0x68
  c1f0df:	mov    esi,0x1
  c1f0e4:	call   QWORD PTR [rip+0x22e9de]        # e4dac8 <_DYNAMIC+0x308>
  c1f0ea:	test   rax,rax
  c1f0ed:	je     c1fce7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4e47>
  c1f0f3:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a7a51]        # 2c6b4b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x7c8>
  c1f0fa:	movups XMMWORD PTR [rax+0x50],xmm0
  c1f0fe:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a7a36]        # 2c6b3b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x7b8>
  c1f105:	movups XMMWORD PTR [rax+0x40],xmm0
  c1f109:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a7a1b]        # 2c6b2b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x7a8>
  c1f110:	movups XMMWORD PTR [rax+0x30],xmm0
  c1f114:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a7a00]        # 2c6b1b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x798>
  c1f11b:	movups XMMWORD PTR [rax+0x20],xmm0
  c1f11f:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a79e5]        # 2c6b0b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x788>
  c1f126:	movups XMMWORD PTR [rax+0x10],xmm0
  c1f12a:	movdqu xmm0,XMMWORD PTR [rip+0xffffffffff6a79c9]        # 2c6afb <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x778>
  c1f132:	movdqu XMMWORD PTR [rax],xmm0
  c1f136:	movabs rcx,0xb0d0bdd0b0d0b6d0
  c1f140:	mov    QWORD PTR [rax+0x60],rcx
  c1f144:	mov    rcx,QWORD PTR [rsp+0x40]
  c1f149:	mov    BYTE PTR [rcx],0x1e
  c1f14c:	mov    QWORD PTR [rcx+0x8],0x68
  c1f154:	mov    QWORD PTR [rcx+0x10],rax
  c1f158:	mov    QWORD PTR [rcx+0x18],0x68
  c1f160:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1f165:	mov    rcx,QWORD PTR [rsp+0x40]
  c1f16a:	mov    BYTE PTR [rcx],0x1f
  c1f16d:	lea    rax,[rip+0xffffffffff6a78e7]        # 2c6a5b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x6d8>
  c1f174:	jmp    c1cda7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1f07>
  c1f179:	mov    rcx,QWORD PTR [rsp+0x40]
  c1f17e:	mov    BYTE PTR [rcx],0x1f
  c1f181:	lea    rax,[rip+0xffffffffff6a702e]        # 2c61b6 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x17f5>
  c1f188:	mov    QWORD PTR [rcx+0x8],rax
  c1f18c:	mov    QWORD PTR [rcx+0x10],0x57
  c1f194:	jmp    c1e52a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x368a>
  c1f199:	lea    rdi,[rsp+0x110]
  c1f1a1:	lea    r9,[rsp+0x70]
  c1f1a6:	mov    rcx,QWORD PTR [rsp+0x298]
  c1f1ae:	mov    r8,QWORD PTR [rsp+0x260]
  c1f1b6:	call   rax
  c1f1b8:	cmp    BYTE PTR [rsp+0x110],0xff
  c1f1c0:	je     c1f2d3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4433>
  c1f1c6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c1f1cf:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c1f1d8:	movdqu xmm2,XMMWORD PTR [rsp+0x130]
  c1f1e1:	movdqu XMMWORD PTR [rsp+0x1c8],xmm2
  c1f1ea:	movdqu XMMWORD PTR [rsp+0x1b8],xmm1
  c1f1f3:	movdqu XMMWORD PTR [rsp+0x1a8],xmm0
  c1f1fc:	movdqu xmm0,XMMWORD PTR [rsp+0x1a8]
  c1f205:	movdqu xmm1,XMMWORD PTR [rsp+0x1b8]
  c1f20e:	movdqu xmm2,XMMWORD PTR [rsp+0x1c8]
  c1f217:	movdqa XMMWORD PTR [rsp+0x240],xmm2
  c1f220:	movdqa XMMWORD PTR [rsp+0x230],xmm1
  c1f229:	movdqa XMMWORD PTR [rsp+0x220],xmm0
  c1f232:	mov    rax,QWORD PTR [rsp+0x40]
  c1f237:	movdqu XMMWORD PTR [rax+0x20],xmm2
  c1f23c:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1f241:	movdqu XMMWORD PTR [rax],xmm0
  c1f245:	jmp    c1e52a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x368a>
  c1f24a:	mov    rcx,QWORD PTR [rsp+0x40]
  c1f24f:	mov    BYTE PTR [rcx],0x1f
  c1f252:	lea    rax,[rip+0xffffffffff6a7855]        # 2c6aae <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x72b>
  c1f259:	jmp    c1c628 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1788>
  c1f25e:	mov    edx,0xa
  c1f263:	lea    rsi,[rip+0xffffffffff6a7a61]        # 2c6ccb <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x948>
  c1f26a:	mov    rdi,QWORD PTR [rsp+0x40]
  c1f26f:	mov    BYTE PTR [rdi],0x1c
  c1f272:	mov    QWORD PTR [rdi+0x8],rsi
  c1f276:	mov    QWORD PTR [rdi+0x10],rdx
  c1f27a:	mov    QWORD PTR [rdi+0x18],rcx
  c1f27e:	mov    QWORD PTR [rdi+0x20],rax
  c1f282:	jmp    c1e52a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x368a>
  c1f287:	mov    rax,QWORD PTR [rsp+0x1b8]
  c1f28f:	movdqu xmm0,XMMWORD PTR [rsp+0x1a8]
  c1f298:	jmp    c1ece3 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3e43>
  c1f29d:	mov    rax,QWORD PTR [rsp+0x50]
  c1f2a2:	mov    rsi,QWORD PTR [rax+0x10]
  c1f2a6:	cmp    rsi,0x3e7
  c1f2ad:	jbe    c1f358 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x44b8>
  c1f2b3:	mov    rcx,QWORD PTR [rsp+0x40]
  c1f2b8:	mov    BYTE PTR [rcx],0x23
  c1f2bb:	lea    rax,[rip+0xffffffffff6a7586]        # 2c6848 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x4c5>
  c1f2c2:	mov    QWORD PTR [rcx+0x8],rax
  c1f2c6:	mov    QWORD PTR [rcx+0x10],0x3f
  c1f2ce:	jmp    c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1f2d3:	mov    rax,QWORD PTR [rsp+0x128]
  c1f2db:	mov    QWORD PTR [rsp+0x1b8],rax
  c1f2e3:	movups xmm0,XMMWORD PTR [rsp+0x118]
  c1f2eb:	movaps XMMWORD PTR [rsp+0x220],xmm0
  c1f2f3:	movdqu xmm1,XMMWORD PTR [rsp+0x1c8]
  c1f2fc:	movdqa XMMWORD PTR [rsp+0x240],xmm1
  c1f305:	movdqu xmm2,XMMWORD PTR [rsp+0x1b8]
  c1f30e:	movdqa XMMWORD PTR [rsp+0x230],xmm2
  c1f317:	movaps XMMWORD PTR [rsp+0x2e0],xmm0
  c1f31f:	movdqa XMMWORD PTR [rsp+0x300],xmm1
  c1f328:	movdqa XMMWORD PTR [rsp+0x2f0],xmm2
  c1f331:	mov    rax,QWORD PTR [rsp+0x2f0]
  c1f339:	mov    QWORD PTR [rsp+0x280],rax
  c1f341:	movdqa xmm0,XMMWORD PTR [rsp+0x2e0]
  c1f34a:	movdqa XMMWORD PTR [rsp+0x270],xmm0
  c1f353:	jmp    c1ecf4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3e54>
  c1f358:	cmp    QWORD PTR [rsp+0x408],rsi
  c1f360:	jae    c1fcf7 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4e57>
  c1f366:	mov    rax,QWORD PTR [rsp+0x50]
  c1f36b:	mov    rax,QWORD PTR [rax+0x8]
  c1f36f:	imul   rcx,QWORD PTR [rsp+0x408],0x78
  c1f378:	mov    QWORD PTR [rsp+0x2a8],rcx
  c1f380:	inc    QWORD PTR [rax+rcx*1+0x58]
  c1f385:	lea    rdi,[rsp+0x70]
  c1f38a:	mov    ecx,0x8
  c1f38f:	mov    r8d,0x10
  c1f395:	mov    rsi,r12
  c1f398:	xor    edx,edx
  c1f39a:	call   c4f8a0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsbxgXiyEKxkX_6bsl_vm>
  c1f39f:	mov    rdi,QWORD PTR [rsp+0x78]
  c1f3a4:	cmp    BYTE PTR [rsp+0x70],0x0
  c1f3a9:	jne    c1fad4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4c34>
  c1f3af:	add    QWORD PTR [rsp+0x2b0],r14
  c1f3b7:	mov    rax,QWORD PTR [rsp+0x80]
  c1f3bf:	mov    QWORD PTR [rsp+0x150],rdi
  c1f3c7:	mov    QWORD PTR [rsp+0x158],rax
  c1f3cf:	mov    QWORD PTR [rsp+0x160],0x0
  c1f3db:	mov    QWORD PTR [rsp+0x1a0],0x0
  c1f3e7:	mov    QWORD PTR [rsp+0x1a8],0x8
  c1f3f3:	mov    QWORD PTR [rsp+0x1b0],0x0
  c1f3ff:	xor    ebp,ebp
  c1f401:	lea    rax,[rip+0x217328]        # e36730 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xb30>
  c1f408:	mov    QWORD PTR [rsp+0x2a0],rax
  c1f410:	jmp    c1f43e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x459e>
  c1f412:	mov    rcx,QWORD PTR [rcx+0x28]
  c1f416:	shl    eax,0x4
  c1f419:	mov    r15,QWORD PTR [rcx+rax*1]
  c1f41d:	mov    al,0x1
  c1f41f:	inc    QWORD PTR [rsp+0x108]
  c1f427:	add    rbp,0x4
  c1f42b:	movzx  edx,al
  c1f42e:	lea    rdi,[rsp+0x150]
  c1f436:	mov    rsi,r15
  c1f439:	call   c24720 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCsbxgXiyEKxkX_6bsl_vm9ParamSlotE8push_mutBG_>
  c1f43e:	cmp    QWORD PTR [rsp+0x298],rbp
  c1f446:	je     c1f78a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x48ea>
  c1f44c:	mov    rdi,rbp
  c1f44f:	movzx  eax,BYTE PTR [rbx+rbp*1]
  c1f453:	lea    rcx,[rip+0xffffffffff6a6b2e]        # 2c5f88 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x15c7>
  c1f45a:	movsxd rax,DWORD PTR [rcx+rax*4]
  c1f45e:	add    rax,rcx
  c1f461:	mov    rcx,QWORD PTR [rsp+0x408]
  c1f469:	mov    rdx,QWORD PTR [rsp+0x50]
  c1f46e:	jmp    rax
  c1f470:	mov    rsi,QWORD PTR [rdx+0x10]
  c1f474:	cmp    rcx,rsi
  c1f477:	jae    c1fcb4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4e14>
  c1f47d:	mov    rdx,QWORD PTR [rdx+0x8]
  c1f481:	mov    rsi,QWORD PTR [rsp+0x2a8]
  c1f489:	lea    rcx,[rdx+rsi*1]
  c1f48d:	movzx  eax,BYTE PTR [rsp+0x108]
  c1f495:	jmp    c1f726 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4886>
  c1f49a:	movzx  eax,WORD PTR [rbx+rdi*1+0x2]
  c1f49f:	cmp    QWORD PTR [rsp+0x148],rax
  c1f4a7:	mov    rcx,QWORD PTR [rsp+0x68]
  c1f4ac:	jbe    c1f841 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x49a1>
  c1f4b2:	cmp    BYTE PTR [rcx+rax*8],0x0
  c1f4b6:	je     c1f841 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x49a1>
  c1f4bc:	mov    r12d,DWORD PTR [rcx+rax*8+0x4]
  c1f4c1:	mov    rcx,QWORD PTR [rsp+0x3e8]
  c1f4c9:	cmp    QWORD PTR [rcx+0x10],r12
  c1f4cd:	jbe    c1f8b0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4a10>
  c1f4d3:	mov    rcx,QWORD PTR [rsp+0x68]
  c1f4d8:	movzx  eax,WORD PTR [rcx+rax*8+0x2]
  c1f4dd:	mov    QWORD PTR [rsp+0x290],rax
  c1f4e5:	mov    rax,QWORD PTR [rsp+0x3e8]
  c1f4ed:	mov    r15,QWORD PTR [rax+0x8]
  c1f4f1:	lea    rax,[rip+0xffffffffff6a74b7]        # 2c69af <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x62c>
  c1f4f8:	mov    QWORD PTR [rsp+0x78],rax
  c1f4fd:	mov    QWORD PTR [rsp+0x80],0x3a
  c1f509:	mov    BYTE PTR [rsp+0x70],0x1f
  c1f50e:	lea    rdi,[rsp+0x70]
  c1f513:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1f518:	mov    rax,r12
  c1f51b:	shl    rax,0x5
  c1f51f:	mov    rcx,QWORD PTR [rsp+0x290]
  c1f527:	cmp    QWORD PTR [r15+rax*1+0x10],rcx
  c1f52c:	jbe    c1f8ef <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4a4f>
  c1f532:	add    r15,rax
  c1f535:	mov    rax,QWORD PTR [rsp+0x290]
  c1f53d:	lea    rsi,[rax+rax*2]
  c1f541:	shl    esi,0x3
  c1f544:	add    rsi,QWORD PTR [r15+0x8]
  c1f548:	lea    rdi,[rsp+0x70]
  c1f54d:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1f552:	mov    rax,QWORD PTR [rsp+0x70]
  c1f557:	mov    rcx,QWORD PTR [rsp+0x80]
  c1f55f:	mov    QWORD PTR [rsp+0x2b8],rcx
  c1f567:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1f56d:	mov    QWORD PTR [rsp+0x370],rax
  c1f575:	movdqu XMMWORD PTR [rsp+0x378],xmm0
  c1f57e:	mov    rdi,QWORD PTR [rsp+0x48]
  c1f583:	mov    r15,QWORD PTR [rdi+0x10]
  c1f587:	lea    rsi,[rsp+0x370]
  c1f58f:	call   c24780 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueE8push_mutCsbxgXiyEKxkX_6bsl_vm>
  c1f594:	mov    r14,QWORD PTR [rsp+0x1b0]
  c1f59c:	cmp    r14,QWORD PTR [rsp+0x1a0]
  c1f5a4:	jne    c1f5b4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4714>
  c1f5a6:	lea    rdi,[rsp+0x1a0]
  c1f5ae:	call   QWORD PTR [rip+0x233a64]        # e53018 <_DYNAMIC+0x5858>
  c1f5b4:	mov    rax,QWORD PTR [rsp+0x1a8]
  c1f5bc:	lea    rcx,[r14+r14*2]
  c1f5c0:	mov    QWORD PTR [rax+rcx*8],r15
  c1f5c4:	mov    DWORD PTR [rax+rcx*8+0x8],r12d
  c1f5c9:	mov    rdx,QWORD PTR [rsp+0x290]
  c1f5d1:	mov    QWORD PTR [rax+rcx*8+0x10],rdx
  c1f5d6:	jmp    c1f6b8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4818>
  c1f5db:	movzx  r12d,WORD PTR [rbx+rdi*1+0x2]
  c1f5e1:	mov    rax,QWORD PTR [rsp+0x3e0]
  c1f5e9:	cmp    QWORD PTR [rax+0x10],r12
  c1f5ed:	jbe    c1f861 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x49c1>
  c1f5f3:	lea    rsi,[r12+r12*2]
  c1f5f7:	shl    esi,0x3
  c1f5fa:	add    rsi,QWORD PTR [rax+0x8]
  c1f5fe:	lea    rdi,[rsp+0x70]
  c1f603:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1f608:	mov    rax,QWORD PTR [rsp+0x70]
  c1f60d:	mov    rcx,QWORD PTR [rsp+0x80]
  c1f615:	mov    QWORD PTR [rsp+0x2c0],rcx
  c1f61d:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1f623:	mov    QWORD PTR [rsp+0x358],rax
  c1f62b:	movdqu XMMWORD PTR [rsp+0x360],xmm0
  c1f634:	mov    rdi,QWORD PTR [rsp+0x48]
  c1f639:	mov    r15,QWORD PTR [rdi+0x10]
  c1f63d:	lea    rsi,[rsp+0x358]
  c1f645:	call   c24780 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueE8push_mutCsbxgXiyEKxkX_6bsl_vm>
  c1f64a:	mov    rax,QWORD PTR [rsp+0x50]
  c1f64f:	mov    rsi,QWORD PTR [rax+0x10]
  c1f653:	cmp    QWORD PTR [rsp+0x408],rsi
  c1f65b:	jae    c1fcbd <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4e1d>
  c1f661:	mov    rax,QWORD PTR [rax+0x8]
  c1f665:	mov    rcx,QWORD PTR [rsp+0x2a8]
  c1f66d:	mov    eax,DWORD PTR [rax+rcx*1+0x70]
  c1f671:	mov    DWORD PTR [rsp+0x290],eax
  c1f678:	mov    r14,QWORD PTR [rsp+0x1b0]
  c1f680:	cmp    r14,QWORD PTR [rsp+0x1a0]
  c1f688:	jne    c1f698 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x47f8>
  c1f68a:	lea    rdi,[rsp+0x1a0]
  c1f692:	call   QWORD PTR [rip+0x233980]        # e53018 <_DYNAMIC+0x5858>
  c1f698:	mov    rax,QWORD PTR [rsp+0x1a8]
  c1f6a0:	lea    rcx,[r14+r14*2]
  c1f6a4:	mov    QWORD PTR [rax+rcx*8],r15
  c1f6a8:	mov    edx,DWORD PTR [rsp+0x290]
  c1f6af:	mov    DWORD PTR [rax+rcx*8+0x8],edx
  c1f6b3:	mov    QWORD PTR [rax+rcx*8+0x10],r12
  c1f6b8:	inc    r14
  c1f6bb:	mov    QWORD PTR [rsp+0x1b0],r14
  c1f6c3:	jmp    c1f41d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x457d>
  c1f6c8:	mov    rsi,QWORD PTR [rdx+0x10]
  c1f6cc:	cmp    rcx,rsi
  c1f6cf:	jae    c1fccc <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4e2c>
  c1f6d5:	mov    rdx,QWORD PTR [rdx+0x8]
  c1f6d9:	mov    rsi,QWORD PTR [rsp+0x2a8]
  c1f6e1:	lea    rcx,[rdx+rsi*1]
  c1f6e5:	movzx  eax,BYTE PTR [rsp+0x108]
  c1f6ed:	mov    r15,rax
  c1f6f0:	sub    r15,QWORD PTR [rdx+rsi*1+0x30]
  c1f6f5:	jae    c1f73d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x489d>
  c1f6f7:	mov    rcx,QWORD PTR [rcx+0x28]
  c1f6fb:	shl    eax,0x4
  c1f6fe:	mov    r15,QWORD PTR [rcx+rax*1]
  c1f702:	jmp    c1f741 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x48a1>
  c1f704:	mov    rsi,QWORD PTR [rdx+0x10]
  c1f708:	cmp    rcx,rsi
  c1f70b:	jae    c1fcab <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4e0b>
  c1f711:	mov    rdx,QWORD PTR [rdx+0x8]
  c1f715:	mov    rsi,QWORD PTR [rsp+0x2a8]
  c1f71d:	lea    rcx,[rdx+rsi*1]
  c1f721:	movzx  eax,BYTE PTR [rbx+rdi*1+0x1]
  c1f726:	mov    r15,rax
  c1f729:	sub    r15,QWORD PTR [rdx+rsi*1+0x30]
  c1f72e:	jb     c1f412 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4572>
  c1f734:	add    r15,QWORD PTR [rcx+0x60]
  c1f738:	jmp    c1f41d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x457d>
  c1f73d:	add    r15,QWORD PTR [rcx+0x60]
  c1f741:	mov    rcx,QWORD PTR [rsp+0x48]
  c1f746:	mov    rax,QWORD PTR [rcx+0x8]
  c1f74a:	mov    DWORD PTR [rsp+0x70],0x2
  c1f752:	cmp    r15,QWORD PTR [rcx+0x10]
  c1f756:	jae    c1f889 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x49e9>
  c1f75c:	lea    rcx,[r15+r15*2]
  c1f760:	lea    r14,[rax+rcx*8]
  c1f764:	mov    rdi,r14
  c1f767:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1f76c:	mov    rax,QWORD PTR [rsp+0x80]
  c1f774:	mov    QWORD PTR [r14+0x10],rax
  c1f778:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1f77e:	movdqu XMMWORD PTR [r14],xmm0
  c1f783:	xor    eax,eax
  c1f785:	jmp    c1f41f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x457f>
  c1f78a:	mov    rdi,QWORD PTR [rsp+0x48]
  c1f78f:	mov    r14,QWORD PTR [rdi+0x10]
  c1f793:	mov    rsi,QWORD PTR [rsp+0x2b0]
  c1f79b:	call   c0daa0 <_RNvCsbxgXiyEKxkX_6bsl_vm18push_own_registers>
  c1f7a0:	mov    rax,QWORD PTR [rsp+0x160]
  c1f7a8:	mov    QWORD PTR [rsp+0xa0],rax
  c1f7b0:	movups xmm0,XMMWORD PTR [rsp+0x150]
  c1f7b8:	movups XMMWORD PTR [rsp+0x90],xmm0
  c1f7c0:	movdqu xmm0,XMMWORD PTR [rsp+0x1a0]
  c1f7c9:	movdqu XMMWORD PTR [rsp+0xa8],xmm0
  c1f7d2:	mov    rax,QWORD PTR [rsp+0x1b0]
  c1f7da:	mov    QWORD PTR [rsp+0xb8],rax
  c1f7e2:	mov    eax,DWORD PTR [rsp+0x268]
  c1f7e9:	mov    DWORD PTR [rsp+0xe0],eax
  c1f7f0:	mov    rax,QWORD PTR [rsp+0x260]
  c1f7f8:	mov    QWORD PTR [rsp+0xc0],rax
  c1f800:	mov    QWORD PTR [rsp+0xc8],0x0
  c1f80c:	mov    QWORD PTR [rsp+0xd0],r14
  c1f814:	mov    QWORD PTR [rsp+0xd8],r14
  c1f81c:	mov    BYTE PTR [rsp+0xe4],r13b
  c1f824:	mov    QWORD PTR [rsp+0x70],0x0
  c1f82d:	lea    rsi,[rsp+0x70]
  c1f832:	mov    rdi,QWORD PTR [rsp+0x50]
  c1f837:	call   c24680 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCsbxgXiyEKxkX_6bsl_vm5FrameE8push_mutBG_>
  c1f83c:	jmp    c1c9c8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x1b28>
  c1f841:	mov    rcx,QWORD PTR [rsp+0x40]
  c1f846:	mov    BYTE PTR [rcx],0x1f
  c1f849:	lea    rax,[rip+0xffffffffff6a720b]        # 2c6a5b <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x6d8>
  c1f850:	mov    QWORD PTR [rcx+0x8],rax
  c1f854:	mov    QWORD PTR [rcx+0x10],0x53
  c1f85c:	jmp    c1f916 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4a76>
  c1f861:	mov    rcx,QWORD PTR [rsp+0x40]
  c1f866:	mov    BYTE PTR [rcx],0x1f
  c1f869:	lea    rax,[rip+0xffffffffff6a68a8]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1f870:	mov    QWORD PTR [rcx+0x8],rax
  c1f874:	mov    QWORD PTR [rcx+0x10],0x4f
  c1f87c:	mov    rax,QWORD PTR [rsp+0x2c0]
  c1f884:	jmp    c1f912 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4a72>
  c1f889:	lea    rdi,[rsp+0x70]
  c1f88e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1f893:	mov    rcx,QWORD PTR [rsp+0x40]
  c1f898:	mov    BYTE PTR [rcx],0x1f
  c1f89b:	lea    rax,[rip+0xffffffffff6a706a]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1f8a2:	mov    QWORD PTR [rcx+0x8],rax
  c1f8a6:	mov    QWORD PTR [rcx+0x10],0x4f
  c1f8ae:	jmp    c1f916 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4a76>
  c1f8b0:	lea    rcx,[rip+0xffffffffff6a70f8]        # 2c69af <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x62c>
  c1f8b7:	mov    QWORD PTR [rsp+0x78],rcx
  c1f8bc:	mov    QWORD PTR [rsp+0x80],0x3a
  c1f8c8:	lea    rax,[rsp+0x80]
  c1f8d0:	movdqu xmm0,XMMWORD PTR [rax]
  c1f8d4:	movups xmm1,XMMWORD PTR [rax+0x10]
  c1f8d8:	mov    rax,QWORD PTR [rsp+0x40]
  c1f8dd:	movups XMMWORD PTR [rax+0x20],xmm1
  c1f8e1:	movdqu XMMWORD PTR [rax+0x10],xmm0
  c1f8e6:	mov    BYTE PTR [rax],0x1f
  c1f8e9:	mov    QWORD PTR [rax+0x8],rcx
  c1f8ed:	jmp    c1f916 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4a76>
  c1f8ef:	mov    rcx,QWORD PTR [rsp+0x40]
  c1f8f4:	mov    BYTE PTR [rcx],0x1f
  c1f8f7:	lea    rax,[rip+0xffffffffff6a681a]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1f8fe:	mov    QWORD PTR [rcx+0x8],rax
  c1f902:	mov    QWORD PTR [rcx+0x10],0x4f
  c1f90a:	mov    rax,QWORD PTR [rsp+0x2b8]
  c1f912:	mov    QWORD PTR [rcx+0x18],rax
  c1f916:	mov    rax,QWORD PTR [rsp+0x1a0]
  c1f91e:	test   rax,rax
  c1f921:	je     c1f93e <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4a9e>
  c1f923:	mov    rdi,QWORD PTR [rsp+0x1a8]
  c1f92b:	shl    rax,0x3
  c1f92f:	lea    rsi,[rax+rax*2]
  c1f933:	mov    edx,0x8
  c1f938:	call   QWORD PTR [rip+0x22e0c2]        # e4da00 <_DYNAMIC+0x240>
  c1f93e:	mov    rsi,QWORD PTR [rsp+0x150]
  c1f946:	test   rsi,rsi
  c1f949:	je     c1eace <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3c2e>
  c1f94f:	mov    rdi,QWORD PTR [rsp+0x158]
  c1f957:	shl    rsi,0x4
  c1f95b:	jmp    c1e737 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x3897>
  c1f960:	lea    rdx,[rip+0x216eb9]        # e36820 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xc20>
  c1f967:	mov    rdi,QWORD PTR [rsp+0x408]
  c1f96f:	call   QWORD PTR [rip+0x22e163]        # e4dad8 <_DYNAMIC+0x318>
  c1f975:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1f97a:	lea    rdx,[rip+0x216e57]        # e367d8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xbd8>
  c1f981:	mov    rdi,r15
  c1f984:	call   QWORD PTR [rip+0x22e14e]        # e4dad8 <_DYNAMIC+0x318>
  c1f98a:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1f98f:	lea    rdx,[rip+0x217062]        # e369f8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xdf8>
  c1f996:	call   QWORD PTR [rip+0x22e13c]        # e4dad8 <_DYNAMIC+0x318>
  c1f99c:	lea    rdx,[rip+0x216f6d]        # e36910 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xd10>
  c1f9a3:	mov    rdi,r15
  c1f9a6:	call   QWORD PTR [rip+0x22e12c]        # e4dad8 <_DYNAMIC+0x318>
  c1f9ac:	lea    rdx,[rip+0x216fbd]        # e36970 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xd70>
  c1f9b3:	mov    rdi,r15
  c1f9b6:	call   QWORD PTR [rip+0x22e11c]        # e4dad8 <_DYNAMIC+0x318>
  c1f9bc:	lea    rdx,[rip+0x216d85]        # e36748 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xb48>
  c1f9c3:	mov    rdi,r15
  c1f9c6:	call   QWORD PTR [rip+0x22e10c]        # e4dad8 <_DYNAMIC+0x318>
  c1f9cc:	lea    rdx,[rip+0x216e65]        # e36838 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xc38>
  c1f9d3:	call   QWORD PTR [rip+0x22e0ff]        # e4dad8 <_DYNAMIC+0x318>
  c1f9d9:	lea    rdx,[rip+0x216e88]        # e36868 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xc68>
  c1f9e0:	mov    rdi,r15
  c1f9e3:	call   QWORD PTR [rip+0x22e0ef]        # e4dad8 <_DYNAMIC+0x318>
  c1f9e9:	lea    rdx,[rip+0x2170c8]        # e36ab8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xeb8>
  c1f9f0:	call   QWORD PTR [rip+0x22e0e2]        # e4dad8 <_DYNAMIC+0x318>
  c1f9f6:	lea    rdx,[rip+0x216ee3]        # e368e0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xce0>
  c1f9fd:	call   QWORD PTR [rip+0x22e0d5]        # e4dad8 <_DYNAMIC+0x318>
  c1fa03:	lea    rdx,[rip+0x216ea6]        # e368b0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xcb0>
  c1fa0a:	call   QWORD PTR [rip+0x22e0c8]        # e4dad8 <_DYNAMIC+0x318>
  c1fa10:	lea    rdx,[rip+0x217101]        # e36b18 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xf18>
  c1fa17:	call   QWORD PTR [rip+0x22e0bb]        # e4dad8 <_DYNAMIC+0x318>
  c1fa1d:	lea    rdx,[rip+0x216f64]        # e36988 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xd88>
  c1fa24:	mov    rdi,r15
  c1fa27:	call   QWORD PTR [rip+0x22e0ab]        # e4dad8 <_DYNAMIC+0x318>
  c1fa2d:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fa32:	lea    rdx,[rip+0x216d27]        # e36760 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xb60>
  c1fa39:	mov    rdi,r15
  c1fa3c:	call   QWORD PTR [rip+0x22e096]        # e4dad8 <_DYNAMIC+0x318>
  c1fa42:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fa47:	lea    rdx,[rip+0x216f0a]        # e36958 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xd58>
  c1fa4e:	call   QWORD PTR [rip+0x22e084]        # e4dad8 <_DYNAMIC+0x318>
  c1fa54:	lea    rdx,[rip+0x2170d5]        # e36b30 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xf30>
  c1fa5b:	mov    rdi,QWORD PTR [rsp+0x408]
  c1fa63:	call   QWORD PTR [rip+0x22e06f]        # e4dad8 <_DYNAMIC+0x318>
  c1fa69:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fa6e:	lea    rdx,[rip+0x216d33]        # e367a8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xba8>
  c1fa75:	mov    rdi,r15
  c1fa78:	call   QWORD PTR [rip+0x22e05a]        # e4dad8 <_DYNAMIC+0x318>
  c1fa7e:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fa83:	lea    rdx,[rip+0x216fce]        # e36a58 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xe58>
  c1fa8a:	call   QWORD PTR [rip+0x22e048]        # e4dad8 <_DYNAMIC+0x318>
  c1fa90:	lea    rdx,[rip+0x217039]        # e36ad0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xed0>
  c1fa97:	mov    rdi,QWORD PTR [rsp+0x408]
  c1fa9f:	call   QWORD PTR [rip+0x22e033]        # e4dad8 <_DYNAMIC+0x318>
  c1faa5:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1faaa:	lea    rdx,[rip+0x216d3f]        # e367f0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xbf0>
  c1fab1:	mov    rdi,r15
  c1fab4:	call   QWORD PTR [rip+0x22e01e]        # e4dad8 <_DYNAMIC+0x318>
  c1faba:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fabf:	lea    rdx,[rip+0x216cfa]        # e367c0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xbc0>
  c1fac6:	mov    rdi,r15
  c1fac9:	call   QWORD PTR [rip+0x22e009]        # e4dad8 <_DYNAMIC+0x318>
  c1facf:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fad4:	mov    rsi,QWORD PTR [rsp+0x80]
  c1fadc:	call   QWORD PTR [rip+0x22dfc6]        # e4daa8 <_DYNAMIC+0x2e8>
  c1fae2:	lea    rdx,[rip+0x216d97]        # e36880 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xc80>
  c1fae9:	mov    rdi,r15
  c1faec:	call   QWORD PTR [rip+0x22dfe6]        # e4dad8 <_DYNAMIC+0x318>
  c1faf2:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1faf7:	lea    rdx,[rip+0x21704a]        # e36b48 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xf48>
  c1fafe:	mov    rdi,QWORD PTR [rsp+0x408]
  c1fb06:	call   QWORD PTR [rip+0x22dfcc]        # e4dad8 <_DYNAMIC+0x318>
  c1fb0c:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fb11:	lea    rdx,[rip+0x216ef8]        # e36a10 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xe10>
  c1fb18:	mov    rdi,QWORD PTR [rsp+0x408]
  c1fb20:	call   QWORD PTR [rip+0x22dfb2]        # e4dad8 <_DYNAMIC+0x318>
  c1fb26:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fb2b:	lea    rdx,[rip+0x216cd6]        # e36808 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xc08>
  c1fb32:	mov    rdi,r15
  c1fb35:	call   QWORD PTR [rip+0x22df9d]        # e4dad8 <_DYNAMIC+0x318>
  c1fb3b:	lea    rdx,[rip+0x216de6]        # e36928 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xd28>
  c1fb42:	mov    rdi,r15
  c1fb45:	call   QWORD PTR [rip+0x22df8d]        # e4dad8 <_DYNAMIC+0x318>
  c1fb4b:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fb50:	lea    rdx,[rip+0x216d41]        # e36898 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xc98>
  c1fb57:	mov    rdi,r15
  c1fb5a:	call   QWORD PTR [rip+0x22df78]        # e4dad8 <_DYNAMIC+0x318>
  c1fb60:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fb65:	lea    rdx,[rip+0x216f7c]        # e36ae8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xee8>
  c1fb6c:	mov    rdi,QWORD PTR [rsp+0x408]
  c1fb74:	call   QWORD PTR [rip+0x22df5e]        # e4dad8 <_DYNAMIC+0x318>
  c1fb7a:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fb7f:	lea    rdx,[rip+0x216ea2]        # e36a28 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xe28>
  c1fb86:	mov    rdi,QWORD PTR [rsp+0x408]
  c1fb8e:	call   QWORD PTR [rip+0x22df44]        # e4dad8 <_DYNAMIC+0x318>
  c1fb94:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fb99:	lea    rdx,[rip+0x216da0]        # e36940 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xd40>
  c1fba0:	mov    rdi,r15
  c1fba3:	call   QWORD PTR [rip+0x22df2f]        # e4dad8 <_DYNAMIC+0x318>
  c1fba9:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fbae:	lea    rdx,[rip+0x216f4b]        # e36b00 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xf00>
  c1fbb5:	call   QWORD PTR [rip+0x22df1d]        # e4dad8 <_DYNAMIC+0x318>
  c1fbbb:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fbc0:	lea    rdx,[rip+0x216e01]        # e369c8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xdc8>
  c1fbc7:	mov    rdi,r15
  c1fbca:	call   QWORD PTR [rip+0x22df08]        # e4dad8 <_DYNAMIC+0x318>
  c1fbd0:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fbd5:	lea    rdx,[rip+0x216b9c]        # e36778 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xb78>
  c1fbdc:	mov    rdi,r15
  c1fbdf:	call   QWORD PTR [rip+0x22def3]        # e4dad8 <_DYNAMIC+0x318>
  c1fbe5:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fbea:	lea    rdx,[rip+0x216f6f]        # e36b60 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xf60>
  c1fbf1:	call   QWORD PTR [rip+0x22dee1]        # e4dad8 <_DYNAMIC+0x318>
  c1fbf7:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fbfc:	lea    rdx,[rip+0x216e3d]        # e36a40 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xe40>
  c1fc03:	call   QWORD PTR [rip+0x22decf]        # e4dad8 <_DYNAMIC+0x318>
  c1fc09:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fc0e:	lea    rdx,[rip+0x216e5b]        # e36a70 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xe70>
  c1fc15:	mov    rdi,QWORD PTR [rsp+0x408]
  c1fc1d:	call   QWORD PTR [rip+0x22deb5]        # e4dad8 <_DYNAMIC+0x318>
  c1fc23:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fc28:	lea    rdx,[rip+0x216a71]        # e366a0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xaa0>
  c1fc2f:	call   QWORD PTR [rip+0x22dea3]        # e4dad8 <_DYNAMIC+0x318>
  c1fc35:	lea    rdx,[rip+0x216da4]        # e369e0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xde0>
  c1fc3c:	mov    rdi,r15
  c1fc3f:	call   QWORD PTR [rip+0x22de93]        # e4dad8 <_DYNAMIC+0x318>
  c1fc45:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fc4a:	lea    rdx,[rip+0x216b3f]        # e36790 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xb90>
  c1fc51:	mov    rdi,r15
  c1fc54:	call   QWORD PTR [rip+0x22de7e]        # e4dad8 <_DYNAMIC+0x318>
  c1fc5a:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fc5f:	lea    rdx,[rip+0x216e22]        # e36a88 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xe88>
  c1fc66:	mov    rdi,rbx
  c1fc69:	call   QWORD PTR [rip+0x22de69]        # e4dad8 <_DYNAMIC+0x318>
  c1fc6f:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fc74:	lea    rdx,[rip+0x2169f5]        # e36670 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xa70>
  c1fc7b:	mov    rdi,r15
  c1fc7e:	call   QWORD PTR [rip+0x22de54]        # e4dad8 <_DYNAMIC+0x318>
  c1fc84:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fc89:	lea    rdx,[rip+0x216e10]        # e36aa0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xea0>
  c1fc90:	mov    rdi,rbx
  c1fc93:	call   QWORD PTR [rip+0x22de3f]        # e4dad8 <_DYNAMIC+0x318>
  c1fc99:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fc9e:	lea    rdx,[rip+0x216a13]        # e366b8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xab8>
  c1fca5:	call   QWORD PTR [rip+0x22de2d]        # e4dad8 <_DYNAMIC+0x318>
  c1fcab:	lea    rax,[rip+0x216a4e]        # e36700 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xb00>
  c1fcb2:	jmp    c1fcc4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4e24>
  c1fcb4:	lea    rax,[rip+0x216a2d]        # e366e8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xae8>
  c1fcbb:	jmp    c1fcc4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4e24>
  c1fcbd:	lea    rax,[rip+0x216a54]        # e36718 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xb18>
  c1fcc4:	mov    QWORD PTR [rsp+0x2a0],rax
  c1fccc:	mov    rdi,QWORD PTR [rsp+0x408]
  c1fcd4:	mov    rdx,QWORD PTR [rsp+0x2a0]
  c1fcdc:	call   QWORD PTR [rip+0x22ddf6]        # e4dad8 <_DYNAMIC+0x318>
  c1fce2:	jmp    c1e693 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x37f3>
  c1fce7:	mov    edi,0x1
  c1fcec:	mov    esi,0x68
  c1fcf1:	call   QWORD PTR [rip+0x22ddb1]        # e4daa8 <_DYNAMIC+0x2e8>
  c1fcf7:	lea    rdx,[rip+0x2169d2]        # e366d0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xad0>
  c1fcfe:	mov    rdi,QWORD PTR [rsp+0x408]
  c1fd06:	call   QWORD PTR [rip+0x22ddcc]        # e4dad8 <_DYNAMIC+0x318>
  c1fd0c:	mov    rbx,rax
  c1fd0f:	mov    rax,QWORD PTR [rsp+0x80]
  c1fd17:	mov    QWORD PTR [r14+0x10],rax
  c1fd1b:	movups xmm0,XMMWORD PTR [rsp+0x70]
  c1fd20:	movups XMMWORD PTR [r14],xmm0
  c1fd24:	jmp    c1fd9c <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4efc>
  c1fd26:	mov    rbx,rax
  c1fd29:	mov    rax,QWORD PTR [rsp+0x80]
  c1fd31:	mov    QWORD PTR [r14+0x10],rax
  c1fd35:	movaps xmm0,XMMWORD PTR [rsp+0x70]
  c1fd3a:	movups XMMWORD PTR [r14],xmm0
  c1fd3e:	mov    rdi,rbx
  c1fd41:	call   d9b550 <_Unwind_Resume@plt>
  c1fd46:	jmp    c1ffd6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5136>
  c1fd4b:	jmp    c1fd99 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4ef9>
  c1fd4d:	mov    rbx,rax
  c1fd50:	mov    rax,QWORD PTR [rsp+0x280]
  c1fd58:	mov    QWORD PTR [r14+0x10],rax
  c1fd5c:	movdqa xmm0,XMMWORD PTR [rsp+0x270]
  c1fd65:	movdqu XMMWORD PTR [r14],xmm0
  c1fd6a:	jmp    c200be <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x521e>
  c1fd6f:	mov    rbx,rax
  c1fd72:	lea    rdi,[rsp+0x150]
  c1fd7a:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1fd7f:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c1fd84:	mov    rbx,rax
  c1fd87:	lea    rdi,[rsp+0x1a0]
  c1fd8f:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1fd94:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c1fd99:	mov    rbx,rax
  c1fd9c:	mov    rax,QWORD PTR [rsp+0x1a0]
  c1fda4:	test   rax,rax
  c1fda7:	je     c1fdc4 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x4f24>
  c1fda9:	mov    rdi,QWORD PTR [rsp+0x1a8]
  c1fdb1:	shl    rax,0x3
  c1fdb5:	lea    rsi,[rax+rax*2]
  c1fdb9:	mov    edx,0x8
  c1fdbe:	call   QWORD PTR [rip+0x22dc3c]        # e4da00 <_DYNAMIC+0x240>
  c1fdc4:	mov    rsi,QWORD PTR [rsp+0x150]
  c1fdcc:	test   rsi,rsi
  c1fdcf:	je     c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c1fdd5:	mov    rdi,QWORD PTR [rsp+0x158]
  c1fddd:	shl    rsi,0x4
  c1fde1:	mov    edx,0x8
  c1fde6:	call   QWORD PTR [rip+0x22dc14]        # e4da00 <_DYNAMIC+0x240>
  c1fdec:	mov    rdi,rbx
  c1fdef:	call   d9b550 <_Unwind_Resume@plt>
  c1fdf4:	mov    rbx,rax
  c1fdf7:	cmp    BYTE PTR [rsp+0x1a0],0xff
  c1fdff:	je     c20182 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52e2>
  c1fe05:	lea    rdi,[rsp+0x1a0]
  c1fe0d:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1fe12:	jmp    c20182 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52e2>
  c1fe17:	jmp    c200bb <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x521b>
  c1fe1c:	mov    rbx,rax
  c1fe1f:	lea    rdi,[rsp+0x270]
  c1fe27:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1fe2c:	jmp    c200be <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x521e>
  c1fe31:	mov    rbx,rax
  c1fe34:	lea    rdi,[rsp+0x1a0]
  c1fe3c:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c1fe41:	jmp    c2016d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52cd>
  c1fe46:	mov    rbx,rax
  c1fe49:	mov    rax,QWORD PTR [rsp+0x230]
  c1fe51:	mov    QWORD PTR [r14+0x10],rax
  c1fe55:	movdqa xmm0,XMMWORD PTR [rsp+0x220]
  c1fe5e:	movdqu XMMWORD PTR [r14],xmm0
  c1fe63:	jmp    c20197 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52f7>
  c1fe68:	mov    rbx,rax
  c1fe6b:	mov    rax,QWORD PTR [rsp+0x280]
  c1fe73:	mov    QWORD PTR [r14+0x10],rax
  c1fe77:	movdqa xmm0,XMMWORD PTR [rsp+0x270]
  c1fe80:	movdqu XMMWORD PTR [r14],xmm0
  c1fe85:	jmp    c201a9 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5309>
  c1fe8a:	mov    rbx,rax
  c1fe8d:	mov    rax,QWORD PTR [rsp+0x160]
  c1fe95:	mov    QWORD PTR [r14+0x10],rax
  c1fe99:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1fea2:	movdqu XMMWORD PTR [r14],xmm0
  c1fea7:	jmp    c200de <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x523e>
  c1feac:	mov    rbx,rax
  c1feaf:	test   bpl,bpl
  c1feb2:	jne    c20046 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x51a6>
  c1feb8:	jmp    c20182 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52e2>
  c1febd:	jmp    c20194 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52f4>
  c1fec2:	jmp    c201a6 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5306>
  c1fec7:	mov    rbx,rax
  c1feca:	lea    rdi,[rsp+0x220]
  c1fed2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1fed7:	jmp    c20197 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52f7>
  c1fedc:	mov    rbx,rax
  c1fedf:	lea    rdi,[rsp+0x270]
  c1fee7:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1feec:	jmp    c201a9 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5309>
  c1fef1:	mov    rbx,rax
  c1fef4:	mov    rax,QWORD PTR [rsp+0x120]
  c1fefc:	mov    QWORD PTR [r14+0x10],rax
  c1ff00:	movdqa xmm0,XMMWORD PTR [rsp+0x110]
  c1ff09:	movdqu XMMWORD PTR [r14],xmm0
  c1ff0e:	jmp    c2016d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52cd>
  c1ff13:	jmp    c1ff17 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5077>
  c1ff15:	jmp    c1ff17 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5077>
  c1ff17:	mov    rbx,rax
  c1ff1a:	mov    rax,QWORD PTR [rsp+0x80]
  c1ff22:	mov    QWORD PTR [r14+0x10],rax
  c1ff26:	movups xmm0,XMMWORD PTR [rsp+0x70]
  c1ff2b:	movups XMMWORD PTR [r14],xmm0
  c1ff2f:	mov    rdi,rbx
  c1ff32:	call   d9b550 <_Unwind_Resume@plt>
  c1ff37:	mov    rbx,rax
  c1ff3a:	mov    rax,QWORD PTR [rsp+0x160]
  c1ff42:	mov    QWORD PTR [r14+0x10],rax
  c1ff46:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1ff4f:	movdqu XMMWORD PTR [r14],xmm0
  c1ff54:	jmp    c2007d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x51dd>
  c1ff59:	jmp    c2017f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52df>
  c1ff5e:	jmp    c200db <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x523b>
  c1ff63:	mov    rbx,rax
  c1ff66:	lea    rdi,[rsp+0x150]
  c1ff6e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1ff73:	jmp    c200de <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x523e>
  c1ff78:	mov    rbx,rax
  c1ff7b:	jmp    c200fe <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x525e>
  c1ff80:	jmp    c2016a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52ca>
  c1ff85:	mov    rbx,rax
  c1ff88:	lea    rdi,[rsp+0x110]
  c1ff90:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1ff95:	jmp    c2016d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52cd>
  c1ff9a:	mov    rbx,rax
  c1ff9d:	mov    rax,QWORD PTR [rsp+0x160]
  c1ffa5:	mov    QWORD PTR [r14+0x10],rax
  c1ffa9:	movdqa xmm0,XMMWORD PTR [rsp+0x150]
  c1ffb2:	movdqu XMMWORD PTR [r14],xmm0
  c1ffb7:	jmp    c20158 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52b8>
  c1ffbc:	jmp    c2007a <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x51da>
  c1ffc1:	mov    rbx,rax
  c1ffc4:	lea    rdi,[rsp+0x150]
  c1ffcc:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1ffd1:	jmp    c2007d <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x51dd>
  c1ffd6:	mov    rbx,rax
  c1ffd9:	mov    rax,QWORD PTR [rsp+0x1b0]
  c1ffe1:	mov    QWORD PTR [r14+0x10],rax
  c1ffe5:	movups xmm0,XMMWORD PTR [rsp+0x1a0]
  c1ffed:	movups XMMWORD PTR [r14],xmm0
  c1fff1:	mov    rdi,rbx
  c1fff4:	call   d9b550 <_Unwind_Resume@plt>
  c1fff9:	mov    rbx,rax
  c1fffc:	mov    rax,QWORD PTR [rsp+0x70]
  c20001:	dec    QWORD PTR [rax]
  c20004:	jne    c200fe <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x525e>
  c2000a:	lea    rdi,[rsp+0x70]
  c2000f:	call   QWORD PTR [rip+0x22d9fb]        # e4da10 <_DYNAMIC+0x250>
  c20015:	jmp    c200fe <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x525e>
  c2001a:	jmp    c20155 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52b5>
  c2001f:	mov    rbx,rax
  c20022:	lea    rdi,[rsp+0x70]
  c20027:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c2002c:	jmp    c20046 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x51a6>
  c2002e:	mov    rbx,rax
  c20031:	lea    rdi,[rsp+0x150]
  c20039:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c2003e:	jmp    c20158 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52b8>
  c20043:	mov    rbx,rax
  c20046:	lea    rdi,[rsp+0x110]
  c2004e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c20053:	jmp    c20182 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x52e2>
  c20058:	mov    rbx,rax
  c2005b:	mov    rax,QWORD PTR [rsp+0x160]
  c20063:	mov    QWORD PTR [r14+0x10],rax
  c20067:	movdqu xmm0,XMMWORD PTR [rsp+0x150]
  c20070:	movdqu XMMWORD PTR [r14],xmm0
  c20075:	jmp    c20212 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5372>
  c2007a:	mov    rbx,rax
  c2007d:	mov    rax,QWORD PTR [rsp+0x220]
  c20085:	dec    QWORD PTR [rax]
  c20088:	jne    c20121 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5281>
  c2008e:	lea    rdi,[rsp+0x220]
  c20096:	call   QWORD PTR [rip+0x22d9b4]        # e4da50 <_DYNAMIC+0x290>
  c2009c:	jmp    c20121 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5281>
  c200a1:	jmp    c201d0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5330>
  c200a6:	mov    rbx,rax
  c200a9:	lea    rdi,[rsp+0x1a0]
  c200b1:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c200b6:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c200bb:	mov    rbx,rax
  c200be:	cmp    BYTE PTR [rsp+0x68],0x0
  c200c3:	je     c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c200c9:	lea    rdi,[rsp+0x150]
  c200d1:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c200d6:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c200db:	mov    rbx,rax
  c200de:	mov    rsi,QWORD PTR [rsp+0x110]
  c200e6:	test   rsi,rsi
  c200e9:	je     c200fe <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x525e>
  c200eb:	mov    rdi,QWORD PTR [rsp+0x118]
  c200f3:	mov    edx,0x1
  c200f8:	call   QWORD PTR [rip+0x22d902]        # e4da00 <_DYNAMIC+0x240>
  c200fe:	cmp    DWORD PTR [rsp+0x220],0x6
  c20106:	je     c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c2010c:	lea    rdi,[rsp+0x220]
  c20114:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c20119:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c2011e:	mov    rbx,rax
  c20121:	lea    rdi,[rsp+0x110]
  c20129:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c2012e:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c20133:	mov    rbx,rax
  c20136:	jmp    c201e5 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5345>
  c2013b:	jmp    c201d0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5330>
  c20140:	mov    rbx,rax
  c20143:	lea    rdi,[rsp+0x150]
  c2014b:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c20150:	jmp    c20212 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5372>
  c20155:	mov    rbx,rax
  c20158:	lea    rdi,[rsp+0x110]
  c20160:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c20165:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c2016a:	mov    rbx,rax
  c2016d:	lea    rdi,[rsp+0x220]
  c20175:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c2017a:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c2017f:	mov    rbx,rax
  c20182:	lea    rdi,[rsp+0x220]
  c2018a:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c2018f:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c20194:	mov    rbx,rax
  c20197:	lea    rdi,[rsp+0x1a0]
  c2019f:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c201a4:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c201a6:	mov    rbx,rax
  c201a9:	lea    rdi,[rsp+0x1a0]
  c201b1:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c201b6:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c201b8:	mov    rbx,rax
  c201bb:	lea    rdi,[rsp+0x2c8]
  c201c3:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c201c8:	jmp    c201d8 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5338>
  c201ca:	call   QWORD PTR [rip+0x22d850]        # e4da20 <_DYNAMIC+0x260>
  c201d0:	mov    rbx,rax
  c201d3:	jmp    c20212 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5372>
  c201d5:	mov    rbx,rax
  c201d8:	lea    rdi,[rsp+0x150]
  c201e0:	call   c0a040 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueEECsbxgXiyEKxkX_6bsl_vm>
  c201e5:	mov    rax,QWORD PTR [rsp+0x110]
  c201ed:	dec    QWORD PTR [rax]
  c201f0:	jne    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c201f2:	lea    rdi,[rsp+0x110]
  c201fa:	call   QWORD PTR [rip+0x22d830]        # e4da30 <_DYNAMIC+0x270>
  c20200:	jmp    c2021f <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x537f>
  c20202:	mov    rbx,rax
  c20205:	lea    rdi,[rsp+0x1a0]
  c2020d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c20212:	mov    rsi,QWORD PTR [rsp+0x110]
  c2021a:	test   rsi,rsi
  c2021d:	jne    c20227 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold+0x5387>
  c2021f:	mov    rdi,rbx
  c20222:	call   d9b550 <_Unwind_Resume@plt>
  c20227:	mov    rdi,QWORD PTR [rsp+0x118]
  c2022f:	shl    rsi,0x3
  c20233:	mov    edx,0x8
  c20238:	call   QWORD PTR [rip+0x22d7c2]        # e4da00 <_DYNAMIC+0x240>
  c2023e:	mov    rdi,rbx
  c20241:	call   d9b550 <_Unwind_Resume@plt>
  c20246:	call   QWORD PTR [rip+0x22d7d4]        # e4da20 <_DYNAMIC+0x260>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
