#!/usr/bin/env bash
set -euo pipefail
binary="$1"
scenario="$2"
output_dir="$3"
for run in 1 2 3 4 5 6 7; do
    "$binary" "$scenario" > "$output_dir/profile-$run.stdout"
done
