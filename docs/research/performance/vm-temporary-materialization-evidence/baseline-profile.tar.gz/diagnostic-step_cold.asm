
target/profiling/bsl-cli:     file format elf64-x86-64


Disassembly of section .text:

0000000000c1a340 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold>:
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2621
  c1a340:	push   rbp
  c1a341:	push   r15
  c1a343:	push   r14
  c1a345:	push   r13
  c1a347:	push   r12
  c1a349:	push   rbx
  c1a34a:	sub    rsp,0x398
  c1a351:	mov    QWORD PTR [rsp+0x158],r9
  c1a359:	mov    QWORD PTR [rsp+0x100],rcx
  c1a361:	mov    QWORD PTR [rsp+0x50],rdx
  c1a366:	mov    rbx,rsi
  c1a369:	mov    QWORD PTR [rsp+0x48],rdi
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2639
  c1a36e:	movzx  eax,bl
  c1a371:	add    eax,0xfffffffd
  c1a374:	cmp    eax,0x34
  c1a377:	ja     c1ae7a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xb3a>
  c1a37d:	mov    rdx,QWORD PTR [rsp+0x420]
  c1a385:	mov    rdi,QWORD PTR [rsp+0x418]
  c1a38d:	mov    r15,QWORD PTR [rsp+0x400]
  c1a395:	mov    rsi,QWORD PTR [rsp+0x3f8]
  c1a39d:	mov    r11,QWORD PTR [rsp+0x3e8]
  c1a3a5:	mov    r9,QWORD PTR [rsp+0x3e0]
  c1a3ad:	mov    r10,QWORD PTR [rsp+0x3d8]
  c1a3b5:	mov    rcx,rbx
  c1a3b8:	shr    rcx,0x8
  c1a3bc:	mov    QWORD PTR [rsp+0x118],rcx
  c1a3c4:	mov    r13,rbx
  c1a3c7:	shr    r13,0x10
  c1a3cb:	mov    r12,rbx
  c1a3ce:	shr    r12,0x20
  c1a3d2:	mov    r14,rbx
  c1a3d5:	shr    r14,0x30
  c1a3d9:	lea    rcx,[rip+0xffffffffff6ac644]        # 2c6a24 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x13db>
  c1a3e0:	movsxd rax,DWORD PTR [rcx+rax*4]
  c1a3e4:	add    rax,rcx
  c1a3e7:	mov    rbp,rbx
  c1a3ea:	shr    rbp,0x18
  c1a3ee:	shr    rbx,0x28
  c1a3f2:	jmp    rax
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3209
  c1a3f4:	lea    rax,[rip+0xffffffffff6ad250]        # 2c764b <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x640>
  c1a3fb:	mov    QWORD PTR [rsp+0x78],rax
  c1a400:	mov    QWORD PTR [rsp+0x80],0x54
  c1a40c:	mov    BYTE PTR [rsp+0x70],0x1f
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14CatalogContextE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1335
  c1a411:	test   r15,r15
  c1a414:	je     c1b187 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xe47>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1a41a:	mov    r12,rsi
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3208
  c1a41d:	shl    ebp,0x8
  c1a420:	movzx  ebx,r13b
  c1a424:	lea    rdi,[rsp+0x70]
  c1a429:	mov    r14,r8
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14CatalogContextE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1a42c:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3213
  c1a431:	movzx  eax,bp
  c1a434:	or     rax,rbx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCskDxgodD397f_12bsl_bytecode13configuration9LinkEntryE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1a437:	cmp    rax,QWORD PTR [r14+0xe8]
  c1a43e:	jae    c1b167 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xe27>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCskDxgodD397f_12bsl_bytecode13configuration9LinkEntryECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a444:	mov    rcx,QWORD PTR [r14+0xe0]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3212
  c1a44b:	cmp    BYTE PTR [rcx+rax*8],0x0
  c1a44f:	je     c1b167 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xe27>
  c1a455:	mov    ebx,DWORD PTR [rcx+rax*8+0x4]
  c1a459:	movzx  r14d,WORD PTR [rcx+rax*8+0x2]
  c1a45f:	lea    rdi,[rsp+0x70]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3220
  c1a464:	mov    esi,ebx
  c1a466:	mov    rdx,r15
  c1a469:	mov    rcx,r12
  c1a46c:	mov    r8,QWORD PTR [rsp+0x50]
  c1a471:	mov    r9,QWORD PTR [rsp+0x100]
  c1a479:	call   c4baa0 <_RNvNtCslyNhMBcJWAz_6bsl_vm7modules19ensure_module_ready>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultbNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1a47e:	movzx  ecx,BYTE PTR [rsp+0x70]
  c1a483:	movzx  eax,BYTE PTR [rsp+0x71]
  c1a488:	cmp    cl,0xff
  c1a48b:	jne    c1bd8d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1a4d>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3220
  c1a491:	test   al,0x1
  c1a493:	jne    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE3getB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1a499:	cmp    QWORD PTR [r12+0x10],rbx
  c1a49e:	jbe    c1de4f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3b0f>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceEB14_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a4a4:	mov    r15,QWORD PTR [r12+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE3getB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1a4a9:	shl    rbx,0x5
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3228
  c1a4ad:	lea    rax,[rip+0xffffffffff6ad1eb]        # 2c769f <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x694>
  c1a4b4:	mov    QWORD PTR [rsp+0x78],rax
  c1a4b9:	mov    QWORD PTR [rsp+0x80],0x3a
  c1a4c5:	mov    BYTE PTR [rsp+0x70],0x1f
  c1a4ca:	lea    rdi,[rsp+0x70]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1a4cf:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1a4d4:	cmp    QWORD PTR [r15+rbx*1+0x10],r14
  c1a4d9:	jbe    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1a4df:	add    r15,rbx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1a4e2:	lea    rsi,[r14+r14*2]
  c1a4e6:	shl    esi,0x3
  c1a4e9:	add    rsi,QWORD PTR [r15+0x8]
  c1a4ed:	lea    rdi,[rsp+0x70]
_RNvYNvYNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneINtNtNtBN_3ops8function6FnOnceTRB5_EE9call_onceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ops/function.rs:250
  c1a4f2:	call   c246a0 <_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1162
  c1a4f7:	mov    rax,QWORD PTR [rsp+0x70]
  c1a4fc:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3229
  c1a502:	mov    QWORD PTR [rsp+0x1b0],rax
  c1a50a:	movdqu XMMWORD PTR [rsp+0x1b8],xmm0
  c1a513:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1a518:	mov    rsi,QWORD PTR [rax+0x10]
  c1a51c:	mov    r15,QWORD PTR [rsp+0x418]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a524:	cmp    r15,rsi
  c1a527:	jae    c1f1af <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4e6f>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a52d:	mov    rsi,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a531:	imul   rbx,r15,0x78
  c1a535:	lea    rdx,[rsi+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1a539:	movzx  ecx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1a541:	mov    rax,rcx
  c1a544:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1a549:	jae    c1e528 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x41e8>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a54f:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a553:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1a556:	mov    rax,QWORD PTR [rax+rcx*1]
  c1a55a:	jmp    c1e52c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x41ec>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1a55f:	mov    r14,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1a564:	mov    rsi,QWORD PTR [r14+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a568:	cmp    rdi,rsi
  c1a56b:	jae    c1eeca <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4b8a>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a571:	mov    r9,QWORD PTR [r14+0x8]
  c1a575:	mov    rbx,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1a57d:	mov    rax,QWORD PTR [rbx+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a581:	imul   r15,rdi,0x78
  c1a585:	lea    rsi,[r9+r15*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1a589:	movzx  edx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1a591:	mov    rcx,rdx
  c1a594:	sub    rcx,QWORD PTR [r9+r15*1+0x30]
  c1a599:	jae    c1b277 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xf37>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a59f:	mov    rcx,QWORD PTR [rsi+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a5a3:	shl    edx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1a5a6:	mov    rcx,QWORD PTR [rcx+rdx*1]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1a5aa:	cmp    rcx,rax
  c1a5ad:	jb     c1b284 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xf44>
  c1a5b3:	jmp    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1a5b8:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1a5bd:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a5c1:	cmp    rdi,rsi
  c1a5c4:	mov    r15,rdi
  c1a5c7:	jae    c1eed7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4b97>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a5cd:	mov    rdi,QWORD PTR [rax+0x8]
  c1a5d1:	mov    rax,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1a5d9:	mov    rax,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a5dd:	imul   rbx,r15,0x78
  c1a5e1:	lea    rsi,[rdi+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1a5e5:	movzx  edx,r13b
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1a5e9:	mov    rcx,rdx
  c1a5ec:	sub    rcx,QWORD PTR [rdi+rbx*1+0x30]
  c1a5f1:	jae    c1b2ea <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xfaa>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a5f7:	mov    rcx,QWORD PTR [rsi+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a5fb:	shl    edx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1a5fe:	mov    rcx,QWORD PTR [rcx+rdx*1]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1a602:	cmp    rcx,rax
  c1a605:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
  c1a60b:	jmp    c1b2f7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xfb7>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2641
  c1a610:	movzx  r12d,bpl
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:460
  c1a614:	test   r12,r12
  c1a617:	je     c1b70a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x13ca>
  c1a61d:	lea    ebx,[r12*8+0x0]
  c1a625:	call   QWORD PTR [rip+0x2347c5]        # e4edf0 <_DYNAMIC+0x300>
_RNvNtCscdodAO9FK5_5alloc5alloc5alloc():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/alloc.rs:101
  c1a62b:	mov    esi,0x8
  c1a630:	mov    rdi,rbx
  c1a633:	call   QWORD PTR [rip+0x2347bf]        # e4edf8 <_DYNAMIC+0x308>
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:469
  c1a639:	test   rax,rax
  c1a63c:	mov    r15,QWORD PTR [rsp+0x418]
  c1a644:	jne    c1b717 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x13d7>
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:442
  c1a64a:	mov    edi,0x8
  c1a64f:	mov    rsi,rbx
  c1a652:	call   QWORD PTR [rip+0x234780]        # e4edd8 <_DYNAMIC+0x2e8>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1a658:	mov    r14,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1a65d:	mov    rsi,QWORD PTR [r14+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a661:	cmp    rdi,rsi
  c1a664:	mov    r15,rdi
  c1a667:	jae    c1eee7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4ba7>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1a66d:	mov    rbx,rdx
  c1a670:	mov    r13,r8
  c1a673:	mov    rax,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a67b:	mov    rsi,QWORD PTR [rax+0x8]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1a67f:	mov    rdx,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a683:	imul   rdi,r15,0x78
  c1a687:	mov    rcx,QWORD PTR [r14+0x8]
  c1a68b:	mov    QWORD PTR [rsp+0x158],rdi
  c1a693:	add    rcx,rdi
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2805
  c1a696:	movzx  r8d,bpl
  c1a69a:	movzx  r9d,r12b
  c1a69e:	lea    rdi,[rsp+0x70]
  c1a6a3:	call   c23d20 <_RNvMs_CslyNhMBcJWAz_6bsl_vmNtB4_8CallArgs4load>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtCslyNhMBcJWAz_6bsl_vm8CallArgsNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchBM_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1a6a8:	mov    eax,DWORD PTR [rsp+0x70]
  c1a6ac:	cmp    eax,0xffffffff
  c1a6af:	je     c1b1b3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xe73>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1a6b5:	mov    ecx,DWORD PTR [rsp+0xa4]
  c1a6bc:	mov    DWORD PTR [rsp+0x190],ecx
  c1a6c3:	movdqu xmm0,XMMWORD PTR [rsp+0x74]
  c1a6c9:	movdqu xmm1,XMMWORD PTR [rsp+0x84]
  c1a6d2:	movdqu xmm2,XMMWORD PTR [rsp+0x94]
  c1a6db:	movdqa XMMWORD PTR [rsp+0x180],xmm2
  c1a6e4:	movdqa XMMWORD PTR [rsp+0x170],xmm1
  c1a6ed:	movdqa XMMWORD PTR [rsp+0x160],xmm0
  c1a6f6:	movups xmm3,XMMWORD PTR [rsp+0xa8]
  c1a6fe:	movups XMMWORD PTR [rsp+0x1e8],xmm3
  c1a706:	mov    rdx,QWORD PTR [rsp+0xb8]
  c1a70e:	mov    QWORD PTR [rsp+0x1f8],rdx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2805
  c1a716:	movdqu XMMWORD PTR [rsp+0x1b4],xmm0
  c1a71f:	movdqu XMMWORD PTR [rsp+0x1c4],xmm1
  c1a728:	movdqu XMMWORD PTR [rsp+0x1d4],xmm2
  c1a731:	mov    DWORD PTR [rsp+0x1e4],ecx
  c1a738:	mov    DWORD PTR [rsp+0x1b0],eax
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1a73f:	mov    rsi,QWORD PTR [r14+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1a743:	cmp    r15,rsi
  c1a746:	jae    c1ef58 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4c18>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1a74c:	mov    rcx,QWORD PTR [rsp+0x3d8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecINtNtB9_6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB23_5value8BslValueEINtNtB9_6result6ResultB2U_NtNtB23_5error7RtErrorEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1a754:	cmp    rbx,QWORD PTR [rcx+0x10]
  c1a758:	jae    c1b63c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x12fc>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2806
  c1a75e:	mov    rax,QWORD PTR [r14+0x8]
  c1a762:	mov    rdx,QWORD PTR [rsp+0x158]
  c1a76a:	mov    rax,QWORD PTR [rax+rdx*1+0x58]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtB8_3vec3VecINtNtCs4NRVxsYgnAr_4core6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB25_5value8BslValueEINtNtB1l_6result6ResultB2W_NtNtB25_5error7RtErrorEEEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a76f:	mov    rcx,QWORD PTR [rcx+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecINtNtB9_6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB23_5value8BslValueEINtNtB9_6result6ResultB2U_NtNtB23_5error7RtErrorEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1a773:	lea    rdx,[rbx+rbx*2]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtB9_6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB1x_5value8BslValueEINtNtB9_6result6ResultB2o_NtNtB1x_5error7RtErrorEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1a777:	cmp    rax,QWORD PTR [rcx+rdx*8+0x10]
  c1a77c:	jae    c1b63c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x12fc>
_RNvMs_NtCslyNhMBcJWAz_6bsl_vm7linkingNtB4_16LinkedComponents8function():
  c1a782:	lea    rcx,[rcx+rdx*8]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtCs4NRVxsYgnAr_4core6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB1P_5value8BslValueEINtNtB15_6result6ResultB2G_NtNtB1P_5error7RtErrorEEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1a786:	mov    rcx,QWORD PTR [rcx+0x8]
_RNCNvMs_NtCslyNhMBcJWAz_6bsl_vm7linkingNtB6_16LinkedComponents8functions_0B8_():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/linking.rs:139
  c1a78a:	mov    r14,QWORD PTR [rcx+rax*8]
_RNvMs_NtCslyNhMBcJWAz_6bsl_vm7linkingNtB4_16LinkedComponents8function():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/linking.rs:140
  c1a78e:	lea    rax,[rip+0xffffffffff6aea0e]        # 2c91a3 <anon.c9c1bb84f46a61489330f0a2bb8a4939.7.llvm.1835705092723400288>
  c1a795:	mov    QWORD PTR [rsp+0x78],rax
  c1a79a:	mov    QWORD PTR [rsp+0x80],0x42
  c1a7a6:	mov    BYTE PTR [rsp+0x70],0x1f
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtBV_5value8BslValueEINtNtB5_6result6ResultB1M_NtNtBV_5error7RtErrorEE5ok_orB2z_ECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1335
  c1a7ab:	test   r14,r14
  c1a7ae:	je     c1b654 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1314>
  c1a7b4:	lea    rdi,[rsp+0x70]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1a7b9:	call   c35d80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.1835705092723400288>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1a7be:	mov    r11,QWORD PTR [rsp+0x3e0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2813
  c1a7c6:	lea    rax,[r11+0x28]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2814
  c1a7ca:	lea    rcx,[r11+0x30]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2818
  c1a7ce:	mov    rdx,QWORD PTR [r11+0x20]
  c1a7d2:	mov    QWORD PTR [rsp+0x120],rax
  c1a7da:	mov    QWORD PTR [rsp+0x128],rcx
  c1a7e2:	mov    QWORD PTR [rsp+0x130],rdx
  c1a7ea:	mov    QWORD PTR [rsp+0x138],r13
  c1a7f2:	mov    r12,QWORD PTR [rsp+0x3d8]
  c1a7fa:	mov    QWORD PTR [rsp+0x140],r12
  c1a802:	mov    rax,QWORD PTR [rsp+0x3f0]
  c1a80a:	mov    QWORD PTR [rsp+0x148],rax
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2852
  c1a812:	lea    rdx,[r12+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2853
  c1a817:	lea    rsi,[r12+0x58]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2854
  c1a81c:	lea    rdi,[r12+0x68]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1a821:	lea    r8,[r12+0xf0]
  c1a829:	mov    rax,QWORD PTR [r12+0xf0]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1a831:	mov    r9,QWORD PTR [r12+0x118]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1a839:	test   rax,rax
  c1a83c:	cmove  r8,rax
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1a840:	lea    rcx,[r12+0x100]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtCsbxvJACuny95_6bsl_rt12temp_storage18TempStorageSessionEEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1a848:	lea    r10,[r12+0x110]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1a850:	lea    rax,[r12+0x118]
  c1a858:	test   r9,r9
  c1a85b:	cmove  rax,r9
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1a85f:	movq   xmm0,QWORD PTR [r12+0x110]
  c1a869:	movq   xmm1,QWORD PTR [r12+0x100]
  c1a873:	punpcklqdq xmm1,xmm0
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1a877:	mov    r9,QWORD PTR [rsp+0x3e8]
  c1a87f:	mov    QWORD PTR [rsp+0x70],r9
  c1a884:	mov    r9,QWORD PTR [rip+0x234585]        # e4ee10 <_DYNAMIC+0x320>
  c1a88b:	mov    QWORD PTR [rsp+0x78],r9
  c1a890:	mov    BYTE PTR [rsp+0xf8],0x0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2849
  c1a898:	movups xmm0,XMMWORD PTR [r11]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1a89c:	movups XMMWORD PTR [rsp+0x80],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2850
  c1a8a4:	movdqu xmm0,XMMWORD PTR [r11+0x10]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1a8aa:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1a8b3:	mov    QWORD PTR [rsp+0xa0],rdx
  c1a8bb:	mov    QWORD PTR [rsp+0xa8],rsi
  c1a8c3:	mov    QWORD PTR [rsp+0xb0],rdi
  c1a8cb:	mov    QWORD PTR [rsp+0xb8],r8
  c1a8d3:	mov    QWORD PTR [rsp+0xc0],0x0
  c1a8df:	lea    rdx,[rsp+0x120]
  c1a8e7:	mov    QWORD PTR [rsp+0xd0],rdx
  c1a8ef:	lea    rdx,[rip+0x21d282]        # e37b78 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xda0>
  c1a8f6:	mov    QWORD PTR [rsp+0xd8],rdx
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1a8fe:	pxor   xmm0,xmm0
  c1a902:	pcmpeqd xmm0,xmm1
  c1a906:	movq   xmm1,r10
  c1a90b:	movq   xmm2,rcx
  c1a910:	punpcklqdq xmm2,xmm1
  c1a914:	pshufd xmm1,xmm0,0xb1
  c1a919:	pand   xmm1,xmm0
  c1a91d:	pandn  xmm1,xmm2
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1a921:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1a92a:	mov    QWORD PTR [rsp+0xf0],rax
  c1a932:	lea    rdi,[rsp+0x1b0]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2862
  c1a93a:	call   c24560 <_RNvMs_CslyNhMBcJWAz_6bsl_vmNtB4_8CallArgs8as_slice>
  c1a93f:	mov    rcx,rdx
  c1a942:	lea    rdi,[rsp+0x160]
  c1a94a:	lea    rsi,[rsp+0x70]
  c1a94f:	mov    rdx,rax
  c1a952:	call   r14
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1a955:	movzx  eax,BYTE PTR [rsp+0x160]
  c1a95d:	cmp    al,0xff
  c1a95f:	je     c1d364 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3024>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1a965:	movups xmm0,XMMWORD PTR [rsp+0x161]
  c1a96d:	movdqu xmm1,XMMWORD PTR [rsp+0x170]
  c1a976:	movdqu xmm2,XMMWORD PTR [rsp+0x180]
  c1a97f:	movdqu XMMWORD PTR [rsp+0x23f],xmm1
  c1a988:	movaps XMMWORD PTR [rsp+0x230],xmm0
  c1a990:	mov    rcx,QWORD PTR [rsp+0x48]
  c1a995:	movdqu XMMWORD PTR [rcx+0x20],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2862
  c1a99a:	movups xmm0,XMMWORD PTR [rsp+0x23f]
  c1a9a2:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1a9a6:	movdqa xmm0,XMMWORD PTR [rsp+0x230]
  c1a9af:	jmp    c1ae6e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xb2e>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3236
  c1a9b4:	lea    rax,[rip+0xffffffffff6acc90]        # 2c764b <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x640>
  c1a9bb:	mov    QWORD PTR [rsp+0x78],rax
  c1a9c0:	mov    QWORD PTR [rsp+0x80],0x54
  c1a9cc:	mov    BYTE PTR [rsp+0x70],0x1f
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14CatalogContextE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1335
  c1a9d1:	test   r15,r15
  c1a9d4:	je     c1b187 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xe47>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1a9da:	mov    r12,rsi
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3235
  c1a9dd:	shl    ebp,0x8
  c1a9e0:	movzx  ebx,r13b
  c1a9e4:	lea    rdi,[rsp+0x70]
  c1a9e9:	mov    r14,r8
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14CatalogContextE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1a9ec:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3240
  c1a9f1:	movzx  eax,bp
  c1a9f4:	or     rax,rbx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCskDxgodD397f_12bsl_bytecode13configuration9LinkEntryE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1a9f7:	cmp    rax,QWORD PTR [r14+0xe8]
  c1a9fe:	jae    c1b167 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xe27>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCskDxgodD397f_12bsl_bytecode13configuration9LinkEntryECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1aa04:	mov    rcx,QWORD PTR [r14+0xe0]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3239
  c1aa0b:	cmp    BYTE PTR [rcx+rax*8],0x0
  c1aa0f:	je     c1b167 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xe27>
  c1aa15:	mov    ebx,DWORD PTR [rcx+rax*8+0x4]
  c1aa19:	movzx  r14d,WORD PTR [rcx+rax*8+0x2]
  c1aa1f:	lea    rdi,[rsp+0x70]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3247
  c1aa24:	mov    esi,ebx
  c1aa26:	mov    rdx,r15
  c1aa29:	mov    rcx,r12
  c1aa2c:	mov    r8,QWORD PTR [rsp+0x50]
  c1aa31:	mov    r9,QWORD PTR [rsp+0x100]
  c1aa39:	call   c4baa0 <_RNvNtCslyNhMBcJWAz_6bsl_vm7modules19ensure_module_ready>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultbNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1aa3e:	movzx  ecx,BYTE PTR [rsp+0x70]
  c1aa43:	movzx  eax,BYTE PTR [rsp+0x71]
  c1aa48:	cmp    cl,0xff
  c1aa4b:	jne    c1bd8d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1a4d>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3247
  c1aa51:	test   al,0x1
  c1aa53:	jne    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
  c1aa59:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1aa5e:	mov    rsi,QWORD PTR [rax+0x10]
  c1aa62:	mov    rdi,QWORD PTR [rsp+0x418]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1aa6a:	cmp    rdi,rsi
  c1aa6d:	jae    c1f163 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4e23>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1aa73:	mov    r8,QWORD PTR [rax+0x8]
  c1aa77:	mov    rax,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1aa7f:	mov    rax,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1aa83:	imul   r15,rdi,0x78
  c1aa87:	lea    rsi,[r8+r15*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1aa8b:	movzx  edx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1aa93:	mov    rcx,rdx
  c1aa96:	sub    rcx,QWORD PTR [r8+r15*1+0x30]
  c1aa9b:	jae    c1deb9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3b79>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1aaa1:	mov    rcx,QWORD PTR [rsi+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1aaa5:	shl    edx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1aaa8:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1aaac:	jmp    c1debd <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3b7d>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2653
  c1aab1:	shl    ebx,0x8
  c1aab4:	movzx  ecx,r12b
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2659
  c1aab8:	movzx  eax,bx
  c1aabb:	or     rax,rcx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1aabe:	cmp    rax,QWORD PTR [r8+0x58]
  c1aac2:	jae    c1b1fe <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xebe>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtB8_2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1aac8:	mov    rcx,QWORD PTR [r8+0x50]
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1aacc:	mov    rbx,QWORD PTR [rcx+rax*8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1aad0:	inc    QWORD PTR [rbx]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1aad3:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeE13from_inner_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:383
  c1aad9:	mov    QWORD PTR [rsp+0x120],rbx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2663
  c1aae1:	movzx  r15d,bpl
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:460
  c1aae5:	test   r15,r15
  c1aae8:	je     c1bb42 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1802>
  c1aaee:	lea    eax,[r15*8+0x0]
  c1aaf6:	lea    r14,[rax+rax*2]
  c1aafa:	call   QWORD PTR [rip+0x2342f0]        # e4edf0 <_DYNAMIC+0x300>
_RNvNtCscdodAO9FK5_5alloc5alloc5alloc():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/alloc.rs:101
  c1ab00:	mov    esi,0x8
  c1ab05:	mov    rdi,r14
  c1ab08:	call   QWORD PTR [rip+0x2342ea]        # e4edf8 <_DYNAMIC+0x308>
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:469
  c1ab0e:	test   rax,rax
  c1ab11:	jne    c1bb47 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1807>
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:442
  c1ab17:	mov    edi,0x8
  c1ab1c:	mov    rsi,r14
  c1ab1f:	call   QWORD PTR [rip+0x2342b3]        # e4edd8 <_DYNAMIC+0x2e8>
  c1ab25:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2703
  c1ab2a:	test   BYTE PTR [rsp+0x118],0x1
  c1ab32:	je     c1b21e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xede>
  c1ab38:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1ab3d:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ab41:	cmp    rdi,rsi
  c1ab44:	jae    c1ef82 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4c42>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ab4a:	mov    r9,QWORD PTR [rax+0x8]
  c1ab4e:	mov    r10,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1ab56:	mov    rax,QWORD PTR [r10+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ab5a:	imul   r8,rdi,0x78
  c1ab5e:	lea    rsi,[r9+r8*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1ab62:	movzx  edx,r13b
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1ab66:	mov    rcx,rdx
  c1ab69:	sub    rcx,QWORD PTR [r9+r8*1+0x30]
  c1ab6e:	jae    c1b996 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1656>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ab74:	mov    rcx,QWORD PTR [rsi+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ab78:	shl    edx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1ab7b:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1ab7f:	jmp    c1b99a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x165a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ab84:	mov    r14,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1ab89:	mov    rsi,QWORD PTR [r14+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ab8d:	cmp    rdi,rsi
  c1ab90:	mov    r15,rdi
  c1ab93:	jae    c1eef7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4bb7>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ab99:	mov    r13,rdx
  c1ab9c:	mov    rax,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1aba4:	mov    rsi,QWORD PTR [rax+0x8]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1aba8:	mov    rdx,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1abac:	imul   rbx,r15,0x78
  c1abb0:	mov    rcx,QWORD PTR [r14+0x8]
  c1abb4:	add    rcx,rbx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2870
  c1abb7:	movzx  r8d,bpl
  c1abbb:	movzx  r9d,r12b
  c1abbf:	lea    rdi,[rsp+0x70]
  c1abc4:	call   c23d20 <_RNvMs_CslyNhMBcJWAz_6bsl_vmNtB4_8CallArgs4load>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtCslyNhMBcJWAz_6bsl_vm8CallArgsNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchBM_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1abc9:	mov    eax,DWORD PTR [rsp+0x70]
  c1abcd:	cmp    eax,0xffffffff
  c1abd0:	je     c1b1b3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xe73>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1abd6:	mov    ecx,DWORD PTR [rsp+0xa4]
  c1abdd:	mov    DWORD PTR [rsp+0x190],ecx
  c1abe4:	movdqu xmm0,XMMWORD PTR [rsp+0x74]
  c1abea:	movdqu xmm1,XMMWORD PTR [rsp+0x84]
  c1abf3:	movdqu xmm2,XMMWORD PTR [rsp+0x94]
  c1abfc:	movdqa XMMWORD PTR [rsp+0x180],xmm2
  c1ac05:	movdqa XMMWORD PTR [rsp+0x170],xmm1
  c1ac0e:	movdqa XMMWORD PTR [rsp+0x160],xmm0
  c1ac17:	movups xmm3,XMMWORD PTR [rsp+0xa8]
  c1ac1f:	movups XMMWORD PTR [rsp+0x1e8],xmm3
  c1ac27:	mov    rdx,QWORD PTR [rsp+0xb8]
  c1ac2f:	mov    QWORD PTR [rsp+0x1f8],rdx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2870
  c1ac37:	movdqu XMMWORD PTR [rsp+0x1b4],xmm0
  c1ac40:	movdqu XMMWORD PTR [rsp+0x1c4],xmm1
  c1ac49:	movdqu XMMWORD PTR [rsp+0x1d4],xmm2
  c1ac52:	mov    DWORD PTR [rsp+0x1e4],ecx
  c1ac59:	mov    DWORD PTR [rsp+0x1b0],eax
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1ac60:	mov    rsi,QWORD PTR [r14+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ac64:	cmp    r15,rsi
  c1ac67:	jae    c1ef6d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4c2d>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ac6d:	mov    rcx,QWORD PTR [rsp+0x3d8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecINtNtB9_6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB23_5value8BslValueEINtNtB9_6result6ResultB2U_NtNtB23_5error7RtErrorEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1ac75:	cmp    r13,QWORD PTR [rcx+0x28]
  c1ac79:	jae    c1b699 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1359>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2871
  c1ac7f:	mov    rax,QWORD PTR [r14+0x8]
  c1ac83:	mov    rax,QWORD PTR [rax+rbx*1+0x58]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtB8_3vec3VecINtNtCs4NRVxsYgnAr_4core6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB25_5value8BslValueEINtNtB1l_6result6ResultB2W_NtNtB25_5error7RtErrorEEEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ac88:	mov    rcx,QWORD PTR [rcx+0x20]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecINtNtB9_6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB23_5value8BslValueEINtNtB9_6result6ResultB2U_NtNtB23_5error7RtErrorEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1ac8c:	lea    rdx,[r13*2+0x0]
  c1ac94:	add    rdx,r13
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtB9_6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB1x_5value8BslValueEINtNtB9_6result6ResultB2o_NtNtB1x_5error7RtErrorEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1ac97:	cmp    rax,QWORD PTR [rcx+rdx*8+0x10]
  c1ac9c:	jae    c1b699 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1359>
_RNvMs_NtCslyNhMBcJWAz_6bsl_vm7linkingNtB4_16LinkedComponents11constructor():
  c1aca2:	lea    rcx,[rcx+rdx*8]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtCs4NRVxsYgnAr_4core6option6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtB1P_5value8BslValueEINtNtB15_6result6ResultB2G_NtNtB1P_5error7RtErrorEEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1aca6:	mov    rcx,QWORD PTR [rcx+0x8]
_RNCNvMs_NtCslyNhMBcJWAz_6bsl_vm7linkingNtB6_16LinkedComponents11constructors_0B8_():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/linking.rs:153
  c1acaa:	mov    r14,QWORD PTR [rcx+rax*8]
_RNvMs_NtCslyNhMBcJWAz_6bsl_vm7linkingNtB4_16LinkedComponents11constructor():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/linking.rs:154
  c1acae:	lea    rax,[rip+0xffffffffff6ae4a3]        # 2c9158 <anon.c9c1bb84f46a61489330f0a2bb8a4939.6.llvm.1835705092723400288>
  c1acb5:	mov    QWORD PTR [rsp+0x78],rax
  c1acba:	mov    QWORD PTR [rsp+0x80],0x4b
  c1acc6:	mov    BYTE PTR [rsp+0x70],0x1f
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtBV_5value8BslValueEINtNtB5_6result6ResultB1M_NtNtBV_5error7RtErrorEE5ok_orB2z_ECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1335
  c1accb:	test   r14,r14
  c1acce:	je     c1b6b1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1371>
  c1acd4:	lea    rdi,[rsp+0x70]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1acd9:	call   c35d80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.1835705092723400288>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1acde:	mov    r13,QWORD PTR [rsp+0x3d8]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2877
  c1ace6:	lea    rcx,[r13+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2878
  c1acea:	lea    rdx,[r13+0x58]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2879
  c1acee:	lea    rsi,[r13+0x68]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1acf2:	lea    rdi,[r13+0xf0]
  c1acf9:	mov    rax,QWORD PTR [r13+0xf0]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1ad00:	mov    r8,QWORD PTR [r13+0x118]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1ad07:	test   rax,rax
  c1ad0a:	cmove  rdi,rax
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1ad0e:	lea    r9,[r13+0x100]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1ad15:	lea    rax,[r13+0x118]
  c1ad1c:	test   r8,r8
  c1ad1f:	cmove  rax,r8
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtCsbxvJACuny95_6bsl_rt12temp_storage18TempStorageSessionEEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1ad23:	lea    r8,[r13+0x110]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1ad2a:	movq   xmm0,QWORD PTR [r13+0x110]
  c1ad33:	movq   xmm1,QWORD PTR [r13+0x100]
  c1ad3c:	punpcklqdq xmm1,xmm0
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1ad40:	mov    r10,QWORD PTR [rsp+0x3e8]
  c1ad48:	mov    QWORD PTR [rsp+0x70],r10
  c1ad4d:	mov    r10,QWORD PTR [rip+0x2340bc]        # e4ee10 <_DYNAMIC+0x320>
  c1ad54:	mov    QWORD PTR [rsp+0x78],r10
  c1ad59:	mov    BYTE PTR [rsp+0xf8],0x0
  c1ad61:	mov    r13,QWORD PTR [rsp+0x3e0]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2874
  c1ad69:	movups xmm0,XMMWORD PTR [r13+0x0]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1ad6e:	movups XMMWORD PTR [rsp+0x80],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2875
  c1ad76:	movdqu xmm0,XMMWORD PTR [r13+0x10]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1ad7c:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1ad85:	mov    QWORD PTR [rsp+0xa0],rcx
  c1ad8d:	mov    QWORD PTR [rsp+0xa8],rdx
  c1ad95:	mov    QWORD PTR [rsp+0xb0],rsi
  c1ad9d:	mov    QWORD PTR [rsp+0xb8],rdi
  c1ada5:	mov    QWORD PTR [rsp+0xc0],0x0
  c1adb1:	mov    QWORD PTR [rsp+0xd0],0x0
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1adbd:	pxor   xmm0,xmm0
  c1adc1:	pcmpeqd xmm0,xmm1
  c1adc5:	movq   xmm1,r8
  c1adca:	movq   xmm2,r9
  c1adcf:	punpcklqdq xmm2,xmm1
  c1add3:	pshufd xmm1,xmm0,0xb1
  c1add8:	pand   xmm1,xmm0
  c1addc:	pandn  xmm1,xmm2
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1ade0:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1ade9:	mov    QWORD PTR [rsp+0xf0],rax
  c1adf1:	lea    rdi,[rsp+0x1b0]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2887
  c1adf9:	call   c24560 <_RNvMs_CslyNhMBcJWAz_6bsl_vmNtB4_8CallArgs8as_slice>
  c1adfe:	mov    rcx,rdx
  c1ae01:	lea    rdi,[rsp+0x160]
  c1ae09:	lea    rsi,[rsp+0x70]
  c1ae0e:	mov    rdx,rax
  c1ae11:	call   r14
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1ae14:	movzx  eax,BYTE PTR [rsp+0x160]
  c1ae1c:	cmp    al,0xff
  c1ae1e:	je     c1d3ce <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x308e>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1ae24:	movups xmm0,XMMWORD PTR [rsp+0x161]
  c1ae2c:	movdqu xmm1,XMMWORD PTR [rsp+0x170]
  c1ae35:	movdqu xmm2,XMMWORD PTR [rsp+0x180]
  c1ae3e:	movdqu XMMWORD PTR [rsp+0x12f],xmm1
  c1ae47:	movaps XMMWORD PTR [rsp+0x120],xmm0
  c1ae4f:	mov    rcx,QWORD PTR [rsp+0x48]
  c1ae54:	movdqu XMMWORD PTR [rcx+0x20],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2887
  c1ae59:	movups xmm0,XMMWORD PTR [rsp+0x12f]
  c1ae61:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1ae65:	movdqa xmm0,XMMWORD PTR [rsp+0x120]
  c1ae6e:	movdqu XMMWORD PTR [rcx+0x1],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1ae73:	mov    BYTE PTR [rcx],al
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ae75:	jmp    c1b6f8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x13b8>
  c1ae7a:	mov    rcx,QWORD PTR [rsp+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3260
  c1ae7f:	mov    BYTE PTR [rcx],0x1f
  c1ae82:	lea    rax,[rip+0xffffffffff6acaca]        # 2c7953 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x948>
  c1ae89:	mov    QWORD PTR [rcx+0x8],rax
  c1ae8d:	mov    QWORD PTR [rcx+0x10],0x5e
  c1ae95:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3062
  c1ae9a:	lea    rax,[rip+0xffffffffff6ac7aa]        # 2c764b <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x640>
  c1aea1:	mov    QWORD PTR [rsp+0x78],rax
  c1aea6:	lea    rcx,[rsp+0x80]
  c1aeae:	mov    QWORD PTR [rsp+0x80],0x54
  c1aeba:	mov    BYTE PTR [rsp+0x70],0x1f
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14CatalogContextE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1335
  c1aebf:	test   r15,r15
  c1aec2:	je     c1b18f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xe4f>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3057
  c1aec8:	shl    ebx,0x8
  c1aecb:	movzx  ebp,r12b
  c1aecf:	lea    rdi,[rsp+0x70]
  c1aed4:	mov    r12,r8
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14CatalogContextE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1aed7:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCskDxgodD397f_12bsl_bytecode13configuration9LinkEntryE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1aedc:	mov    rdx,QWORD PTR [r12+0xe8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3068
  c1aee4:	movzx  eax,bx
  c1aee7:	or     rax,rbp
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCskDxgodD397f_12bsl_bytecode13configuration9LinkEntryE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1aeea:	cmp    rax,rdx
  c1aeed:	jae    c1af03 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xbc3>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3068
  c1aeef:	mov    r12,QWORD PTR [r12+0xe0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3065
  c1aef7:	cmp    WORD PTR [r12+rax*8],0x1
  c1aefd:	jne    c1bd43 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1a03>
  c1af03:	mov    rcx,QWORD PTR [rsp+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3070
  c1af08:	mov    BYTE PTR [rcx],0x1f
  c1af0b:	lea    rax,[rip+0xffffffffff6ac8d9]        # 2c77eb <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x7e0>
  c1af12:	mov    QWORD PTR [rcx+0x8],rax
  c1af16:	mov    QWORD PTR [rcx+0x10],0x5d
  c1af1e:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1af23:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1af28:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1af2c:	cmp    rdi,rsi
  c1af2f:	jae    c1ef07 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4bc7>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1af35:	mov    rdx,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1af39:	imul   rbx,rdi,0x78
  c1af3d:	lea    rcx,[rdx+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1af41:	movzx  eax,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1af49:	mov    r14,rax
  c1af4c:	sub    r14,QWORD PTR [rdx+rbx*1+0x30]
  c1af51:	jae    c1b340 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1000>
  c1af57:	mov    r13,rdi
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1af5a:	mov    rcx,QWORD PTR [rcx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1af5e:	shl    eax,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1af61:	mov    r14,QWORD PTR [rcx+rax*1]
  c1af65:	jmp    c1b347 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1007>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1af6a:	mov    r14,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1af6f:	mov    rsi,QWORD PTR [r14+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1af73:	cmp    rdi,rsi
  c1af76:	mov    r15,rdi
  c1af79:	jae    c1ef14 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4bd4>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1af7f:	mov    rdi,QWORD PTR [r14+0x8]
  c1af83:	mov    rax,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1af8b:	mov    rax,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1af8f:	imul   rbx,r15,0x78
  c1af93:	lea    rsi,[rdi+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1af97:	movzx  edx,r13b
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1af9b:	mov    rcx,rdx
  c1af9e:	sub    rcx,QWORD PTR [rdi+rbx*1+0x30]
  c1afa3:	jae    c1b3d7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1097>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1afa9:	mov    rcx,QWORD PTR [rsi+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1afad:	shl    edx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1afb0:	mov    rcx,QWORD PTR [rcx+rdx*1]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1afb4:	cmp    rcx,rax
  c1afb7:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
  c1afbd:	jmp    c1b3e4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x10a4>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1afc2:	mov    rax,QWORD PTR [rsp+0x408]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2905
  c1afca:	cmp    QWORD PTR [rax],0x0
  c1afce:	jne    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
  c1afd4:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1afd9:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1afdd:	cmp    rdi,rsi
  c1afe0:	jae    c1efbe <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4c7e>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1afe6:	mov    rcx,QWORD PTR [rax+0x8]
  c1afea:	mov    r9,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1aff2:	mov    rdx,QWORD PTR [r9+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1aff6:	imul   r10,rdi,0x78
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1affa:	movzx  esi,r13b
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE3lenBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:3054
  c1affe:	mov    rax,QWORD PTR [rcx+r10*1+0x30]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b003:	add    rcx,r10
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1b006:	mov    r13,rsi
  c1b009:	sub    r13,rax
  c1b00c:	jae    c1ba0d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x16cd>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b012:	mov    rdi,QWORD PTR [rcx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b016:	shl    esi,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1b019:	mov    r13,QWORD PTR [rdi+rsi*1]
  c1b01d:	jmp    c1ba11 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x16d1>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b022:	mov    r9,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1b027:	mov    rsi,QWORD PTR [r9+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b02b:	cmp    rdi,rsi
  c1b02e:	jae    c1ef24 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4be4>
_RNvXsc_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameEINtNtNtCs4NRVxsYgnAr_4core3ops5index5IndexjE5indexBG_():
  c1b034:	mov    rbp,rdx
  c1b037:	mov    r14,r8
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b03a:	mov    r8,QWORD PTR [r9+0x8]
  c1b03e:	mov    rax,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1b046:	mov    rax,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b04a:	imul   r15,rdi,0x78
  c1b04e:	lea    rsi,[r8+r15*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1b052:	movzx  edx,r13b
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1b056:	mov    rcx,rdx
  c1b059:	sub    rcx,QWORD PTR [r8+r15*1+0x30]
  c1b05e:	jae    c1b42d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x10ed>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b064:	mov    rcx,QWORD PTR [rsi+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b068:	shl    edx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1b06b:	mov    rcx,QWORD PTR [rcx+rdx*1]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1b06f:	cmp    rcx,rax
  c1b072:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
  c1b078:	jmp    c1b43a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x10fa>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b07d:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1b082:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b086:	cmp    rdi,rsi
  c1b089:	jae    c1ef31 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4bf1>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b08f:	mov    rdx,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b093:	imul   rbx,rdi,0x78
  c1b097:	lea    rcx,[rdx+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1b09b:	movzx  eax,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1b0a3:	mov    r14,rax
  c1b0a6:	sub    r14,QWORD PTR [rdx+rbx*1+0x30]
  c1b0ab:	jae    c1b480 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1140>
  c1b0b1:	mov    r13,rdi
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b0b4:	mov    rcx,QWORD PTR [rcx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b0b8:	shl    eax,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1b0bb:	mov    r14,QWORD PTR [rcx+rax*1]
  c1b0bf:	jmp    c1b487 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1147>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b0c4:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1b0c9:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b0cd:	cmp    rdi,rsi
  c1b0d0:	jae    c1ef3e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4bfe>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b0d6:	mov    rdx,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b0da:	imul   rbx,rdi,0x78
  c1b0de:	lea    rcx,[rdx+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1b0e2:	movzx  eax,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1b0ea:	mov    r14,rax
  c1b0ed:	sub    r14,QWORD PTR [rdx+rbx*1+0x30]
  c1b0f2:	jae    c1b517 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x11d7>
  c1b0f8:	mov    r13,rdi
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b0fb:	mov    rcx,QWORD PTR [rcx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b0ff:	shl    eax,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1b102:	mov    r14,QWORD PTR [rcx+rax*1]
  c1b106:	jmp    c1b51e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x11de>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b10b:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1b110:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b114:	cmp    rdi,rsi
  c1b117:	jae    c1ef4b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4c0b>
_RNvXsc_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameEINtNtNtCs4NRVxsYgnAr_4core3ops5index5IndexjE5indexBG_():
  c1b11d:	mov    r14,rdx
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b120:	mov    r9,QWORD PTR [rax+0x8]
  c1b124:	mov    rax,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1b12c:	mov    rax,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b130:	imul   r15,rdi,0x78
  c1b134:	lea    rsi,[r9+r15*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1b138:	movzx  edx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1b140:	mov    rcx,rdx
  c1b143:	sub    rcx,QWORD PTR [r9+r15*1+0x30]
  c1b148:	jae    c1b5e6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x12a6>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b14e:	mov    rcx,QWORD PTR [rsi+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b152:	shl    edx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1b155:	mov    rcx,QWORD PTR [rcx+rdx*1]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1b159:	cmp    rcx,rax
  c1b15c:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
  c1b162:	jmp    c1b5f3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x12b3>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b167:	mov    rcx,QWORD PTR [rsp+0x48]
  c1b16c:	mov    BYTE PTR [rcx],0x1f
  c1b16f:	lea    rax,[rip+0xffffffffff6ac563]        # 2c76d9 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x6ce>
  c1b176:	mov    QWORD PTR [rcx+0x8],rax
  c1b17a:	mov    QWORD PTR [rcx+0x10],0x72
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3215
  c1b182:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1b187:	lea    rcx,[rsp+0x80]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14CatalogContextE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1337
  c1b18f:	movdqu xmm0,XMMWORD PTR [rcx]
  c1b193:	movdqu xmm1,XMMWORD PTR [rcx+0x10]
  c1b198:	mov    rcx,QWORD PTR [rsp+0x48]
  c1b19d:	movdqu XMMWORD PTR [rcx+0x20],xmm1
  c1b1a2:	movdqu XMMWORD PTR [rcx+0x10],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1b1a7:	mov    BYTE PTR [rcx],0x1f
  c1b1aa:	mov    QWORD PTR [rcx+0x8],rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b1ae:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtCslyNhMBcJWAz_6bsl_vm8CallArgsNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchBM_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1b1b3:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1b1b9:	movdqu xmm1,XMMWORD PTR [rsp+0x88]
  c1b1c2:	movdqu xmm2,XMMWORD PTR [rsp+0x98]
  c1b1cb:	movdqu XMMWORD PTR [rsp+0x184],xmm2
  c1b1d4:	movdqu XMMWORD PTR [rsp+0x174],xmm1
  c1b1dd:	movdqu XMMWORD PTR [rsp+0x164],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b1e6:	mov    rax,QWORD PTR [rsp+0x48]
  c1b1eb:	movdqu XMMWORD PTR [rax+0x20],xmm2
  c1b1f0:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1b1f5:	movdqu XMMWORD PTR [rax],xmm0
  c1b1f9:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1b1fe:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1b203:	mov    BYTE PTR [rcx],0x1f
  c1b206:	lea    rax,[rip+0xffffffffff6ac63b]        # 2c7848 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x83d>
  c1b20d:	mov    QWORD PTR [rcx+0x8],rax
  c1b211:	mov    QWORD PTR [rcx+0x10],0x47
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b219:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1b21e:	mov    rsi,QWORD PTR [rsp+0x3d0]
_RNvXs4_NtCs4NRVxsYgnAr_4core6optionINtB5_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueENtNtB7_5clone5Clone5cloneCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:2274
  c1b226:	cmp    DWORD PTR [rsi],0xffffffff
  c1b229:	je     c1b9ed <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x16ad>
  c1b22f:	lea    rdi,[rsp+0x70]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:2275
  c1b234:	call   c246a0 <_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1b239:	movsd  xmm0,QWORD PTR [rsp+0x70]
  c1b23f:	movaps XMMWORD PTR [rsp+0x50],xmm0
  c1b244:	movups xmm0,XMMWORD PTR [rsp+0x78]
  c1b249:	movaps XMMWORD PTR [rsp+0x100],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2708
  c1b251:	mov    DWORD PTR [rsp+0x70],0x2
  c1b259:	lea    rdi,[rsp+0x70]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE9unwrap_orCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1043
  c1b25e:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1b263:	movdqa xmm1,XMMWORD PTR [rsp+0x100]
  c1b26c:	movdqa xmm0,XMMWORD PTR [rsp+0x50]
  c1b272:	jmp    c1b9f6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x16b6>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b277:	add    rcx,QWORD PTR [rsi+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1b27b:	cmp    rcx,rax
  c1b27e:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3014
  c1b284:	mov    rdx,QWORD PTR [rbx+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b288:	lea    rsi,[rcx+rcx*2]
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b28c:	mov    eax,DWORD PTR [rdx+rsi*8]
  c1b28f:	lea    edi,[rax-0x2]
  c1b292:	cmp    rax,0x2
  c1b296:	mov    ecx,0x3
  c1b29b:	cmovb  edi,ecx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b29e:	lea    rdx,[rdx+rsi*8]
  c1b2a2:	lea    rsi,[rip+0xffffffffff6ab89f]        # 2c6b48 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x14ff>
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b2a9:	movsxd rdi,DWORD PTR [rsi+rdi*4]
  c1b2ad:	add    rdi,rsi
  c1b2b0:	jmp    rdi
  c1b2b2:	mov    rcx,QWORD PTR [rdx+0x8]
  c1b2b6:	mov    rsi,QWORD PTR [rdx+0x10]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1b2ba:	mov    edx,DWORD PTR [rdx+0x4]
  c1b2bd:	shl    rdx,0x20
  c1b2c1:	or     rdx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3014
  c1b2c4:	mov    QWORD PTR [rsp+0x230],rdx
  c1b2cc:	mov    QWORD PTR [rsp+0x238],rcx
  c1b2d4:	mov    QWORD PTR [rsp+0x240],rsi
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3015
  c1b2dc:	cmp    eax,0x6
  c1b2df:	jne    c1c31d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1fdd>
  c1b2e5:	jmp    c1c3ab <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x206b>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b2ea:	add    rcx,QWORD PTR [rsi+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1b2ee:	cmp    rcx,rax
  c1b2f1:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b2f7:	mov    rax,QWORD PTR [rsp+0x100]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2695
  c1b2ff:	mov    rax,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b303:	lea    rcx,[rcx+rcx*2]
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b307:	mov    edi,DWORD PTR [rax+rcx*8]
  c1b30a:	mov    r8d,edi
  c1b30d:	sub    r8d,0x2
  c1b311:	mov    edx,0x3
  c1b316:	cmovb  r8d,edx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b31a:	lea    rsi,[rax+rcx*8]
  c1b31e:	lea    rax,[rip+0xffffffffff6ab84b]        # 2c6b70 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1527>
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b325:	movsxd rcx,DWORD PTR [rax+r8*4]
  c1b329:	add    rcx,rax
  c1b32c:	jmp    rcx
  c1b32e:	mov    ecx,DWORD PTR [rsi+0x4]
  c1b331:	mov    rax,QWORD PTR [rsi+0x8]
  c1b335:	mov    rsi,QWORD PTR [rsi+0x10]
  c1b339:	mov    edx,edi
  c1b33b:	jmp    c1c546 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2206>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b340:	mov    r13,rdi
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b343:	add    r14,QWORD PTR [rcx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b347:	mov    rax,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b34f:	mov    r15,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1b353:	mov    r12,QWORD PTR [rax+0x10]
  c1b357:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2674
  c1b35c:	call   QWORD PTR [rip+0x23900e]        # e54370 <_DYNAMIC+0x5880>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1b362:	cmp    r14,r12
  c1b365:	jae    c1b5aa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x126a>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1b36b:	lea    rax,[r14+r14*2]
  c1b36f:	lea    r14,[r15+rax*8]
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1b373:	mov    eax,DWORD PTR [r15+rax*8]
  c1b377:	mov    edx,eax
  c1b379:	sub    edx,0x2
  c1b37c:	mov    ecx,0x3
  c1b381:	cmovae ecx,edx
  c1b384:	cmp    ecx,0x8
  c1b387:	ja     c1d235 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2ef5>
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
  c1b38d:	mov    edx,0x1e7
  c1b392:	bt     edx,ecx
  c1b395:	mov    r15,r13
  c1b398:	jae    c1c0f1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1db1>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1b39e:	mov    rax,QWORD PTR [rsp+0x80]
  c1b3a6:	mov    QWORD PTR [r14+0x10],rax
  c1b3aa:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1b3b0:	movdqu XMMWORD PTR [r14],xmm0
  c1b3b5:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1b3ba:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1b3be:	cmp    r15,rsi
  c1b3c1:	jb     c1bec5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b85>
  c1b3c7:	lea    rdx,[rip+0x21c65a]        # e37a28 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xc50>
  c1b3ce:	mov    rdi,r15
  c1b3d1:	call   QWORD PTR [rip+0x233a31]        # e4ee08 <_DYNAMIC+0x318>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b3d7:	add    rcx,QWORD PTR [rsi+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1b3db:	cmp    rcx,rax
  c1b3de:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b3e4:	mov    rax,QWORD PTR [rsp+0x100]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2678
  c1b3ec:	mov    rax,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b3f0:	lea    rcx,[rcx+rcx*2]
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b3f4:	mov    edi,DWORD PTR [rax+rcx*8]
  c1b3f7:	mov    r8d,edi
  c1b3fa:	sub    r8d,0x2
  c1b3fe:	mov    edx,0x3
  c1b403:	cmovb  r8d,edx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b407:	lea    rsi,[rax+rcx*8]
  c1b40b:	lea    rax,[rip+0xffffffffff6ab786]        # 2c6b98 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x154f>
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b412:	movsxd rcx,DWORD PTR [rax+r8*4]
  c1b416:	add    rcx,rax
  c1b419:	jmp    rcx
  c1b41b:	mov    ecx,DWORD PTR [rsi+0x4]
  c1b41e:	mov    rax,QWORD PTR [rsi+0x8]
  c1b422:	mov    rsi,QWORD PTR [rsi+0x10]
  c1b426:	mov    edx,edi
  c1b428:	jmp    c1c8c4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2584>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b42d:	add    rcx,QWORD PTR [rsi+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1b431:	cmp    rcx,rax
  c1b434:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b43a:	mov    rax,QWORD PTR [rsp+0x100]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2713
  c1b442:	mov    rdx,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b446:	lea    rcx,[rcx+rcx*2]
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b44a:	mov    edi,DWORD PTR [rdx+rcx*8]
  c1b44d:	mov    esi,edi
  c1b44f:	sub    esi,0x2
  c1b452:	mov    eax,0x3
  c1b457:	cmovb  esi,eax
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b45a:	lea    rdx,[rdx+rcx*8]
  c1b45e:	lea    rcx,[rip+0xffffffffff6ab6bb]        # 2c6b20 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x14d7>
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b465:	movsxd rsi,DWORD PTR [rcx+rsi*4]
  c1b469:	add    rsi,rcx
  c1b46c:	jmp    rsi
  c1b46e:	mov    ecx,DWORD PTR [rdx+0x4]
  c1b471:	mov    rsi,QWORD PTR [rdx+0x8]
  c1b475:	mov    rdx,QWORD PTR [rdx+0x10]
  c1b479:	mov    eax,edi
  c1b47b:	jmp    c1cb04 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x27c4>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b480:	mov    r13,rdi
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b483:	add    r14,QWORD PTR [rcx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b487:	mov    rax,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b48f:	mov    r15,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1b493:	mov    r12,QWORD PTR [rax+0x10]
  c1b497:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2691
  c1b49c:	call   QWORD PTR [rip+0x235886]        # e50d28 <_DYNAMIC+0x2238>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1b4a2:	cmp    r14,r12
  c1b4a5:	jae    c1b5aa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x126a>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1b4ab:	lea    rax,[r14+r14*2]
  c1b4af:	lea    r14,[r15+rax*8]
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1b4b3:	mov    eax,DWORD PTR [r15+rax*8]
  c1b4b7:	mov    edx,eax
  c1b4b9:	sub    edx,0x2
  c1b4bc:	mov    ecx,0x3
  c1b4c1:	cmovae ecx,edx
  c1b4c4:	cmp    ecx,0x8
  c1b4c7:	ja     c1d254 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2f14>
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
  c1b4cd:	mov    edx,0x1e7
  c1b4d2:	bt     edx,ecx
  c1b4d5:	mov    r15,r13
  c1b4d8:	jae    c1c11e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1dde>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1b4de:	mov    rax,QWORD PTR [rsp+0x80]
  c1b4e6:	mov    QWORD PTR [r14+0x10],rax
  c1b4ea:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1b4f0:	movdqu XMMWORD PTR [r14],xmm0
  c1b4f5:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1b4fa:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1b4fe:	cmp    r15,rsi
  c1b501:	jb     c1bec5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b85>
  c1b507:	lea    rdx,[rip+0x21c5c2]        # e37ad0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xcf8>
  c1b50e:	mov    rdi,r15
  c1b511:	call   QWORD PTR [rip+0x2338f1]        # e4ee08 <_DYNAMIC+0x318>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b517:	mov    r13,rdi
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b51a:	add    r14,QWORD PTR [rcx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b51e:	mov    rax,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b526:	mov    r15,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1b52a:	mov    r12,QWORD PTR [rax+0x10]
  c1b52e:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2686
  c1b533:	call   QWORD PTR [rip+0x238e3f]        # e54378 <_DYNAMIC+0x5888>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1b539:	cmp    r14,r12
  c1b53c:	jae    c1b5aa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x126a>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1b53e:	lea    rax,[r14+r14*2]
  c1b542:	lea    r14,[r15+rax*8]
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1b546:	mov    eax,DWORD PTR [r15+rax*8]
  c1b54a:	mov    edx,eax
  c1b54c:	sub    edx,0x2
  c1b54f:	mov    ecx,0x3
  c1b554:	cmovae ecx,edx
  c1b557:	cmp    ecx,0x8
  c1b55a:	ja     c1d273 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2f33>
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
  c1b560:	mov    edx,0x1e7
  c1b565:	bt     edx,ecx
  c1b568:	mov    r15,r13
  c1b56b:	jae    c1c14b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1e0b>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1b571:	mov    rax,QWORD PTR [rsp+0x80]
  c1b579:	mov    QWORD PTR [r14+0x10],rax
  c1b57d:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1b583:	movdqu XMMWORD PTR [r14],xmm0
  c1b588:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1b58d:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1b591:	cmp    r15,rsi
  c1b594:	jb     c1bec5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b85>
  c1b59a:	lea    rdx,[rip+0x21c4ff]        # e37aa0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xcc8>
  c1b5a1:	mov    rdi,r15
  c1b5a4:	call   QWORD PTR [rip+0x23385e]        # e4ee08 <_DYNAMIC+0x318>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1b5aa:	mov    eax,DWORD PTR [rsp+0x70]
  c1b5ae:	mov    edx,eax
  c1b5b0:	sub    edx,0x2
  c1b5b3:	mov    ecx,0x3
  c1b5b8:	cmovae ecx,edx
  c1b5bb:	cmp    ecx,0x8
  c1b5be:	ja     c1bef9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1bb9>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b5c4:	mov    edx,0x1e7
  c1b5c9:	bt     edx,ecx
  c1b5cc:	jae    c1b967 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1627>
  c1b5d2:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1b5d7:	mov    BYTE PTR [rcx],0x1f
  c1b5da:	lea    rax,[rip+0xffffffffff6abfb3]        # 2c7594 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x589>
  c1b5e1:	jmp    c1dfeb <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cab>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b5e6:	add    rcx,QWORD PTR [rsi+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1b5ea:	cmp    rcx,rax
  c1b5ed:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b5f3:	mov    rax,QWORD PTR [rsp+0x100]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2753
  c1b5fb:	mov    rax,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b5ff:	lea    rcx,[rcx+rcx*2]
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b603:	mov    edi,DWORD PTR [rax+rcx*8]
  c1b606:	mov    r9d,edi
  c1b609:	sub    r9d,0x2
  c1b60d:	mov    edx,0x3
  c1b612:	cmovb  r9d,edx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b616:	lea    rsi,[rax+rcx*8]
  c1b61a:	lea    rax,[rip+0xffffffffff6ab4d7]        # 2c6af8 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x14af>
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b621:	movsxd rcx,DWORD PTR [rax+r9*4]
  c1b625:	add    rcx,rax
  c1b628:	jmp    rcx
  c1b62a:	mov    ecx,DWORD PTR [rsi+0x4]
  c1b62d:	mov    rax,QWORD PTR [rsi+0x8]
  c1b631:	mov    rsi,QWORD PTR [rsi+0x10]
  c1b635:	mov    edx,edi
  c1b637:	jmp    c1ceaa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2b6a>
_RNvMs_NtCslyNhMBcJWAz_6bsl_vm7linkingNtB4_16LinkedComponents8function():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/linking.rs:140
  c1b63c:	lea    rax,[rip+0xffffffffff6adb60]        # 2c91a3 <anon.c9c1bb84f46a61489330f0a2bb8a4939.7.llvm.1835705092723400288>
  c1b643:	mov    QWORD PTR [rsp+0x78],rax
  c1b648:	mov    QWORD PTR [rsp+0x80],0x42
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtBV_5value8BslValueEINtNtB5_6result6ResultB1M_NtNtBV_5error7RtErrorEE5ok_orB2z_ECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1337
  c1b654:	mov    eax,DWORD PTR [rsp+0x71]
  c1b658:	mov    ecx,DWORD PTR [rsp+0x74]
  c1b65c:	mov    rdx,QWORD PTR [rsp+0x48]
  c1b661:	mov    DWORD PTR [rdx+0x4],ecx
  c1b664:	mov    DWORD PTR [rdx+0x1],eax
  c1b667:	mov    rax,QWORD PTR [rsp+0x80]
  c1b66f:	mov    rcx,QWORD PTR [rsp+0x88]
  c1b677:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1b680:	mov    QWORD PTR [rdx+0x10],rax
  c1b684:	mov    QWORD PTR [rdx+0x18],rcx
  c1b688:	movdqu XMMWORD PTR [rdx+0x20],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1b68d:	mov    BYTE PTR [rdx],0x1f
  c1b690:	lea    rax,[rip+0xffffffffff6adb0c]        # 2c91a3 <anon.c9c1bb84f46a61489330f0a2bb8a4939.7.llvm.1835705092723400288>
  c1b697:	jmp    c1b6f4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x13b4>
_RNvMs_NtCslyNhMBcJWAz_6bsl_vm7linkingNtB4_16LinkedComponents11constructor():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/linking.rs:154
  c1b699:	lea    rax,[rip+0xffffffffff6adab8]        # 2c9158 <anon.c9c1bb84f46a61489330f0a2bb8a4939.6.llvm.1835705092723400288>
  c1b6a0:	mov    QWORD PTR [rsp+0x78],rax
  c1b6a5:	mov    QWORD PTR [rsp+0x80],0x4b
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionFG1_QL2_INtNtCsbxvJACuny95_6bsl_rt9component11CallContextL1_ERL0_SNtNtBV_5value8BslValueEINtNtB5_6result6ResultB1M_NtNtBV_5error7RtErrorEE5ok_orB2z_ECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1337
  c1b6b1:	mov    eax,DWORD PTR [rsp+0x71]
  c1b6b5:	mov    ecx,DWORD PTR [rsp+0x74]
  c1b6b9:	mov    rdx,QWORD PTR [rsp+0x48]
  c1b6be:	mov    DWORD PTR [rdx+0x4],ecx
  c1b6c1:	mov    DWORD PTR [rdx+0x1],eax
  c1b6c4:	mov    rax,QWORD PTR [rsp+0x80]
  c1b6cc:	mov    rcx,QWORD PTR [rsp+0x88]
  c1b6d4:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1b6dd:	mov    QWORD PTR [rdx+0x10],rax
  c1b6e1:	mov    QWORD PTR [rdx+0x18],rcx
  c1b6e5:	movdqu XMMWORD PTR [rdx+0x20],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1b6ea:	mov    BYTE PTR [rdx],0x1f
  c1b6ed:	lea    rax,[rip+0xffffffffff6ada64]        # 2c9158 <anon.c9c1bb84f46a61489330f0a2bb8a4939.6.llvm.1835705092723400288>
  c1b6f4:	mov    QWORD PTR [rdx+0x8],rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b6f8:	lea    rdi,[rsp+0x1b0]
  c1b700:	call   c0a020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCslyNhMBcJWAz_6bsl_vm8CallArgsEBD_>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1b705:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1b70a:	mov    eax,0x8
  c1b70f:	mov    r15,QWORD PTR [rsp+0x418]
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecjE16with_capacity_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:977
  c1b717:	mov    QWORD PTR [rsp+0x120],r12
  c1b71f:	mov    QWORD PTR [rsp+0x128],rax
  c1b727:	mov    QWORD PTR [rsp+0x130],0x0
_RNvXsW_NtNtCs4NRVxsYgnAr_4core3cmp5implshNtB7_10PartialOrd2lt():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/cmp.rs:1916
  c1b733:	test   bpl,bpl
  c1b736:	je     c1bfaa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1c6a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b73c:	imul   rax,r15,0x78
  c1b740:	mov    QWORD PTR [rsp+0x158],rax
  c1b748:	jmp    c1b767 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1427>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1b74a:	mov    rax,QWORD PTR [rsp+0x1b8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1b752:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1b755:	je     c1b954 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1614>
_RNvXsW_NtNtCs4NRVxsYgnAr_4core3cmp5implshNtB7_10PartialOrd2lt():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/cmp.rs:1916
  c1b75b:	inc    r13
  c1b75e:	dec    r12
_RNvXs3_NtNtCs4NRVxsYgnAr_4core4iter5rangeINtNtNtB9_3ops5range5RangehENtB5_17RangeIteratorImpl9spec_nextCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/iter/range.rs:900
  c1b761:	je     c1bf43 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1c03>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b767:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1b76c:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b770:	cmp    r15,rsi
  c1b773:	jae    c1eeb5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4b75>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b779:	mov    rsi,QWORD PTR [rax+0x8]
  c1b77d:	mov    rdi,QWORD PTR [rsp+0x158]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b785:	lea    rdx,[rsi+rdi*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1b789:	movzx  ecx,r13b
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1b78d:	mov    rax,rcx
  c1b790:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c1b795:	jae    c1b7a4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1464>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b797:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1b79b:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1b79e:	mov    rax,QWORD PTR [rax+rcx*1]
  c1b7a2:	jmp    c1b7a8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1468>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b7a4:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b7a8:	mov    rcx,QWORD PTR [rsp+0x100]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1b7b0:	cmp    rax,QWORD PTR [rcx+0x10]
  c1b7b4:	jae    c1bf17 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1bd7>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2643
  c1b7ba:	mov    rdx,QWORD PTR [rcx+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b7be:	lea    rax,[rax+rax*2]
  c1b7c2:	lea    rcx,[rdx+rax*8]
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1b7c6:	mov    eax,DWORD PTR [rdx+rax*8]
  c1b7c9:	lea    edx,[rax-0x2]
  c1b7cc:	cmp    rax,0x2
  c1b7d0:	mov    esi,0x3
  c1b7d5:	cmovb  edx,esi
  c1b7d8:	lea    rsi,[rip+0xffffffffff6ab409]        # 2c6be8 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x159f>
  c1b7df:	movsxd rdx,DWORD PTR [rsi+rdx*4]
  c1b7e3:	add    rdx,rsi
  c1b7e6:	jmp    rdx
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1b7e8:	mov    r14d,DWORD PTR [rcx+0x4]
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
  c1b7ec:	mov    rbx,QWORD PTR [rcx+0x8]
  c1b7f0:	mov    rdx,QWORD PTR [rcx+0x10]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1b7f4:	mov    rcx,r14
  c1b7f7:	shl    rcx,0x20
  c1b7fb:	or     rcx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2643
  c1b7fe:	mov    QWORD PTR [rsp+0x1b0],rcx
  c1b806:	mov    QWORD PTR [rsp+0x1b8],rbx
  c1b80e:	mov    QWORD PTR [rsp+0x278],rdx
  c1b816:	mov    QWORD PTR [rsp+0x1c0],rdx
_RNvCslyNhMBcJWAz_6bsl_vm12dim_to_usize():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3271
  c1b81e:	cmp    eax,0x1
  c1b821:	ja     c1dbe8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38a8>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3273
  c1b827:	lea    rdi,[rsp+0x1b0]
  c1b82f:	call   QWORD PTR [rip+0x234c53]        # e50488 <_DYNAMIC+0x1998>
  c1b835:	mov    BYTE PTR [rsp+0x70],0x4
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionxE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1335
  c1b83a:	cmp    rax,0x1
  c1b83e:	jne    c1b9e1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x16a1>
_RNvCslyNhMBcJWAz_6bsl_vm12dim_to_usize():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3273
  c1b844:	mov    rbp,rdx
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionxE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1b847:	lea    rdi,[rsp+0x70]
  c1b84c:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
_RNvXso_NtNtNtCs4NRVxsYgnAr_4core7convert3num18ptr_try_from_implsjINtB9_7TryFromxE8try_from():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/convert/num.rs:278
  c1b851:	test   rbp,rbp
  c1b854:	js     c1b9e1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x16a1>
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecjE8push_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1037
  c1b85a:	mov    r15,QWORD PTR [rsp+0x130]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1040
  c1b862:	cmp    r15,QWORD PTR [rsp+0x120]
  c1b86a:	jne    c1b87a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x153a>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1041
  c1b86c:	lea    rdi,[rsp+0x120]
  c1b874:	call   QWORD PTR [rip+0x234fa6]        # e50820 <_DYNAMIC+0x1d30>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nulljECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1b87a:	mov    rax,QWORD PTR [rsp+0x128]
  c1b882:	mov    QWORD PTR [rsp+0x68],rbp
_RINvNtCs4NRVxsYgnAr_4core3ptr5writejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:1933
  c1b887:	mov    QWORD PTR [rax+r15*8],rbp
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecjE8push_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1046
  c1b88b:	inc    r15
  c1b88e:	mov    QWORD PTR [rsp+0x130],r15
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1b896:	mov    eax,DWORD PTR [rsp+0x1b0]
  c1b89d:	mov    ecx,eax
  c1b89f:	sub    ecx,0x2
  c1b8a2:	mov    edx,0x3
  c1b8a7:	cmovb  ecx,edx
  c1b8aa:	cmp    ecx,0x8
  c1b8ad:	ja     c1b928 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x15e8>
  c1b8af:	mov    edx,0x1e7
  c1b8b4:	bt     edx,ecx
  c1b8b7:	mov    r15,QWORD PTR [rsp+0x418]
  c1b8bf:	jb     c1b75b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x141b>
  c1b8c5:	cmp    ecx,0x3
  c1b8c8:	jne    c1b74a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x140a>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1b8ce:	test   eax,eax
  c1b8d0:	je     c1b75b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x141b>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1b8d6:	mov    rax,QWORD PTR [rsp+0x1b8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1b8de:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1b8e1:	jne    c1b75b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x141b>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1b8e7:	lea    rdi,[rsp+0x1b8]
  c1b8ef:	call   QWORD PTR [rip+0x233443]        # e4ed38 <_DYNAMIC+0x248>
  c1b8f5:	jmp    c1b75b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x141b>
_RNvXsi_NtCsi8OWPsLN6MM_10bsl_number6numberNtB5_4ReprNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-number/src/number.rs:143
  c1b8fa:	test   al,0x1
  c1b8fc:	je     c1b7e8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x14a8>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1b902:	mov    rbx,QWORD PTR [rcx+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1b906:	inc    QWORD PTR [rbx]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1b909:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2643
  c1b90f:	mov    QWORD PTR [rsp+0x1b0],0x1
  c1b91b:	mov    QWORD PTR [rsp+0x1b8],rbx
  c1b923:	jmp    c1b827 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x14e7>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1b928:	mov    rax,QWORD PTR [rsp+0x1b8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1b930:	dec    QWORD PTR [rax]
  c1b933:	mov    r15,QWORD PTR [rsp+0x418]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1b93b:	jne    c1b75b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x141b>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1b941:	lea    rdi,[rsp+0x1b8]
  c1b949:	call   QWORD PTR [rip+0x2333f9]        # e4ed48 <_DYNAMIC+0x258>
  c1b94f:	jmp    c1b75b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x141b>
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1b954:	lea    rdi,[rsp+0x1b8]
  c1b95c:	call   QWORD PTR [rip+0x2333de]        # e4ed40 <_DYNAMIC+0x250>
  c1b962:	jmp    c1b75b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x141b>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b967:	cmp    ecx,0x3
  c1b96a:	jne    c1bedb <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b9b>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1b970:	test   eax,eax
  c1b972:	je     c1b5d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1292>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1b978:	mov    rax,QWORD PTR [rsp+0x78]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1b97d:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1b980:	jne    c1b5d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1292>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1b986:	lea    rdi,[rsp+0x78]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1b98b:	call   QWORD PTR [rip+0x2333a7]        # e4ed38 <_DYNAMIC+0x248>
  c1b991:	jmp    c1b5d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1292>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1b996:	add    rcx,QWORD PTR [rsi+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1b99a:	cmp    rcx,rax
  c1b99d:	jae    c1b9c3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1683>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2704
  c1b99f:	mov    rax,QWORD PTR [r10+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1b9a3:	lea    rcx,[rcx+rcx*2]
  c1b9a7:	lea    rsi,[rax+rcx*8]
  c1b9ab:	lea    rdi,[rsp+0x70]
_RNvYNvYNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneINtNtNtBN_3ops8function6FnOnceTRB5_EE9call_onceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ops/function.rs:250
  c1b9b0:	call   c246a0 <_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1162
  c1b9b5:	movq   xmm0,QWORD PTR [rsp+0x70]
  c1b9bb:	movdqu xmm1,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2704
  c1b9c1:	jmp    c1b9f6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x16b6>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1b9c3:	lea    rax,[rip+0xffffffffff6ab3d6]        # 2c6da0 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1757>
  c1b9ca:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1b9cf:	mov    BYTE PTR [rcx],0x1f
  c1b9d2:	mov    DWORD PTR [rcx+0x8],eax
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1b9d5:	shr    rax,0x20
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1b9d9:	mov    DWORD PTR [rcx+0xc],eax
  c1b9dc:	jmp    c1dfef <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3caf>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1b9e1:	mov    al,0x4
  c1b9e3:	mov    rdx,QWORD PTR [rsp+0x68]
  c1b9e8:	jmp    c1dbf1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38b1>
  c1b9ed:	mov    eax,0x2
  c1b9f2:	movd   xmm0,eax
  c1b9f6:	mov    rax,QWORD PTR [rsp+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2710
  c1b9fb:	mov    BYTE PTR [rax],0x7
  c1b9fe:	movq   QWORD PTR [rax+0x8],xmm0
  c1ba03:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1ba08:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1ba0d:	add    r13,QWORD PTR [rcx+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1ba11:	cmp    r13,rdx
  c1ba14:	jae    c1bb22 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x17e2>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ba1a:	mov    QWORD PTR [rsp+0x278],r10
  c1ba22:	mov    r15,QWORD PTR [r9+0x8]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2925
  c1ba26:	test   r12b,r12b
  c1ba29:	je     c1c178 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1e38>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2923
  c1ba2f:	movzx  ebx,bpl
  c1ba33:	sub    rbx,rax
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2927
  c1ba36:	jae    c1c287 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1f47>
  c1ba3c:	mov    rbx,r8
  c1ba3f:	mov    DWORD PTR [rsp+0x68],0x0
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2935
  c1ba47:	movzx  r8d,bpl
  c1ba4b:	movzx  r9d,r12b
  c1ba4f:	lea    rdi,[rsp+0x70]
  c1ba54:	mov    rsi,r15
  c1ba57:	call   c23d20 <_RNvMs_CslyNhMBcJWAz_6bsl_vmNtB4_8CallArgs4load>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtCslyNhMBcJWAz_6bsl_vm8CallArgsNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchBM_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1ba5c:	mov    eax,DWORD PTR [rsp+0x70]
  c1ba60:	cmp    eax,0xffffffff
  c1ba63:	je     c1db62 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3822>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1ba69:	mov    ecx,DWORD PTR [rsp+0xa4]
  c1ba70:	mov    DWORD PTR [rsp+0x1e0],ecx
  c1ba77:	movdqu xmm0,XMMWORD PTR [rsp+0x74]
  c1ba7d:	movdqu xmm1,XMMWORD PTR [rsp+0x84]
  c1ba86:	movdqu xmm2,XMMWORD PTR [rsp+0x94]
  c1ba8f:	movdqa XMMWORD PTR [rsp+0x1d0],xmm2
  c1ba98:	movdqa XMMWORD PTR [rsp+0x1c0],xmm1
  c1baa1:	movdqa XMMWORD PTR [rsp+0x1b0],xmm0
  c1baaa:	movups xmm3,XMMWORD PTR [rsp+0xa8]
  c1bab2:	movups XMMWORD PTR [rsp+0x198],xmm3
  c1baba:	mov    rdx,QWORD PTR [rsp+0xb8]
  c1bac2:	mov    QWORD PTR [rsp+0x1a8],rdx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2935
  c1baca:	movdqu XMMWORD PTR [rsp+0x164],xmm0
  c1bad3:	movdqu XMMWORD PTR [rsp+0x174],xmm1
  c1badc:	movdqu XMMWORD PTR [rsp+0x184],xmm2
  c1bae5:	mov    DWORD PTR [rsp+0x194],ecx
  c1baec:	mov    DWORD PTR [rsp+0x160],eax
  c1baf3:	mov    al,0x1
  c1baf5:	mov    DWORD PTR [rsp+0x68],eax
  c1baf9:	lea    rdi,[rsp+0x160]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2936
  c1bb01:	call   c24560 <_RNvMs_CslyNhMBcJWAz_6bsl_vmNtB4_8CallArgs8as_slice>
  c1bb06:	mov    rcx,rax
  c1bb09:	mov    al,0x1
  c1bb0b:	mov    DWORD PTR [rsp+0x68],eax
  c1bb0f:	mov    r8,rbx
  c1bb12:	mov    r11,QWORD PTR [rsp+0x3e8]
  c1bb1a:	mov    rbp,rdx
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2927
  c1bb1d:	jmp    c1d6e4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x33a4>
  c1bb22:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1bb27:	mov    BYTE PTR [rcx],0x1f
  c1bb2a:	lea    rax,[rip+0xffffffffff6abd82]        # 2c78b3 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x8a8>
  c1bb31:	mov    QWORD PTR [rcx+0x8],rax
  c1bb35:	mov    QWORD PTR [rcx+0x10],0x4d
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bb3d:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1bb42:	mov    eax,0x8
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE16with_capacity_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:977
  c1bb47:	mov    QWORD PTR [rsp+0x160],r15
  c1bb4f:	mov    QWORD PTR [rsp+0x168],rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bb57:	mov    QWORD PTR [rsp+0x170],0x0
_RNvXsW_NtNtCs4NRVxsYgnAr_4core3cmp5implshNtB7_10PartialOrd2lt():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/cmp.rs:1916
  c1bb63:	test   bpl,bpl
_RNvXs3_NtNtCs4NRVxsYgnAr_4core4iter5rangeINtNtNtB9_3ops5range5RangehENtB5_17RangeIteratorImpl9spec_nextCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/iter/range.rs:900
  c1bb66:	je     c1bdcb <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1a8b>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bb6c:	imul   rax,QWORD PTR [rsp+0x418],0x78
  c1bb75:	mov    QWORD PTR [rsp+0x158],rax
  c1bb7d:	jmp    c1bbc4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1884>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
  c1bb7f:	nop
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1bb80:	mov    rax,QWORD PTR [rsp+0x168]
_RNvMNtNtCs4NRVxsYgnAr_4core3ptr7mut_ptrONtNtCsbxvJACuny95_6bsl_rt5value8BslValue3addCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mut_ptr.rs:961
  c1bb88:	lea    rcx,[rbx+rbx*2]
_RINvNtCs4NRVxsYgnAr_4core3ptr5writeNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:1933
  c1bb8c:	mov    rdx,QWORD PTR [rsp+0x2e8]
  c1bb94:	mov    QWORD PTR [rax+rcx*8+0x10],rdx
  c1bb99:	movdqu xmm0,XMMWORD PTR [rsp+0x2d8]
  c1bba2:	movdqu XMMWORD PTR [rax+rcx*8],xmm0
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8push_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1046
  c1bba7:	inc    rbx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bbaa:	mov    QWORD PTR [rsp+0x170],rbx
_RNvXsW_NtNtCs4NRVxsYgnAr_4core3cmp5implshNtB7_10PartialOrd2lt():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/cmp.rs:1916
  c1bbb2:	inc    r13
  c1bbb5:	dec    r15
  c1bbb8:	mov    rdi,r12
  c1bbbb:	mov    r8,r14
_RNvXs3_NtNtCs4NRVxsYgnAr_4core4iter5rangeINtNtNtB9_3ops5range5RangehENtB5_17RangeIteratorImpl9spec_nextCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/iter/range.rs:900
  c1bbbe:	je     c1bdc3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1a83>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bbc4:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1bbc9:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1bbcd:	cmp    QWORD PTR [rsp+0x418],rsi
  c1bbd5:	jae    c1ee9b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4b5b>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1bbdb:	mov    rsi,QWORD PTR [rax+0x8]
  c1bbdf:	mov    r9,QWORD PTR [rsp+0x158]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1bbe7:	lea    rdx,[rsi+r9*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1bbeb:	movzx  ecx,r13b
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1bbef:	mov    rax,rcx
  c1bbf2:	sub    rax,QWORD PTR [rsi+r9*1+0x30]
  c1bbf7:	mov    rsi,QWORD PTR [rsp+0x100]
  c1bbff:	jae    c1bc0e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x18ce>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1bc01:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1bc05:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1bc08:	mov    rax,QWORD PTR [rax+rcx*1]
  c1bc0c:	jmp    c1bc12 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x18d2>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1bc0e:	add    rax,QWORD PTR [rdx+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1bc12:	cmp    rax,QWORD PTR [rsi+0x10]
  c1bc16:	jae    c1bcf3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x19b3>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2665
  c1bc1c:	mov    rdx,QWORD PTR [rsi+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1bc20:	lea    rax,[rax+rax*2]
  c1bc24:	lea    rcx,[rdx+rax*8]
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1bc28:	mov    eax,DWORD PTR [rdx+rax*8]
  c1bc2b:	mov    edx,eax
  c1bc2d:	sub    edx,0x2
  c1bc30:	mov    esi,0x3
  c1bc35:	cmovb  edx,esi
  c1bc38:	lea    rsi,[rip+0xffffffffff6aaf81]        # 2c6bc0 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1577>
  c1bc3f:	movsxd rdx,DWORD PTR [rsi+rdx*4]
  c1bc43:	add    rdx,rsi
  c1bc46:	jmp    rdx
  c1bc48:	mov    edi,DWORD PTR [rcx+0x4]
  c1bc4b:	mov    rbp,QWORD PTR [rcx+0x8]
  c1bc4f:	mov    r8,QWORD PTR [rcx+0x10]
  c1bc53:	jmp    c1bca0 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1960>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1bc55:	mov    rbp,QWORD PTR [rcx+0x8]
  c1bc59:	mov    eax,0xb
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1bc5e:	jmp    c1bc8f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x194f>
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
  c1bc60:	mov    eax,0x2
  c1bc65:	jmp    c1bca0 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1960>
  c1bc67:	mov    eax,0x3
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1bc6c:	jmp    c1bca0 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1960>
_RNvXsi_NtCsi8OWPsLN6MM_10bsl_number6numberNtB5_4ReprNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-number/src/number.rs:143
  c1bc6e:	test   al,0x1
  c1bc70:	je     c1bc48 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1908>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1bc72:	mov    rbp,QWORD PTR [rcx+0x8]
  c1bc76:	mov    eax,0x1
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1bc7b:	inc    QWORD PTR [rbp+0x0]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1bc7f:	jne    c1bca0 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1960>
  c1bc81:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1bc86:	mov    rbp,QWORD PTR [rcx+0x8]
  c1bc8a:	mov    eax,0x6
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
  c1bc8f:	inc    QWORD PTR [rbp+0x0]
  c1bc93:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
  c1bc99:	nop    DWORD PTR [rax+0x0]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1bca0:	mov    eax,eax
  c1bca2:	mov    r12,rdi
  c1bca5:	mov    rcx,rdi
  c1bca8:	shl    rcx,0x20
  c1bcac:	or     rcx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2665
  c1bcaf:	mov    QWORD PTR [rsp+0x2d8],rcx
  c1bcb7:	mov    QWORD PTR [rsp+0x2e0],rbp
  c1bcbf:	mov    r14,r8
  c1bcc2:	mov    QWORD PTR [rsp+0x2e8],r8
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8push_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1037
  c1bcca:	mov    rbx,QWORD PTR [rsp+0x170]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1040
  c1bcd2:	cmp    rbx,QWORD PTR [rsp+0x160]
  c1bcda:	jne    c1bb80 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1840>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1041
  c1bce0:	lea    rdi,[rsp+0x160]
  c1bce8:	call   QWORD PTR [rip+0x234c82]        # e50970 <_DYNAMIC+0x1e80>
  c1bcee:	jmp    c1bb80 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1840>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bcf3:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1bcf8:	mov    BYTE PTR [rcx],0x1f
  c1bcfb:	lea    rax,[rip+0xffffffffff6ab09e]        # 2c6da0 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1757>
  c1bd02:	mov    QWORD PTR [rcx+0x8],rax
  c1bd06:	mov    QWORD PTR [rcx+0x10],0x4f
  c1bd0e:	mov    QWORD PTR [rcx+0x18],r8
  c1bd12:	lea    rdi,[rsp+0x160]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2671
  c1bd1a:	call   c09ca0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueEECslyNhMBcJWAz_6bsl_vm>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1bd1f:	mov    rax,QWORD PTR [rsp+0x120]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1bd27:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1bd2a:	jne    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1bd30:	lea    rdi,[rsp+0x120]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1bd38:	call   QWORD PTR [rip+0x233022]        # e4ed60 <_DYNAMIC+0x270>
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1bd3e:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bd43:	mov    QWORD PTR [rsp+0x158],rdx
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3066
  c1bd4b:	mov    ebx,DWORD PTR [r12+rax*8+0x4]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3067
  c1bd50:	movzx  ebp,WORD PTR [r12+rax*8+0x2]
  c1bd56:	lea    rdi,[rsp+0x70]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3075
  c1bd5b:	mov    esi,ebx
  c1bd5d:	mov    rdx,r15
  c1bd60:	mov    rcx,QWORD PTR [rsp+0x3f8]
  c1bd68:	mov    r8,QWORD PTR [rsp+0x50]
  c1bd6d:	mov    r9,QWORD PTR [rsp+0x100]
  c1bd75:	call   c4baa0 <_RNvNtCslyNhMBcJWAz_6bsl_vm7modules19ensure_module_ready>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultbNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1bd7a:	movzx  ecx,BYTE PTR [rsp+0x70]
  c1bd7f:	movzx  eax,BYTE PTR [rsp+0x71]
  c1bd84:	cmp    cl,0xff
  c1bd87:	je     c1c18c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1e4c>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1bd8d:	movdqu xmm0,XMMWORD PTR [rsp+0x72]
  c1bd93:	movdqu xmm1,XMMWORD PTR [rsp+0x82]
  c1bd9c:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1bda5:	mov    rdx,QWORD PTR [rsp+0x48]
  c1bdaa:	movdqu XMMWORD PTR [rdx+0x20],xmm2
  c1bdaf:	movdqu XMMWORD PTR [rdx+0x12],xmm1
  c1bdb4:	movdqu XMMWORD PTR [rdx+0x2],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1bdb9:	mov    BYTE PTR [rdx],cl
  c1bdbb:	mov    BYTE PTR [rdx+0x1],al
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bdbe:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2667
  c1bdc3:	mov    rbx,QWORD PTR [rsp+0x120]
  c1bdcb:	mov    rax,QWORD PTR [rsp+0x170]
  c1bdd3:	mov    QWORD PTR [rsp+0x80],rax
  c1bddb:	mov    rax,QWORD PTR [rsp+0x160]
  c1bde3:	mov    QWORD PTR [rsp+0x70],rax
  c1bde8:	mov    rax,QWORD PTR [rsp+0x168]
  c1bdf0:	mov    QWORD PTR [rsp+0x78],rax
  c1bdf5:	lea    rdi,[rsp+0x1b0]
  c1bdfd:	lea    rdx,[rsp+0x70]
  c1be02:	mov    rsi,rbx
  c1be05:	call   QWORD PTR [rip+0x23751d]        # e53328 <_DYNAMIC+0x4838>
  c1be0b:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1be10:	mov    rsi,QWORD PTR [rax+0x10]
  c1be14:	mov    r15,QWORD PTR [rsp+0x418]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1be1c:	cmp    r15,rsi
  c1be1f:	jae    c1efe5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4ca5>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1be25:	mov    rsi,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1be29:	imul   rbx,r15,0x78
  c1be2d:	lea    rdx,[rsi+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1be31:	movzx  ecx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1be39:	mov    rax,rcx
  c1be3c:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1be41:	jae    c1be50 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b10>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1be43:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1be47:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1be4a:	mov    rax,QWORD PTR [rax+rcx*1]
  c1be4e:	jmp    c1be54 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b14>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1be50:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1be54:	mov    rsi,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1be5c:	mov    rcx,QWORD PTR [rsi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2669
  c1be60:	mov    rdx,QWORD PTR [rsp+0x1c0]
  c1be68:	mov    QWORD PTR [rsp+0x80],rdx
  c1be70:	movdqu xmm0,XMMWORD PTR [rsp+0x1b0]
  c1be79:	movdqa XMMWORD PTR [rsp+0x70],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1be7f:	cmp    rax,QWORD PTR [rsi+0x10]
  c1be83:	jae    c1e5a9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4269>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1be89:	lea    rax,[rax+rax*2]
  c1be8d:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1be91:	mov    rdi,r14
  c1be94:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1be99:	mov    rax,QWORD PTR [rsp+0x1c0]
  c1bea1:	mov    QWORD PTR [r14+0x10],rax
  c1bea5:	movdqu xmm0,XMMWORD PTR [rsp+0x1b0]
  c1beae:	movdqu XMMWORD PTR [r14],xmm0
  c1beb3:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1beb8:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1bebc:	cmp    r15,rsi
  c1bebf:	jae    c1f066 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4d26>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1bec5:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bec9:	inc    QWORD PTR [rax+rbx*1+0x58]
  c1bece:	mov    rax,QWORD PTR [rsp+0x48]
  c1bed3:	mov    BYTE PTR [rax],0xff
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3221
  c1bed6:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1bedb:	mov    rax,QWORD PTR [rsp+0x78]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1bee0:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1bee3:	jne    c1b5d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1292>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1bee9:	lea    rdi,[rsp+0x78]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1beee:	call   QWORD PTR [rip+0x232e4c]        # e4ed40 <_DYNAMIC+0x250>
  c1bef4:	jmp    c1b5d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1292>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1bef9:	mov    rax,QWORD PTR [rsp+0x78]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1befe:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1bf01:	jne    c1b5d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1292>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1bf07:	lea    rdi,[rsp+0x78]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1bf0c:	call   QWORD PTR [rip+0x232e36]        # e4ed48 <_DYNAMIC+0x258>
  c1bf12:	jmp    c1b5d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1292>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bf17:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1bf1c:	mov    BYTE PTR [rcx],0x1f
  c1bf1f:	lea    rax,[rip+0xffffffffff6aae7a]        # 2c6da0 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1757>
  c1bf26:	mov    QWORD PTR [rcx+0x8],rax
  c1bf2a:	mov    QWORD PTR [rcx+0x10],0x4f
  c1bf32:	mov    rax,QWORD PTR [rsp+0x278]
  c1bf3a:	mov    QWORD PTR [rcx+0x18],rax
  c1bf3e:	jmp    c1dc3a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38fa>
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecjE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1bf43:	mov    rax,QWORD PTR [rsp+0x130]
_RNvMNtCs4NRVxsYgnAr_4core5sliceSj11split_firstCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/mod.rs:199
  c1bf4b:	test   rax,rax
  c1bf4e:	je     c1bfaa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1c6a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2646
  c1bf50:	mov    rcx,QWORD PTR [rsp+0x128]
_RNvMNtCs4NRVxsYgnAr_4core5sliceSj11split_firstCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/mod.rs:199
  c1bf58:	dec    rax
_RNvCslyNhMBcJWAz_6bsl_vm18build_nested_array():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3289
  c1bf5b:	mov    rdx,QWORD PTR [rcx]
_RNvMNtCs4NRVxsYgnAr_4core5sliceSj11split_firstCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/mod.rs:199
  c1bf5e:	add    rcx,0x8
_RNvMNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_3ops5range5RangejENCNvCslyNhMBcJWAz_6bsl_vm18build_nested_array0E3newB1p_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/iter/adapters/map.rs:69
  c1bf62:	mov    QWORD PTR [rsp+0x80],0x0
  c1bf6e:	mov    QWORD PTR [rsp+0x88],rdx
  c1bf76:	mov    QWORD PTR [rsp+0x70],rcx
  c1bf7b:	mov    QWORD PTR [rsp+0x78],rax
  c1bf80:	lea    rdi,[rsp+0x1b0]
  c1bf88:	lea    rsi,[rsp+0x70]
_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3map3MapINtNtNtB24_3ops5range5RangejENCNvCslyNhMBcJWAz_6bsl_vm18build_nested_array0EE9from_iterB3g_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/spec_from_iter.rs:33
  c1bf8d:	call   c33c40 <_RNvXs_NtNtCscdodAO9FK5_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueEINtB4_18SpecFromIterNestedB12_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3map3MapINtNtNtB2k_3ops5range5RangejENCNvCslyNhMBcJWAz_6bsl_vm18build_nested_array0EE9from_iterB3w_>
_RNvCslyNhMBcJWAz_6bsl_vm18build_nested_array():
  c1bf92:	lea    rdi,[rsp+0x160]
  c1bf9a:	lea    rsi,[rsp+0x1b0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3299
  c1bfa2:	call   QWORD PTR [rip+0x2349d0]        # e50978 <_DYNAMIC+0x1e88>
  c1bfa8:	jmp    c1bfdb <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1c9b>
_RNvMNtCscdodAO9FK5_5alloc3vecINtB2_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3newCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:464
  c1bfaa:	mov    QWORD PTR [rsp+0x70],0x0
  c1bfb3:	mov    QWORD PTR [rsp+0x78],0x8
  c1bfbc:	mov    QWORD PTR [rsp+0x80],0x0
  c1bfc8:	lea    rdi,[rsp+0x160]
  c1bfd0:	lea    rsi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm18build_nested_array():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3301
  c1bfd5:	call   QWORD PTR [rip+0x23499d]        # e50978 <_DYNAMIC+0x1e88>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1bfdb:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1bfe0:	mov    rsi,QWORD PTR [rax+0x10]
  c1bfe4:	mov    r15,QWORD PTR [rsp+0x418]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1bfec:	cmp    r15,rsi
  c1bfef:	jae    c1efa9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4c69>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1bff5:	mov    rsi,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1bff9:	imul   rbx,r15,0x78
  c1bffd:	lea    rdx,[rsi+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1c001:	movzx  ecx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1c009:	mov    rax,rcx
  c1c00c:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1c011:	jae    c1c020 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1ce0>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c013:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c017:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1c01a:	mov    rax,QWORD PTR [rax+rcx*1]
  c1c01e:	jmp    c1c024 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1ce4>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1c020:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c024:	mov    rsi,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c02c:	mov    rcx,QWORD PTR [rsi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2648
  c1c030:	mov    rdx,QWORD PTR [rsp+0x170]
  c1c038:	mov    QWORD PTR [rsp+0x80],rdx
  c1c040:	movdqu xmm0,XMMWORD PTR [rsp+0x160]
  c1c049:	movdqa XMMWORD PTR [rsp+0x70],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1c04f:	cmp    rax,QWORD PTR [rsi+0x10]
  c1c053:	jae    c1c0c7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1d87>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1c055:	lea    rax,[rax+rax*2]
  c1c059:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1c05d:	mov    rdi,r14
  c1c060:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1c065:	mov    rax,QWORD PTR [rsp+0x170]
  c1c06d:	mov    QWORD PTR [r14+0x10],rax
  c1c071:	movdqu xmm0,XMMWORD PTR [rsp+0x160]
  c1c07a:	movdqu XMMWORD PTR [r14],xmm0
  c1c07f:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1c084:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1c088:	cmp    r15,rsi
  c1c08b:	jae    c1effa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4cba>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c091:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2649
  c1c095:	inc    QWORD PTR [rax+rbx*1+0x58]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2650
  c1c09a:	mov    rsi,QWORD PTR [rsp+0x120]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1c0a2:	test   rsi,rsi
  c1c0a5:	je     c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2650
  c1c0ab:	mov    rdi,QWORD PTR [rsp+0x128]
_RNvMs9_NtCs4NRVxsYgnAr_4core3numj13unchecked_mul():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num/uint_macros.rs:1359
  c1c0b3:	shl    rsi,0x3
_RNvNtCscdodAO9FK5_5alloc5alloc15dealloc_nonnull():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/alloc.rs:128
  c1c0b7:	mov    edx,0x8
  c1c0bc:	call   QWORD PTR [rip+0x232c6e]        # e4ed30 <_DYNAMIC+0x240>
  c1c0c2:	jmp    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c0c7:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1c0cc:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c0d1:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1c0d6:	mov    BYTE PTR [rcx],0x1f
  c1c0d9:	lea    rax,[rip+0xffffffffff6ab4b4]        # 2c7594 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x589>
  c1c0e0:	mov    QWORD PTR [rcx+0x8],rax
  c1c0e4:	mov    QWORD PTR [rcx+0x10],0x4f
  c1c0ec:	jmp    c1dc3a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38fa>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c0f1:	cmp    ecx,0x3
  c1c0f4:	jne    c1c83b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x24fb>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c0fa:	test   eax,eax
  c1c0fc:	je     c1b39e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x105e>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c102:	mov    rax,QWORD PTR [r14+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c106:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1c109:	jne    c1b39e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x105e>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c10f:	lea    rdi,[r14+0x8]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1c113:	call   QWORD PTR [rip+0x232c1f]        # e4ed38 <_DYNAMIC+0x248>
  c1c119:	jmp    c1b39e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x105e>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c11e:	cmp    ecx,0x3
  c1c121:	jne    c1c896 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2556>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c127:	test   eax,eax
  c1c129:	je     c1b4de <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x119e>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c12f:	mov    rax,QWORD PTR [r14+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c133:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1c136:	jne    c1b4de <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x119e>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c13c:	lea    rdi,[r14+0x8]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1c140:	call   QWORD PTR [rip+0x232bf2]        # e4ed38 <_DYNAMIC+0x248>
  c1c146:	jmp    c1b4de <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x119e>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c14b:	cmp    ecx,0x3
  c1c14e:	jne    c1cad6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2796>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c154:	test   eax,eax
  c1c156:	je     c1b571 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1231>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c15c:	mov    rax,QWORD PTR [r14+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c160:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1c163:	jne    c1b571 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1231>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c169:	lea    rdi,[r14+0x8]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1c16d:	call   QWORD PTR [rip+0x232bc5]        # e4ed38 <_DYNAMIC+0x248>
  c1c173:	jmp    c1b571 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1231>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c178:	mov    ecx,0x8
  c1c17d:	xor    ebp,ebp
  c1c17f:	mov    DWORD PTR [rsp+0x68],0x0
  c1c187:	jmp    c1d6e4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x33a4>
  c1c18c:	mov    QWORD PTR [rsp+0x68],r12
  c1c191:	mov    DWORD PTR [rsp+0x278],ebx
  c1c198:	mov    QWORD PTR [rsp+0x270],rbp
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3075
  c1c1a0:	test   al,0x1
  c1c1a2:	jne    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
  c1c1a8:	mov    rax,QWORD PTR [rsp+0x428]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1c1b0:	cmp    r14,QWORD PTR [rax+0x40]
  c1c1b4:	jae    c1de99 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3b59>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtB8_3vec3VecNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c1ba:	mov    rax,QWORD PTR [rax+0x38]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1c1be:	lea    rcx,[r14+r14*2]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c1c2:	mov    rsi,QWORD PTR [rax+rcx*8+0x8]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1c1c7:	mov    rdx,QWORD PTR [rax+rcx*8+0x10]
_RNvMNtNtCs4NRVxsYgnAr_4core3ptr7mut_ptrONtNtCskDxgodD397f_12bsl_bytecode5instr7ArgMode3addCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mut_ptr.rs:961
  c1c1cc:	lea    rax,[rdx*4+0x0]
  c1c1d4:	mov    QWORD PTR [rsp+0x2a8],rax
_RNvXsd_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeENtNtB9_3cmp9PartialEq2eqCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:1714
  c1c1dc:	test   rdx,rdx
  c1c1df:	mov    rbp,QWORD PTR [rsp+0x68]
  c1c1e4:	mov    rcx,QWORD PTR [rsp+0x158]
  c1c1ec:	mov    r12,rdx
  c1c1ef:	mov    rbx,rsi
_RNvXs2J_NtNtCs4NRVxsYgnAr_4core5slice4iterINtB6_4IterNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/iter/macros.rs:180
  c1c1f2:	je     c1e29a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3f5a>
  c1c1f8:	xor    r14d,r14d
  c1c1fb:	jmp    c1c212 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1ed2>
_RNvXsd_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeENtNtB9_3cmp9PartialEq2eqCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:1714
  c1c1fd:	add    r14,0x4
  c1c201:	lea    rax,[rdx*4+0x0]
  c1c209:	cmp    rax,r14
_RNvXs2J_NtNtCs4NRVxsYgnAr_4core5slice4iterINtB6_4IterNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/iter/macros.rs:180
  c1c20c:	je     c1e29a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3f5a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3087
  c1c212:	cmp    BYTE PTR [rsi+r14*1],0x4
  c1c217:	jne    c1c1fd <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1ebd>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3089
  c1c219:	movzx  eax,WORD PTR [rsi+r14*1+0x2]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCskDxgodD397f_12bsl_bytecode13configuration9LinkEntryE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1c21f:	cmp    rcx,rax
  c1c222:	jbe    c1e694 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4354>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3088
  c1c228:	cmp    BYTE PTR [rbp+rax*8+0x0],0x0
  c1c22d:	je     c1e694 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4354>
  c1c233:	mov    esi,DWORD PTR [rbp+rax*8+0x4]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3095
  c1c237:	lea    rdi,[rsp+0x70]
  c1c23c:	mov    rdx,r15
  c1c23f:	mov    rcx,QWORD PTR [rsp+0x3f8]
  c1c247:	mov    r8,QWORD PTR [rsp+0x50]
  c1c24c:	mov    r9,QWORD PTR [rsp+0x100]
  c1c254:	call   c4baa0 <_RNvNtCslyNhMBcJWAz_6bsl_vm7modules19ensure_module_ready>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultbNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1c259:	movzx  ecx,BYTE PTR [rsp+0x70]
  c1c25e:	movzx  eax,BYTE PTR [rsp+0x71]
  c1c263:	cmp    cl,0xff
  c1c266:	jne    c1bd8d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1a4d>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3095
  c1c26c:	cmp    al,0x1
  c1c26e:	mov    rcx,QWORD PTR [rsp+0x158]
  c1c276:	mov    rdx,r12
  c1c279:	mov    rsi,rbx
  c1c27c:	jne    c1c1fd <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1ebd>
  c1c282:	jmp    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1c287:	add    rbx,QWORD PTR [rcx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2930
  c1c28b:	movzx  esi,r12b
  c1c28f:	mov    rax,rbx
  c1c292:	add    rax,rsi
  c1c295:	setb   cl
  c1c298:	cmp    rax,rdx
  c1c29b:	seta   al
_RNvMs9_NtCs4NRVxsYgnAr_4core3numj11checked_sub():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num/uint_macros.rs:1050
  c1c29e:	or     al,cl
  c1c2a0:	je     c1d687 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3347>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c2a6:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1c2ab:	mov    BYTE PTR [rcx],0x1f
  c1c2ae:	lea    rax,[rip+0xffffffffff6ab64b]        # 2c7900 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x8f5>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c2b5:	mov    QWORD PTR [rcx+0x8],rax
  c1c2b9:	mov    QWORD PTR [rcx+0x10],0x53
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3091
  c1c2c1:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c2c6:	mov    rax,QWORD PTR [rdx+0x8]
  c1c2ca:	mov    ecx,0xb
  c1c2cf:	jmp    c1c300 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1fc0>
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
  c1c2d1:	mov    ecx,0x2
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:19
  c1c2d6:	jmp    c1c309 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1fc9>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c2d8:	mov    rax,QWORD PTR [rsi+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c2dc:	inc    QWORD PTR [rax]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1c2df:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c2e5:	mov    edx,0xb
  c1c2ea:	jmp    c1c546 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2206>
_RNvXsi_NtCsi8OWPsLN6MM_10bsl_number6numberNtB5_4ReprNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-number/src/number.rs:143
  c1c2ef:	test   al,0x1
  c1c2f1:	je     c1b2b2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xf72>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c2f7:	mov    rax,QWORD PTR [rdx+0x8]
  c1c2fb:	mov    ecx,0x1
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
  c1c300:	inc    QWORD PTR [rax]
  c1c303:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1c309:	mov    edx,ecx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3014
  c1c30b:	mov    QWORD PTR [rsp+0x230],rdx
  c1c313:	mov    QWORD PTR [rsp+0x238],rax
  c1c31b:	mov    eax,ecx
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3020
  c1c31d:	lea    rcx,[rip+0xffffffffff6ab57d]        # 2c78a1 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x896>
  c1c324:	lea    rdx,[rip+0xffffffffff6ab564]        # 2c788f <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x884>
  c1c32b:	test   bpl,0x1
  c1c32f:	cmovne rdx,rcx
  c1c333:	mov    rsi,QWORD PTR [rsp+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3018
  c1c338:	mov    BYTE PTR [rsi],0x1
  c1c33b:	lea    rcx,[rip+0xffffffffff6aaf2e]        # 2c7270 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x265>
  c1c342:	mov    QWORD PTR [rsi+0x8],rcx
  c1c346:	mov    QWORD PTR [rsi+0x10],0xc
  c1c34e:	mov    QWORD PTR [rsi+0x18],rdx
  c1c352:	mov    QWORD PTR [rsi+0x20],0x12
  c1c35a:	jmp    c1d527 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x31e7>
  c1c35f:	mov    edx,0x2
  c1c364:	jmp    c1c546 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2206>
_RNvXsi_NtCsi8OWPsLN6MM_10bsl_number6numberNtB5_4ReprNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-number/src/number.rs:143
  c1c369:	test   dil,0x1
  c1c36d:	je     c1b32e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xfee>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c373:	mov    rax,QWORD PTR [rsi+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c377:	inc    QWORD PTR [rax]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1c37a:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c380:	mov    edx,0x1
  c1c385:	jmp    c1c546 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2206>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c38a:	mov    rcx,QWORD PTR [rdx+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c38e:	inc    QWORD PTR [rcx]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1c391:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3014
  c1c397:	mov    QWORD PTR [rsp+0x230],0x6
  c1c3a3:	mov    QWORD PTR [rsp+0x238],rcx
  c1c3ab:	mov    r12,r8
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3016
  c1c3ae:	mov    QWORD PTR [rsp+0x70],rcx
  c1c3b3:	lea    rdi,[rsp+0x120]
  c1c3bb:	lea    rsi,[rsp+0x70]
_RNvXsB_NtCscdodAO9FK5_5alloc6stringNtNtCsbxvJACuny95_6bsl_rt6string9BslStringNtB5_8ToString9to_stringCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/string.rs:2907
  c1c3c0:	call   c24c00 <_RNvXsC_NtCscdodAO9FK5_5alloc6stringNtNtCsbxvJACuny95_6bsl_rt6string9BslStringNtB5_12SpecToString14spec_to_stringCslyNhMBcJWAz_6bsl_vm>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c3c5:	mov    rax,QWORD PTR [rsp+0x70]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c3ca:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1c3cd:	jne    c1c3da <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x209a>
  c1c3cf:	lea    rdi,[rsp+0x70]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1c3d4:	call   QWORD PTR [rip+0x232966]        # e4ed40 <_DYNAMIC+0x250>
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1c3da:	mov    rsi,QWORD PTR [r14+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c3de:	cmp    QWORD PTR [rsp+0x418],rsi
  c1c3e6:	jae    c1f04c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4d0c>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c3ec:	movdqu xmm0,XMMWORD PTR [rbx+0x8]
  c1c3f1:	mov    rax,QWORD PTR [rsp+0x428]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtB8_6string6StringECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c3f9:	mov    r9,QWORD PTR [rax+0x98]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtB6_6string6StringE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1c400:	mov    rax,QWORD PTR [rax+0xa0]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c407:	mov    rbx,QWORD PTR [rsp+0x128]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VechE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1c40f:	mov    rdx,QWORD PTR [rsp+0x130]
  c1c417:	mov    rcx,QWORD PTR [r14+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c41b:	add    rcx,r15
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3035
  c1c41e:	mov    rsi,QWORD PTR [rsp+0x3f0]
  c1c426:	mov    QWORD PTR [rsp+0x38],rsi
  c1c42b:	mov    rsi,QWORD PTR [rsp+0x3e0]
  c1c433:	mov    QWORD PTR [rsp+0x30],rsi
  c1c438:	mov    rsi,QWORD PTR [rsp+0x3d8]
  c1c440:	mov    QWORD PTR [rsp+0x28],rsi
  c1c445:	mov    QWORD PTR [rsp+0x20],rcx
  c1c44a:	movdqu XMMWORD PTR [rsp+0x10],xmm0
  c1c450:	mov    rcx,QWORD PTR [rsp+0x420]
  c1c458:	mov    QWORD PTR [rsp+0x8],rcx
  c1c45d:	mov    QWORD PTR [rsp],rax
  c1c461:	movzx  ecx,bpl
  c1c465:	and    ecx,0x1
  c1c468:	lea    rdi,[rsp+0x70]
  c1c46d:	mov    rsi,rbx
  c1c470:	mov    r8,r12
  c1c473:	call   c4bdc0 <_RNvNtCslyNhMBcJWAz_6bsl_vm7snippet19run_dynamic_snippet>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1c478:	movzx  eax,BYTE PTR [rsp+0x70]
  c1c47d:	cmp    al,0xff
  c1c47f:	je     c1c4d4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2194>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1c481:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1c486:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1c48f:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1c498:	movdqu XMMWORD PTR [rsp+0x1bf],xmm1
  c1c4a1:	movaps XMMWORD PTR [rsp+0x1b0],xmm0
  c1c4a9:	mov    rcx,QWORD PTR [rsp+0x48]
  c1c4ae:	movdqu XMMWORD PTR [rcx+0x20],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3046
  c1c4b3:	movups xmm0,XMMWORD PTR [rsp+0x1bf]
  c1c4bb:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1c4bf:	movdqa xmm0,XMMWORD PTR [rsp+0x1b0]
  c1c4c8:	movdqu XMMWORD PTR [rcx+0x1],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1c4cd:	mov    BYTE PTR [rcx],al
  c1c4cf:	jmp    c1d505 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x31c5>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1c4d4:	mov    rax,QWORD PTR [rsp+0x88]
  c1c4dc:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3035
  c1c4e2:	movdqa XMMWORD PTR [rsp+0x160],xmm0
  c1c4eb:	mov    QWORD PTR [rsp+0x170],rax
  c1c4f3:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1c4f8:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c4fc:	cmp    QWORD PTR [rsp+0x418],rsi
  c1c504:	jae    c1f0ba <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4d7a>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c50a:	mov    rsi,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c50e:	lea    rdx,[rsi+r15*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1c512:	movzx  ecx,r13b
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1c516:	mov    rax,rcx
  c1c519:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c1c51e:	jae    c1d430 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x30f0>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c524:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c528:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1c52b:	mov    rax,QWORD PTR [rax+rcx*1]
  c1c52f:	jmp    c1d434 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x30f4>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c534:	mov    rax,QWORD PTR [rsi+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c538:	inc    QWORD PTR [rax]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1c53b:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm8reg_load():
  c1c541:	mov    edx,0x6
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1c546:	mov    edx,edx
  c1c548:	shl    rcx,0x20
  c1c54c:	or     rcx,rdx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2695
  c1c54f:	mov    QWORD PTR [rsp+0x120],rcx
  c1c557:	mov    QWORD PTR [rsp+0x128],rax
  c1c55f:	mov    QWORD PTR [rsp+0x130],rsi
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionQNtNtCsbxvJACuny95_6bsl_rt3env7HostEnvE6as_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:764
  c1c567:	mov    r14,QWORD PTR [r9+0x28]
_RNvMNtCslyNhMBcJWAz_6bsl_vm7linkingNtB2_6HostIo3env():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/linking.rs:43
  c1c56b:	lea    rax,[rip+0xffffffffff6acae5]        # 2c9057 <anon.c9c1bb84f46a61489330f0a2bb8a4939.4.llvm.1835705092723400288>
  c1c572:	mov    QWORD PTR [rsp+0x78],rax
  c1c577:	mov    QWORD PTR [rsp+0x80],0x68
  c1c583:	mov    BYTE PTR [rsp+0x70],0x1f
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionQNtNtCsbxvJACuny95_6bsl_rt3env7HostEnvE6as_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:764
  c1c588:	test   r14,r14
  c1c58b:	je     c1c642 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2302>
_RNvMNtCslyNhMBcJWAz_6bsl_vm7linkingNtB2_6HostIo3env():
  c1c591:	lea    rdi,[rsp+0x70]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionQNtNtCsbxvJACuny95_6bsl_rt3env7HostEnvE5ok_orNtNtBN_5error7RtErrorECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1c596:	call   c35d80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.1835705092723400288>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c59b:	mov    rax,QWORD PTR [r14+0x40]
  c1c59f:	mov    rcx,QWORD PTR [r14+0x48]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c5a3:	inc    QWORD PTR [rax]
  c1c5a6:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_E13from_inner_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:383
  c1c5ac:	mov    QWORD PTR [rsp+0x230],rax
  c1c5b4:	mov    QWORD PTR [rsp+0x238],rcx
_RNvXsq_NtCscdodAO9FK5_5alloc2rcINtB5_2RcDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_ENtNtNtCs4NRVxsYgnAr_4core3ops5deref5Deref5derefCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2441
  c1c5bc:	mov    rdx,QWORD PTR [rcx+0x10]
  c1c5c0:	dec    rdx
  c1c5c3:	and    rdx,0xfffffffffffffff0
  c1c5c7:	add    rdx,rax
  c1c5ca:	add    rdx,0x10
  c1c5ce:	lea    rdi,[rsp+0x70]
  c1c5d3:	lea    rsi,[rsp+0x120]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2697
  c1c5db:	call   QWORD PTR [rip+0x237d9f]        # e54380 <_DYNAMIC+0x5890>
  c1c5e1:	mov    rcx,QWORD PTR [rsp+0x50]
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1c5e6:	movzx  eax,BYTE PTR [rsp+0x70]
  c1c5eb:	cmp    al,0xff
  c1c5ed:	je     c1c66e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x232e>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1c5ef:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1c5f4:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1c5fd:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1c606:	movdqu XMMWORD PTR [rsp+0x1bf],xmm1
  c1c60f:	movaps XMMWORD PTR [rsp+0x1b0],xmm0
  c1c617:	mov    rcx,QWORD PTR [rsp+0x48]
  c1c61c:	movdqu XMMWORD PTR [rcx+0x20],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2697
  c1c621:	movups xmm0,XMMWORD PTR [rsp+0x1bf]
  c1c629:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1c62d:	movdqa xmm0,XMMWORD PTR [rsp+0x1b0]
  c1c636:	movdqu XMMWORD PTR [rcx+0x1],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1c63b:	mov    BYTE PTR [rcx],al
  c1c63d:	jmp    c1c784 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2444>
_RNvMNtCslyNhMBcJWAz_6bsl_vm7linkingNtB2_6HostIo3env():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/linking.rs:43
  c1c642:	lea    rcx,[rsp+0x80]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionQNtNtCsbxvJACuny95_6bsl_rt3env7HostEnvE5ok_orNtNtBN_5error7RtErrorECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1337
  c1c64a:	movdqu xmm0,XMMWORD PTR [rcx]
  c1c64e:	movdqu xmm1,XMMWORD PTR [rcx+0x10]
  c1c653:	mov    rcx,QWORD PTR [rsp+0x48]
  c1c658:	movdqu XMMWORD PTR [rcx+0x20],xmm1
  c1c65d:	movdqu XMMWORD PTR [rcx+0x10],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1c662:	mov    BYTE PTR [rcx],0x1f
  c1c665:	mov    QWORD PTR [rcx+0x8],rax
  c1c669:	jmp    c1c79f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x245f>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1c66e:	mov    rax,QWORD PTR [rsp+0x88]
  c1c676:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2697
  c1c67c:	movdqa XMMWORD PTR [rsp+0x160],xmm0
  c1c685:	mov    QWORD PTR [rsp+0x170],rax
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1c68d:	mov    rsi,QWORD PTR [rcx+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c691:	cmp    r15,rsi
  c1c694:	jae    c1f076 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4d36>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c69a:	mov    rsi,QWORD PTR [rcx+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c69e:	lea    rdx,[rsi+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1c6a2:	movzx  ecx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1c6aa:	mov    rax,rcx
  c1c6ad:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1c6b2:	jae    c1c6c1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2381>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c6b4:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c6b8:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1c6bb:	mov    rax,QWORD PTR [rax+rcx*1]
  c1c6bf:	jmp    c1c6c5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2385>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1c6c1:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c6c5:	mov    rsi,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c6cd:	mov    rcx,QWORD PTR [rsi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2699
  c1c6d1:	mov    rdx,QWORD PTR [rsp+0x170]
  c1c6d9:	mov    QWORD PTR [rsp+0x80],rdx
  c1c6e1:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1c6ea:	movdqa XMMWORD PTR [rsp+0x70],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1c6f0:	cmp    rax,QWORD PTR [rsi+0x10]
  c1c6f4:	jae    c1c75f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x241f>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1c6f6:	lea    rax,[rax+rax*2]
  c1c6fa:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1c6fe:	mov    rdi,r14
  c1c701:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1c706:	mov    rax,QWORD PTR [rsp+0x170]
  c1c70e:	mov    QWORD PTR [r14+0x10],rax
  c1c712:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1c71b:	movdqu XMMWORD PTR [r14],xmm0
  c1c720:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1c725:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1c729:	cmp    r15,rsi
  c1c72c:	jae    c1f0d4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4d94>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c732:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2700
  c1c736:	inc    QWORD PTR [rax+rbx*1+0x58]
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c73b:	mov    rax,QWORD PTR [rsp+0x230]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c743:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_ENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1c746:	jne    c1ca24 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x26e4>
  c1c74c:	lea    rdi,[rsp+0x230]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1c754:	call   QWORD PTR [rip+0x23264e]        # e4eda8 <_DYNAMIC+0x2b8>
  c1c75a:	jmp    c1ca24 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x26e4>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c75f:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1c764:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c769:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1c76e:	mov    BYTE PTR [rcx],0x1f
  c1c771:	lea    rax,[rip+0xffffffffff6aae1c]        # 2c7594 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x589>
  c1c778:	mov    QWORD PTR [rcx+0x8],rax
  c1c77c:	mov    QWORD PTR [rcx+0x10],0x4f
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c784:	mov    rax,QWORD PTR [rsp+0x230]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c78c:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_ENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1c78f:	jne    c1c79f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x245f>
  c1c791:	lea    rdi,[rsp+0x230]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1c799:	call   QWORD PTR [rip+0x232609]        # e4eda8 <_DYNAMIC+0x2b8>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c79f:	lea    rdi,[rsp+0x128]
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c7a7:	mov    eax,DWORD PTR [rsp+0x120]
  c1c7ae:	mov    edx,eax
  c1c7b0:	sub    edx,0x2
  c1c7b3:	mov    ecx,0x3
  c1c7b8:	cmovae ecx,edx
  c1c7bb:	cmp    ecx,0x8
  c1c7be:	ja     c1caa9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2769>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c7c4:	mov    edx,0x1e7
  c1c7c9:	bt     edx,ecx
  c1c7cc:	jb     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1c7d2:	cmp    ecx,0x3
  c1c7d5:	jne    c1ca93 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2753>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c7db:	test   eax,eax
  c1c7dd:	je     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c7e3:	mov    rax,QWORD PTR [rsp+0x128]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c7eb:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1c7ee:	jne    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1c7f4:	jmp    c1d33d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2ffd>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c7f9:	mov    rax,QWORD PTR [rsi+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c7fd:	inc    QWORD PTR [rax]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1c800:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c806:	mov    edx,0xb
  c1c80b:	jmp    c1c8c4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2584>
  c1c810:	mov    edx,0x2
  c1c815:	jmp    c1c8c4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2584>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c81a:	mov    rsi,QWORD PTR [rdx+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c81e:	inc    QWORD PTR [rsi]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1c821:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c827:	mov    eax,0xb
  c1c82c:	jmp    c1cb04 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x27c4>
  c1c831:	mov    eax,0x2
  c1c836:	jmp    c1cb04 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x27c4>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c83b:	mov    rax,QWORD PTR [r14+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c83f:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1c842:	jne    c1b39e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x105e>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c848:	lea    rdi,[r14+0x8]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1c84c:	call   QWORD PTR [rip+0x2324ee]        # e4ed40 <_DYNAMIC+0x250>
  c1c852:	jmp    c1b39e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x105e>
_RNvXsi_NtCsi8OWPsLN6MM_10bsl_number6numberNtB5_4ReprNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-number/src/number.rs:143
  c1c857:	test   dil,0x1
  c1c85b:	je     c1b41b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x10db>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c861:	mov    rax,QWORD PTR [rsi+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c865:	inc    QWORD PTR [rax]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1c868:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c86e:	mov    edx,0x1
  c1c873:	jmp    c1c8c4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2584>
_RNvXsi_NtCsi8OWPsLN6MM_10bsl_number6numberNtB5_4ReprNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-number/src/number.rs:143
  c1c875:	test   dil,0x1
  c1c879:	je     c1b46e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x112e>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c87f:	mov    rsi,QWORD PTR [rdx+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c883:	inc    QWORD PTR [rsi]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1c886:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c88c:	mov    eax,0x1
  c1c891:	jmp    c1cb04 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x27c4>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c896:	mov    rax,QWORD PTR [r14+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c89a:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1c89d:	jne    c1b4de <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x119e>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1c8a3:	lea    rdi,[r14+0x8]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1c8a7:	call   QWORD PTR [rip+0x232493]        # e4ed40 <_DYNAMIC+0x250>
  c1c8ad:	jmp    c1b4de <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x119e>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1c8b2:	mov    rax,QWORD PTR [rsi+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1c8b6:	inc    QWORD PTR [rax]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1c8b9:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm8reg_load():
  c1c8bf:	mov    edx,0x6
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1c8c4:	mov    edx,edx
  c1c8c6:	shl    rcx,0x20
  c1c8ca:	or     rcx,rdx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2678
  c1c8cd:	mov    QWORD PTR [rsp+0x120],rcx
  c1c8d5:	mov    QWORD PTR [rsp+0x128],rax
  c1c8dd:	mov    QWORD PTR [rsp+0x130],rsi
  c1c8e5:	lea    rdi,[rsp+0x70]
  c1c8ea:	lea    rsi,[rsp+0x120]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2679
  c1c8f2:	mov    rdx,r11
  c1c8f5:	call   QWORD PTR [rip+0x237a8d]        # e54388 <_DYNAMIC+0x5898>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1c8fb:	movzx  eax,BYTE PTR [rsp+0x70]
  c1c900:	cmp    al,0xff
  c1c902:	je     c1c957 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2617>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1c904:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1c909:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1c912:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1c91b:	movdqu XMMWORD PTR [rsp+0x1bf],xmm1
  c1c924:	movaps XMMWORD PTR [rsp+0x1b0],xmm0
  c1c92c:	mov    rcx,QWORD PTR [rsp+0x48]
  c1c931:	movdqu XMMWORD PTR [rcx+0x20],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2679
  c1c936:	movups xmm0,XMMWORD PTR [rsp+0x1bf]
  c1c93e:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1c942:	movdqa xmm0,XMMWORD PTR [rsp+0x1b0]
  c1c94b:	movdqu XMMWORD PTR [rcx+0x1],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1c950:	mov    BYTE PTR [rcx],al
  c1c952:	jmp    c1ca5b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x271b>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1c957:	mov    rax,QWORD PTR [rsp+0x88]
  c1c95f:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2679
  c1c965:	movdqa XMMWORD PTR [rsp+0x160],xmm0
  c1c96e:	mov    QWORD PTR [rsp+0x170],rax
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1c976:	mov    rsi,QWORD PTR [r14+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c97a:	cmp    r15,rsi
  c1c97d:	jae    c1f01d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4cdd>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c983:	mov    rsi,QWORD PTR [r14+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c987:	lea    rdx,[rsi+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1c98b:	movzx  ecx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1c993:	mov    rax,rcx
  c1c996:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1c99b:	jae    c1c9aa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x266a>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c99d:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1c9a1:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1c9a4:	mov    rax,QWORD PTR [rax+rcx*1]
  c1c9a8:	jmp    c1c9ae <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x266e>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1c9aa:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1c9ae:	mov    rsi,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1c9b6:	mov    rcx,QWORD PTR [rsi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2681
  c1c9ba:	mov    rdx,QWORD PTR [rsp+0x170]
  c1c9c2:	mov    QWORD PTR [rsp+0x80],rdx
  c1c9ca:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1c9d3:	movdqa XMMWORD PTR [rsp+0x70],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1c9d9:	cmp    rax,QWORD PTR [rsi+0x10]
  c1c9dd:	jae    c1ca36 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x26f6>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1c9df:	lea    rax,[rax+rax*2]
  c1c9e3:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1c9e7:	mov    rdi,r14
  c1c9ea:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1c9ef:	mov    rax,QWORD PTR [rsp+0x170]
  c1c9f7:	mov    QWORD PTR [r14+0x10],rax
  c1c9fb:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1ca04:	movdqu XMMWORD PTR [r14],xmm0
  c1ca09:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1ca0e:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1ca12:	cmp    r15,rsi
  c1ca15:	jae    c1f08b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4d4b>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ca1b:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2682
  c1ca1f:	inc    QWORD PTR [rax+rbx*1+0x58]
  c1ca24:	lea    rdi,[rsp+0x120]
  c1ca2c:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1ca31:	jmp    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
  c1ca36:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1ca3b:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ca40:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1ca45:	mov    BYTE PTR [rcx],0x1f
  c1ca48:	lea    rax,[rip+0xffffffffff6aab45]        # 2c7594 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x589>
  c1ca4f:	mov    QWORD PTR [rcx+0x8],rax
  c1ca53:	mov    QWORD PTR [rcx+0x10],0x4f
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ca5b:	lea    rdi,[rsp+0x128]
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1ca63:	mov    eax,DWORD PTR [rsp+0x120]
  c1ca6a:	mov    edx,eax
  c1ca6c:	sub    edx,0x2
  c1ca6f:	mov    ecx,0x3
  c1ca74:	cmovae ecx,edx
  c1ca77:	cmp    ecx,0x8
  c1ca7a:	ja     c1caa9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2769>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ca7c:	mov    edx,0x1e7
  c1ca81:	bt     edx,ecx
  c1ca84:	jb     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1ca8a:	cmp    ecx,0x3
  c1ca8d:	je     c1c7db <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x249b>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1ca93:	mov    rax,QWORD PTR [rsp+0x128]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1ca9b:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1ca9e:	jne    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1caa4:	jmp    c1ce68 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2b28>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1caa9:	mov    rax,QWORD PTR [rsp+0x128]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1cab1:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1cab4:	jne    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1caba:	jmp    c1d359 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3019>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1cabf:	mov    rax,QWORD PTR [rsi+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1cac3:	inc    QWORD PTR [rax]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1cac6:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1cacc:	mov    edx,0xb
  c1cad1:	jmp    c1ceaa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2b6a>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1cad6:	mov    rax,QWORD PTR [r14+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1cada:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1cadd:	jne    c1b571 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1231>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1cae3:	lea    rdi,[r14+0x8]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1cae7:	call   QWORD PTR [rip+0x232253]        # e4ed40 <_DYNAMIC+0x250>
  c1caed:	jmp    c1b571 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1231>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1caf2:	mov    rsi,QWORD PTR [rdx+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1caf6:	inc    QWORD PTR [rsi]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1caf9:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1caff:	mov    eax,0x6
  c1cb04:	shl    ebx,0x8
  c1cb07:	movzx  edi,r12b
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1cb0b:	mov    r8d,eax
  c1cb0e:	shl    rcx,0x20
  c1cb12:	or     rcx,r8
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2713
  c1cb15:	mov    QWORD PTR [rsp+0x230],rcx
  c1cb1d:	mov    QWORD PTR [rsp+0x238],rsi
  c1cb25:	mov    QWORD PTR [rsp+0x240],rdx
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2714
  c1cb2d:	and    ebx,0xff00
  c1cb33:	or     ebx,edi
_RNvMNtCsbxvJACuny95_6bsl_rt5valueNtB2_8BslValue10object_ref():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:648
  c1cb35:	cmp    eax,0xb
  c1cb38:	jne    c1ccd5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2995>
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:649
  c1cb3e:	cmp    BYTE PTR [rsi+0x10],0xf
  c1cb42:	jne    c1ccd5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2995>
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:650
  c1cb48:	add    rsi,0x18
  c1cb4c:	mov    rdx,r10
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2721
  c1cb4f:	lea    rcx,[r10+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2722
  c1cb53:	lea    r12,[r10+0x58]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2723
  c1cb57:	lea    rdi,[r10+0x68]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cb5b:	lea    r8,[r10+0xf0]
  c1cb62:	mov    rax,QWORD PTR [r10+0xf0]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cb69:	mov    r9,QWORD PTR [r10+0x118]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cb70:	test   rax,rax
  c1cb73:	cmove  r8,rax
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cb77:	add    r10,0x100
  c1cb7e:	mov    r13,r11
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtCsbxvJACuny95_6bsl_rt12temp_storage18TempStorageSessionEEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cb81:	lea    r11,[rdx+0x110]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cb88:	lea    rax,[rdx+0x118]
  c1cb8f:	test   r9,r9
  c1cb92:	cmove  rax,r9
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cb96:	movq   xmm0,QWORD PTR [rdx+0x110]
  c1cb9e:	movq   xmm1,QWORD PTR [rdx+0x100]
  c1cba6:	punpcklqdq xmm1,xmm0
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1cbaa:	mov    QWORD PTR [rsp+0x70],r13
  c1cbaf:	mov    r9,QWORD PTR [rip+0x23225a]        # e4ee10 <_DYNAMIC+0x320>
  c1cbb6:	mov    QWORD PTR [rsp+0x78],r9
  c1cbbb:	mov    BYTE PTR [rsp+0xf8],0x0
  c1cbc3:	mov    rbp,QWORD PTR [rsp+0x3e0]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2718
  c1cbcb:	movups xmm0,XMMWORD PTR [rbp+0x0]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1cbcf:	movups XMMWORD PTR [rsp+0x80],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2719
  c1cbd7:	movdqu xmm0,XMMWORD PTR [rbp+0x10]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1cbdc:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1cbe5:	mov    QWORD PTR [rsp+0xa0],rcx
  c1cbed:	mov    QWORD PTR [rsp+0xa8],r12
  c1cbf5:	mov    QWORD PTR [rsp+0xb0],rdi
  c1cbfd:	mov    QWORD PTR [rsp+0xb8],r8
  c1cc05:	mov    QWORD PTR [rsp+0xc0],0x0
  c1cc11:	mov    QWORD PTR [rsp+0xd0],0x0
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cc1d:	pxor   xmm0,xmm0
  c1cc21:	pcmpeqd xmm0,xmm1
  c1cc25:	movq   xmm1,r11
  c1cc2a:	movq   xmm2,r10
  c1cc2f:	punpcklqdq xmm2,xmm1
  c1cc33:	pshufd xmm1,xmm0,0xb1
  c1cc38:	pand   xmm1,xmm0
  c1cc3c:	pandn  xmm1,xmm2
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1cc40:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1cc49:	mov    QWORD PTR [rsp+0xf0],rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2733
  c1cc51:	add    rdx,0xb8
  c1cc58:	lea    rdi,[rsp+0x1b0]
  c1cc60:	lea    r9,[rsp+0x70]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2731
  c1cc65:	mov    ecx,ebx
  c1cc67:	mov    r8,r14
  c1cc6a:	call   c373a0 <_RNvNtCslyNhMBcJWAz_6bsl_vm7linking18component_prop_get>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1cc6f:	movzx  eax,BYTE PTR [rsp+0x1b0]
  c1cc77:	cmp    al,0xff
  c1cc79:	je     c1d292 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2f52>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1cc7f:	movups xmm0,XMMWORD PTR [rsp+0x1b1]
  c1cc87:	movdqu xmm1,XMMWORD PTR [rsp+0x1c0]
  c1cc90:	movdqu xmm2,XMMWORD PTR [rsp+0x1d0]
  c1cc99:	movdqu XMMWORD PTR [rsp+0x16f],xmm1
  c1cca2:	movaps XMMWORD PTR [rsp+0x160],xmm0
  c1ccaa:	mov    rcx,QWORD PTR [rsp+0x48]
  c1ccaf:	movdqu XMMWORD PTR [rcx+0x20],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2737
  c1ccb4:	movups xmm0,XMMWORD PTR [rsp+0x16f]
  c1ccbc:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1ccc0:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1ccc9:	movdqu XMMWORD PTR [rcx+0x1],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1ccce:	mov    BYTE PTR [rcx],al
  c1ccd0:	jmp    c1ce1b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2adb>
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1ccd5:	mov    rsi,QWORD PTR [r9+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ccd9:	cmp    QWORD PTR [rsp+0x418],rsi
  c1cce1:	jae    c1efcb <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4c8b>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1cce7:	mov    rcx,QWORD PTR [rsp+0x158]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecINtNtB9_4cell7RefCellINtNtB9_6option6OptionTINtNtB13_2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEmEEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1ccef:	cmp    rbp,QWORD PTR [rcx+0x10]
  c1ccf3:	jae    c1cdf1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2ab1>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2740
  c1ccf9:	mov    rax,QWORD PTR [r9+0x8]
  c1ccfd:	mov    rax,QWORD PTR [rax+r15*1+0x58]
  c1cd02:	mov    rcx,QWORD PTR [rcx+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecINtNtB9_4cell7RefCellINtNtB9_6option6OptionTINtNtB13_2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEmEEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1cd06:	lea    rdx,[rbp*2+0x0]
  c1cd0e:	add    rdx,rbp
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtB9_4cell7RefCellINtNtB9_6option6OptionTINtNtCscdodAO9FK5_5alloc2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEmEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1cd11:	cmp    rax,QWORD PTR [rcx+rdx*8+0x10]
  c1cd16:	jae    c1cdff <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2abf>
_RNvCslyNhMBcJWAz_6bsl_vm10prop_cache():
  c1cd1c:	lea    rdx,[rcx+rdx*8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtB9_4cell7RefCellINtNtB9_6option6OptionTINtNtCscdodAO9FK5_5alloc2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEmEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1cd20:	lea    rcx,[rax+rax*2]
  c1cd24:	shl    rcx,0x3
  c1cd28:	add    rcx,QWORD PTR [rdx+0x8]
  c1cd2c:	lea    rdi,[rsp+0x1b0]
  c1cd34:	lea    rsi,[rsp+0x230]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2740
  c1cd3c:	mov    edx,ebx
  c1cd3e:	call   QWORD PTR [rip+0x2375bc]        # e54300 <_DYNAMIC+0x5810>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2739
  c1cd44:	movzx  eax,BYTE PTR [rsp+0x1b0]
  c1cd4c:	cmp    eax,0xff
  c1cd51:	je     c1d542 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3202>
  c1cd57:	cmp    eax,0x5
  c1cd5a:	jne    c1d653 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3313>
_RNvMs_NtCsbxvJACuny95_6bsl_rt8internerNtB4_6NameId5index():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/interner.rs:38
  c1cd60:	mov    eax,ebx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCscdodAO9FK5_5alloc6string6StringE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1cd62:	cmp    QWORD PTR [r14+0x40],rax
  c1cd66:	jbe    c1de22 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3ae2>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2743
  c1cd6c:	mov    rcx,QWORD PTR [r14+0x38]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCscdodAO9FK5_5alloc6string6StringE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1cd70:	lea    rax,[rax+rax*2]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1cd74:	mov    rdx,QWORD PTR [rcx+rax*8+0x8]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VechE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1cd79:	mov    rcx,QWORD PTR [rcx+rax*8+0x10]
  c1cd7e:	lea    rdi,[rsp+0x70]
  c1cd83:	lea    rsi,[rsp+0x230]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2743
  c1cd8b:	call   QWORD PTR [rip+0x237577]        # e54308 <_DYNAMIC+0x5818>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1cd91:	movzx  eax,BYTE PTR [rsp+0x70]
  c1cd96:	cmp    al,0xff
  c1cd98:	je     c1e410 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x40d0>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1cd9e:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1cda3:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1cdac:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1cdb5:	movdqu XMMWORD PTR [rsp+0x16f],xmm1
  c1cdbe:	movaps XMMWORD PTR [rsp+0x160],xmm0
  c1cdc6:	mov    rcx,QWORD PTR [rsp+0x48]
  c1cdcb:	movdqu XMMWORD PTR [rcx+0x20],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2743
  c1cdd0:	movups xmm0,XMMWORD PTR [rsp+0x16f]
  c1cdd8:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1cddc:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1cde5:	movdqu XMMWORD PTR [rcx+0x1],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1cdea:	mov    BYTE PTR [rcx],al
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2743
  c1cdec:	jmp    c1de3d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3afd>
  c1cdf1:	lea    rax,[rip+0xffffffffff6aa09d]        # 2c6e95 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x184c>
  c1cdf8:	mov    ecx,0x41
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecINtNtB9_4cell7RefCellINtNtB9_6option6OptionTINtNtB13_2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEmEEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1cdfd:	jmp    c1ce0b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2acb>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1cdff:	lea    rax,[rip+0xffffffffff6aa0d0]        # 2c6ed6 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x188d>
  c1ce06:	mov    ecx,0x45
  c1ce0b:	mov    rdx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1ce10:	mov    BYTE PTR [rdx],0x1f
  c1ce13:	mov    QWORD PTR [rdx+0x8],rax
  c1ce17:	mov    QWORD PTR [rdx+0x10],rcx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ce1b:	lea    rdi,[rsp+0x238]
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1ce23:	mov    eax,DWORD PTR [rsp+0x230]
  c1ce2a:	mov    edx,eax
  c1ce2c:	sub    edx,0x2
  c1ce2f:	mov    ecx,0x3
  c1ce34:	cmovae ecx,edx
  c1ce37:	cmp    ecx,0x8
  c1ce3a:	ja     c1d348 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3008>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ce40:	mov    edx,0x1e7
  c1ce45:	bt     edx,ecx
  c1ce48:	jb     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1ce4e:	cmp    ecx,0x3
  c1ce51:	je     c1d324 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2fe4>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1ce57:	mov    rax,QWORD PTR [rsp+0x238]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1ce5f:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1ce62:	jne    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1ce68:	call   QWORD PTR [rip+0x231ed2]        # e4ed40 <_DYNAMIC+0x250>
  c1ce6e:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ce73:	mov    edx,0x2
  c1ce78:	jmp    c1ceaa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2b6a>
_RNvXsi_NtCsi8OWPsLN6MM_10bsl_number6numberNtB5_4ReprNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
/home/kan/Документы/develop/open-bsl/crates/bsl-number/src/number.rs:143
  c1ce7a:	test   dil,0x1
  c1ce7e:	je     c1b62a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x12ea>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1ce84:	mov    rax,QWORD PTR [rsi+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1ce88:	inc    QWORD PTR [rax]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1ce8b:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
  c1ce91:	mov    edx,0x1
  c1ce96:	jmp    c1ceaa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2b6a>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1ce98:	mov    rax,QWORD PTR [rsi+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1ce9c:	inc    QWORD PTR [rax]
_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics/mod.rs:459
  c1ce9f:	je     c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvCslyNhMBcJWAz_6bsl_vm8reg_load():
  c1cea5:	mov    edx,0x6
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1ceaa:	mov    edx,edx
  c1ceac:	shl    rcx,0x20
  c1ceb0:	or     rcx,rdx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2753
  c1ceb3:	mov    QWORD PTR [rsp+0x230],rcx
  c1cebb:	mov    QWORD PTR [rsp+0x238],rax
  c1cec3:	mov    QWORD PTR [rsp+0x240],rsi
  c1cecb:	mov    rcx,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1ced0:	mov    rsi,QWORD PTR [rcx+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ced4:	cmp    QWORD PTR [rsp+0x418],rsi
  c1cedc:	jae    c1ef8f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4c4f>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1cee2:	mov    rax,QWORD PTR [rsp+0x100]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2754
  c1ceea:	mov    rax,QWORD PTR [rax+0x10]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ceee:	mov    rdi,QWORD PTR [rcx+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1cef2:	lea    rsi,[rdi+r15*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1cef6:	movzx  edx,r13b
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1cefa:	mov    rcx,rdx
  c1cefd:	sub    rcx,QWORD PTR [rdi+r15*1+0x30]
  c1cf02:	jae    c1cf11 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2bd1>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1cf04:	mov    rcx,QWORD PTR [rsi+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1cf08:	shl    edx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1cf0b:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1cf0f:	jmp    c1cf15 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2bd5>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1cf11:	add    rcx,QWORD PTR [rsi+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1cf15:	cmp    rcx,rax
  c1cf18:	jae    c1d129 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2de9>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1cf1e:	mov    r13,r8
  c1cf21:	shl    ebx,0x8
  c1cf24:	movzx  ebp,r12b
  c1cf28:	mov    rax,QWORD PTR [rsp+0x100]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2754
  c1cf30:	mov    rax,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1cf34:	lea    rcx,[rcx+rcx*2]
  c1cf38:	lea    rsi,[rax+rcx*8]
  c1cf3c:	lea    r12,[rsp+0x70]
_RNvYNvYNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneINtNtNtBN_3ops8function6FnOnceTRB5_EE9call_onceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ops/function.rs:250
  c1cf41:	mov    rdi,r12
  c1cf44:	call   c246a0 <_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1162
  c1cf49:	mov    rax,QWORD PTR [rsp+0x70]
  c1cf4e:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2754
  c1cf54:	mov    QWORD PTR [rsp+0x120],rax
  c1cf5c:	movdqu XMMWORD PTR [rsp+0x128],xmm0
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2755
  c1cf65:	and    ebx,0xff00
  c1cf6b:	or     ebx,ebp
_RNvMNtCsbxvJACuny95_6bsl_rt5valueNtB2_8BslValue10object_ref():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:648
  c1cf6d:	cmp    DWORD PTR [rsp+0x230],0xb
  c1cf75:	jne    c1d149 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2e09>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1cf7b:	mov    rsi,QWORD PTR [rsp+0x238]
_RNvMNtCsbxvJACuny95_6bsl_rt5valueNtB2_8BslValue10object_ref():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:649
  c1cf83:	cmp    BYTE PTR [rsi+0x10],0xf
  c1cf87:	jne    c1d149 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2e09>
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:650
  c1cf8d:	add    rsi,0x18
  c1cf91:	mov    rdx,QWORD PTR [rsp+0x3d8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2762
  c1cf99:	lea    rcx,[rdx+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2763
  c1cf9d:	lea    r14,[rdx+0x58]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2764
  c1cfa1:	lea    rdi,[rdx+0x68]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cfa5:	lea    r8,[rdx+0xf0]
  c1cfac:	mov    rax,QWORD PTR [rdx+0xf0]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cfb3:	mov    r9,QWORD PTR [rdx+0x118]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cfba:	test   rax,rax
  c1cfbd:	cmove  r8,rax
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cfc1:	lea    r10,[rdx+0x100]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtCsbxvJACuny95_6bsl_rt12temp_storage18TempStorageSessionEEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cfc8:	lea    r11,[rdx+0x110]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cfcf:	lea    rax,[rdx+0x118]
  c1cfd6:	test   r9,r9
  c1cfd9:	cmove  rax,r9
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1cfdd:	movq   xmm0,QWORD PTR [rdx+0x110]
  c1cfe5:	movq   xmm1,QWORD PTR [rdx+0x100]
  c1cfed:	punpcklqdq xmm1,xmm0
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1cff1:	mov    r9,QWORD PTR [rsp+0x3e8]
  c1cff9:	mov    QWORD PTR [rsp+0x70],r9
  c1cffe:	mov    r9,QWORD PTR [rip+0x231e0b]        # e4ee10 <_DYNAMIC+0x320>
  c1d005:	mov    QWORD PTR [rsp+0x78],r9
  c1d00a:	mov    BYTE PTR [rsp+0xf8],0x0
  c1d012:	mov    r9,QWORD PTR [rsp+0x3e0]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2759
  c1d01a:	movups xmm0,XMMWORD PTR [r9]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1d01e:	movups XMMWORD PTR [rsp+0x80],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2760
  c1d026:	movdqu xmm0,XMMWORD PTR [r9+0x10]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1d02c:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1d035:	mov    QWORD PTR [rsp+0xa0],rcx
  c1d03d:	mov    QWORD PTR [rsp+0xa8],r14
  c1d045:	mov    QWORD PTR [rsp+0xb0],rdi
  c1d04d:	mov    QWORD PTR [rsp+0xb8],r8
  c1d055:	mov    QWORD PTR [rsp+0xc0],0x0
  c1d061:	mov    QWORD PTR [rsp+0xd0],0x0
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1d06d:	pxor   xmm0,xmm0
  c1d071:	pcmpeqd xmm0,xmm1
  c1d075:	movq   xmm1,r11
  c1d07a:	movq   xmm2,r10
  c1d07f:	punpcklqdq xmm2,xmm1
  c1d083:	pshufd xmm1,xmm0,0xb1
  c1d088:	pand   xmm1,xmm0
  c1d08c:	pandn  xmm1,xmm2
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1d090:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1d099:	mov    QWORD PTR [rsp+0xf0],rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2774
  c1d0a1:	add    rdx,0xb8
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2776
  c1d0a8:	mov    rax,QWORD PTR [rsp+0x130]
  c1d0b0:	mov    QWORD PTR [rsp+0x170],rax
  c1d0b8:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c1d0c1:	movdqa XMMWORD PTR [rsp+0x160],xmm0
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2772
  c1d0ca:	mov    QWORD PTR [rsp],r12
  c1d0ce:	lea    rdi,[rsp+0x1b0]
  c1d0d6:	lea    r8,[rsp+0x160]
  c1d0de:	mov    ecx,ebx
  c1d0e0:	mov    r9,r13
  c1d0e3:	call   c374c0 <_RNvNtCslyNhMBcJWAz_6bsl_vm7linking18component_prop_set>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1d0e8:	cmp    BYTE PTR [rsp+0x1b0],0xff
  c1d0f0:	je     c1da68 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3728>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1d0f6:	movdqu xmm0,XMMWORD PTR [rsp+0x1b0]
  c1d0ff:	movdqu xmm1,XMMWORD PTR [rsp+0x1c0]
  c1d108:	movdqu xmm2,XMMWORD PTR [rsp+0x1d0]
  c1d111:	mov    rax,QWORD PTR [rsp+0x48]
  c1d116:	movdqu XMMWORD PTR [rax+0x20],xmm2
  c1d11b:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1d120:	movdqu XMMWORD PTR [rax],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d124:	jmp    c1d2ec <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2fac>
  c1d129:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1d12e:	mov    BYTE PTR [rcx],0x1f
  c1d131:	lea    rax,[rip+0xffffffffff6a9c68]        # 2c6da0 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1757>
  c1d138:	mov    QWORD PTR [rcx+0x8],rax
  c1d13c:	mov    QWORD PTR [rcx+0x10],0x4f
  c1d144:	jmp    c1d2ec <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2fac>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d149:	lea    rdi,[rsp+0x70]
  c1d14e:	lea    rsi,[rsp+0x120]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2783
  c1d156:	call   c246a0 <_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1d15b:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1d160:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d164:	cmp    QWORD PTR [rsp+0x418],rsi
  c1d16c:	jae    c1f032 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4cf2>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d172:	mov    rcx,QWORD PTR [rsp+0x158]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecINtNtB9_4cell7RefCellINtNtB9_6option6OptionTINtNtB13_2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEmEEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1d17a:	cmp    r14,QWORD PTR [rcx+0x10]
  c1d17e:	jae    c1d224 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2ee4>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d184:	mov    rax,QWORD PTR [rsp+0x50]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2784
  c1d189:	mov    rax,QWORD PTR [rax+0x8]
  c1d18d:	mov    rax,QWORD PTR [rax+r15*1+0x58]
  c1d192:	mov    rcx,QWORD PTR [rcx+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtCscdodAO9FK5_5alloc3vec3VecINtNtB9_4cell7RefCellINtNtB9_6option6OptionTINtNtB13_2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEmEEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1d196:	lea    rdx,[r14+r14*2]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtB9_4cell7RefCellINtNtB9_6option6OptionTINtNtCscdodAO9FK5_5alloc2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEmEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1d19a:	cmp    rax,QWORD PTR [rcx+rdx*8+0x10]
  c1d19f:	jae    c1d2b9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2f79>
_RNvCslyNhMBcJWAz_6bsl_vm10prop_cache():
  c1d1a5:	lea    rcx,[rcx+rdx*8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtB9_4cell7RefCellINtNtB9_6option6OptionTINtNtCscdodAO9FK5_5alloc2rc2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEmEEEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1d1a9:	lea    r8,[rax+rax*2]
  c1d1ad:	shl    r8,0x3
  c1d1b1:	add    r8,QWORD PTR [rcx+0x8]
  c1d1b5:	lea    rdi,[rsp+0x1b0]
  c1d1bd:	lea    rsi,[rsp+0x230]
  c1d1c5:	lea    rcx,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2781
  c1d1ca:	mov    edx,ebx
  c1d1cc:	call   QWORD PTR [rip+0x237166]        # e54338 <_DYNAMIC+0x5848>
  c1d1d2:	movzx  eax,BYTE PTR [rsp+0x1b0]
  c1d1da:	cmp    al,0x5
  c1d1dc:	setne  bpl
  c1d1e0:	je     c1dab1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3771>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1d1e6:	cmp    al,0xff
  c1d1e8:	je     c1da6a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x372a>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1d1ee:	movdqu xmm0,XMMWORD PTR [rsp+0x1b1]
  c1d1f7:	movdqu xmm1,XMMWORD PTR [rsp+0x1c1]
  c1d200:	movdqu xmm2,XMMWORD PTR [rsp+0x1d0]
  c1d209:	mov    rcx,QWORD PTR [rsp+0x48]
  c1d20e:	movdqu XMMWORD PTR [rcx+0x20],xmm2
  c1d213:	movdqu XMMWORD PTR [rcx+0x11],xmm1
  c1d218:	movdqu XMMWORD PTR [rcx+0x1],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1d21d:	mov    BYTE PTR [rcx],al
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2790
  c1d21f:	jmp    c1d2df <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2f9f>
  c1d224:	lea    rax,[rip+0xffffffffff6a9c6a]        # 2c6e95 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x184c>
  c1d22b:	mov    ecx,0x41
  c1d230:	jmp    c1d2c5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2f85>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1d235:	mov    rax,QWORD PTR [r14+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1d239:	dec    QWORD PTR [rax]
  c1d23c:	mov    r15,r13
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1d23f:	jne    c1b39e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x105e>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1d245:	lea    rdi,[r14+0x8]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1d249:	call   QWORD PTR [rip+0x231af9]        # e4ed48 <_DYNAMIC+0x258>
  c1d24f:	jmp    c1b39e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x105e>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1d254:	mov    rax,QWORD PTR [r14+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1d258:	dec    QWORD PTR [rax]
  c1d25b:	mov    r15,r13
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1d25e:	jne    c1b4de <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x119e>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1d264:	lea    rdi,[r14+0x8]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1d268:	call   QWORD PTR [rip+0x231ada]        # e4ed48 <_DYNAMIC+0x258>
  c1d26e:	jmp    c1b4de <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x119e>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1d273:	mov    rax,QWORD PTR [r14+0x8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1d277:	dec    QWORD PTR [rax]
  c1d27a:	mov    r15,r13
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1d27d:	jne    c1b571 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1231>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1d283:	lea    rdi,[r14+0x8]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1d287:	call   QWORD PTR [rip+0x231abb]        # e4ed48 <_DYNAMIC+0x258>
  c1d28d:	jmp    c1b571 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1231>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1d292:	mov    rax,QWORD PTR [rsp+0x1c8]
  c1d29a:	movdqu xmm0,XMMWORD PTR [rsp+0x1b8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2731
  c1d2a3:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c1d2ac:	mov    QWORD PTR [rsp+0x130],rax
  c1d2b4:	jmp    c1d564 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3224>
  c1d2b9:	lea    rax,[rip+0xffffffffff6a9c16]        # 2c6ed6 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x188d>
  c1d2c0:	mov    ecx,0x45
  c1d2c5:	mov    rdx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1d2ca:	mov    BYTE PTR [rdx],0x1f
  c1d2cd:	mov    QWORD PTR [rdx+0x8],rax
  c1d2d1:	mov    QWORD PTR [rdx+0x10],rcx
  c1d2d5:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2785
  c1d2da:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1d2df:	lea    rdi,[rsp+0x120]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2793
  c1d2e7:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1d2ec:	lea    rdi,[rsp+0x238]
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1d2f4:	mov    eax,DWORD PTR [rsp+0x230]
  c1d2fb:	mov    edx,eax
  c1d2fd:	sub    edx,0x2
  c1d300:	mov    ecx,0x3
  c1d305:	cmovae ecx,edx
  c1d308:	cmp    ecx,0x8
  c1d30b:	ja     c1d348 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3008>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d30d:	mov    edx,0x1e7
  c1d312:	bt     edx,ecx
  c1d315:	jb     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1d31b:	cmp    ecx,0x3
  c1d31e:	jne    c1ce57 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2b17>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1d324:	test   eax,eax
  c1d326:	je     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1d32c:	mov    rax,QWORD PTR [rsp+0x238]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1d334:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1d337:	jne    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1d33d:	call   QWORD PTR [rip+0x2319f5]        # e4ed38 <_DYNAMIC+0x248>
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1d343:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1d348:	mov    rax,QWORD PTR [rsp+0x238]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1d350:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1d353:	jne    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1d359:	call   QWORD PTR [rip+0x2319e9]        # e4ed48 <_DYNAMIC+0x258>
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1d35f:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1d364:	mov    rax,QWORD PTR [rsp+0x178]
  c1d36c:	movdqu xmm0,XMMWORD PTR [rsp+0x168]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2862
  c1d375:	movdqa XMMWORD PTR [rsp+0x280],xmm0
  c1d37e:	mov    QWORD PTR [rsp+0x290],rax
  c1d386:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1d38b:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d38f:	cmp    r15,rsi
  c1d392:	jae    c1f0fb <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4dbb>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d398:	mov    rsi,QWORD PTR [rax+0x8]
  c1d39c:	mov    rdi,QWORD PTR [rsp+0x158]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d3a4:	lea    rdx,[rsi+rdi*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1d3a8:	movzx  ecx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1d3b0:	mov    rax,rcx
  c1d3b3:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c1d3b8:	jae    c1dcca <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x398a>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d3be:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d3c2:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1d3c5:	mov    rax,QWORD PTR [rax+rcx*1]
  c1d3c9:	jmp    c1dcce <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x398e>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1d3ce:	mov    rax,QWORD PTR [rsp+0x178]
  c1d3d6:	movdqu xmm0,XMMWORD PTR [rsp+0x168]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2887
  c1d3df:	movdqa XMMWORD PTR [rsp+0x230],xmm0
  c1d3e8:	mov    QWORD PTR [rsp+0x240],rax
  c1d3f0:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1d3f5:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d3f9:	cmp    r15,rsi
  c1d3fc:	jae    c1f110 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4dd0>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d402:	mov    rsi,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d406:	lea    rdx,[rsi+rbx*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1d40a:	movzx  ecx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1d412:	mov    rax,rcx
  c1d415:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c1d41a:	jae    c1dd66 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3a26>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d420:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d424:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1d427:	mov    rax,QWORD PTR [rax+rcx*1]
  c1d42b:	jmp    c1dd6a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3a2a>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1d430:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d434:	mov    rsi,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d43c:	mov    rcx,QWORD PTR [rsi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3048
  c1d440:	mov    rdx,QWORD PTR [rsp+0x170]
  c1d448:	mov    QWORD PTR [rsp+0x80],rdx
  c1d450:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1d459:	movdqa XMMWORD PTR [rsp+0x70],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1d45f:	cmp    rax,QWORD PTR [rsi+0x10]
  c1d463:	jae    c1d4e0 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x31a0>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1d465:	lea    rax,[rax+rax*2]
  c1d469:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1d46d:	mov    rdi,r14
  c1d470:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1d475:	mov    rax,QWORD PTR [rsp+0x170]
  c1d47d:	mov    QWORD PTR [r14+0x10],rax
  c1d481:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1d48a:	movdqu XMMWORD PTR [r14],xmm0
  c1d48f:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1d494:	mov    rsi,QWORD PTR [rax+0x10]
  c1d498:	mov    rdi,QWORD PTR [rsp+0x418]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1d4a0:	cmp    rdi,rsi
  c1d4a3:	jae    c1f137 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4df7>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d4a9:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3049
  c1d4ad:	inc    QWORD PTR [rax+r15*1+0x58]
_RNvXs1_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVechENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:424
  c1d4b2:	mov    rsi,QWORD PTR [rsp+0x120]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1d4ba:	test   rsi,rsi
  c1d4bd:	je     c1d4cd <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x318d>
_RNvNtCscdodAO9FK5_5alloc5alloc15dealloc_nonnull():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/alloc.rs:128
  c1d4bf:	mov    edx,0x1
  c1d4c4:	mov    rdi,rbx
  c1d4c7:	call   QWORD PTR [rip+0x231863]        # e4ed30 <_DYNAMIC+0x240>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3050
  c1d4cd:	cmp    DWORD PTR [rsp+0x230],0x6
  c1d4d5:	je     c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
  c1d4db:	jmp    c1da9f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x375f>
  c1d4e0:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1d4e5:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d4ea:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1d4ef:	mov    BYTE PTR [rcx],0x1f
  c1d4f2:	lea    rax,[rip+0xffffffffff6aa09b]        # 2c7594 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x589>
  c1d4f9:	mov    QWORD PTR [rcx+0x8],rax
  c1d4fd:	mov    QWORD PTR [rcx+0x10],0x4f
_RNvXs1_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVechENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:424
  c1d505:	mov    rsi,QWORD PTR [rsp+0x120]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1d50d:	test   rsi,rsi
  c1d510:	je     c1d520 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x31e0>
_RNvNtCscdodAO9FK5_5alloc5alloc15dealloc_nonnull():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/alloc.rs:128
  c1d512:	mov    edx,0x1
  c1d517:	mov    rdi,rbx
  c1d51a:	call   QWORD PTR [rip+0x231810]        # e4ed30 <_DYNAMIC+0x240>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3050
  c1d520:	mov    eax,DWORD PTR [rsp+0x230]
  c1d527:	cmp    eax,0x6
  c1d52a:	je     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1d530:	lea    rdi,[rsp+0x230]
  c1d538:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1d53d:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2745
  c1d542:	mov    rax,QWORD PTR [rsp+0x1c8]
  c1d54a:	mov    QWORD PTR [rsp+0x130],rax
  c1d552:	movdqu xmm0,XMMWORD PTR [rsp+0x1b8]
  c1d55b:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c1d564:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1d569:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d56d:	cmp    QWORD PTR [rsp+0x418],rsi
  c1d575:	mov    rdi,QWORD PTR [rsp+0x100]
  c1d57d:	jae    c1f0a0 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4d60>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d583:	mov    rsi,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d587:	lea    rdx,[rsi+r15*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1d58b:	movzx  ecx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1d593:	mov    rax,rcx
  c1d596:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c1d59b:	jae    c1d5aa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x326a>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d59d:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d5a1:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1d5a4:	mov    rax,QWORD PTR [rax+rcx*1]
  c1d5a8:	jmp    c1d5ae <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x326e>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1d5aa:	add    rax,QWORD PTR [rdx+0x60]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d5ae:	mov    rcx,QWORD PTR [rdi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2749
  c1d5b2:	mov    rdx,QWORD PTR [rsp+0x130]
  c1d5ba:	mov    QWORD PTR [rsp+0x80],rdx
  c1d5c2:	movdqa xmm0,XMMWORD PTR [rsp+0x120]
  c1d5cb:	movdqa XMMWORD PTR [rsp+0x70],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1d5d1:	cmp    rax,QWORD PTR [rdi+0x10]
  c1d5d5:	jae    c1d629 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x32e9>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1d5d7:	lea    rax,[rax+rax*2]
  c1d5db:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1d5df:	mov    rdi,r14
  c1d5e2:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1d5e7:	mov    rax,QWORD PTR [rsp+0x130]
  c1d5ef:	mov    QWORD PTR [r14+0x10],rax
  c1d5f3:	movdqa xmm0,XMMWORD PTR [rsp+0x120]
  c1d5fc:	movdqu XMMWORD PTR [r14],xmm0
  c1d601:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1d606:	mov    rsi,QWORD PTR [rax+0x10]
  c1d60a:	mov    rdi,QWORD PTR [rsp+0x418]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1d612:	cmp    rdi,rsi
  c1d615:	jae    c1f0e9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4da9>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d61b:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2750
  c1d61f:	inc    QWORD PTR [rax+r15*1+0x58]
  c1d624:	jmp    c1da9f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x375f>
  c1d629:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1d62e:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d633:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1d638:	mov    BYTE PTR [rcx],0x1f
  c1d63b:	lea    rax,[rip+0xffffffffff6a9f52]        # 2c7594 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x589>
  c1d642:	mov    QWORD PTR [rcx+0x8],rax
  c1d646:	mov    QWORD PTR [rcx+0x10],0x4f
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2751
  c1d64e:	jmp    c1ce1b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2adb>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1d653:	movups xmm0,XMMWORD PTR [rsp+0x1d0]
  c1d65b:	mov    rcx,QWORD PTR [rsp+0x48]
  c1d660:	movups XMMWORD PTR [rcx+0x20],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2745
  c1d664:	movdqu xmm0,XMMWORD PTR [rsp+0x1b1]
  c1d66d:	movdqu xmm1,XMMWORD PTR [rsp+0x1c0]
  c1d676:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1d67b:	movdqu XMMWORD PTR [rcx+0x10],xmm1
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1d680:	mov    BYTE PTR [rcx],al
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2746
  c1d682:	jmp    c1ce1b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2adb>
  c1d687:	mov    QWORD PTR [rsp+0x270],rsi
  c1d68f:	mov    rbp,r8
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2931
  c1d692:	lea    rax,[rip+0xffffffffff6aa267]        # 2c7900 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x8f5>
  c1d699:	mov    QWORD PTR [rsp+0x78],rax
  c1d69e:	mov    QWORD PTR [rsp+0x80],0x53
  c1d6aa:	mov    BYTE PTR [rsp+0x70],0x1f
  c1d6af:	mov    DWORD PTR [rsp+0x68],0x0
  c1d6b7:	lea    rdi,[rsp+0x70]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE5ok_orNtNtBO_5error7RtErrorECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1d6bc:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
_RINvNtNtCs4NRVxsYgnAr_4core5slice5index24get_offset_len_noubcheckNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:89
  c1d6c1:	lea    rax,[rbx+rbx*2]
  c1d6c5:	lea    rcx,[r15+rax*8]
  c1d6c9:	mov    DWORD PTR [rsp+0x68],0x0
  c1d6d1:	mov    r8,rbp
  c1d6d4:	mov    r11,QWORD PTR [rsp+0x3e8]
  c1d6dc:	mov    rbp,QWORD PTR [rsp+0x270]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d6e4:	lea    rax,[r13*2+0x0]
  c1d6ec:	add    rax,r13
  c1d6ef:	lea    rdx,[r15+rax*8]
_RNvMs_NtCsbxvJACuny95_6bsl_rt8internerNtB4_6NameId10from_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/interner.rs:47
  c1d6f3:	mov    DWORD PTR [rsp+0x26c],r14d
_RNvMNtCsbxvJACuny95_6bsl_rt5valueNtB2_8BslValue10object_ref():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:648
  c1d6fb:	cmp    DWORD PTR [rdx],0xb
  c1d6fe:	jne    c1d911 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x35d1>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1d704:	mov    r13,QWORD PTR [rdx+0x8]
_RNvMNtCsbxvJACuny95_6bsl_rt5valueNtB2_8BslValue10object_ref():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/value/mod.rs:649
  c1d708:	cmp    BYTE PTR [r13+0x10],0xf
  c1d70d:	jne    c1d911 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x35d1>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d713:	mov    QWORD PTR [rsp+0x2a8],rcx
  c1d71b:	mov    QWORD PTR [rsp+0x270],rbp
  c1d723:	mov    rbx,r8
  c1d726:	mov    r10,QWORD PTR [rsp+0x3d8]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2945
  c1d72e:	lea    rdx,[r10+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2946
  c1d732:	lea    rsi,[r10+0x58]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2947
  c1d736:	lea    rdi,[r10+0x68]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1d73a:	lea    r8,[r10+0xf0]
  c1d741:	mov    rax,QWORD PTR [r10+0xf0]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1d748:	mov    r9,QWORD PTR [r10+0x118]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt4http17HttpClientFactoryEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1d74f:	test   rax,rax
  c1d752:	cmove  r8,rax
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1d756:	lea    rcx,[r10+0x100]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt3env15UserMessageSinkEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1d75d:	lea    rax,[r10+0x118]
  c1d764:	test   r9,r9
  c1d767:	cmove  rax,r9
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtCsbxvJACuny95_6bsl_rt12temp_storage18TempStorageSessionEEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1d76b:	lea    r9,[r10+0x110]
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1d772:	movq   xmm0,QWORD PTR [r10+0x110]
  c1d77b:	movq   xmm1,QWORD PTR [r10+0x100]
  c1d784:	punpcklqdq xmm1,xmm0
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1d788:	mov    QWORD PTR [rsp+0x70],r11
  c1d78d:	mov    r10,QWORD PTR [rip+0x23167c]        # e4ee10 <_DYNAMIC+0x320>
  c1d794:	mov    QWORD PTR [rsp+0x78],r10
  c1d799:	mov    BYTE PTR [rsp+0xf8],0x0
  c1d7a1:	mov    r10,QWORD PTR [rsp+0x3e0]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2942
  c1d7a9:	movups xmm0,XMMWORD PTR [r10]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1d7ad:	movups XMMWORD PTR [rsp+0x80],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2943
  c1d7b5:	movdqu xmm0,XMMWORD PTR [r10+0x10]
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1d7bb:	movdqu XMMWORD PTR [rsp+0x90],xmm0
  c1d7c4:	mov    QWORD PTR [rsp+0xa0],rdx
  c1d7cc:	mov    QWORD PTR [rsp+0xa8],rsi
  c1d7d4:	mov    QWORD PTR [rsp+0xb0],rdi
  c1d7dc:	mov    QWORD PTR [rsp+0xb8],r8
  c1d7e4:	mov    rdx,QWORD PTR [rsp+0x408]
  c1d7ec:	mov    QWORD PTR [rsp+0xc0],rdx
  c1d7f4:	lea    rdx,[rip+0x219fcd]        # e377c8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0x9f0>
  c1d7fb:	mov    QWORD PTR [rsp+0xc8],rdx
  c1d803:	mov    QWORD PTR [rsp+0xd0],0x0
_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionINtNtCscdodAO9FK5_5alloc2rc2RcDNtNtCsbxvJACuny95_6bsl_rt15background_jobs20BackgroundJobServiceEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:742
  c1d80f:	pxor   xmm0,xmm0
  c1d813:	pcmpeqd xmm0,xmm1
  c1d817:	movq   xmm1,r9
  c1d81c:	movq   xmm2,rcx
  c1d821:	punpcklqdq xmm2,xmm1
  c1d825:	pshufd xmm1,xmm0,0xb1
  c1d82a:	pand   xmm1,xmm0
  c1d82e:	pandn  xmm1,xmm2
_RNvMs3_NtCsbxvJACuny95_6bsl_rt9componentNtB5_11CallContext11interpreter():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:224
  c1d832:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
  c1d83b:	mov    QWORD PTR [rsp+0xf0],rax
  c1d843:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1d848:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1d84c:	cmp    QWORD PTR [rsp+0x418],rsi
  c1d854:	mov    rcx,QWORD PTR [rsp+0x278]
  c1d85c:	jae    c1f149 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4e09>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d862:	lea    rdi,[r13+0x18]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d866:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2963
  c1d86a:	mov    r15,QWORD PTR [rax+rcx*1+0x58]
  c1d86f:	mov    rbp,rdi
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2965
  c1d872:	call   QWORD PTR [rip+0x236b18]        # e54390 <_DYNAMIC+0x58a0>
  c1d878:	mov    r8,QWORD PTR [rsp+0x3d8]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2964
  c1d880:	sub    r8,0xffffffffffffff80
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2960
  c1d884:	mov    ecx,DWORD PTR [rsp+0x26c]
  c1d88b:	mov    QWORD PTR [rsp+0x10],rbx
  c1d890:	mov    DWORD PTR [rsp+0x8],ecx
  c1d894:	mov    QWORD PTR [rsp],rdx
  c1d898:	lea    rdi,[rsp+0x1b0]
  c1d8a0:	mov    rsi,QWORD PTR [rsp+0x158]
  c1d8a8:	mov    rdx,QWORD PTR [rsp+0x420]
  c1d8b0:	mov    rcx,r15
  c1d8b3:	mov    r9,rax
  c1d8b6:	call   c0e620 <_RNvCslyNhMBcJWAz_6bsl_vm23cached_component_method>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultINtNtB7_6option6OptionRNtNtCsbxvJACuny95_6bsl_rt9component16MethodDescriptorENtNtB1b_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1d8bb:	movzx  eax,BYTE PTR [rsp+0x1b0]
  c1d8c3:	cmp    al,0xff
  c1d8c5:	je     c1e009 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cc9>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1d8cb:	mov    ecx,DWORD PTR [rsp+0x1b1]
  c1d8d2:	mov    edx,DWORD PTR [rsp+0x1b4]
  c1d8d9:	mov    rsi,QWORD PTR [rsp+0x48]
  c1d8de:	mov    DWORD PTR [rsi+0x4],edx
  c1d8e1:	mov    DWORD PTR [rsi+0x1],ecx
  c1d8e4:	mov    rcx,QWORD PTR [rsp+0x1b8]
  c1d8ec:	movups xmm0,XMMWORD PTR [rsp+0x1d0]
  c1d8f4:	movups XMMWORD PTR [rsi+0x20],xmm0
  c1d8f8:	movdqu xmm0,XMMWORD PTR [rsp+0x1c0]
  c1d901:	movdqu XMMWORD PTR [rsi+0x10],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1d906:	mov    BYTE PTR [rsi],al
  c1d908:	mov    QWORD PTR [rsi+0x8],rcx
  c1d90c:	jmp    c1da4a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x370a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1d911:	mov    rsi,QWORD PTR [rsp+0x3d8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSINtNtB9_6option6OptionNtNtCsbxvJACuny95_6bsl_rt7builtin13BuiltinMethodEE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1d919:	cmp    QWORD PTR [rsi+0x40],r14
  c1d91d:	jbe    c1d9e8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x36a8>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtCsbxvJACuny95_6bsl_rt7builtin13BuiltinMethodEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1d923:	mov    rax,QWORD PTR [rsi+0x38]
_RNvMs1_NtCs4NRVxsYgnAr_4core6optionINtB5_6OptionRIBy_NtNtCsbxvJACuny95_6bsl_rt7builtin13BuiltinMethodEE6copiedCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:2138
  c1d927:	movzx  eax,BYTE PTR [rax+r14*1]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2997
  c1d92c:	mov    QWORD PTR [rsp+0x1b0],r8
  c1d934:	lea    rdi,[rsp+0x26c]
  c1d93c:	mov    QWORD PTR [rsp+0x1b8],rdi
  c1d944:	mov    QWORD PTR [rsp+0x1c0],rdx
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt7builtin13BuiltinMethodE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm9step_colds_0EB26_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1364
  c1d94c:	cmp    al,0xff
  c1d94e:	je     c1da08 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x36c8>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1d954:	mov    r8,QWORD PTR [rsi+0x58]
  c1d958:	mov    rsi,QWORD PTR [rsi+0x60]
_RNvXsq_NtCscdodAO9FK5_5alloc2rcINtB5_2RcDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_ENtNtNtCs4NRVxsYgnAr_4core3ops5deref5Deref5derefCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2441
  c1d95c:	mov    rdi,QWORD PTR [rsi+0x10]
  c1d960:	dec    rdi
  c1d963:	and    rdi,0xfffffffffffffff0
  c1d967:	add    rdi,r8
  c1d96a:	add    rdi,0x10
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3001
  c1d96e:	mov    QWORD PTR [rsp+0x8],rsi
  c1d973:	mov    QWORD PTR [rsp],rdi
  c1d977:	movzx  esi,al
  c1d97a:	lea    rdi,[rsp+0x70]
  c1d97f:	mov    r8,rbp
  c1d982:	mov    r9,r11
  c1d985:	call   QWORD PTR [rip+0x236995]        # e54320 <_DYNAMIC+0x5830>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1d98b:	movzx  eax,BYTE PTR [rsp+0x70]
  c1d990:	cmp    al,0xff
  c1d992:	je     c1e1fe <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3ebe>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1d998:	movups xmm0,XMMWORD PTR [rsp+0x71]
  c1d99d:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1d9a6:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1d9af:	movdqu XMMWORD PTR [rsp+0x1bf],xmm1
  c1d9b8:	movaps XMMWORD PTR [rsp+0x1b0],xmm0
  c1d9c0:	mov    rcx,QWORD PTR [rsp+0x48]
  c1d9c5:	movdqu XMMWORD PTR [rcx+0x20],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3007
  c1d9ca:	movups xmm0,XMMWORD PTR [rsp+0x1bf]
  c1d9d2:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1d9d6:	movdqa xmm0,XMMWORD PTR [rsp+0x1b0]
  c1d9df:	movdqu XMMWORD PTR [rcx+0x1],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1d9e4:	mov    BYTE PTR [rcx],al
  c1d9e6:	jmp    c1da4a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x370a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2997
  c1d9e8:	mov    QWORD PTR [rsp+0x1b0],r8
  c1d9f0:	lea    rax,[rsp+0x26c]
  c1d9f8:	mov    QWORD PTR [rsp+0x1b8],rax
  c1da00:	mov    QWORD PTR [rsp+0x1c0],rdx
  c1da08:	lea    rdi,[rsp+0x70]
  c1da0d:	lea    rsi,[rsp+0x1b0]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt7builtin13BuiltinMethodE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm9step_colds_0EB26_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1366
  c1da15:	call   c0b5c0 <_RNCNvCslyNhMBcJWAz_6bsl_vm9step_colds_0B3_>
  c1da1a:	movzx  eax,WORD PTR [rsp+0x70]
  c1da1f:	movups xmm0,XMMWORD PTR [rsp+0x72]
  c1da24:	mov    rcx,QWORD PTR [rsp+0x48]
  c1da29:	movups XMMWORD PTR [rcx+0x2],xmm0
  c1da2d:	movups xmm0,XMMWORD PTR [rsp+0x82]
  c1da35:	movups XMMWORD PTR [rcx+0x12],xmm0
  c1da39:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1da42:	movdqu XMMWORD PTR [rcx+0x20],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1da47:	mov    WORD PTR [rcx],ax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1da4a:	mov    eax,DWORD PTR [rsp+0x68]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1da4e:	test   al,al
  c1da50:	je     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1da56:	lea    rdi,[rsp+0x160]
  c1da5e:	call   c0a020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCslyNhMBcJWAz_6bsl_vm8CallArgsEBD_>
  c1da63:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1da68:	xor    ebp,ebp
  c1da6a:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1da6f:	mov    rsi,QWORD PTR [rax+0x10]
  c1da73:	mov    rdi,QWORD PTR [rsp+0x418]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1da7b:	cmp    rdi,rsi
  c1da7e:	jae    c1f125 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4de5>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1da84:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2792
  c1da88:	inc    QWORD PTR [rax+r15*1+0x58]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2793
  c1da8d:	test   bpl,bpl
  c1da90:	je     c1da9f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x375f>
  c1da92:	lea    rdi,[rsp+0x120]
  c1da9a:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1da9f:	lea    rdi,[rsp+0x230]
  c1daa7:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1daac:	jmp    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
_RNvMs_NtCsbxvJACuny95_6bsl_rt8internerNtB4_6NameId5index():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/interner.rs:38
  c1dab1:	mov    eax,ebx
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCscdodAO9FK5_5alloc6string6StringE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1dab3:	cmp    QWORD PTR [r13+0x40],rax
  c1dab7:	jbe    c1e26d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3f2d>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2787
  c1dabd:	mov    rcx,QWORD PTR [r13+0x38]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCscdodAO9FK5_5alloc6string6StringE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1dac1:	lea    rax,[rax+rax*2]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1dac5:	mov    rdx,QWORD PTR [rcx+rax*8+0x8]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VechE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1daca:	mov    rcx,QWORD PTR [rcx+rax*8+0x10]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2787
  c1dacf:	mov    rax,QWORD PTR [rsp+0x130]
  c1dad7:	mov    QWORD PTR [rsp+0x170],rax
  c1dadf:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c1dae8:	movdqa XMMWORD PTR [rsp+0x160],xmm0
  c1daf1:	lea    rdi,[rsp+0x70]
  c1daf6:	lea    rsi,[rsp+0x230]
  c1dafe:	lea    r8,[rsp+0x160]
  c1db06:	call   QWORD PTR [rip+0x236834]        # e54340 <_DYNAMIC+0x5850>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1db0c:	cmp    BYTE PTR [rsp+0x70],0xff
  c1db11:	je     c1e4ed <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x41ad>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1db17:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1db1d:	movdqu xmm1,XMMWORD PTR [rsp+0x80]
  c1db26:	movdqu xmm2,XMMWORD PTR [rsp+0x90]
  c1db2f:	mov    rax,QWORD PTR [rsp+0x48]
  c1db34:	movdqu XMMWORD PTR [rax+0x20],xmm2
  c1db39:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1db3e:	movdqu XMMWORD PTR [rax],xmm0
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1db42:	cmp    BYTE PTR [rsp+0x1b0],0xff
  c1db4a:	je     c1d2ec <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2fac>
  c1db50:	lea    rdi,[rsp+0x1b0]
  c1db58:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
  c1db5d:	jmp    c1d2ec <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2fac>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtCslyNhMBcJWAz_6bsl_vm8CallArgsNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchBM_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1db62:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
  c1db68:	movdqu xmm1,XMMWORD PTR [rsp+0x88]
  c1db71:	movdqu xmm2,XMMWORD PTR [rsp+0x98]
  c1db7a:	movdqu XMMWORD PTR [rsp+0x1d4],xmm2
  c1db83:	movdqu XMMWORD PTR [rsp+0x1c4],xmm1
  c1db8c:	movdqu XMMWORD PTR [rsp+0x1b4],xmm0
  c1db95:	jmp    c1b1e6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0xea6>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1db9a:	mov    rbx,QWORD PTR [rcx+0x8]
  c1db9e:	mov    eax,0x6
  c1dba3:	jmp    c1dbae <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x386e>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1dba5:	mov    rbx,QWORD PTR [rcx+0x8]
  c1dba9:	mov    eax,0xb
_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone():
  c1dbae:	inc    QWORD PTR [rbx]
  c1dbb1:	jne    c1dbc1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3881>
_RNvCslyNhMBcJWAz_6bsl_vm8reg_load():
  c1dbb3:	ud2
  c1dbb5:	mov    eax,0x2
  c1dbba:	jmp    c1dbc1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3881>
  c1dbbc:	mov    eax,0x3
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE10ok_or_elseNtNtBM_5error7RtErrorNCNvCslyNhMBcJWAz_6bsl_vm8reg_load0EB1Y_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1365
  c1dbc1:	shl    r14,0x20
  c1dbc5:	or     r14,rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2643
  c1dbc8:	mov    QWORD PTR [rsp+0x1b0],r14
  c1dbd0:	mov    QWORD PTR [rsp+0x1b8],rbx
  c1dbd8:	mov    rax,QWORD PTR [rsp+0x278]
  c1dbe0:	mov    QWORD PTR [rsp+0x1c0],rax
  c1dbe8:	mov    al,0x1
  c1dbea:	lea    rdx,[rip+0xffffffffff6a93b3]        # 2c6fa4 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x195b>
  c1dbf1:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1dbf6:	mov    BYTE PTR [rcx],al
  c1dbf8:	mov    QWORD PTR [rcx+0x8],rdx
  c1dbfc:	mov    QWORD PTR [rcx+0x10],0xa
  c1dc04:	lea    rax,[rip+0xffffffffff6a93a3]        # 2c6fae <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1965>
  c1dc0b:	mov    QWORD PTR [rcx+0x18],rax
  c1dc0f:	mov    QWORD PTR [rcx+0x20],0x1c
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1dc17:	mov    eax,DWORD PTR [rsp+0x1b0]
  c1dc1e:	mov    edx,eax
  c1dc20:	sub    edx,0x2
  c1dc23:	mov    ecx,0x3
  c1dc28:	cmovae ecx,edx
  c1dc2b:	cmp    ecx,0x8
  c1dc2e:	ja     c1dcaa <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x396a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1dc30:	mov    edx,0x1e7
  c1dc35:	bt     edx,ecx
  c1dc38:	jae    c1dc67 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3927>
_RNvXs1_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecjENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:424
  c1dc3a:	mov    rsi,QWORD PTR [rsp+0x120]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1dc42:	test   rsi,rsi
  c1dc45:	je     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvXs1_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecjENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:424
  c1dc4b:	mov    rdi,QWORD PTR [rsp+0x128]
_RNvMs9_NtCs4NRVxsYgnAr_4core3numj13unchecked_mul():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num/uint_macros.rs:1359
  c1dc53:	shl    rsi,0x3
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1dc57:	mov    edx,0x8
  c1dc5c:	call   QWORD PTR [rip+0x2310ce]        # e4ed30 <_DYNAMIC+0x240>
  c1dc62:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1dc67:	cmp    ecx,0x3
  c1dc6a:	jne    c1dc8d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x394d>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsi8OWPsLN6MM_10bsl_number6number4ReprECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1dc6c:	test   eax,eax
  c1dc6e:	je     c1dc3a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38fa>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1dc70:	mov    rax,QWORD PTR [rsp+0x1b8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1dc78:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsi8OWPsLN6MM_10bsl_number6number6BigDecENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1dc7b:	jne    c1dc3a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38fa>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1dc7d:	lea    rdi,[rsp+0x1b8]
  c1dc85:	call   QWORD PTR [rip+0x2310ad]        # e4ed38 <_DYNAMIC+0x248>
  c1dc8b:	jmp    c1dc3a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38fa>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1dc8d:	mov    rax,QWORD PTR [rsp+0x1b8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1dc95:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1dc98:	jne    c1dc3a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38fa>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1dc9a:	lea    rdi,[rsp+0x1b8]
  c1dca2:	call   QWORD PTR [rip+0x231098]        # e4ed40 <_DYNAMIC+0x250>
  c1dca8:	jmp    c1dc3a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38fa>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1dcaa:	mov    rax,QWORD PTR [rsp+0x1b8]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1dcb2:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6object9BslObjectENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1dcb5:	jne    c1dc3a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38fa>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1dcb7:	lea    rdi,[rsp+0x1b8]
  c1dcbf:	call   QWORD PTR [rip+0x231083]        # e4ed48 <_DYNAMIC+0x258>
  c1dcc5:	jmp    c1dc3a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x38fa>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1dcca:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1dcce:	mov    rsi,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1dcd6:	mov    rcx,QWORD PTR [rsi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2864
  c1dcda:	mov    rdx,QWORD PTR [rsp+0x290]
  c1dce2:	mov    QWORD PTR [rsp+0x170],rdx
  c1dcea:	movdqa xmm0,XMMWORD PTR [rsp+0x280]
  c1dcf3:	movdqa XMMWORD PTR [rsp+0x160],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1dcfc:	cmp    rax,QWORD PTR [rsi+0x10]
  c1dd00:	jae    c1dd54 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3a14>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1dd02:	lea    rax,[rax+rax*2]
  c1dd06:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1dd0a:	mov    rdi,r14
  c1dd0d:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1dd12:	mov    rax,QWORD PTR [rsp+0x290]
  c1dd1a:	mov    QWORD PTR [r14+0x10],rax
  c1dd1e:	movdqa xmm0,XMMWORD PTR [rsp+0x280]
  c1dd27:	movdqu XMMWORD PTR [r14],xmm0
  c1dd2c:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1dd31:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1dd35:	cmp    r15,rsi
  c1dd38:	jae    c1f170 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4e30>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1dd3e:	mov    rax,QWORD PTR [rax+0x8]
  c1dd42:	mov    rcx,QWORD PTR [rsp+0x158]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2865
  c1dd4a:	inc    QWORD PTR [rax+rcx*1+0x58]
  c1dd4f:	jmp    c1dde3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3aa3>
  c1dd54:	lea    rdi,[rsp+0x160]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1dd5c:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1dd61:	jmp    c1de02 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3ac2>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1dd66:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1dd6a:	mov    rsi,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1dd72:	mov    rcx,QWORD PTR [rsi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2889
  c1dd76:	mov    rdx,QWORD PTR [rsp+0x240]
  c1dd7e:	mov    QWORD PTR [rsp+0x170],rdx
  c1dd86:	movdqa xmm0,XMMWORD PTR [rsp+0x230]
  c1dd8f:	movdqa XMMWORD PTR [rsp+0x160],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1dd98:	cmp    rax,QWORD PTR [rsi+0x10]
  c1dd9c:	jae    c1ddf5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3ab5>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1dd9e:	lea    rax,[rax+rax*2]
  c1dda2:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1dda6:	mov    rdi,r14
  c1dda9:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1ddae:	mov    rax,QWORD PTR [rsp+0x240]
  c1ddb6:	mov    QWORD PTR [r14+0x10],rax
  c1ddba:	movdqa xmm0,XMMWORD PTR [rsp+0x230]
  c1ddc3:	movdqu XMMWORD PTR [r14],xmm0
  c1ddc8:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1ddcd:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1ddd1:	cmp    r15,rsi
  c1ddd4:	jae    c1f185 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4e45>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ddda:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2890
  c1ddde:	inc    QWORD PTR [rax+rbx*1+0x58]
  c1dde3:	lea    rdi,[rsp+0x1b0]
  c1ddeb:	call   c0a020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCslyNhMBcJWAz_6bsl_vm8CallArgsEBD_>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1ddf0:	jmp    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
  c1ddf5:	lea    rdi,[rsp+0x160]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1ddfd:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1de02:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1de07:	mov    BYTE PTR [rcx],0x1f
  c1de0a:	lea    rax,[rip+0xffffffffff6a9783]        # 2c7594 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x589>
  c1de11:	mov    QWORD PTR [rcx+0x8],rax
  c1de15:	mov    QWORD PTR [rcx+0x10],0x4f
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1de1d:	jmp    c1b6f8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x13b8>
  c1de22:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1de27:	mov    BYTE PTR [rcx],0x1f
  c1de2a:	lea    rax,[rip+0xffffffffff6a900d]        # 2c6e3e <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x17f5>
  c1de31:	mov    QWORD PTR [rcx+0x8],rax
  c1de35:	mov    QWORD PTR [rcx+0x10],0x57
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1de3d:	lea    rdi,[rsp+0x1b0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2746
  c1de45:	call   c09620 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECslyNhMBcJWAz_6bsl_vm>
  c1de4a:	jmp    c1ce1b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2adb>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3228
  c1de4f:	mov    QWORD PTR [rsp+0x80],0x3a
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1337
  c1de5b:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1de64:	mov    rcx,QWORD PTR [rsp+0x48]
  c1de69:	movdqu XMMWORD PTR [rcx+0x20],xmm0
  c1de6e:	mov    rax,QWORD PTR [rsp+0x80]
  c1de76:	mov    QWORD PTR [rcx+0x10],rax
  c1de7a:	mov    rax,QWORD PTR [rsp+0x88]
  c1de82:	mov    QWORD PTR [rcx+0x18],rax
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1de86:	mov    BYTE PTR [rcx],0x1f
  c1de89:	lea    rax,[rip+0xffffffffff6a980f]        # 2c769f <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x694>
  c1de90:	mov    QWORD PTR [rcx+0x8],rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1de94:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1de99:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1de9e:	mov    BYTE PTR [rcx],0x1f
  c1dea1:	lea    rax,[rip+0xffffffffff6a957c]        # 2c7424 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x419>
  c1dea8:	mov    QWORD PTR [rcx+0x8],rax
  c1deac:	mov    QWORD PTR [rcx+0x10],0x5c
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1deb4:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1deb9:	add    rcx,QWORD PTR [rsi+0x60]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1debd:	cmp    rcx,rax
  c1dec0:	jae    c1dfdc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3c9c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1dec6:	mov    rax,QWORD PTR [rsp+0x100]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3250
  c1dece:	mov    rax,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1ded2:	lea    rcx,[rcx+rcx*2]
  c1ded6:	lea    rsi,[rax+rcx*8]
  c1deda:	lea    rdi,[rsp+0x70]
_RNvYNvYNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneINtNtNtBN_3ops8function6FnOnceTRB5_EE9call_onceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ops/function.rs:250
  c1dedf:	call   c246a0 <_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1162
  c1dee4:	mov    rax,QWORD PTR [rsp+0x70]
  c1dee9:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3250
  c1deef:	mov    QWORD PTR [rsp+0x160],rax
  c1def7:	movdqu XMMWORD PTR [rsp+0x168],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE7get_mutB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1df00:	cmp    QWORD PTR [r12+0x10],rbx
  c1df05:	jbe    c1e2f8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3fb8>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceEB14_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1df0b:	mov    r13,QWORD PTR [r12+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3255
  c1df10:	lea    rax,[rip+0xffffffffff6a9788]        # 2c769f <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x694>
  c1df17:	mov    QWORD PTR [rsp+0x78],rax
  c1df1c:	mov    QWORD PTR [rsp+0x80],0x3a
  c1df28:	mov    BYTE PTR [rsp+0x70],0x1f
  c1df2d:	lea    rdi,[rsp+0x70]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionQNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1df32:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE7get_mutB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1df37:	shl    rbx,0x5
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1df3b:	mov    rax,QWORD PTR [r13+rbx*1+0x8]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE12as_mut_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1df40:	mov    rcx,QWORD PTR [r13+rbx*1+0x10]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3256
  c1df45:	mov    rdx,QWORD PTR [rsp+0x170]
  c1df4d:	mov    QWORD PTR [rsp+0x1c0],rdx
  c1df55:	movdqu xmm0,XMMWORD PTR [rsp+0x160]
  c1df5e:	movdqa XMMWORD PTR [rsp+0x1b0],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1df67:	cmp    rcx,r14
  c1df6a:	jbe    c1e5b8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4278>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1df70:	lea    rcx,[r14+r14*2]
  c1df74:	lea    r14,[rax+rcx*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1df78:	mov    rax,QWORD PTR [rsp+0x170]
  c1df80:	mov    QWORD PTR [rsp+0x80],rax
  c1df88:	movups xmm0,XMMWORD PTR [rsp+0x160]
  c1df90:	movaps XMMWORD PTR [rsp+0x70],xmm0
  c1df95:	mov    rdi,r14
  c1df98:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1df9d:	mov    rax,QWORD PTR [rsp+0x80]
  c1dfa5:	mov    QWORD PTR [r14+0x10],rax
  c1dfa9:	movdqa xmm0,XMMWORD PTR [rsp+0x70]
  c1dfaf:	movdqu XMMWORD PTR [r14],xmm0
  c1dfb4:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1dfb9:	mov    rsi,QWORD PTR [rax+0x10]
  c1dfbd:	mov    rdi,QWORD PTR [rsp+0x418]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1dfc5:	cmp    rdi,rsi
  c1dfc8:	jae    c1f1d9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4e99>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1dfce:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3257
  c1dfd2:	inc    QWORD PTR [rax+r15*1+0x58]
  c1dfd7:	jmp    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
  c1dfdc:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1dfe1:	mov    BYTE PTR [rcx],0x1f
  c1dfe4:	lea    rax,[rip+0xffffffffff6a8db5]        # 2c6da0 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1757>
  c1dfeb:	mov    QWORD PTR [rcx+0x8],rax
  c1dfef:	mov    QWORD PTR [rcx+0x10],0x4f
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3266
  c1dff7:	add    rsp,0x398
  c1dffe:	pop    rbx
  c1dfff:	pop    r12
  c1e001:	pop    r13
  c1e003:	pop    r14
  c1e005:	pop    r15
  c1e007:	pop    rbp
  c1e008:	ret
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultINtNtB7_6option6OptionRNtNtCsbxvJACuny95_6bsl_rt9component16MethodDescriptorENtNtB1b_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1e009:	mov    r14,QWORD PTR [rsp+0x1b8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2960
  c1e011:	test   r14,r14
  c1e014:	je     c1e441 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4101>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2970
  c1e01a:	mov    rdi,rbp
  c1e01d:	call   QWORD PTR [rip+0x236375]        # e54398 <_DYNAMIC+0x58a8>
  c1e023:	mov    rcx,QWORD PTR [rax+0x10]
  c1e027:	mov    rax,QWORD PTR [rax+0x18]
_RNvMs2_NtCsbxvJACuny95_6bsl_rt9componentNtB5_5Arity7accepts():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:108
  c1e02b:	cmp    BYTE PTR [r14+0x20],r12b
  c1e02f:	ja     c1e50d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x41cd>
  c1e035:	cmp    BYTE PTR [r14+0x21],r12b
  c1e039:	jb     c1e50d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x41cd>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerDNtNtCsbxvJACuny95_6bsl_rt15object_protocol14ObjectProtocolEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1e03f:	mov    rax,QWORD PTR [r13+0x18]
  c1e043:	mov    rdx,QWORD PTR [r13+0x20]
_RNvXsq_NtCscdodAO9FK5_5alloc2rcINtB5_2RcDNtNtCsbxvJACuny95_6bsl_rt15object_protocol14ObjectProtocolEL_ENtNtNtCs4NRVxsYgnAr_4core3ops5deref5Deref5derefCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2441
  c1e047:	mov    rcx,QWORD PTR [rdx+0x10]
  c1e04b:	dec    rcx
  c1e04e:	and    rcx,0xfffffffffffffff0
  c1e052:	lea    rsi,[rax+rcx*1]
  c1e056:	add    rsi,0x10
_RNvMs4_NtCsbxvJACuny95_6bsl_rt9componentNtB5_16MethodDescriptor6invoke():
  c1e05a:	mov    rax,QWORD PTR [r14+0x8]
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:678
  c1e05e:	cmp    DWORD PTR [r14],0x1
  c1e062:	jne    c1e6c8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4388>
  c1e068:	lea    rdi,[rsp+0x1b0]
  c1e070:	lea    r9,[rsp+0x70]
  c1e075:	mov    rcx,QWORD PTR [rsp+0x2a8]
  c1e07d:	mov    r8,QWORD PTR [rsp+0x270]
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:680
  c1e085:	call   rax
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt9component11CallOutcomeNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1e087:	mov    rax,QWORD PTR [rsp+0x1b0]
  c1e08f:	cmp    rax,0xfffffffffffffffe
  c1e093:	je     c1e72b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x43eb>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1e099:	mov    rcx,QWORD PTR [rsp+0x228]
  c1e0a1:	mov    QWORD PTR [rsp+0x360],rcx
  c1e0a9:	movups xmm0,XMMWORD PTR [rsp+0x218]
  c1e0b1:	movaps XMMWORD PTR [rsp+0x350],xmm0
  c1e0b9:	movups xmm0,XMMWORD PTR [rsp+0x208]
  c1e0c1:	movaps XMMWORD PTR [rsp+0x340],xmm0
  c1e0c9:	movups xmm0,XMMWORD PTR [rsp+0x1f8]
  c1e0d1:	movaps XMMWORD PTR [rsp+0x330],xmm0
  c1e0d9:	movups xmm0,XMMWORD PTR [rsp+0x1b8]
  c1e0e1:	movdqu xmm1,XMMWORD PTR [rsp+0x1c8]
  c1e0ea:	movdqu xmm2,XMMWORD PTR [rsp+0x1d8]
  c1e0f3:	movups xmm3,XMMWORD PTR [rsp+0x1e8]
  c1e0fb:	movaps XMMWORD PTR [rsp+0x320],xmm3
  c1e103:	movaps XMMWORD PTR [rsp+0x230],xmm0
  c1e10b:	movdqa XMMWORD PTR [rsp+0x240],xmm1
  c1e114:	movdqa XMMWORD PTR [rsp+0x250],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2971
  c1e11d:	movdqa XMMWORD PTR [rsp+0x310],xmm2
  c1e126:	movdqa XMMWORD PTR [rsp+0x300],xmm1
  c1e12f:	movaps XMMWORD PTR [rsp+0x2f0],xmm0
  c1e137:	cmp    rax,0xffffffffffffffff
  c1e13b:	je     c1e860 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4520>
  c1e141:	mov    rdx,QWORD PTR [rsp+0x410]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2981
  c1e149:	mov    QWORD PTR [rsp+0x1b0],rax
  c1e151:	movaps xmm0,XMMWORD PTR [rsp+0x230]
  c1e159:	movaps xmm1,XMMWORD PTR [rsp+0x240]
  c1e161:	movaps xmm2,XMMWORD PTR [rsp+0x250]
  c1e169:	movups XMMWORD PTR [rsp+0x1b8],xmm0
  c1e171:	movups XMMWORD PTR [rsp+0x1c8],xmm1
  c1e179:	movups XMMWORD PTR [rsp+0x1d8],xmm2
  c1e181:	movdqa xmm0,XMMWORD PTR [rsp+0x320]
  c1e18a:	movdqa xmm1,XMMWORD PTR [rsp+0x330]
  c1e193:	movdqa xmm2,XMMWORD PTR [rsp+0x340]
  c1e19c:	movaps xmm3,XMMWORD PTR [rsp+0x350]
  c1e1a4:	movdqu XMMWORD PTR [rsp+0x1e8],xmm0
  c1e1ad:	movdqu XMMWORD PTR [rsp+0x1f8],xmm1
  c1e1b6:	movdqu XMMWORD PTR [rsp+0x208],xmm2
  c1e1bf:	movups XMMWORD PTR [rsp+0x218],xmm3
  c1e1c7:	mov    rax,QWORD PTR [rsp+0x360]
  c1e1cf:	mov    QWORD PTR [rsp+0x228],rax
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2982
  c1e1d7:	movzx  ecx,BYTE PTR [rsp+0x118]
  c1e1df:	lea    r8,[rsp+0x1b0]
  c1e1e7:	mov    rdi,QWORD PTR [rsp+0x48]
  c1e1ec:	mov    rsi,QWORD PTR [rsp+0x408]
  c1e1f4:	call   c47880 <_RNvMs1_NtCslyNhMBcJWAz_6bsl_vm9schedulerNtB5_10AsyncState20begin_sync_host_call>
  c1e1f9:	jmp    c1da4a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x370a>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1e1fe:	mov    rax,QWORD PTR [rsp+0x88]
  c1e206:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e20c:	movdqa XMMWORD PTR [rsp+0x280],xmm0
  c1e215:	mov    QWORD PTR [rsp+0x290],rax
  c1e21d:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1e222:	mov    rsi,QWORD PTR [rax+0x10]
  c1e226:	mov    rbx,QWORD PTR [rsp+0x418]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1e22e:	cmp    rbx,rsi
  c1e231:	mov    r15,QWORD PTR [rsp+0x278]
  c1e239:	jae    c1f19a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4e5a>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e23f:	mov    rsi,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1e243:	lea    rdx,[rsi+r15*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1e247:	movzx  ecx,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1e24f:	mov    rax,rcx
  c1e252:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c1e257:	jae    c1e34f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x400f>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e25d:	mov    rax,QWORD PTR [rdx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1e261:	shl    ecx,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1e264:	mov    rax,QWORD PTR [rax+rcx*1]
  c1e268:	jmp    c1e353 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4013>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e26d:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1e272:	mov    BYTE PTR [rcx],0x1f
  c1e275:	lea    rax,[rip+0xffffffffff6a8bc2]        # 2c6e3e <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x17f5>
  c1e27c:	mov    QWORD PTR [rcx+0x8],rax
  c1e280:	mov    QWORD PTR [rcx+0x10],0x57
  c1e288:	lea    rdi,[rsp+0x1b0]
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1e290:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
  c1e295:	jmp    c1d2df <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x2f9f>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e29a:	lea    rdi,[rsp+0x70]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3106
  c1e29f:	mov    rsi,r15
  c1e2a2:	mov    edx,DWORD PTR [rsp+0x278]
  c1e2a9:	call   c4b8e0 <_RNvMs0_NtCslyNhMBcJWAz_6bsl_vm7modulesNtB5_14CatalogContext7program>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultRNtNtCskDxgodD397f_12bsl_bytecode5chunk7ProgramNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1e2ae:	movzx  eax,BYTE PTR [rsp+0x70]
  c1e2b3:	cmp    al,0xff
  c1e2b5:	je     c1e5ca <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x428a>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1e2bb:	mov    ecx,DWORD PTR [rsp+0x71]
  c1e2bf:	mov    edx,DWORD PTR [rsp+0x74]
  c1e2c3:	mov    rsi,QWORD PTR [rsp+0x48]
  c1e2c8:	mov    DWORD PTR [rsi+0x4],edx
  c1e2cb:	mov    DWORD PTR [rsi+0x1],ecx
  c1e2ce:	mov    rcx,QWORD PTR [rsp+0x78]
  c1e2d3:	movups xmm0,XMMWORD PTR [rsp+0x90]
  c1e2db:	movups XMMWORD PTR [rsi+0x20],xmm0
  c1e2df:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c1e2e8:	movdqu XMMWORD PTR [rsi+0x10],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1e2ed:	mov    BYTE PTR [rsi],al
  c1e2ef:	mov    QWORD PTR [rsi+0x8],rcx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e2f3:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3255
  c1e2f8:	mov    QWORD PTR [rsp+0x80],0x3a
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionQNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1337
  c1e304:	movdqu xmm0,XMMWORD PTR [rsp+0x90]
  c1e30d:	mov    rcx,QWORD PTR [rsp+0x48]
  c1e312:	movdqu XMMWORD PTR [rcx+0x20],xmm0
  c1e317:	mov    rax,QWORD PTR [rsp+0x80]
  c1e31f:	mov    QWORD PTR [rcx+0x10],rax
  c1e323:	mov    rax,QWORD PTR [rsp+0x88]
  c1e32b:	mov    QWORD PTR [rcx+0x18],rax
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1e32f:	mov    BYTE PTR [rcx],0x1f
  c1e332:	lea    rax,[rip+0xffffffffff6a9366]        # 2c769f <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x694>
  c1e339:	mov    QWORD PTR [rcx+0x8],rax
  c1e33d:	lea    rdi,[rsp+0x160]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3258
  c1e345:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1e34a:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1e34f:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e353:	mov    rsi,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e35b:	mov    rcx,QWORD PTR [rsi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3010
  c1e35f:	mov    rdx,QWORD PTR [rsp+0x290]
  c1e367:	mov    QWORD PTR [rsp+0x80],rdx
  c1e36f:	movdqa xmm0,XMMWORD PTR [rsp+0x280]
  c1e378:	movdqa XMMWORD PTR [rsp+0x70],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1e37e:	cmp    rax,QWORD PTR [rsi+0x10]
  c1e382:	jae    c1e3e6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x40a6>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1e384:	lea    rax,[rax+rax*2]
  c1e388:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1e38c:	mov    rdi,r14
  c1e38f:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1e394:	mov    rax,QWORD PTR [rsp+0x290]
  c1e39c:	mov    QWORD PTR [r14+0x10],rax
  c1e3a0:	movdqa xmm0,XMMWORD PTR [rsp+0x280]
  c1e3a9:	movdqu XMMWORD PTR [r14],xmm0
  c1e3ae:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1e3b3:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1e3b7:	cmp    rbx,rsi
  c1e3ba:	jae    c1f1c4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4e84>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e3c0:	mov    rax,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3011
  c1e3c4:	inc    QWORD PTR [rax+r15*1+0x58]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1e3c9:	cmp    BYTE PTR [rsp+0x68],0x0
  c1e3ce:	je     c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
  c1e3d4:	lea    rdi,[rsp+0x160]
  c1e3dc:	call   c0a020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCslyNhMBcJWAz_6bsl_vm8CallArgsEBD_>
  c1e3e1:	jmp    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
  c1e3e6:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1e3eb:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e3f0:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1e3f5:	mov    BYTE PTR [rcx],0x1f
  c1e3f8:	lea    rax,[rip+0xffffffffff6a9195]        # 2c7594 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x589>
  c1e3ff:	mov    QWORD PTR [rcx+0x8],rax
  c1e403:	mov    QWORD PTR [rcx+0x10],0x4f
  c1e40b:	jmp    c1da4a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x370a>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1e410:	mov    rax,QWORD PTR [rsp+0x88]
  c1e418:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2743
  c1e41e:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c1e427:	mov    QWORD PTR [rsp+0x130],rax
  c1e42f:	lea    rdi,[rsp+0x1b0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2746
  c1e437:	call   c09620 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECslyNhMBcJWAz_6bsl_vm>
  c1e43c:	jmp    c1d564 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3224>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2987
  c1e441:	mov    eax,DWORD PTR [rsp+0x26c]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCscdodAO9FK5_5alloc6string6StringE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1e448:	cmp    QWORD PTR [rbx+0x40],rax
  c1e44c:	jbe    c1e6a8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4368>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2987
  c1e452:	mov    rcx,QWORD PTR [rbx+0x38]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCscdodAO9FK5_5alloc6string6StringE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1e456:	lea    rax,[rax+rax*2]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e45a:	mov    rdx,QWORD PTR [rcx+rax*8+0x8]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VechE8as_sliceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1e45f:	mov    rcx,QWORD PTR [rcx+rax*8+0x10]
  c1e464:	lea    rax,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2988
  c1e469:	mov    QWORD PTR [rsp],rax
  c1e46d:	lea    rdi,[rsp+0x1b0]
  c1e475:	mov    rsi,rbp
  c1e478:	mov    r8,QWORD PTR [rsp+0x2a8]
  c1e480:	mov    r9,QWORD PTR [rsp+0x270]
  c1e488:	call   QWORD PTR [rip+0x235e8a]        # e54318 <_DYNAMIC+0x5828>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2173
  c1e48e:	movzx  eax,BYTE PTR [rsp+0x1b0]
  c1e496:	cmp    al,0xff
  c1e498:	je     c1e7b6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4476>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1e49e:	movups xmm0,XMMWORD PTR [rsp+0x1b1]
  c1e4a6:	movdqu xmm1,XMMWORD PTR [rsp+0x1c0]
  c1e4af:	movdqu xmm2,XMMWORD PTR [rsp+0x1d0]
  c1e4b8:	movdqu XMMWORD PTR [rsp+0x12f],xmm1
  c1e4c1:	movaps XMMWORD PTR [rsp+0x120],xmm0
  c1e4c9:	mov    rcx,QWORD PTR [rsp+0x48]
  c1e4ce:	movdqu XMMWORD PTR [rcx+0x20],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2988
  c1e4d3:	movups xmm0,XMMWORD PTR [rsp+0x12f]
  c1e4db:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1e4df:	movdqa xmm0,XMMWORD PTR [rsp+0x120]
  c1e4e8:	jmp    c1d9df <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x369f>
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1e4ed:	cmp    BYTE PTR [rsp+0x1b0],0xff
  c1e4f5:	je     c1da6a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x372a>
  c1e4fb:	lea    rdi,[rsp+0x1b0]
  c1e503:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
  c1e508:	jmp    c1da6a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x372a>
_RNvMNtCs4NRVxsYgnAr_4core5sliceSRe5firstCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/mod.rs:156
  c1e50d:	cmp    QWORD PTR [r14+0x18],0x0
  c1e512:	je     c1e78d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x444d>
_RNvMs4_NtCsbxvJACuny95_6bsl_rt9componentNtB5_16MethodDescriptor11check_arity():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:702
  c1e518:	mov    rsi,QWORD PTR [r14+0x10]
_RNvMs1_NtCs4NRVxsYgnAr_4core6optionINtB5_6OptionRReE6copiedCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:2138
  c1e51c:	mov    rdx,QWORD PTR [rsi]
  c1e51f:	mov    rsi,QWORD PTR [rsi+0x8]
  c1e523:	jmp    c1e799 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4459>
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1e528:	add    rax,QWORD PTR [rdx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e52c:	mov    rsi,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e534:	mov    rcx,QWORD PTR [rsi+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3232
  c1e538:	mov    rdx,QWORD PTR [rsp+0x1c0]
  c1e540:	mov    QWORD PTR [rsp+0x80],rdx
  c1e548:	movdqu xmm0,XMMWORD PTR [rsp+0x1b0]
  c1e551:	movdqa XMMWORD PTR [rsp+0x70],xmm0
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1e557:	cmp    rax,QWORD PTR [rsi+0x10]
  c1e55b:	jae    c1e5a9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4269>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1e55d:	lea    rax,[rax+rax*2]
  c1e561:	lea    r14,[rcx+rax*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1e565:	mov    rdi,r14
  c1e568:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1e56d:	mov    rax,QWORD PTR [rsp+0x1c0]
  c1e575:	mov    QWORD PTR [r14+0x10],rax
  c1e579:	movdqu xmm0,XMMWORD PTR [rsp+0x1b0]
  c1e582:	movdqu XMMWORD PTR [r14],xmm0
  c1e587:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE12as_mut_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1903
  c1e58c:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1e590:	cmp    r15,rsi
  c1e593:	jb     c1bec5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b85>
  c1e599:	lea    rdx,[rip+0x2192c0]        # e37860 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xa88>
  c1e5a0:	mov    rdi,r15
  c1e5a3:	call   QWORD PTR [rip+0x23085f]        # e4ee08 <_DYNAMIC+0x318>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e5a9:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1e5ae:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1e5b3:	jmp    c1b5d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1292>
  c1e5b8:	lea    rdi,[rsp+0x1b0]
  c1e5c0:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1e5c5:	jmp    c1b5d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1292>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultRNtNtCskDxgodD397f_12bsl_bytecode5chunk7ProgramNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1e5ca:	mov    rax,QWORD PTR [rsp+0x78]
  c1e5cf:	mov    rcx,QWORD PTR [rsp+0x270]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCskDxgodD397f_12bsl_bytecode5chunk5ChunkE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1e5d7:	cmp    QWORD PTR [rax+0x28],rcx
  c1e5db:	jbe    c1e779 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4439>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCskDxgodD397f_12bsl_bytecode5chunk5ChunkECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e5e1:	mov    rax,QWORD PTR [rax+0x20]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCskDxgodD397f_12bsl_bytecode5chunk5ChunkE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1e5e5:	imul   r14,rcx,0xc8
  c1e5ec:	mov    QWORD PTR [rsp+0x2c0],rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3114
  c1e5f4:	cmp    BYTE PTR [rax+r14*1+0xc1],0x0
  c1e5fd:	je     c1e7cc <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x448c>
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCslyNhMBcJWAz_6bsl_vm():
  c1e603:	call   QWORD PTR [rip+0x2307e7]        # e4edf0 <_DYNAMIC+0x300>
_RNvNtCscdodAO9FK5_5alloc5alloc5alloc():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/alloc.rs:101
  c1e609:	mov    edi,0x68
  c1e60e:	mov    esi,0x1
  c1e613:	call   QWORD PTR [rip+0x2307df]        # e4edf8 <_DYNAMIC+0x308>
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:469
  c1e619:	test   rax,rax
  c1e61c:	je     c1f222 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4ee2>
_RINvNtCs4NRVxsYgnAr_4core3ptr19copy_nonoverlappinghECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:551
  c1e622:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a900a]        # 2c7633 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x628>
  c1e629:	movups XMMWORD PTR [rax+0x50],xmm0
  c1e62d:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a8fef]        # 2c7623 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x618>
  c1e634:	movups XMMWORD PTR [rax+0x40],xmm0
  c1e638:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a8fd4]        # 2c7613 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x608>
  c1e63f:	movups XMMWORD PTR [rax+0x30],xmm0
  c1e643:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a8fb9]        # 2c7603 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x5f8>
  c1e64a:	movups XMMWORD PTR [rax+0x20],xmm0
  c1e64e:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6a8f9e]        # 2c75f3 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x5e8>
  c1e655:	movups XMMWORD PTR [rax+0x10],xmm0
  c1e659:	movdqu xmm0,XMMWORD PTR [rip+0xffffffffff6a8f82]        # 2c75e3 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x5d8>
  c1e661:	movdqu XMMWORD PTR [rax],xmm0
  c1e665:	movabs rcx,0xb0d0bdd0b0d0b6d0
  c1e66f:	mov    QWORD PTR [rax+0x60],rcx
  c1e673:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3115
  c1e678:	mov    BYTE PTR [rcx],0x1e
  c1e67b:	mov    QWORD PTR [rcx+0x8],0x68
  c1e683:	mov    QWORD PTR [rcx+0x10],rax
  c1e687:	mov    QWORD PTR [rcx+0x18],0x68
  c1e68f:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
  c1e694:	mov    rcx,QWORD PTR [rsp+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3091
  c1e699:	mov    BYTE PTR [rcx],0x1f
  c1e69c:	lea    rax,[rip+0xffffffffff6a90a8]        # 2c774b <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x740>
  c1e6a3:	jmp    c1c2b5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1f75>
  c1e6a8:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1e6ad:	mov    BYTE PTR [rcx],0x1f
  c1e6b0:	lea    rax,[rip+0xffffffffff6a8787]        # 2c6e3e <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x17f5>
  c1e6b7:	mov    QWORD PTR [rcx+0x8],rax
  c1e6bb:	mov    QWORD PTR [rcx+0x10],0x57
  c1e6c3:	jmp    c1da4a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x370a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e6c8:	lea    rdi,[rsp+0x120]
  c1e6d0:	lea    r9,[rsp+0x70]
  c1e6d5:	mov    rcx,QWORD PTR [rsp+0x2a8]
  c1e6dd:	mov    r8,QWORD PTR [rsp+0x270]
_RNvMs4_NtCsbxvJACuny95_6bsl_rt9componentNtB5_16MethodDescriptor6invoke():
/home/kan/Документы/develop/open-bsl/crates/bsl-rt/src/component.rs:679
  c1e6e5:	call   rax
_RINvMNtCs4NRVxsYgnAr_4core6resultINtB3_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBM_5error7RtErrorE3mapNtNtBM_9component11CallOutcomeNcNtB1M_5Ready0ECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:835
  c1e6e7:	cmp    BYTE PTR [rsp+0x120],0xff
  c1e6ef:	je     c1e802 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x44c2>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:837
  c1e6f5:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c1e6fe:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c1e707:	movdqu xmm2,XMMWORD PTR [rsp+0x140]
  c1e710:	movdqu XMMWORD PTR [rsp+0x1d8],xmm2
  c1e719:	movdqu XMMWORD PTR [rsp+0x1c8],xmm1
  c1e722:	movdqu XMMWORD PTR [rsp+0x1b8],xmm0
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt9component11CallOutcomeNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2175
  c1e72b:	movdqu xmm0,XMMWORD PTR [rsp+0x1b8]
  c1e734:	movdqu xmm1,XMMWORD PTR [rsp+0x1c8]
  c1e73d:	movdqu xmm2,XMMWORD PTR [rsp+0x1d8]
  c1e746:	movdqa XMMWORD PTR [rsp+0x250],xmm2
  c1e74f:	movdqa XMMWORD PTR [rsp+0x240],xmm1
  c1e758:	movdqa XMMWORD PTR [rsp+0x230],xmm0
  c1e761:	mov    rax,QWORD PTR [rsp+0x48]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2971
  c1e766:	movdqu XMMWORD PTR [rax+0x20],xmm2
  c1e76b:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1e770:	movdqu XMMWORD PTR [rax],xmm0
  c1e774:	jmp    c1da4a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x370a>
  c1e779:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1e77e:	mov    BYTE PTR [rcx],0x1f
  c1e781:	lea    rax,[rip+0xffffffffff6a9016]        # 2c779e <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x793>
  c1e788:	jmp    c1bb31 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x17f1>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e78d:	lea    rdx,[rip+0xffffffffff6a95ef]        # 2c7d83 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0xd78>
  c1e794:	mov    esi,0xa
  c1e799:	mov    rdi,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1e79e:	mov    BYTE PTR [rdi],0x1c
  c1e7a1:	mov    QWORD PTR [rdi+0x8],rdx
  c1e7a5:	mov    QWORD PTR [rdi+0x10],rsi
  c1e7a9:	mov    QWORD PTR [rdi+0x18],rcx
  c1e7ad:	mov    QWORD PTR [rdi+0x20],rax
  c1e7b1:	jmp    c1da4a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x370a>
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1e7b6:	mov    rax,QWORD PTR [rsp+0x1c8]
  c1e7be:	movdqu xmm0,XMMWORD PTR [rsp+0x1b8]
  c1e7c7:	jmp    c1e20c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3ecc>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e7cc:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE3lenBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:3054
  c1e7d1:	mov    rsi,QWORD PTR [rax+0x10]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3119
  c1e7d5:	cmp    rsi,0x3e7
  c1e7dc:	jbe    c1e887 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4547>
  c1e7e2:	mov    rcx,QWORD PTR [rsp+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3120
  c1e7e7:	mov    BYTE PTR [rcx],0x23
  c1e7ea:	lea    rax,[rip+0xffffffffff6a8d24]        # 2c7515 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x50a>
  c1e7f1:	mov    QWORD PTR [rcx+0x8],rax
  c1e7f5:	mov    QWORD PTR [rcx+0x10],0x3f
  c1e7fd:	jmp    c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RINvMNtCs4NRVxsYgnAr_4core6resultINtB3_6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtBM_5error7RtErrorE3mapNtNtBM_9component11CallOutcomeNcNtB1M_5Ready0ECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:836
  c1e802:	mov    rax,QWORD PTR [rsp+0x138]
  c1e80a:	mov    QWORD PTR [rsp+0x1c8],rax
  c1e812:	movups xmm0,XMMWORD PTR [rsp+0x128]
_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultNtNtCsbxvJACuny95_6bsl_rt9component11CallOutcomeNtNtBO_5error7RtErrorENtNtNtB7_3ops9try_trait3Try6branchCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2174
  c1e81a:	movaps XMMWORD PTR [rsp+0x230],xmm0
  c1e822:	movdqu xmm1,XMMWORD PTR [rsp+0x1d8]
  c1e82b:	movdqa XMMWORD PTR [rsp+0x250],xmm1
  c1e834:	movdqu xmm2,XMMWORD PTR [rsp+0x1c8]
  c1e83d:	movdqa XMMWORD PTR [rsp+0x240],xmm2
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2971
  c1e846:	movaps XMMWORD PTR [rsp+0x2f0],xmm0
  c1e84e:	movdqa XMMWORD PTR [rsp+0x310],xmm1
  c1e857:	movdqa XMMWORD PTR [rsp+0x300],xmm2
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2972
  c1e860:	mov    rax,QWORD PTR [rsp+0x300]
  c1e868:	mov    QWORD PTR [rsp+0x290],rax
  c1e870:	movdqa xmm0,XMMWORD PTR [rsp+0x2f0]
  c1e879:	movdqa XMMWORD PTR [rsp+0x280],xmm0
  c1e882:	jmp    c1e21d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3edd>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1e887:	cmp    QWORD PTR [rsp+0x418],rsi
  c1e88f:	jae    c1f232 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4ef2>
_RNvXsd_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameEINtNtNtCs4NRVxsYgnAr_4core3ops5index8IndexMutjE9index_mutBG_():
  c1e895:	mov    rax,QWORD PTR [rsp+0x50]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e89a:	mov    rax,QWORD PTR [rax+0x8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1e89e:	imul   rcx,QWORD PTR [rsp+0x418],0x78
  c1e8a7:	mov    QWORD PTR [rsp+0x2b8],rcx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3124
  c1e8af:	inc    QWORD PTR [rax+rcx*1+0x58]
  c1e8b4:	lea    rdi,[rsp+0x70]
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:434
  c1e8b9:	mov    ecx,0x8
  c1e8be:	mov    r8d,0x10
  c1e8c4:	mov    rsi,r12
  c1e8c7:	xor    edx,edx
  c1e8c9:	call   c45540 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCslyNhMBcJWAz_6bsl_vm>
  c1e8ce:	mov    rdi,QWORD PTR [rsp+0x78]
  c1e8d3:	cmp    BYTE PTR [rsp+0x70],0x0
  c1e8d8:	jne    c1f00f <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4ccf>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e8de:	add    QWORD PTR [rsp+0x2c0],r14
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:435
  c1e8e6:	mov    rax,QWORD PTR [rsp+0x80]
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE16with_capacity_inBG_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:977
  c1e8ee:	mov    QWORD PTR [rsp+0x160],rdi
  c1e8f6:	mov    QWORD PTR [rsp+0x168],rax
  c1e8fe:	mov    QWORD PTR [rsp+0x170],0x0
_RNvMNtCscdodAO9FK5_5alloc3vecINtB2_3VecTjmjEE3newCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:464
  c1e90a:	mov    QWORD PTR [rsp+0x1b0],0x0
  c1e916:	mov    QWORD PTR [rsp+0x1b8],0x8
  c1e922:	mov    QWORD PTR [rsp+0x1c0],0x0
  c1e92e:	xor    ebp,ebp
  c1e930:	lea    rax,[rip+0x218fd1]        # e37908 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xb30>
  c1e937:	mov    QWORD PTR [rsp+0x2b0],rax
  c1e93f:	jmp    c1e96d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x462d>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e941:	mov    rcx,QWORD PTR [rcx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1e945:	shl    eax,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1e948:	mov    r15,QWORD PTR [rcx+rax*1]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e94c:	mov    al,0x1
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE4pushBG_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1004
  c1e94e:	inc    QWORD PTR [rsp+0x118]
  c1e956:	add    rbp,0x4
  c1e95a:	movzx  edx,al
  c1e95d:	lea    rdi,[rsp+0x160]
  c1e965:	mov    rsi,r15
  c1e968:	call   c23c60 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE8push_mutBG_>
_RNvXsd_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeENtNtB9_3cmp9PartialEq2eqCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:1714
  c1e96d:	cmp    QWORD PTR [rsp+0x2a8],rbp
_RNvXs2J_NtNtCs4NRVxsYgnAr_4core5slice4iterINtB6_4IterNtNtCskDxgodD397f_12bsl_bytecode5instr7ArgModeENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/iter/macros.rs:180
  c1e975:	je     c1ecc2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4982>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1e97b:	mov    rdi,rbp
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3128
  c1e97e:	movzx  eax,BYTE PTR [rbx+rbp*1]
  c1e982:	lea    rcx,[rip+0xffffffffff6a8287]        # 2c6c10 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x15c7>
  c1e989:	movsxd rax,DWORD PTR [rcx+rax*4]
  c1e98d:	add    rax,rcx
  c1e990:	mov    rcx,QWORD PTR [rsp+0x418]
  c1e998:	mov    rdx,QWORD PTR [rsp+0x50]
  c1e99d:	jmp    rax
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1e99f:	mov    rsi,QWORD PTR [rdx+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1e9a3:	cmp    rcx,rsi
  c1e9a6:	jae    c1f1ef <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4eaf>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1e9ac:	mov    rdx,QWORD PTR [rdx+0x8]
  c1e9b0:	mov    rsi,QWORD PTR [rsp+0x2b8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1e9b8:	lea    rcx,[rdx+rsi*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1e9bc:	movzx  eax,BYTE PTR [rsp+0x118]
  c1e9c4:	jmp    c1ec5b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x491b>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3159
  c1e9c9:	movzx  eax,WORD PTR [rbx+rdi*1+0x2]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCskDxgodD397f_12bsl_bytecode13configuration9LinkEntryE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1e9ce:	cmp    QWORD PTR [rsp+0x158],rax
  c1e9d6:	mov    rcx,QWORD PTR [rsp+0x68]
  c1e9db:	jbe    c1ed7c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4a3c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3156
  c1e9e1:	cmp    BYTE PTR [rcx+rax*8],0x0
  c1e9e5:	je     c1ed7c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4a3c>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3157
  c1e9eb:	mov    r12d,DWORD PTR [rcx+rax*8+0x4]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE3getB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1e9f0:	mov    rcx,QWORD PTR [rsp+0x3f8]
  c1e9f8:	cmp    QWORD PTR [rcx+0x10],r12
  c1e9fc:	jbe    c1edeb <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4aab>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ea02:	mov    rcx,QWORD PTR [rsp+0x68]
  c1ea07:	movzx  eax,WORD PTR [rcx+rax*8+0x2]
  c1ea0c:	mov    QWORD PTR [rsp+0x2a0],rax
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceEB14_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ea14:	mov    rax,QWORD PTR [rsp+0x3f8]
  c1ea1c:	mov    r15,QWORD PTR [rax+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3168
  c1ea20:	lea    rax,[rip+0xffffffffff6a8c78]        # 2c769f <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x694>
  c1ea27:	mov    QWORD PTR [rsp+0x78],rax
  c1ea2c:	mov    QWORD PTR [rsp+0x80],0x3a
  c1ea38:	mov    BYTE PTR [rsp+0x70],0x1f
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1339
  c1ea3d:	lea    rdi,[rsp+0x70]
  c1ea42:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE3getB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1ea47:	mov    rax,r12
  c1ea4a:	shl    rax,0x5
  c1ea4e:	mov    rcx,QWORD PTR [rsp+0x2a0]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1ea56:	cmp    QWORD PTR [r15+rax*1+0x10],rcx
  c1ea5b:	jbe    c1ee2a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4aea>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ea61:	add    r15,rax
  c1ea64:	mov    rax,QWORD PTR [rsp+0x2a0]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1ea6c:	lea    rsi,[rax+rax*2]
  c1ea70:	shl    esi,0x3
  c1ea73:	add    rsi,QWORD PTR [r15+0x8]
_RNvYNvYNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneINtNtNtBN_3ops8function6FnOnceTRB5_EE9call_onceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ops/function.rs:250
  c1ea77:	lea    rdi,[rsp+0x70]
  c1ea7c:	call   c246a0 <_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1162
  c1ea81:	mov    rax,QWORD PTR [rsp+0x70]
  c1ea86:	mov    rcx,QWORD PTR [rsp+0x80]
  c1ea8e:	mov    QWORD PTR [rsp+0x2c8],rcx
  c1ea96:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3170
  c1ea9c:	mov    QWORD PTR [rsp+0x380],rax
  c1eaa4:	movdqu XMMWORD PTR [rsp+0x388],xmm0
  c1eaad:	mov    rdi,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3lenCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:3054
  c1eab5:	mov    r15,QWORD PTR [rdi+0x10]
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE4pushCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1004
  c1eab9:	lea    rsi,[rsp+0x380]
  c1eac1:	call   c23cc0 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8push_mutCslyNhMBcJWAz_6bsl_vm>
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecTjmjEE8push_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1037
  c1eac6:	mov    r14,QWORD PTR [rsp+0x1c0]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1040
  c1eace:	cmp    r14,QWORD PTR [rsp+0x1b0]
  c1ead6:	jne    c1eae6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x47a6>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1041
  c1ead8:	lea    rdi,[rsp+0x1b0]
  c1eae0:	call   QWORD PTR [rip+0x235872]        # e54358 <_DYNAMIC+0x5868>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullTjmjEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1eae6:	mov    rax,QWORD PTR [rsp+0x1b8]
_RNvMNtNtCs4NRVxsYgnAr_4core3ptr7mut_ptrOTjmjE3addCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mut_ptr.rs:961
  c1eaee:	lea    rcx,[r14+r14*2]
_RINvNtCs4NRVxsYgnAr_4core3ptr5writeTjmjEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:1933
  c1eaf2:	mov    QWORD PTR [rax+rcx*8],r15
  c1eaf6:	mov    DWORD PTR [rax+rcx*8+0x8],r12d
  c1eafb:	mov    rdx,QWORD PTR [rsp+0x2a0]
  c1eb03:	mov    QWORD PTR [rax+rcx*8+0x10],rdx
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecTjmjEE8push_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1046
  c1eb08:	jmp    c1ebed <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x48ad>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3141
  c1eb0d:	movzx  r12d,WORD PTR [rbx+rdi*1+0x2]
  c1eb13:	mov    rax,QWORD PTR [rsp+0x3f0]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3getCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:219
  c1eb1b:	cmp    QWORD PTR [rax+0x10],r12
  c1eb1f:	jbe    c1ed9c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4a5c>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:221
  c1eb25:	lea    rsi,[r12+r12*2]
  c1eb29:	shl    esi,0x3
  c1eb2c:	add    rsi,QWORD PTR [rax+0x8]
_RNvYNvYNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneINtNtNtBN_3ops8function6FnOnceTRB5_EE9call_onceCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ops/function.rs:250
  c1eb30:	lea    rdi,[rsp+0x70]
  c1eb35:	call   c246a0 <_RNvXs4_NtCsbxvJACuny95_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1162
  c1eb3a:	mov    rax,QWORD PTR [rsp+0x70]
  c1eb3f:	mov    rcx,QWORD PTR [rsp+0x80]
  c1eb47:	mov    QWORD PTR [rsp+0x2d0],rcx
  c1eb4f:	movdqu xmm0,XMMWORD PTR [rsp+0x78]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3142
  c1eb55:	mov    QWORD PTR [rsp+0x368],rax
  c1eb5d:	movdqu XMMWORD PTR [rsp+0x370],xmm0
  c1eb66:	mov    rdi,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3lenCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:3054
  c1eb6e:	mov    r15,QWORD PTR [rdi+0x10]
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE4pushCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1004
  c1eb72:	lea    rsi,[rsp+0x368]
  c1eb7a:	call   c23cc0 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8push_mutCslyNhMBcJWAz_6bsl_vm>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1eb7f:	mov    rax,QWORD PTR [rsp+0x50]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1eb84:	mov    rsi,QWORD PTR [rax+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1eb88:	cmp    QWORD PTR [rsp+0x418],rsi
  c1eb90:	jae    c1f1f8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4eb8>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1eb96:	mov    rax,QWORD PTR [rax+0x8]
  c1eb9a:	mov    rcx,QWORD PTR [rsp+0x2b8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3145
  c1eba2:	mov    eax,DWORD PTR [rax+rcx*1+0x70]
  c1eba6:	mov    DWORD PTR [rsp+0x2a0],eax
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecTjmjEE8push_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1037
  c1ebad:	mov    r14,QWORD PTR [rsp+0x1c0]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1040
  c1ebb5:	cmp    r14,QWORD PTR [rsp+0x1b0]
  c1ebbd:	jne    c1ebcd <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x488d>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1041
  c1ebbf:	lea    rdi,[rsp+0x1b0]
  c1ebc7:	call   QWORD PTR [rip+0x23578b]        # e54358 <_DYNAMIC+0x5868>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullTjmjEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ebcd:	mov    rax,QWORD PTR [rsp+0x1b8]
_RNvMNtNtCs4NRVxsYgnAr_4core3ptr7mut_ptrOTjmjE3addCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mut_ptr.rs:961
  c1ebd5:	lea    rcx,[r14+r14*2]
_RINvNtCs4NRVxsYgnAr_4core3ptr5writeTjmjEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:1933
  c1ebd9:	mov    QWORD PTR [rax+rcx*8],r15
  c1ebdd:	mov    edx,DWORD PTR [rsp+0x2a0]
  c1ebe4:	mov    DWORD PTR [rax+rcx*8+0x8],edx
  c1ebe8:	mov    QWORD PTR [rax+rcx*8+0x10],r12
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecTjmjEE8push_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1046
  c1ebed:	inc    r14
  c1ebf0:	mov    QWORD PTR [rsp+0x1c0],r14
  c1ebf8:	jmp    c1e94c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x460c>
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1ebfd:	mov    rsi,QWORD PTR [rdx+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ec01:	cmp    rcx,rsi
  c1ec04:	jae    c1f207 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4ec7>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ec0a:	mov    rdx,QWORD PTR [rdx+0x8]
  c1ec0e:	mov    rsi,QWORD PTR [rsp+0x2b8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ec16:	lea    rcx,[rdx+rsi*1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:163
  c1ec1a:	movzx  eax,BYTE PTR [rsp+0x118]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1ec22:	mov    r15,rax
  c1ec25:	sub    r15,QWORD PTR [rdx+rsi*1+0x30]
  c1ec2a:	jae    c1ec72 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4932>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm9ParamSlotEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ec2c:	mov    rcx,QWORD PTR [rcx+0x28]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm9ParamSlotE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ec30:	shl    eax,0x4
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:165
  c1ec33:	mov    r15,QWORD PTR [rcx+rax*1]
  c1ec37:	jmp    c1ec76 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4936>
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8as_sliceBF_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1864
  c1ec39:	mov    rsi,QWORD PTR [rdx+0x10]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ec3d:	cmp    rcx,rsi
  c1ec40:	jae    c1f1e6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4ea6>
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCslyNhMBcJWAz_6bsl_vm5FrameEB12_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ec46:	mov    rdx,QWORD PTR [rdx+0x8]
  c1ec4a:	mov    rsi,QWORD PTR [rsp+0x2b8]
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ec52:	lea    rcx,[rdx+rsi*1]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3134
  c1ec56:	movzx  eax,BYTE PTR [rbx+rdi*1+0x1]
_RNvMCslyNhMBcJWAz_6bsl_vmNtB2_5Frame9reg_index():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:164
  c1ec5b:	mov    r15,rax
  c1ec5e:	sub    r15,QWORD PTR [rdx+rsi*1+0x30]
  c1ec63:	jb     c1e941 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4601>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:167
  c1ec69:	add    r15,QWORD PTR [rcx+0x60]
  c1ec6d:	jmp    c1e94c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x460c>
  c1ec72:	add    r15,QWORD PTR [rcx+0x60]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ec76:	mov    rcx,QWORD PTR [rsp+0x100]
_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:614
  c1ec7e:	mov    rax,QWORD PTR [rcx+0x8]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3182
  c1ec82:	mov    DWORD PTR [rsp+0x70],0x2
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE7get_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:229
  c1ec8a:	cmp    r15,QWORD PTR [rcx+0x10]
  c1ec8e:	jae    c1edc4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4a84>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:231
  c1ec94:	lea    rcx,[r15+r15*2]
  c1ec98:	lea    r14,[rax+rcx*8]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1ec9c:	mov    rdi,r14
  c1ec9f:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1eca4:	mov    rax,QWORD PTR [rsp+0x80]
  c1ecac:	mov    QWORD PTR [r14+0x10],rax
  c1ecb0:	movdqu xmm0,XMMWORD PTR [rsp+0x70]
  c1ecb6:	movdqu XMMWORD PTR [r14],xmm0
  c1ecbb:	xor    eax,eax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3187
  c1ecbd:	jmp    c1e94e <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x460e>
  c1ecc2:	mov    rdi,QWORD PTR [rsp+0x100]
_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE3lenCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:3054
  c1ecca:	mov    r14,QWORD PTR [rdi+0x10]
  c1ecce:	mov    rsi,QWORD PTR [rsp+0x2c0]
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3193
  c1ecd6:	call   c0d720 <_RNvCslyNhMBcJWAz_6bsl_vm18push_own_registers>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3198
  c1ecdb:	mov    rax,QWORD PTR [rsp+0x170]
  c1ece3:	mov    QWORD PTR [rsp+0xa0],rax
  c1eceb:	movups xmm0,XMMWORD PTR [rsp+0x160]
  c1ecf3:	movups XMMWORD PTR [rsp+0x90],xmm0
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3202
  c1ecfb:	movdqu xmm0,XMMWORD PTR [rsp+0x1b0]
  c1ed04:	movdqu XMMWORD PTR [rsp+0xa8],xmm0
  c1ed0d:	mov    rax,QWORD PTR [rsp+0x1c0]
  c1ed15:	mov    QWORD PTR [rsp+0xb8],rax
  c1ed1d:	mov    eax,DWORD PTR [rsp+0x278]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3194
  c1ed24:	mov    DWORD PTR [rsp+0xe0],eax
  c1ed2b:	mov    rax,QWORD PTR [rsp+0x270]
  c1ed33:	mov    QWORD PTR [rsp+0xc0],rax
  c1ed3b:	mov    QWORD PTR [rsp+0xc8],0x0
  c1ed47:	mov    QWORD PTR [rsp+0xd0],r14
  c1ed4f:	mov    QWORD PTR [rsp+0xd8],r14
  c1ed57:	mov    BYTE PTR [rsp+0xe4],r13b
  c1ed5f:	mov    QWORD PTR [rsp+0x70],0x0
  c1ed68:	lea    rsi,[rsp+0x70]
  c1ed6d:	mov    rdi,QWORD PTR [rsp+0x50]
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE4pushBG_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1004
  c1ed72:	call   c23bc0 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCslyNhMBcJWAz_6bsl_vm5FrameE8push_mutBG_>
  c1ed77:	jmp    c1bece <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x1b8e>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ed7c:	mov    rcx,QWORD PTR [rsp+0x48]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3161
  c1ed81:	mov    BYTE PTR [rcx],0x1f
  c1ed84:	lea    rax,[rip+0xffffffffff6a89c0]        # 2c774b <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x740>
  c1ed8b:	mov    QWORD PTR [rcx+0x8],rax
  c1ed8f:	mov    QWORD PTR [rcx+0x10],0x53
  c1ed97:	jmp    c1ee51 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4b11>
  c1ed9c:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1eda1:	mov    BYTE PTR [rcx],0x1f
  c1eda4:	lea    rax,[rip+0xffffffffff6a7ff5]        # 2c6da0 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1757>
  c1edab:	mov    QWORD PTR [rcx+0x8],rax
  c1edaf:	mov    QWORD PTR [rcx+0x10],0x4f
  c1edb7:	mov    rax,QWORD PTR [rsp+0x2d0]
  c1edbf:	jmp    c1ee4d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4b0d>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1edc4:	lea    rdi,[rsp+0x70]
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1439
  c1edc9:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1edce:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1edd3:	mov    BYTE PTR [rcx],0x1f
  c1edd6:	lea    rax,[rip+0xffffffffff6a87b7]        # 2c7594 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x589>
  c1eddd:	mov    QWORD PTR [rcx+0x8],rax
  c1ede1:	mov    QWORD PTR [rcx+0x10],0x4f
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ede9:	jmp    c1ee51 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4b11>
  c1edeb:	lea    rcx,[rip+0xffffffffff6a88ad]        # 2c769f <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.17.llvm.2195878875420982683+0x694>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3168
  c1edf2:	mov    QWORD PTR [rsp+0x78],rcx
  c1edf7:	mov    QWORD PTR [rsp+0x80],0x3a
  c1ee03:	lea    rax,[rsp+0x80]
_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionRNtNtCslyNhMBcJWAz_6bsl_vm7modules14ModuleInstanceE5ok_orNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEBN_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/option.rs:1337
  c1ee0b:	movdqu xmm0,XMMWORD PTR [rax]
  c1ee0f:	movups xmm1,XMMWORD PTR [rax+0x10]
  c1ee13:	mov    rax,QWORD PTR [rsp+0x48]
  c1ee18:	movups XMMWORD PTR [rax+0x20],xmm1
  c1ee1c:	movdqu XMMWORD PTR [rax+0x10],xmm0
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1ee21:	mov    BYTE PTR [rax],0x1f
  c1ee24:	mov    QWORD PTR [rax+0x8],rcx
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1ee28:	jmp    c1ee51 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4b11>
  c1ee2a:	mov    rcx,QWORD PTR [rsp+0x48]
_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/result.rs:2189
  c1ee2f:	mov    BYTE PTR [rcx],0x1f
  c1ee32:	lea    rax,[rip+0xffffffffff6a7f67]        # 2c6da0 <anon.7da782ee66e3b77fb4a4595b951e57a8.40.llvm.9512178928842507445+0x1757>
  c1ee39:	mov    QWORD PTR [rcx+0x8],rax
  c1ee3d:	mov    QWORD PTR [rcx+0x10],0x4f
  c1ee45:	mov    rax,QWORD PTR [rsp+0x2c8]
  c1ee4d:	mov    QWORD PTR [rcx+0x18],rax
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3205
  c1ee51:	mov    rax,QWORD PTR [rsp+0x1b0]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1ee59:	test   rax,rax
  c1ee5c:	je     c1ee79 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4b39>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3205
  c1ee5e:	mov    rdi,QWORD PTR [rsp+0x1b8]
_RNvMs9_NtCs4NRVxsYgnAr_4core3numj13unchecked_mul():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num/uint_macros.rs:1359
  c1ee66:	shl    rax,0x3
  c1ee6a:	lea    rsi,[rax+rax*2]
_RNvNtCscdodAO9FK5_5alloc5alloc15dealloc_nonnull():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/alloc.rs:128
  c1ee6e:	mov    edx,0x8
  c1ee73:	call   QWORD PTR [rip+0x22feb7]        # e4ed30 <_DYNAMIC+0x240>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3205
  c1ee79:	mov    rsi,QWORD PTR [rsp+0x160]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1ee81:	test   rsi,rsi
  c1ee84:	je     c1dff7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3cb7>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3205
  c1ee8a:	mov    rdi,QWORD PTR [rsp+0x168]
_RNvMs9_NtCs4NRVxsYgnAr_4core3numj13unchecked_mul():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num/uint_macros.rs:1359
  c1ee92:	shl    rsi,0x4
  c1ee96:	jmp    c1dc57 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3917>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1ee9b:	lea    rdx,[rip+0x218b56]        # e379f8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xc20>
  c1eea2:	mov    rdi,QWORD PTR [rsp+0x418]
  c1eeaa:	call   QWORD PTR [rip+0x22ff58]        # e4ee08 <_DYNAMIC+0x318>
  c1eeb0:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1eeb5:	lea    rdx,[rip+0x218af4]        # e379b0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xbd8>
  c1eebc:	mov    rdi,r15
  c1eebf:	call   QWORD PTR [rip+0x22ff43]        # e4ee08 <_DYNAMIC+0x318>
  c1eec5:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1eeca:	lea    rdx,[rip+0x218cff]        # e37bd0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xdf8>
  c1eed1:	call   QWORD PTR [rip+0x22ff31]        # e4ee08 <_DYNAMIC+0x318>
  c1eed7:	lea    rdx,[rip+0x218c0a]        # e37ae8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xd10>
  c1eede:	mov    rdi,r15
  c1eee1:	call   QWORD PTR [rip+0x22ff21]        # e4ee08 <_DYNAMIC+0x318>
  c1eee7:	lea    rdx,[rip+0x218c5a]        # e37b48 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xd70>
  c1eeee:	mov    rdi,r15
  c1eef1:	call   QWORD PTR [rip+0x22ff11]        # e4ee08 <_DYNAMIC+0x318>
  c1eef7:	lea    rdx,[rip+0x218a22]        # e37920 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xb48>
  c1eefe:	mov    rdi,r15
  c1ef01:	call   QWORD PTR [rip+0x22ff01]        # e4ee08 <_DYNAMIC+0x318>
  c1ef07:	lea    rdx,[rip+0x218b02]        # e37a10 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xc38>
  c1ef0e:	call   QWORD PTR [rip+0x22fef4]        # e4ee08 <_DYNAMIC+0x318>
  c1ef14:	lea    rdx,[rip+0x218b25]        # e37a40 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xc68>
  c1ef1b:	mov    rdi,r15
  c1ef1e:	call   QWORD PTR [rip+0x22fee4]        # e4ee08 <_DYNAMIC+0x318>
  c1ef24:	lea    rdx,[rip+0x218d65]        # e37c90 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xeb8>
  c1ef2b:	call   QWORD PTR [rip+0x22fed7]        # e4ee08 <_DYNAMIC+0x318>
  c1ef31:	lea    rdx,[rip+0x218b80]        # e37ab8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xce0>
  c1ef38:	call   QWORD PTR [rip+0x22feca]        # e4ee08 <_DYNAMIC+0x318>
  c1ef3e:	lea    rdx,[rip+0x218b43]        # e37a88 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xcb0>
  c1ef45:	call   QWORD PTR [rip+0x22febd]        # e4ee08 <_DYNAMIC+0x318>
  c1ef4b:	lea    rdx,[rip+0x218d9e]        # e37cf0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xf18>
  c1ef52:	call   QWORD PTR [rip+0x22feb0]        # e4ee08 <_DYNAMIC+0x318>
  c1ef58:	lea    rdx,[rip+0x218c01]        # e37b60 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xd88>
  c1ef5f:	mov    rdi,r15
  c1ef62:	call   QWORD PTR [rip+0x22fea0]        # e4ee08 <_DYNAMIC+0x318>
  c1ef68:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1ef6d:	lea    rdx,[rip+0x2189c4]        # e37938 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xb60>
  c1ef74:	mov    rdi,r15
  c1ef77:	call   QWORD PTR [rip+0x22fe8b]        # e4ee08 <_DYNAMIC+0x318>
  c1ef7d:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1ef82:	lea    rdx,[rip+0x218ba7]        # e37b30 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xd58>
  c1ef89:	call   QWORD PTR [rip+0x22fe79]        # e4ee08 <_DYNAMIC+0x318>
  c1ef8f:	lea    rdx,[rip+0x218d72]        # e37d08 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xf30>
  c1ef96:	mov    rdi,QWORD PTR [rsp+0x418]
  c1ef9e:	call   QWORD PTR [rip+0x22fe64]        # e4ee08 <_DYNAMIC+0x318>
  c1efa4:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1efa9:	lea    rdx,[rip+0x2189d0]        # e37980 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xba8>
  c1efb0:	mov    rdi,r15
  c1efb3:	call   QWORD PTR [rip+0x22fe4f]        # e4ee08 <_DYNAMIC+0x318>
  c1efb9:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1efbe:	lea    rdx,[rip+0x218c6b]        # e37c30 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xe58>
  c1efc5:	call   QWORD PTR [rip+0x22fe3d]        # e4ee08 <_DYNAMIC+0x318>
  c1efcb:	lea    rdx,[rip+0x218cd6]        # e37ca8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xed0>
  c1efd2:	mov    rdi,QWORD PTR [rsp+0x418]
  c1efda:	call   QWORD PTR [rip+0x22fe28]        # e4ee08 <_DYNAMIC+0x318>
  c1efe0:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1efe5:	lea    rdx,[rip+0x2189dc]        # e379c8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xbf0>
  c1efec:	mov    rdi,r15
  c1efef:	call   QWORD PTR [rip+0x22fe13]        # e4ee08 <_DYNAMIC+0x318>
  c1eff5:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1effa:	lea    rdx,[rip+0x218997]        # e37998 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xbc0>
  c1f001:	mov    rdi,r15
  c1f004:	call   QWORD PTR [rip+0x22fdfe]        # e4ee08 <_DYNAMIC+0x318>
  c1f00a:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:442
  c1f00f:	mov    rsi,QWORD PTR [rsp+0x80]
  c1f017:	call   QWORD PTR [rip+0x22fdbb]        # e4edd8 <_DYNAMIC+0x2e8>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1f01d:	lea    rdx,[rip+0x218a34]        # e37a58 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xc80>
  c1f024:	mov    rdi,r15
  c1f027:	call   QWORD PTR [rip+0x22fddb]        # e4ee08 <_DYNAMIC+0x318>
  c1f02d:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f032:	lea    rdx,[rip+0x218ce7]        # e37d20 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xf48>
  c1f039:	mov    rdi,QWORD PTR [rsp+0x418]
  c1f041:	call   QWORD PTR [rip+0x22fdc1]        # e4ee08 <_DYNAMIC+0x318>
  c1f047:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f04c:	lea    rdx,[rip+0x218b95]        # e37be8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xe10>
  c1f053:	mov    rdi,QWORD PTR [rsp+0x418]
  c1f05b:	call   QWORD PTR [rip+0x22fda7]        # e4ee08 <_DYNAMIC+0x318>
  c1f061:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1f066:	lea    rdx,[rip+0x218973]        # e379e0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xc08>
  c1f06d:	mov    rdi,r15
  c1f070:	call   QWORD PTR [rip+0x22fd92]        # e4ee08 <_DYNAMIC+0x318>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1f076:	lea    rdx,[rip+0x218a83]        # e37b00 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xd28>
  c1f07d:	mov    rdi,r15
  c1f080:	call   QWORD PTR [rip+0x22fd82]        # e4ee08 <_DYNAMIC+0x318>
  c1f086:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1f08b:	lea    rdx,[rip+0x2189de]        # e37a70 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xc98>
  c1f092:	mov    rdi,r15
  c1f095:	call   QWORD PTR [rip+0x22fd6d]        # e4ee08 <_DYNAMIC+0x318>
  c1f09b:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1f0a0:	lea    rdx,[rip+0x218c19]        # e37cc0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xee8>
  c1f0a7:	mov    rdi,QWORD PTR [rsp+0x418]
  c1f0af:	call   QWORD PTR [rip+0x22fd53]        # e4ee08 <_DYNAMIC+0x318>
  c1f0b5:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f0ba:	lea    rdx,[rip+0x218b3f]        # e37c00 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xe28>
  c1f0c1:	mov    rdi,QWORD PTR [rsp+0x418]
  c1f0c9:	call   QWORD PTR [rip+0x22fd39]        # e4ee08 <_DYNAMIC+0x318>
  c1f0cf:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1f0d4:	lea    rdx,[rip+0x218a3d]        # e37b18 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xd40>
  c1f0db:	mov    rdi,r15
  c1f0de:	call   QWORD PTR [rip+0x22fd24]        # e4ee08 <_DYNAMIC+0x318>
  c1f0e4:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f0e9:	lea    rdx,[rip+0x218be8]        # e37cd8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xf00>
  c1f0f0:	call   QWORD PTR [rip+0x22fd12]        # e4ee08 <_DYNAMIC+0x318>
  c1f0f6:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1f0fb:	lea    rdx,[rip+0x218a9e]        # e37ba0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xdc8>
  c1f102:	mov    rdi,r15
  c1f105:	call   QWORD PTR [rip+0x22fcfd]        # e4ee08 <_DYNAMIC+0x318>
  c1f10b:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f110:	lea    rdx,[rip+0x218839]        # e37950 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xb78>
  c1f117:	mov    rdi,r15
  c1f11a:	call   QWORD PTR [rip+0x22fce8]        # e4ee08 <_DYNAMIC+0x318>
  c1f120:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1f125:	lea    rdx,[rip+0x218c0c]        # e37d38 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xf60>
  c1f12c:	call   QWORD PTR [rip+0x22fcd6]        # e4ee08 <_DYNAMIC+0x318>
  c1f132:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f137:	lea    rdx,[rip+0x218ada]        # e37c18 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xe40>
  c1f13e:	call   QWORD PTR [rip+0x22fcc4]        # e4ee08 <_DYNAMIC+0x318>
  c1f144:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1f149:	lea    rdx,[rip+0x218af8]        # e37c48 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xe70>
  c1f150:	mov    rdi,QWORD PTR [rsp+0x418]
  c1f158:	call   QWORD PTR [rip+0x22fcaa]        # e4ee08 <_DYNAMIC+0x318>
  c1f15e:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f163:	lea    rdx,[rip+0x21870e]        # e37878 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xaa0>
  c1f16a:	call   QWORD PTR [rip+0x22fc98]        # e4ee08 <_DYNAMIC+0x318>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1f170:	lea    rdx,[rip+0x218a41]        # e37bb8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xde0>
  c1f177:	mov    rdi,r15
  c1f17a:	call   QWORD PTR [rip+0x22fc88]        # e4ee08 <_DYNAMIC+0x318>
  c1f180:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f185:	lea    rdx,[rip+0x2187dc]        # e37968 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xb90>
  c1f18c:	mov    rdi,r15
  c1f18f:	call   QWORD PTR [rip+0x22fc73]        # e4ee08 <_DYNAMIC+0x318>
  c1f195:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1f19a:	lea    rdx,[rip+0x218abf]        # e37c60 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xe88>
  c1f1a1:	mov    rdi,rbx
  c1f1a4:	call   QWORD PTR [rip+0x22fc5e]        # e4ee08 <_DYNAMIC+0x318>
  c1f1aa:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f1af:	lea    rdx,[rip+0x218692]        # e37848 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xa70>
  c1f1b6:	mov    rdi,r15
  c1f1b9:	call   QWORD PTR [rip+0x22fc49]        # e4ee08 <_DYNAMIC+0x318>
  c1f1bf:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1f1c4:	lea    rdx,[rip+0x218aad]        # e37c78 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xea0>
  c1f1cb:	mov    rdi,rbx
  c1f1ce:	call   QWORD PTR [rip+0x22fc34]        # e4ee08 <_DYNAMIC+0x318>
  c1f1d4:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
  c1f1d9:	lea    rdx,[rip+0x2186b0]        # e37890 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xab8>
  c1f1e0:	call   QWORD PTR [rip+0x22fc22]        # e4ee08 <_DYNAMIC+0x318>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f1e6:	lea    rax,[rip+0x2186eb]        # e378d8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xb00>
  c1f1ed:	jmp    c1f1ff <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4ebf>
  c1f1ef:	lea    rax,[rip+0x2186ca]        # e378c0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xae8>
  c1f1f6:	jmp    c1f1ff <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4ebf>
  c1f1f8:	lea    rax,[rip+0x2186f1]        # e378f0 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xb18>
  c1f1ff:	mov    QWORD PTR [rsp+0x2b0],rax
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE5indexB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:272
  c1f207:	mov    rdi,QWORD PTR [rsp+0x418]
  c1f20f:	mov    rdx,QWORD PTR [rsp+0x2b0]
  c1f217:	call   QWORD PTR [rip+0x22fbeb]        # e4ee08 <_DYNAMIC+0x318>
  c1f21d:	jmp    c1dbb3 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x3873>
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:442
  c1f222:	mov    edi,0x1
  c1f227:	mov    esi,0x68
  c1f22c:	call   QWORD PTR [rip+0x22fba6]        # e4edd8 <_DYNAMIC+0x2e8>
_RNvXs0_NtNtCs4NRVxsYgnAr_4core5slice5indexjINtB5_10SliceIndexSNtCslyNhMBcJWAz_6bsl_vm5FrameE9index_mutB10_():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/index.rs:278
  c1f232:	lea    rdx,[rip+0x21866f]        # e378a8 <anon.f49b02d6e2664f9d9c41a1c4c2cb5b23.28.llvm.2195878875420982683+0xad0>
  c1f239:	mov    rdi,QWORD PTR [rsp+0x418]
  c1f241:	call   QWORD PTR [rip+0x22fbc1]        # e4ee08 <_DYNAMIC+0x318>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f247:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f24a:	mov    rax,QWORD PTR [rsp+0x80]
  c1f252:	mov    QWORD PTR [r14+0x10],rax
  c1f256:	movups xmm0,XMMWORD PTR [rsp+0x70]
  c1f25b:	movups XMMWORD PTR [r14],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3205
  c1f25f:	jmp    c1f2d7 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4f97>
  c1f261:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f264:	mov    rax,QWORD PTR [rsp+0x80]
  c1f26c:	mov    QWORD PTR [r14+0x10],rax
  c1f270:	movaps xmm0,XMMWORD PTR [rsp+0x70]
  c1f275:	movups XMMWORD PTR [r14],xmm0
  c1f279:	mov    rdi,rbx
  c1f27c:	call   d9c870 <_Unwind_Resume@plt>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f281:	jmp    c1f511 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x51d1>
  c1f286:	jmp    c1f2d4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4f94>
  c1f288:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f28b:	mov    rax,QWORD PTR [rsp+0x290]
  c1f293:	mov    QWORD PTR [r14+0x10],rax
  c1f297:	movdqa xmm0,XMMWORD PTR [rsp+0x280]
  c1f2a0:	movdqu XMMWORD PTR [r14],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1f2a5:	jmp    c1f5f9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52b9>
  c1f2aa:	mov    rbx,rax
  c1f2ad:	lea    rdi,[rsp+0x160]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3258
  c1f2b5:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f2ba:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f2bf:	mov    rbx,rax
  c1f2c2:	lea    rdi,[rsp+0x1b0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3234
  c1f2ca:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f2cf:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f2d4:	mov    rbx,rax
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3205
  c1f2d7:	mov    rax,QWORD PTR [rsp+0x1b0]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1f2df:	test   rax,rax
  c1f2e2:	je     c1f2ff <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x4fbf>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3205
  c1f2e4:	mov    rdi,QWORD PTR [rsp+0x1b8]
_RNvMs9_NtCs4NRVxsYgnAr_4core3numj13unchecked_mul():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num/uint_macros.rs:1359
  c1f2ec:	shl    rax,0x3
  c1f2f0:	lea    rsi,[rax+rax*2]
_RNvNtCscdodAO9FK5_5alloc5alloc15dealloc_nonnull():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/alloc.rs:128
  c1f2f4:	mov    edx,0x8
  c1f2f9:	call   QWORD PTR [rip+0x22fa31]        # e4ed30 <_DYNAMIC+0x240>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3205
  c1f2ff:	mov    rsi,QWORD PTR [rsp+0x160]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1f307:	test   rsi,rsi
  c1f30a:	je     c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3205
  c1f310:	mov    rdi,QWORD PTR [rsp+0x168]
_RNvMs9_NtCs4NRVxsYgnAr_4core3numj13unchecked_mul():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num/uint_macros.rs:1359
  c1f318:	shl    rsi,0x4
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f31c:	mov    edx,0x8
  c1f321:	call   QWORD PTR [rip+0x22fa09]        # e4ed30 <_DYNAMIC+0x240>
  c1f327:	mov    rdi,rbx
  c1f32a:	call   d9c870 <_Unwind_Resume@plt>
  c1f32f:	mov    rbx,rax
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultuNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorEECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/mod.rs:825
  c1f332:	cmp    BYTE PTR [rsp+0x1b0],0xff
  c1f33a:	je     c1f6bd <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x537d>
  c1f340:	lea    rdi,[rsp+0x1b0]
  c1f348:	call   c0a540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5error7RtErrorECslyNhMBcJWAz_6bsl_vm.llvm.2195878875420982683>
  c1f34d:	jmp    c1f6bd <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x537d>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f352:	jmp    c1f5f6 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52b6>
  c1f357:	mov    rbx,rax
  c1f35a:	lea    rdi,[rsp+0x280]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1f362:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f367:	jmp    c1f5f9 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52b9>
  c1f36c:	mov    rbx,rax
  c1f36f:	lea    rdi,[rsp+0x1b0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2746
  c1f377:	call   c09620 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCsbxvJACuny95_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECslyNhMBcJWAz_6bsl_vm>
  c1f37c:	jmp    c1f6a8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5368>
  c1f381:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f384:	mov    rax,QWORD PTR [rsp+0x240]
  c1f38c:	mov    QWORD PTR [r14+0x10],rax
  c1f390:	movdqa xmm0,XMMWORD PTR [rsp+0x230]
  c1f399:	movdqu XMMWORD PTR [r14],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2891
  c1f39e:	jmp    c1f6d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5392>
  c1f3a3:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f3a6:	mov    rax,QWORD PTR [rsp+0x290]
  c1f3ae:	mov    QWORD PTR [r14+0x10],rax
  c1f3b2:	movdqa xmm0,XMMWORD PTR [rsp+0x280]
  c1f3bb:	movdqu XMMWORD PTR [r14],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2866
  c1f3c0:	jmp    c1f6e4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x53a4>
  c1f3c5:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f3c8:	mov    rax,QWORD PTR [rsp+0x170]
  c1f3d0:	mov    QWORD PTR [r14+0x10],rax
  c1f3d4:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1f3dd:	movdqu XMMWORD PTR [r14],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3050
  c1f3e2:	jmp    c1f619 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52d9>
  c1f3e7:	mov    rbx,rax
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2793
  c1f3ea:	test   bpl,bpl
  c1f3ed:	jne    c1f581 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5241>
  c1f3f3:	jmp    c1f6bd <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x537d>
  c1f3f8:	jmp    c1f6cf <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x538f>
  c1f3fd:	jmp    c1f6e1 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x53a1>
  c1f402:	mov    rbx,rax
  c1f405:	lea    rdi,[rsp+0x230]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2891
  c1f40d:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f412:	jmp    c1f6d2 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5392>
  c1f417:	mov    rbx,rax
  c1f41a:	lea    rdi,[rsp+0x280]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2866
  c1f422:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f427:	jmp    c1f6e4 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x53a4>
  c1f42c:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f42f:	mov    rax,QWORD PTR [rsp+0x130]
  c1f437:	mov    QWORD PTR [r14+0x10],rax
  c1f43b:	movdqa xmm0,XMMWORD PTR [rsp+0x120]
  c1f444:	movdqu XMMWORD PTR [r14],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2751
  c1f449:	jmp    c1f6a8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5368>
  c1f44e:	jmp    c1f452 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5112>
  c1f450:	jmp    c1f452 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5112>
  c1f452:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f455:	mov    rax,QWORD PTR [rsp+0x80]
  c1f45d:	mov    QWORD PTR [r14+0x10],rax
  c1f461:	movups xmm0,XMMWORD PTR [rsp+0x70]
  c1f466:	movups XMMWORD PTR [r14],xmm0
  c1f46a:	mov    rdi,rbx
  c1f46d:	call   d9c870 <_Unwind_Resume@plt>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f472:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f475:	mov    rax,QWORD PTR [rsp+0x170]
  c1f47d:	mov    QWORD PTR [r14+0x10],rax
  c1f481:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1f48a:	movdqu XMMWORD PTR [r14],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2701
  c1f48f:	jmp    c1f5b8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5278>
  c1f494:	jmp    c1f6ba <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x537a>
  c1f499:	jmp    c1f616 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52d6>
  c1f49e:	mov    rbx,rax
  c1f4a1:	lea    rdi,[rsp+0x160]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3050
  c1f4a9:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f4ae:	jmp    c1f619 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52d9>
  c1f4b3:	mov    rbx,rax
  c1f4b6:	jmp    c1f639 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52f9>
  c1f4bb:	jmp    c1f6a5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5365>
  c1f4c0:	mov    rbx,rax
  c1f4c3:	lea    rdi,[rsp+0x120]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2751
  c1f4cb:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f4d0:	jmp    c1f6a8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5368>
  c1f4d5:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f4d8:	mov    rax,QWORD PTR [rsp+0x170]
  c1f4e0:	mov    QWORD PTR [r14+0x10],rax
  c1f4e4:	movdqa xmm0,XMMWORD PTR [rsp+0x160]
  c1f4ed:	movdqu XMMWORD PTR [r14],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2683
  c1f4f2:	jmp    c1f693 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5353>
  c1f4f7:	jmp    c1f5b5 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5275>
  c1f4fc:	mov    rbx,rax
  c1f4ff:	lea    rdi,[rsp+0x160]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2701
  c1f507:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f50c:	jmp    c1f5b8 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5278>
  c1f511:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f514:	mov    rax,QWORD PTR [rsp+0x1c0]
  c1f51c:	mov    QWORD PTR [r14+0x10],rax
  c1f520:	movups xmm0,XMMWORD PTR [rsp+0x1b0]
  c1f528:	movups XMMWORD PTR [r14],xmm0
  c1f52c:	mov    rdi,rbx
  c1f52f:	call   d9c870 <_Unwind_Resume@plt>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f534:	mov    rbx,rax
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1f537:	mov    rax,QWORD PTR [rsp+0x70]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1f53c:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt6string13BslStringDataENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1f53f:	jne    c1f639 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52f9>
  c1f545:	lea    rdi,[rsp+0x70]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1f54a:	call   QWORD PTR [rip+0x22f7f0]        # e4ed40 <_DYNAMIC+0x250>
  c1f550:	jmp    c1f639 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52f9>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f555:	jmp    c1f690 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5350>
  c1f55a:	mov    rbx,rax
  c1f55d:	lea    rdi,[rsp+0x70]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2785
  c1f562:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f567:	jmp    c1f581 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5241>
  c1f569:	mov    rbx,rax
  c1f56c:	lea    rdi,[rsp+0x160]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2683
  c1f574:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f579:	jmp    c1f693 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5353>
  c1f57e:	mov    rbx,rax
  c1f581:	lea    rdi,[rsp+0x120]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2793
  c1f589:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f58e:	jmp    c1f6bd <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x537d>
  c1f593:	mov    rbx,rax
_RNvCslyNhMBcJWAz_6bsl_vm9reg_store():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:1432
  c1f596:	mov    rax,QWORD PTR [rsp+0x170]
  c1f59e:	mov    QWORD PTR [r14+0x10],rax
  c1f5a2:	movdqu xmm0,XMMWORD PTR [rsp+0x160]
  c1f5ab:	movdqu XMMWORD PTR [r14],xmm0
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2650
  c1f5b0:	jmp    c1f74d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x540d>
  c1f5b5:	mov    rbx,rax
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_EE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1f5b8:	mov    rax,QWORD PTR [rsp+0x230]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1f5c0:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcDNtNtCsbxvJACuny95_6bsl_rt3env10FileSystemEL_ENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1f5c3:	jne    c1f65c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x531c>
  c1f5c9:	lea    rdi,[rsp+0x230]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1f5d1:	call   QWORD PTR [rip+0x22f7d1]        # e4eda8 <_DYNAMIC+0x2b8>
  c1f5d7:	jmp    c1f65c <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x531c>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f5dc:	jmp    c1f70b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x53cb>
  c1f5e1:	mov    rbx,rax
  c1f5e4:	lea    rdi,[rsp+0x1b0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2671
  c1f5ec:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f5f1:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f5f6:	mov    rbx,rax
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3012
  c1f5f9:	cmp    BYTE PTR [rsp+0x68],0x0
  c1f5fe:	je     c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f604:	lea    rdi,[rsp+0x160]
  c1f60c:	call   c0a020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCslyNhMBcJWAz_6bsl_vm8CallArgsEBD_>
  c1f611:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f616:	mov    rbx,rax
_RNvXs1_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVechENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:424
  c1f619:	mov    rsi,QWORD PTR [rsp+0x120]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1f621:	test   rsi,rsi
  c1f624:	je     c1f639 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x52f9>
_RNvXs1_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVechENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:424
  c1f626:	mov    rdi,QWORD PTR [rsp+0x128]
_RNvNtCscdodAO9FK5_5alloc5alloc15dealloc_nonnull():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/alloc.rs:128
  c1f62e:	mov    edx,0x1
  c1f633:	call   QWORD PTR [rip+0x22f6f7]        # e4ed30 <_DYNAMIC+0x240>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:3050
  c1f639:	cmp    DWORD PTR [rsp+0x230],0x6
  c1f641:	je     c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f647:	lea    rdi,[rsp+0x230]
  c1f64f:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f654:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f659:	mov    rbx,rax
  c1f65c:	lea    rdi,[rsp+0x120]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2701
  c1f664:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f669:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f66e:	mov    rbx,rax
  c1f671:	jmp    c1f720 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x53e0>
  c1f676:	jmp    c1f70b <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x53cb>
  c1f67b:	mov    rbx,rax
  c1f67e:	lea    rdi,[rsp+0x160]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2650
  c1f686:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f68b:	jmp    c1f74d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x540d>
  c1f690:	mov    rbx,rax
  c1f693:	lea    rdi,[rsp+0x120]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2683
  c1f69b:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f6a0:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f6a5:	mov    rbx,rax
  c1f6a8:	lea    rdi,[rsp+0x230]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2751
  c1f6b0:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f6b5:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f6ba:	mov    rbx,rax
  c1f6bd:	lea    rdi,[rsp+0x230]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2793
  c1f6c5:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f6ca:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f6cf:	mov    rbx,rax
  c1f6d2:	lea    rdi,[rsp+0x1b0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2891
  c1f6da:	call   c0a020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCslyNhMBcJWAz_6bsl_vm8CallArgsEBD_>
  c1f6df:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f6e1:	mov    rbx,rax
  c1f6e4:	lea    rdi,[rsp+0x1b0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2866
  c1f6ec:	call   c0a020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCslyNhMBcJWAz_6bsl_vm8CallArgsEBD_>
  c1f6f1:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f6f3:	mov    rbx,rax
  c1f6f6:	lea    rdi,[rsp+0x2d8]
_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueE8push_mutCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1050
  c1f6fe:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
  c1f703:	jmp    c1f713 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x53d3>
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/vec/mod.rs:1035
  c1f705:	call   QWORD PTR [rip+0x22f645]        # e4ed50 <_DYNAMIC+0x260>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f70b:	mov    rbx,rax
  c1f70e:	jmp    c1f74d <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x540d>
  c1f710:	mov    rbx,rax
  c1f713:	lea    rdi,[rsp+0x160]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2671
  c1f71b:	call   c09ca0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsbxvJACuny95_6bsl_rt5value8BslValueEECslyNhMBcJWAz_6bsl_vm>
_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeEE6as_refCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr/non_null.rs:441
  c1f720:	mov    rax,QWORD PTR [rsp+0x120]
_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem/mod.rs:931
  c1f728:	dec    QWORD PTR [rax]
_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcNtNtCsbxvJACuny95_6bsl_rt5shape5ShapeENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2493
  c1f72b:	jne    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
  c1f72d:	lea    rdi,[rsp+0x120]
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/rc.rs:2494
  c1f735:	call   QWORD PTR [rip+0x22f625]        # e4ed60 <_DYNAMIC+0x270>
  c1f73b:	jmp    c1f75a <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x541a>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f73d:	mov    rbx,rax
  c1f740:	lea    rdi,[rsp+0x1b0]
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2645
  c1f748:	call   c0a840 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsbxvJACuny95_6bsl_rt5value8BslValueECslyNhMBcJWAz_6bsl_vm>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2650
  c1f74d:	mov    rsi,QWORD PTR [rsp+0x120]
_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslyNhMBcJWAz_6bsl_vm():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec/mod.rs:634
  c1f755:	test   rsi,rsi
  c1f758:	jne    c1f762 <_RNvCslyNhMBcJWAz_6bsl_vm9step_cold+0x5422>
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f75a:	mov    rdi,rbx
  c1f75d:	call   d9c870 <_Unwind_Resume@plt>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2650
  c1f762:	mov    rdi,QWORD PTR [rsp+0x128]
_RNvMs9_NtCs4NRVxsYgnAr_4core3numj13unchecked_mul():
/home/kan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num/uint_macros.rs:1359
  c1f76a:	shl    rsi,0x3
_RNvCslyNhMBcJWAz_6bsl_vm9step_cold():
  c1f76e:	mov    edx,0x8
  c1f773:	call   QWORD PTR [rip+0x22f5b7]        # e4ed30 <_DYNAMIC+0x240>
  c1f779:	mov    rdi,rbx
  c1f77c:	call   d9c870 <_Unwind_Resume@plt>
/home/kan/Документы/develop/open-bsl/crates/bsl-vm/src/lib.rs:2621
  c1f781:	call   QWORD PTR [rip+0x22f5c9]        # e4ed50 <_DYNAMIC+0x260>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
