#!/usr/bin/env bash
set -euo pipefail
root='/home/kan/Документы/develop/open-bsl'
output='/tmp/open-bsl-spill-profile.mNUyGG'
for scenario in bmp_rotate str_find pi_leibniz call_overhead; do
    destination="$output/$scenario/profile-v2"
    mkdir "$destination"
    cat /proc/loadavg > "$destination/load.txt"
    perf record -q -e cycles:u -e instructions:u -c 1000003 -o "$destination/perf.data" -- bash "$output/repeat.sh" "$root/target/release/bsl-cli" "$root/benchmarks/$scenario.bsl" "$destination" 2> "$destination/record.log"
    perf report -i "$destination/perf.data" --stdio --no-children --percent-limit 0.5 --sort dso,symbol -t ';' > "$destination/report.txt" 2> "$destination/report.log"
    perf script -D -i "$destination/perf.data" > "$destination/events.txt" 2> "$destination/events.log"
    if rg 'PERF_RECORD_(THROTTLE|UNTHROTTLE|LOST)' "$destination/events.txt"; then
        echo "$scenario sampling FAIL"
        exit 1
    fi
    echo "$scenario profile-v2 PASS, no throttle/loss"
done
