#!/usr/bin/env bash
set -euo pipefail
root='/home/kan/Документы/develop/open-bsl'
output='/tmp/open-bsl-spill-profile.mNUyGG'
binary="$root/target/release/bsl-cli"
cd "$output"
git -C "$root" rev-parse HEAD > commit.txt
sha256sum "$binary" > binary.sha256
rustc -Vv > rustc.txt
lscpu > cpu.txt
cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor > governors.txt
cat /sys/devices/system/cpu/intel_pstate/no_turbo > no-turbo.txt
cat /sys/class/power_supply/AC/online > ac-online.txt
for scenario in bmp_rotate str_find pi_leibniz call_overhead; do
    mkdir "$output/$scenario"
    script="$root/benchmarks/$scenario.bsl"
    "$binary" "$script" > "$output/$scenario/warmup.stdout"
    for run in 1 2 3 4 5 6 7; do
        cat /proc/loadavg >> "$output/$scenario/load.txt"
        perf stat -x ';' -e instructions:u,cycles:u -o "$output/$scenario/stat-$run.txt" -- "$binary" "$script" > "$output/$scenario/stat-$run.stdout"
    done
    echo "$scenario counters PASS"
    perf record -q -e cycles:u -e instructions:u -c 100003 -o "$output/$scenario/perf.data" -- bash "$output/repeat.sh" "$binary" "$script" "$output/$scenario" 2> "$output/$scenario/record.log"
    perf report -i "$output/$scenario/perf.data" --stdio --no-children --percent-limit 0.5 --sort dso,symbol -t ';' > "$output/$scenario/report.txt" 2> "$output/$scenario/report.log"
    perf script -i "$output/$scenario/perf.data" -F event,period,ip,sym,symoff,dso > "$output/$scenario/samples.txt" 2> "$output/$scenario/script.log"
    echo "$scenario profile PASS"
done
