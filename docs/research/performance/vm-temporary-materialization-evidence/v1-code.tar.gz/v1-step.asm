
/home/kan/Документы/develop/open-bsl-materialization.UpSJarfM/v1-target/release/bsl-cli:     file format elf64-x86-64


Disassembly of section .text:

0000000000c0f920 <_RNvCsbxgXiyEKxkX_6bsl_vm4step>:
  c0f920:	push   rbp
  c0f921:	push   r15
  c0f923:	push   r14
  c0f925:	push   r13
  c0f927:	push   r12
  c0f929:	push   rbx
  c0f92a:	sub    rsp,0x5e8
  c0f931:	mov    rbx,QWORD PTR [rsi+0x10]
  c0f935:	mov    r11,rbx
  c0f938:	sub    r11,0x1
  c0f93c:	jb     c198d0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fb0>
  c0f942:	lea    r15,[rsi+0x8]
  c0f946:	mov    rax,QWORD PTR [r15]
  c0f949:	imul   r10,r11,0x78
  c0f94d:	mov    r14,QWORD PTR [rax+r10*1+0x50]
  c0f952:	mov    r12,QWORD PTR [rcx+0x28]
  c0f956:	cmp    r14,r12
  c0f959:	jae    c0f9f6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xd6>
  c0f95f:	mov    QWORD PTR [rsp+0x10],r15
  c0f964:	mov    rbp,QWORD PTR [rsp+0x620]
  c0f96c:	mov    QWORD PTR [rsp+0x28],r10
  c0f971:	mov    r15,QWORD PTR [rax+r10*1+0x58]
  c0f976:	mov    r13,QWORD PTR [rcx+0x20]
  c0f97a:	imul   r10,r14,0xc8
  c0f981:	mov    rax,QWORD PTR [r13+r10*1+0x10]
  c0f986:	mov    QWORD PTR [rsp+0x1f0],rax
  c0f98e:	cmp    r15,rax
  c0f991:	jae    c0fa11 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xf1>
  c0f993:	add    r10,r13
  c0f996:	mov    rax,QWORD PTR [r10+0xb0]
  c0f99d:	mov    rbp,r10
  c0f9a0:	mov    r10,r15
  c0f9a3:	mov    QWORD PTR [rsp+0x1e8],rbp
  c0f9ab:	mov    r15,QWORD PTR [rbp+0xb8]
  c0f9b2:	mov    QWORD PTR [rsp+0x578],r15
  c0f9ba:	cmp    r10,r15
  c0f9bd:	mov    r15,r10
  c0f9c0:	mov    QWORD PTR [rsp+0x18],rdi
  c0f9c5:	mov    QWORD PTR [rsp+0x38],rdx
  c0f9ca:	mov    QWORD PTR [rsp+0x1c8],r9
  c0f9d2:	mov    QWORD PTR [rsp+0x3c0],r12
  c0f9da:	mov    QWORD PTR [rsp+0x560],rax
  c0f9e2:	jae    c0fabf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19f>
  c0f9e8:	movzx  eax,BYTE PTR [rax+r15*1]
  c0f9ed:	cmp    al,0x1
  c0f9ef:	adc    al,0xff
  c0f9f1:	jmp    c0fac1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a1>
  c0f9f6:	mov    BYTE PTR [rdi],0x1f
  c0f9f9:	lea    rax,[rip+0xffffffffff6b6893]        # 2c6293 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x18d2>
  c0fa00:	mov    QWORD PTR [rdi+0x8],rax
  c0fa04:	mov    QWORD PTR [rdi+0x10],0x3a
  c0fa0c:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c0fa11:	mov    rbx,rdi
  c0fa14:	mov    DWORD PTR [rsp+0x80],0x2
  c0fa1f:	mov    r8,QWORD PTR [rbp+0x0]
  c0fa23:	mov    rcx,r9
  c0fa26:	mov    r9,QWORD PTR [rbp+0x10]
  c0fa2a:	sub    rsp,0x8
  c0fa2e:	lea    rax,[rsp+0x88]
  c0fa36:	lea    rdi,[rsp+0x128]
  c0fa3e:	push   rax
  c0fa3f:	call   c0dae0 <_RNvCsbxgXiyEKxkX_6bsl_vm20do_return_with_value>
  c0fa44:	add    rsp,0x10
  c0fa48:	movzx  eax,BYTE PTR [rsp+0x120]
  c0fa50:	cmp    al,0xff
  c0fa52:	je     c1738b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a6b>
  c0fa58:	mov    ecx,DWORD PTR [rsp+0x121]
  c0fa5f:	mov    edx,DWORD PTR [rsp+0x124]
  c0fa66:	mov    DWORD PTR [rbx+0x4],edx
  c0fa69:	mov    DWORD PTR [rbx+0x1],ecx
  c0fa6c:	mov    ecx,DWORD PTR [rsp+0x128]
  c0fa73:	movups xmm0,XMMWORD PTR [rsp+0x12c]
  c0fa7b:	movaps XMMWORD PTR [rsp+0x3d0],xmm0
  c0fa83:	mov    edx,DWORD PTR [rsp+0x13c]
  c0fa8a:	mov    DWORD PTR [rsp+0x3e0],edx
  c0fa91:	movups xmm0,XMMWORD PTR [rsp+0x140]
  c0fa99:	movups XMMWORD PTR [rbx+0x20],xmm0
  c0fa9d:	mov    edx,DWORD PTR [rsp+0x3e0]
  c0faa4:	mov    DWORD PTR [rbx+0x1c],edx
  c0faa7:	movdqa xmm0,XMMWORD PTR [rsp+0x3d0]
  c0fab0:	movdqu XMMWORD PTR [rbx+0xc],xmm0
  c0fab5:	mov    BYTE PTR [rbx],al
  c0fab7:	mov    DWORD PTR [rbx+0x8],ecx
  c0faba:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c0fabf:	xor    eax,eax
  c0fac1:	mov    r9,QWORD PTR [rsp+0x620]
  c0fac9:	mov    DWORD PTR [rsp+0x30],eax
  c0facd:	mov    QWORD PTR [rsp+0x3b8],r13
  c0fad5:	mov    QWORD PTR [rsp+0x580],rbx
  c0fadd:	mov    QWORD PTR [rsp+0x8],r11
  c0fae2:	mov    rax,QWORD PTR [rsp+0x658]
  c0faea:	mov    QWORD PTR [rsp+0x4f0],rax
  c0faf2:	mov    QWORD PTR [rsp+0x20],rsi
  c0faf7:	lea    rax,[rsi+0x10]
  c0fafb:	mov    QWORD PTR [rsp+0xf8],rax
  c0fb03:	mov    rax,QWORD PTR [rsp+0x638]
  c0fb0b:	lea    rdx,[rax+0x100]
  c0fb12:	lea    rsi,[rax+0x110]
  c0fb19:	mov    QWORD PTR [rsp+0x3c8],r14
  c0fb21:	lea    rdi,[r14+r14*2]
  c0fb25:	shl    rdi,0x3
  c0fb29:	add    rdi,QWORD PTR [r8+0x8]
  c0fb2d:	mov    QWORD PTR [rsp+0x1b0],rdi
  c0fb35:	mov    QWORD PTR [rsp+0x3a8],rsi
  c0fb3d:	movq   xmm0,rsi
  c0fb42:	mov    QWORD PTR [rsp+0x3b0],rdx
  c0fb4a:	movq   xmm1,rdx
  c0fb4f:	punpcklqdq xmm1,xmm0
  c0fb53:	movdqa XMMWORD PTR [rsp+0x530],xmm1
  c0fb5c:	lea    rdx,[rax+0x58]
  c0fb60:	mov    QWORD PTR [rsp+0x3a0],rdx
  c0fb68:	lea    rdx,[rax+0x48]
  c0fb6c:	mov    QWORD PTR [rsp+0x398],rdx
  c0fb74:	lea    rdx,[rax+0x68]
  c0fb78:	mov    QWORD PTR [rsp+0x390],rdx
  c0fb80:	lea    rdx,[rax+0xf0]
  c0fb87:	mov    QWORD PTR [rsp+0x388],rdx
  c0fb8f:	lea    rdx,[rax+0x118]
  c0fb96:	mov    QWORD PTR [rsp+0x380],rdx
  c0fb9e:	mov    rdx,QWORD PTR [rcx+0x38]
  c0fba2:	mov    QWORD PTR [rsp+0x4d0],rdx
  c0fbaa:	mov    rdx,QWORD PTR [rcx+0x40]
  c0fbae:	mov    QWORD PTR [rsp+0x4d8],rdx
  c0fbb6:	mov    QWORD PTR [rsp+0x570],r8
  c0fbbe:	mov    rdx,QWORD PTR [r8+0x10]
  c0fbc2:	mov    QWORD PTR [rsp+0x4e0],rdx
  c0fbca:	lea    rax,[rax+0xb8]
  c0fbd1:	mov    QWORD PTR [rsp+0x4c8],rax
  c0fbd9:	mov    rax,QWORD PTR [r9]
  c0fbdc:	mov    QWORD PTR [rsp+0x4f8],rax
  c0fbe4:	mov    rax,QWORD PTR [r9+0x8]
  c0fbe8:	mov    QWORD PTR [rsp+0x568],rax
  c0fbf0:	mov    QWORD PTR [rsp+0x1c0],rcx
  c0fbf8:	mov    rax,QWORD PTR [rcx+0x88]
  c0fbff:	mov    QWORD PTR [rsp+0x4e8],rax
  c0fc07:	mov    QWORD PTR [rsp+0x2b0],rax
  c0fc0f:	mov    r10,QWORD PTR [rsp+0x1e8]
  c0fc17:	jmp    c0fc4c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x32c>
  c0fc19:	mov    rcx,QWORD PTR [rsp+0x560]
  c0fc21:	movzx  r12d,BYTE PTR [rcx+rax*1]
  c0fc26:	cmp    r12b,0x1
  c0fc2a:	adc    r12b,0xff
  c0fc2e:	mov    r15,rax
  c0fc31:	mov    r10,QWORD PTR [rsp+0x1e8]
  c0fc39:	mov    DWORD PTR [rsp+0x30],r12d
  c0fc3e:	cmp    r15,QWORD PTR [rsp+0x1f0]
  c0fc46:	jae    c198a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f88>
  c0fc4c:	mov    rcx,QWORD PTR [r10+0x8]
  c0fc50:	movzx  edx,BYTE PTR [rcx+r15*8]
  c0fc55:	movzx  r13d,BYTE PTR [rcx+r15*8+0x1]
  c0fc5b:	movzx  r12d,r13b
  c0fc5f:	movzx  r14d,WORD PTR [rcx+r15*8+0x2]
  c0fc65:	mov    eax,r14d
  c0fc68:	shr    eax,0x8
  c0fc6b:	mov    ebx,DWORD PTR [rcx+r15*8+0x4]
  c0fc70:	lea    rsi,[rip+0xffffffffff6b5a95]        # 2c570c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xd4b>
  c0fc77:	movsxd rdx,DWORD PTR [rsi+rdx*4]
  c0fc7b:	add    rdx,rsi
  c0fc7e:	jmp    rdx
  c0fc80:	mov    rsi,QWORD PTR [rcx+r15*8]
  c0fc84:	lea    rdi,[rsp+0x120]
  c0fc8c:	mov    rbx,QWORD PTR [rsp+0x20]
  c0fc91:	mov    rdx,rbx
  c0fc94:	mov    rcx,QWORD PTR [rsp+0x38]
  c0fc99:	mov    r8,QWORD PTR [rsp+0x1c0]
  c0fca1:	mov    r9,QWORD PTR [rsp+0x570]
  c0fca9:	push   r10
  c0fcab:	push   QWORD PTR [rsp+0x3d0]
  c0fcb2:	mov    r14,QWORD PTR [rsp+0x18]
  c0fcb7:	push   r14
  c0fcb9:	push   QWORD PTR [rsp+0x508]
  c0fcc0:	push   QWORD PTR [rsp+0x670]
  c0fcc7:	push   QWORD PTR [rsp+0x590]
  c0fcce:	push   QWORD PTR [rsp+0x528]
  c0fcd5:	push   QWORD PTR [rsp+0x200]
  c0fcdc:	push   QWORD PTR [rsp+0x670]
  c0fce3:	push   QWORD PTR [rsp+0x688]
  c0fcea:	push   QWORD PTR [rsp+0x688]
  c0fcf1:	push   QWORD PTR [rsp+0x680]
  c0fcf8:	call   c1ad40 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold>
  c0fcfd:	add    rsp,0x60
  c0fd01:	cmp    BYTE PTR [rsp+0x120],0xff
  c0fd09:	mov    r12d,DWORD PTR [rsp+0x30]
  c0fd0e:	jne    c196f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dd4>
  c0fd14:	add    rbx,0x10
  c0fd18:	mov    r13,QWORD PTR [rsp+0x28]
  c0fd1d:	mov    rbp,QWORD PTR [rsp+0x10]
  c0fd22:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c0fd27:	mov    rax,QWORD PTR [rsp+0x20]
  c0fd2c:	add    rax,0x10
  c0fd30:	mov    rsi,QWORD PTR [rax]
  c0fd33:	cmp    QWORD PTR [rsp+0x8],rsi
  c0fd38:	jae    c199b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa096>
  c0fd3e:	mov    rbp,QWORD PTR [rsp+0x10]
  c0fd43:	mov    rsi,QWORD PTR [rbp+0x0]
  c0fd47:	mov    r13,QWORD PTR [rsp+0x28]
  c0fd4c:	lea    rdx,[rsi+r13*1]
  c0fd50:	movzx  ecx,r14b
  c0fd54:	mov    rax,rcx
  c0fd57:	sub    rax,QWORD PTR [rsi+r13*1+0x30]
  c0fd5c:	jae    c10acf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x11af>
  c0fd62:	mov    rax,QWORD PTR [rdx+0x28]
  c0fd66:	shl    ecx,0x4
  c0fd69:	mov    rax,QWORD PTR [rax+rcx*1]
  c0fd6d:	jmp    c10ad3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x11b3>
  c0fd72:	mov    rax,QWORD PTR [rsp+0x20]
  c0fd77:	lea    rbx,[rax+0x10]
  c0fd7b:	mov    rsi,QWORD PTR [rbx]
  c0fd7e:	cmp    QWORD PTR [rsp+0x8],rsi
  c0fd83:	mov    r12d,DWORD PTR [rsp+0x30]
  c0fd88:	jae    c1994a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa02a>
  c0fd8e:	mov    rbp,QWORD PTR [rsp+0x10]
  c0fd93:	mov    rax,QWORD PTR [rbp+0x0]
  c0fd97:	movsx  rcx,r14w
  c0fd9b:	mov    r13,QWORD PTR [rsp+0x28]
  c0fda0:	mov    QWORD PTR [rax+r13*1+0x58],rcx
  c0fda5:	mov    r14,QWORD PTR [rsp+0x8]
  c0fdaa:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c0fdaf:	mov    eax,ebx
  c0fdb1:	shr    eax,0x10
  c0fdb4:	cmp    QWORD PTR [r10+0x40],rax
  c0fdb8:	jbe    c175f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7cd3>
  c0fdbe:	movzx  r12d,bx
  c0fdc2:	mov    rcx,QWORD PTR [rsp+0x3c0]
  c0fdca:	cmp    rcx,r12
  c0fdcd:	jbe    c178b3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f93>
  c0fdd3:	lea    rbx,[rax+rax*2]
  c0fdd7:	shl    ebx,0x3
  c0fdda:	imul   rax,r12,0xc8
  c0fde1:	mov    rcx,QWORD PTR [rsp+0x3b8]
  c0fde9:	lea    rdx,[rcx+rax*1]
  c0fded:	mov    QWORD PTR [rsp+0x1f8],rdx
  c0fdf5:	add    rbx,QWORD PTR [r10+0x38]
  c0fdf9:	cmp    BYTE PTR [rcx+rax*1+0xc1],0x0
  c0fe01:	mov    QWORD PTR [rsp+0x4c0],r12
  c0fe09:	jne    c17be9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x82c9>
  c0fe0f:	mov    rax,QWORD PTR [rsp+0x20]
  c0fe14:	add    rax,0x10
  c0fe18:	mov    rsi,QWORD PTR [rax]
  c0fe1b:	cmp    rsi,0x3e7
  c0fe22:	mov    rdi,QWORD PTR [rsp+0x38]
  c0fe27:	ja     c181f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88d4>
  c0fe2d:	cmp    QWORD PTR [rsp+0x8],rsi
  c0fe32:	jae    c19dbb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa49b>
  c0fe38:	mov    rax,QWORD PTR [rsp+0x10]
  c0fe3d:	mov    rax,QWORD PTR [rax]
  c0fe40:	mov    rcx,QWORD PTR [rsp+0x28]
  c0fe45:	inc    QWORD PTR [rax+rcx*1+0x58]
  c0fe4a:	mov    rcx,QWORD PTR [rbx+0x10]
  c0fe4e:	mov    r12,rcx
  c0fe51:	shl    r12,0x4
  c0fe55:	movabs rax,0xfffffffffffffff
  c0fe5f:	mov    rbp,rcx
  c0fe62:	cmp    rcx,rax
  c0fe65:	seta   al
  c0fe68:	movabs rcx,0x7ffffffffffffff8
  c0fe72:	cmp    r12,rcx
  c0fe75:	seta   cl
  c0fe78:	or     cl,al
  c0fe7a:	jne    c173f1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ad1>
  c0fe80:	test   r12,r12
  c0fe83:	mov    QWORD PTR [rsp+0x1b8],r15
  c0fe8b:	je     c11b1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21fe>
  c0fe91:	call   QWORD PTR [rip+0x23dab1]        # e4d948 <_DYNAMIC+0x300>
  c0fe97:	mov    r15d,0x8
  c0fe9d:	mov    esi,0x8
  c0fea2:	mov    rdi,r12
  c0fea5:	call   QWORD PTR [rip+0x23daa5]        # e4d950 <_DYNAMIC+0x308>
  c0feab:	test   rax,rax
  c0feae:	je     c173fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7adc>
  c0feb4:	mov    rcx,rbp
  c0feb7:	mov    r12,QWORD PTR [rsp+0x20]
  c0febc:	mov    r15,QWORD PTR [rsp+0x1b8]
  c0fec4:	mov    rdi,QWORD PTR [rsp+0x38]
  c0fec9:	jmp    c11b2a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x220a>
  c0fece:	mov    rcx,QWORD PTR [rsp+0x20]
  c0fed3:	add    rcx,0x10
  c0fed7:	mov    rsi,QWORD PTR [rcx]
  c0feda:	cmp    QWORD PTR [rsp+0x8],rsi
  c0fedf:	jae    c19992 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa072>
  c0fee5:	mov    r10,QWORD PTR [rsp+0x10]
  c0feea:	mov    rdi,QWORD PTR [r10]
  c0feed:	mov    r9,QWORD PTR [rsp+0x28]
  c0fef2:	lea    rsi,[rdi+r9*1]
  c0fef6:	movzx  edx,r14b
  c0fefa:	mov    rcx,rdx
  c0fefd:	sub    rcx,QWORD PTR [rdi+r9*1+0x30]
  c0ff02:	jae    c10b2d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x120d>
  c0ff08:	mov    rcx,QWORD PTR [rsi+0x28]
  c0ff0c:	shl    edx,0x4
  c0ff0f:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c0ff13:	jmp    c10b31 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1211>
  c0ff18:	mov    rcx,QWORD PTR [rsp+0x10]
  c0ff1d:	mov    rsi,QWORD PTR [rcx]
  c0ff20:	mov    rcx,QWORD PTR [rsp+0x20]
  c0ff25:	lea    rbp,[rcx+0x10]
  c0ff29:	mov    rdx,QWORD PTR [rbp+0x0]
  c0ff2d:	mov    rdi,QWORD PTR [rsp+0x38]
  c0ff32:	mov    rcx,QWORD PTR [rdi+0x8]
  c0ff36:	mov    r8,QWORD PTR [rdi+0x10]
  c0ff3a:	sub    rsp,0x8
  c0ff3e:	movzx  eax,al
  c0ff41:	movzx  r10d,r14b
  c0ff45:	lea    rdi,[rsp+0x128]
  c0ff4d:	mov    r14,QWORD PTR [rsp+0x10]
  c0ff52:	mov    r9,r14
  c0ff55:	push   rax
  c0ff56:	push   r10
  c0ff58:	push   r12
  c0ff5a:	call   c1a9e0 <_RNvCsbxgXiyEKxkX_6bsl_vm6add_op>
  c0ff5f:	add    rsp,0x20
  c0ff63:	cmp    BYTE PTR [rsp+0x120],0xff
  c0ff6b:	jne    c196f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dd4>
  c0ff71:	mov    rsi,QWORD PTR [rbp+0x0]
  c0ff75:	cmp    r14,rsi
  c0ff78:	jb     c1092a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x100a>
  c0ff7e:	jmp    c19b26 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa206>
  c0ff83:	mov    rax,QWORD PTR [rsp+0x20]
  c0ff88:	add    rax,0x10
  c0ff8c:	mov    rsi,QWORD PTR [rax]
  c0ff8f:	cmp    QWORD PTR [rsp+0x8],rsi
  c0ff94:	jae    c19a0b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0eb>
  c0ff9a:	mov    rax,QWORD PTR [rsp+0x10]
  c0ff9f:	mov    rcx,QWORD PTR [rax]
  c0ffa2:	mov    r13,QWORD PTR [rsp+0x28]
  c0ffa7:	lea    rax,[rcx+r13*1]
  c0ffab:	cmp    QWORD PTR [rcx+r13*1+0x30],r12
  c0ffb0:	jbe    c0ffc6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a6>
  c0ffb2:	mov    rcx,QWORD PTR [rax+0x28]
  c0ffb6:	shl    r12d,0x4
  c0ffba:	cmp    BYTE PTR [rcx+r12*1+0x8],0x0
  c0ffc0:	je     c11a1c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20fc>
  c0ffc6:	movsx  rcx,r14w
  c0ffca:	mov    QWORD PTR [rax+0x58],rcx
  c0ffce:	jmp    c11a20 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2100>
  c0ffd3:	mov    rcx,QWORD PTR [rsp+0x10]
  c0ffd8:	mov    rsi,QWORD PTR [rcx]
  c0ffdb:	mov    rcx,QWORD PTR [rsp+0x20]
  c0ffe0:	lea    rbp,[rcx+0x10]
  c0ffe4:	mov    rdx,QWORD PTR [rbp+0x0]
  c0ffe8:	mov    rdi,QWORD PTR [rsp+0x38]
  c0ffed:	mov    rcx,QWORD PTR [rdi+0x8]
  c0fff1:	mov    r8,QWORD PTR [rdi+0x10]
  c0fff5:	sub    rsp,0x8
  c0fff9:	movzx  eax,al
  c0fffc:	movzx  r10d,r14b
  c10000:	lea    rdi,[rsp+0x128]
  c10008:	mov    r14,QWORD PTR [rsp+0x10]
  c1000d:	mov    r9,r14
  c10010:	push   rax
  c10011:	push   r10
  c10013:	push   r12
  c10015:	call   c082a0 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3remEB2_>
  c1001a:	add    rsp,0x20
  c1001e:	cmp    BYTE PTR [rsp+0x120],0xff
  c10026:	jne    c196f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dd4>
  c1002c:	mov    rsi,QWORD PTR [rbp+0x0]
  c10030:	cmp    r14,rsi
  c10033:	jb     c1092a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x100a>
  c10039:	jmp    c19bfb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2db>
  c1003e:	mov    rcx,QWORD PTR [rsp+0x20]
  c10043:	add    rcx,0x10
  c10047:	mov    rsi,QWORD PTR [rcx]
  c1004a:	cmp    QWORD PTR [rsp+0x8],rsi
  c1004f:	jae    c19a2f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa10f>
  c10055:	mov    rcx,QWORD PTR [rsp+0x38]
  c1005a:	mov    rsi,QWORD PTR [rcx+0x8]
  c1005e:	mov    rdx,QWORD PTR [rcx+0x10]
  c10062:	mov    rbp,QWORD PTR [rsp+0x10]
  c10067:	mov    rcx,QWORD PTR [rbp+0x0]
  c1006b:	mov    r13,QWORD PTR [rsp+0x28]
  c10070:	add    rcx,r13
  c10073:	movzx  r8d,r14b
  c10077:	movzx  r9d,al
  c1007b:	lea    rdi,[rsp+0x120]
  c10083:	call   c24680 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs4load>
  c10088:	mov    eax,DWORD PTR [rsp+0x120]
  c1008f:	cmp    eax,0xffffffff
  c10092:	je     c177a3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e83>
  c10098:	lea    rsi,[rsp+0x124]
  c100a0:	mov    ecx,DWORD PTR [rsi+0x30]
  c100a3:	mov    DWORD PTR [rsp+0x70],ecx
  c100a7:	movups xmm0,XMMWORD PTR [rsi]
  c100aa:	movups xmm1,XMMWORD PTR [rsi+0x10]
  c100ae:	movups xmm2,XMMWORD PTR [rsi+0x20]
  c100b2:	movaps XMMWORD PTR [rsp+0x60],xmm2
  c100b7:	movaps XMMWORD PTR [rsp+0x50],xmm1
  c100bc:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c100c1:	mov    rcx,QWORD PTR [rsi+0x44]
  c100c5:	lea    rdx,[rsp+0x84]
  c100cd:	mov    QWORD PTR [rdx+0x44],rcx
  c100d1:	movups xmm0,XMMWORD PTR [rsi+0x34]
  c100d5:	movups XMMWORD PTR [rdx+0x34],xmm0
  c100d9:	mov    ecx,DWORD PTR [rsp+0x70]
  c100dd:	mov    DWORD PTR [rdx+0x30],ecx
  c100e0:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c100e6:	movdqa xmm1,XMMWORD PTR [rsp+0x50]
  c100ec:	movaps xmm2,XMMWORD PTR [rsp+0x60]
  c100f1:	movups XMMWORD PTR [rdx+0x20],xmm2
  c100f5:	movdqu XMMWORD PTR [rdx+0x10],xmm1
  c100fa:	movdqu XMMWORD PTR [rdx],xmm0
  c100fe:	mov    DWORD PTR [rsp+0x80],eax
  c10105:	cmp    bl,0x2c
  c10108:	jne    c11534 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1c14>
  c1010e:	xor    esi,esi
  c10110:	mov    rax,QWORD PTR [rsp+0x628]
  c10118:	cmp    DWORD PTR [rax],0xffffffff
  c1011b:	cmovne rsi,rax
  c1011f:	lea    rdi,[rsp+0x120]
  c10127:	call   c0d980 <_RNvCsbxgXiyEKxkX_6bsl_vm18current_error_info>
  c1012c:	mov    r14,QWORD PTR [rsp+0x8]
  c10131:	jmp    c1157b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1c5b>
  c10136:	mov    rcx,QWORD PTR [rsp+0x10]
  c1013b:	mov    rsi,QWORD PTR [rcx]
  c1013e:	mov    rcx,QWORD PTR [rsp+0x20]
  c10143:	lea    rbp,[rcx+0x10]
  c10147:	mov    rdx,QWORD PTR [rbp+0x0]
  c1014b:	mov    rdi,QWORD PTR [rsp+0x38]
  c10150:	mov    rcx,QWORD PTR [rdi+0x8]
  c10154:	mov    r8,QWORD PTR [rdi+0x10]
  c10158:	sub    rsp,0x8
  c1015c:	movzx  eax,al
  c1015f:	movzx  r10d,r14b
  c10163:	lea    rdi,[rsp+0x128]
  c1016b:	mov    r14,QWORD PTR [rsp+0x10]
  c10170:	mov    r9,r14
  c10173:	push   rax
  c10174:	push   r10
  c10176:	push   r12
  c10178:	call   c06f20 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3divEB2_>
  c1017d:	add    rsp,0x20
  c10181:	cmp    BYTE PTR [rsp+0x120],0xff
  c10189:	jne    c196f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dd4>
  c1018f:	mov    rsi,QWORD PTR [rbp+0x0]
  c10193:	cmp    r14,rsi
  c10196:	jb     c1092a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x100a>
  c1019c:	jmp    c19beb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2cb>
  c101a1:	mov    rcx,QWORD PTR [rsp+0x20]
  c101a6:	add    rcx,0x10
  c101aa:	mov    rsi,QWORD PTR [rcx]
  c101ad:	cmp    QWORD PTR [rsp+0x8],rsi
  c101b2:	jae    c19abf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa19f>
  c101b8:	mov    rcx,QWORD PTR [rsp+0x10]
  c101bd:	mov    rbx,QWORD PTR [rcx]
  c101c0:	movzx  edx,r14b
  c101c4:	mov    rcx,QWORD PTR [rsp+0x28]
  c101c9:	mov    rbp,QWORD PTR [rbx+rcx*1+0x30]
  c101ce:	add    rbx,rcx
  c101d1:	mov    rcx,rdx
  c101d4:	sub    rcx,rbp
  c101d7:	jae    c10b85 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1265>
  c101dd:	mov    rcx,QWORD PTR [rbx+0x28]
  c101e1:	shl    edx,0x4
  c101e4:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c101e8:	jmp    c10b89 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1269>
  c101ed:	mov    rcx,QWORD PTR [rsp+0x20]
  c101f2:	add    rcx,0x10
  c101f6:	mov    rsi,QWORD PTR [rcx]
  c101f9:	cmp    QWORD PTR [rsp+0x8],rsi
  c101fe:	jae    c19a65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa145>
  c10204:	mov    rcx,QWORD PTR [rsp+0x10]
  c10209:	mov    rbx,QWORD PTR [rcx]
  c1020c:	movzx  edx,r14b
  c10210:	mov    rcx,QWORD PTR [rsp+0x28]
  c10215:	mov    rbp,QWORD PTR [rbx+rcx*1+0x30]
  c1021a:	add    rbx,rcx
  c1021d:	mov    rcx,rdx
  c10220:	sub    rcx,rbp
  c10223:	jae    c10c04 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12e4>
  c10229:	mov    rcx,QWORD PTR [rbx+0x28]
  c1022d:	shl    edx,0x4
  c10230:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c10234:	jmp    c10c08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12e8>
  c10239:	mov    rcx,QWORD PTR [rsp+0x20]
  c1023e:	add    rcx,0x10
  c10242:	mov    rsi,QWORD PTR [rcx]
  c10245:	cmp    QWORD PTR [rsp+0x8],rsi
  c1024a:	jae    c1996e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa04e>
  c10250:	mov    rcx,QWORD PTR [rsp+0x10]
  c10255:	mov    rbx,QWORD PTR [rcx]
  c10258:	movzx  edx,r14b
  c1025c:	mov    rcx,QWORD PTR [rsp+0x28]
  c10261:	mov    rbp,QWORD PTR [rbx+rcx*1+0x30]
  c10266:	add    rbx,rcx
  c10269:	mov    rcx,rdx
  c1026c:	sub    rcx,rbp
  c1026f:	jae    c10c83 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1363>
  c10275:	mov    rcx,QWORD PTR [rbx+0x28]
  c10279:	shl    edx,0x4
  c1027c:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c10280:	jmp    c10c87 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1367>
  c10285:	mov    rcx,QWORD PTR [rsp+0x20]
  c1028a:	add    rcx,0x10
  c1028e:	mov    rsi,QWORD PTR [rcx]
  c10291:	cmp    QWORD PTR [rsp+0x8],rsi
  c10296:	jae    c19938 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa018>
  c1029c:	mov    rcx,QWORD PTR [rsp+0x10]
  c102a1:	mov    rsi,QWORD PTR [rcx]
  c102a4:	mov    r13,QWORD PTR [rsp+0x28]
  c102a9:	lea    rdx,[rsi+r13*1]
  c102ad:	mov    rcx,r12
  c102b0:	sub    rcx,QWORD PTR [rsi+r13*1+0x30]
  c102b5:	jae    c10d02 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13e2>
  c102bb:	mov    rcx,QWORD PTR [rdx+0x28]
  c102bf:	shl    r12d,0x4
  c102c3:	mov    rcx,QWORD PTR [rcx+r12*1]
  c102c7:	jmp    c10d06 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13e6>
  c102cc:	mov    rax,QWORD PTR [rsp+0x20]
  c102d1:	add    rax,0x10
  c102d5:	mov    rsi,QWORD PTR [rax]
  c102d8:	cmp    QWORD PTR [rsp+0x8],rsi
  c102dd:	jae    c19af0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1d0>
  c102e3:	mov    rax,QWORD PTR [rsp+0x10]
  c102e8:	mov    rdx,QWORD PTR [rax]
  c102eb:	mov    r13,QWORD PTR [rsp+0x28]
  c102f0:	lea    rcx,[rdx+r13*1]
  c102f4:	mov    rax,r12
  c102f7:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c102fc:	jae    c10d68 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1448>
  c10302:	mov    rax,QWORD PTR [rcx+0x28]
  c10306:	shl    r12d,0x4
  c1030a:	mov    rax,QWORD PTR [rax+r12*1]
  c1030e:	jmp    c10d6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x144c>
  c10313:	mov    rcx,QWORD PTR [rsp+0x10]
  c10318:	mov    rsi,QWORD PTR [rcx]
  c1031b:	mov    rcx,QWORD PTR [rsp+0x20]
  c10320:	lea    rbp,[rcx+0x10]
  c10324:	mov    rdx,QWORD PTR [rbp+0x0]
  c10328:	mov    rdi,QWORD PTR [rsp+0x38]
  c1032d:	mov    rcx,QWORD PTR [rdi+0x8]
  c10331:	mov    r8,QWORD PTR [rdi+0x10]
  c10335:	sub    rsp,0x8
  c10339:	movzx  eax,al
  c1033c:	movzx  r10d,r14b
  c10340:	lea    rdi,[rsp+0x128]
  c10348:	mov    r14,QWORD PTR [rsp+0x10]
  c1034d:	mov    r9,r14
  c10350:	push   rax
  c10351:	push   r10
  c10353:	push   r12
  c10355:	call   c08c60 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3subEB2_>
  c1035a:	add    rsp,0x20
  c1035e:	cmp    BYTE PTR [rsp+0x120],0xff
  c10366:	jne    c196f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dd4>
  c1036c:	mov    rsi,QWORD PTR [rbp+0x0]
  c10370:	cmp    r14,rsi
  c10373:	jb     c1092a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x100a>
  c10379:	jmp    c19bcb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2ab>
  c1037e:	cmp    QWORD PTR [r10+0x28],r14
  c10382:	jbe    c17613 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7cf3>
  c10388:	mov    rcx,QWORD PTR [r10+0x20]
  c1038c:	lea    rdx,[r14+r14*2]
  c10390:	mov    eax,DWORD PTR [rcx+rdx*8]
  c10393:	mov    esi,eax
  c10395:	sub    esi,0x2
  c10398:	mov    edi,0x3
  c1039d:	cmovae edi,esi
  c103a0:	lea    rcx,[rcx+rdx*8]
  c103a4:	lea    rdx,[rip+0xffffffffff6b5929]        # 2c5cd4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1313>
  c103ab:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c103af:	add    rsi,rdx
  c103b2:	jmp    rsi
  c103b4:	mov    rax,QWORD PTR [rcx+0x10]
  c103b8:	mov    QWORD PTR [rsp+0x90],rax
  c103c0:	movdqu xmm0,XMMWORD PTR [rcx]
  c103c4:	movdqa XMMWORD PTR [rsp+0x80],xmm0
  c103cd:	mov    rdi,QWORD PTR [rsp+0x8]
  c103d2:	mov    r13,QWORD PTR [rsp+0x28]
  c103d7:	mov    r8,QWORD PTR [rsp+0x10]
  c103dc:	mov    rax,QWORD PTR [rsp+0x20]
  c103e1:	add    rax,0x10
  c103e5:	mov    rsi,QWORD PTR [rax]
  c103e8:	cmp    rdi,rsi
  c103eb:	jae    c19c32 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa312>
  c103f1:	mov    rdx,QWORD PTR [r8]
  c103f4:	lea    rcx,[rdx+r13*1]
  c103f8:	mov    rax,r12
  c103fb:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c10400:	jae    c117f1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ed1>
  c10406:	mov    rax,QWORD PTR [rcx+0x28]
  c1040a:	shl    r12d,0x4
  c1040e:	mov    rax,QWORD PTR [rax+r12*1]
  c10412:	jmp    c117f5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ed5>
  c10417:	mov    rax,QWORD PTR [rsp+0x20]
  c1041c:	add    rax,0x10
  c10420:	mov    rsi,QWORD PTR [rax]
  c10423:	mov    rdi,QWORD PTR [rsp+0x8]
  c10428:	cmp    rdi,rsi
  c1042b:	jae    c19ad1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1b1>
  c10431:	mov    rax,QWORD PTR [rsp+0x10]
  c10436:	mov    rdx,QWORD PTR [rax]
  c10439:	mov    r13,QWORD PTR [rsp+0x28]
  c1043e:	lea    rcx,[rdx+r13*1]
  c10442:	mov    rax,r12
  c10445:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c1044a:	jae    c10e08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14e8>
  c10450:	mov    rax,QWORD PTR [rcx+0x28]
  c10454:	shl    r12d,0x4
  c10458:	mov    rax,QWORD PTR [rax+r12*1]
  c1045c:	jmp    c10e0c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14ec>
  c10461:	cmp    QWORD PTR [rsp+0x4e8],r14
  c10469:	jbe    c17452 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b32>
  c1046f:	mov    rax,QWORD PTR [rsp+0x20]
  c10474:	add    rax,0x10
  c10478:	mov    rsi,QWORD PTR [rax]
  c1047b:	cmp    QWORD PTR [rsp+0x8],rsi
  c10480:	jae    c19b14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1f4>
  c10486:	mov    rax,QWORD PTR [rsp+0x10]
  c1048b:	mov    rdx,QWORD PTR [rax]
  c1048e:	mov    r13,QWORD PTR [rsp+0x28]
  c10493:	lea    rcx,[rdx+r13*1]
  c10497:	mov    rax,r12
  c1049a:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c1049f:	jae    c115fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1cdc>
  c104a5:	mov    rax,QWORD PTR [rcx+0x28]
  c104a9:	shl    r12d,0x4
  c104ad:	mov    rax,QWORD PTR [rax+r12*1]
  c104b1:	jmp    c11600 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ce0>
  c104b6:	mov    rcx,QWORD PTR [rsp+0x20]
  c104bb:	add    rcx,0x10
  c104bf:	mov    rsi,QWORD PTR [rcx]
  c104c2:	cmp    QWORD PTR [rsp+0x8],rsi
  c104c7:	jae    c19980 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa060>
  c104cd:	mov    rcx,QWORD PTR [rsp+0x10]
  c104d2:	mov    rbx,QWORD PTR [rcx]
  c104d5:	movzx  edx,r14b
  c104d9:	mov    rcx,QWORD PTR [rsp+0x28]
  c104de:	mov    r9,QWORD PTR [rbx+rcx*1+0x30]
  c104e3:	add    rbx,rcx
  c104e6:	mov    rcx,rdx
  c104e9:	sub    rcx,r9
  c104ec:	jae    c10e9c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x157c>
  c104f2:	mov    rcx,QWORD PTR [rbx+0x28]
  c104f6:	shl    edx,0x4
  c104f9:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c104fd:	jmp    c10ea0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1580>
  c10502:	mov    rax,QWORD PTR [rsp+0x20]
  c10507:	add    rax,0x10
  c1050b:	mov    rsi,QWORD PTR [rax]
  c1050e:	mov    rdi,QWORD PTR [rsp+0x8]
  c10513:	cmp    rdi,rsi
  c10516:	jae    c199ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0cc>
  c1051c:	mov    rax,QWORD PTR [rsp+0x10]
  c10521:	mov    rdx,QWORD PTR [rax]
  c10524:	mov    r13,QWORD PTR [rsp+0x28]
  c10529:	lea    rcx,[rdx+r13*1]
  c1052d:	mov    rax,r12
  c10530:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c10535:	jae    c10f10 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15f0>
  c1053b:	mov    rax,QWORD PTR [rcx+0x28]
  c1053f:	shl    r12d,0x4
  c10543:	mov    rax,QWORD PTR [rax+r12*1]
  c10547:	jmp    c10f14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15f4>
  c1054c:	mov    rax,QWORD PTR [rsp+0x20]
  c10551:	add    rax,0x10
  c10555:	mov    rsi,QWORD PTR [rax]
  c10558:	cmp    QWORD PTR [rsp+0x8],rsi
  c1055d:	jae    c19ade <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1be>
  c10563:	mov    rax,QWORD PTR [rsp+0x10]
  c10568:	mov    rdx,QWORD PTR [rax]
  c1056b:	mov    r13,QWORD PTR [rsp+0x28]
  c10570:	lea    rcx,[rdx+r13*1]
  c10574:	mov    rax,r12
  c10577:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c1057c:	jae    c10fa4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1684>
  c10582:	mov    rax,QWORD PTR [rcx+0x28]
  c10586:	shl    r12d,0x4
  c1058a:	mov    rax,QWORD PTR [rax+r12*1]
  c1058e:	jmp    c10fa8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1688>
  c10593:	mov    rax,QWORD PTR [rsp+0x20]
  c10598:	add    rax,0x10
  c1059c:	mov    rsi,QWORD PTR [rax]
  c1059f:	cmp    QWORD PTR [rsp+0x8],rsi
  c105a4:	jae    c1995c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa03c>
  c105aa:	mov    rax,QWORD PTR [rsp+0x10]
  c105af:	mov    rax,QWORD PTR [rax]
  c105b2:	movzx  ecx,r14b
  c105b6:	mov    r13,QWORD PTR [rsp+0x28]
  c105bb:	mov    rdx,QWORD PTR [rax+r13*1+0x30]
  c105c0:	add    rax,r13
  c105c3:	mov    rdi,rcx
  c105c6:	sub    rdi,rdx
  c105c9:	jae    c11003 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16e3>
  c105cf:	mov    rsi,QWORD PTR [rax+0x28]
  c105d3:	shl    ecx,0x4
  c105d6:	mov    rdi,QWORD PTR [rsi+rcx*1]
  c105da:	jmp    c11007 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16e7>
  c105df:	cmp    QWORD PTR [rsp+0x4e8],r14
  c105e7:	jbe    c17452 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b32>
  c105ed:	mov    rax,QWORD PTR [rsp+0x1c8]
  c105f5:	cmp    QWORD PTR [rax+0x10],r14
  c105f9:	jbe    c178d3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7fb3>
  c105ff:	mov    rax,QWORD PTR [rax+0x8]
  c10603:	lea    rdx,[r14+r14*2]
  c10607:	mov    ecx,DWORD PTR [rax+rdx*8]
  c1060a:	lea    esi,[rcx-0x2]
  c1060d:	cmp    rcx,0x2
  c10611:	mov    edi,0x3
  c10616:	cmovae edi,esi
  c10619:	lea    rax,[rax+rdx*8]
  c1061d:	lea    rdx,[rip+0xffffffffff6b5700]        # 2c5d24 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1363>
  c10624:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c10628:	add    rsi,rdx
  c1062b:	jmp    rsi
  c1062d:	mov    r13,QWORD PTR [rax]
  c10630:	mov    rbx,QWORD PTR [rax+0x8]
  c10634:	mov    r8,QWORD PTR [rax+0x10]
  c10638:	mov    rdi,QWORD PTR [rsp+0x8]
  c1063d:	mov    rdx,QWORD PTR [rsp+0x10]
  c10642:	jmp    c15a99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6179>
  c10647:	mov    rcx,QWORD PTR [rsp+0x10]
  c1064c:	mov    rsi,QWORD PTR [rcx]
  c1064f:	mov    rcx,QWORD PTR [rsp+0x20]
  c10654:	lea    rbp,[rcx+0x10]
  c10658:	mov    rdx,QWORD PTR [rbp+0x0]
  c1065c:	mov    rdi,QWORD PTR [rsp+0x38]
  c10661:	mov    rcx,QWORD PTR [rdi+0x8]
  c10665:	mov    r8,QWORD PTR [rdi+0x10]
  c10669:	sub    rsp,0x8
  c1066d:	movzx  eax,al
  c10670:	movzx  r10d,r14b
  c10674:	lea    rdi,[rsp+0x128]
  c1067c:	mov    r14,QWORD PTR [rsp+0x10]
  c10681:	mov    r9,r14
  c10684:	push   rax
  c10685:	push   r10
  c10687:	push   r12
  c10689:	call   c078e0 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3mulEB2_>
  c1068e:	add    rsp,0x20
  c10692:	cmp    BYTE PTR [rsp+0x120],0xff
  c1069a:	jne    c196f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dd4>
  c106a0:	mov    rsi,QWORD PTR [rbp+0x0]
  c106a4:	cmp    r14,rsi
  c106a7:	jb     c1092a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x100a>
  c106ad:	jmp    c19b46 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa226>
  c106b2:	mov    rax,QWORD PTR [rsp+0x20]
  c106b7:	add    rax,0x10
  c106bb:	mov    rsi,QWORD PTR [rax]
  c106be:	cmp    QWORD PTR [rsp+0x8],rsi
  c106c3:	jae    c19b02 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1e2>
  c106c9:	mov    rax,QWORD PTR [rsp+0x10]
  c106ce:	mov    r9,QWORD PTR [rax]
  c106d1:	mov    r13,QWORD PTR [rsp+0x28]
  c106d6:	mov    rax,QWORD PTR [r9+r13*1+0x30]
  c106db:	add    r9,r13
  c106de:	mov    rcx,r12
  c106e1:	sub    rcx,rax
  c106e4:	jae    c11074 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1754>
  c106ea:	mov    rcx,QWORD PTR [r9+0x28]
  c106ee:	shl    r12d,0x4
  c106f2:	mov    rcx,QWORD PTR [rcx+r12*1]
  c106f6:	jmp    c11078 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1758>
  c106fb:	mov    rcx,QWORD PTR [rsp+0x20]
  c10700:	add    rcx,0x10
  c10704:	mov    rsi,QWORD PTR [rcx]
  c10707:	cmp    QWORD PTR [rsp+0x8],rsi
  c1070c:	jae    c19a53 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa133>
  c10712:	mov    r11,QWORD PTR [rsp+0x10]
  c10717:	mov    rdi,QWORD PTR [r11]
  c1071a:	mov    r10,QWORD PTR [rsp+0x28]
  c1071f:	lea    rsi,[rdi+r10*1]
  c10723:	movzx  edx,r14b
  c10727:	mov    rcx,rdx
  c1072a:	sub    rcx,QWORD PTR [rdi+r10*1+0x30]
  c1072f:	jae    c110e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x17c6>
  c10735:	mov    rcx,QWORD PTR [rsi+0x28]
  c10739:	shl    edx,0x4
  c1073c:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c10740:	jmp    c110ea <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x17ca>
  c10745:	mov    rax,QWORD PTR [rsp+0x20]
  c1074a:	add    rax,0x10
  c1074e:	mov    rsi,QWORD PTR [rax]
  c10751:	cmp    QWORD PTR [rsp+0x8],rsi
  c10756:	jae    c19a41 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa121>
  c1075c:	mov    rax,QWORD PTR [rsp+0x10]
  c10761:	mov    rdx,QWORD PTR [rax]
  c10764:	mov    r13,QWORD PTR [rsp+0x28]
  c10769:	lea    rcx,[rdx+r13*1]
  c1076d:	mov    rax,r12
  c10770:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c10775:	jae    c11140 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1820>
  c1077b:	mov    rax,QWORD PTR [rcx+0x28]
  c1077f:	shl    r12d,0x4
  c10783:	mov    rax,QWORD PTR [rax+r12*1]
  c10787:	jmp    c11144 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1824>
  c1078c:	mov    rcx,QWORD PTR [rsp+0x20]
  c10791:	add    rcx,0x10
  c10795:	mov    rsi,QWORD PTR [rcx]
  c10798:	cmp    QWORD PTR [rsp+0x8],rsi
  c1079d:	jae    c19a77 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa157>
  c107a3:	mov    rbp,QWORD PTR [rsp+0x10]
  c107a8:	mov    rdi,QWORD PTR [rbp+0x0]
  c107ac:	mov    r13,QWORD PTR [rsp+0x28]
  c107b1:	lea    rsi,[rdi+r13*1]
  c107b5:	movzx  edx,r14b
  c107b9:	mov    rcx,rdx
  c107bc:	sub    rcx,QWORD PTR [rdi+r13*1+0x30]
  c107c1:	jae    c1119b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x187b>
  c107c7:	mov    rcx,QWORD PTR [rsi+0x28]
  c107cb:	shl    edx,0x4
  c107ce:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c107d2:	jmp    c1119f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x187f>
  c107d7:	mov    rax,QWORD PTR [rsp+0x20]
  c107dc:	add    rax,0x10
  c107e0:	mov    rsi,QWORD PTR [rax]
  c107e3:	cmp    QWORD PTR [rsp+0x8],rsi
  c107e8:	jae    c199c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0a8>
  c107ee:	mov    rbp,QWORD PTR [rsp+0x10]
  c107f3:	mov    rsi,QWORD PTR [rbp+0x0]
  c107f7:	mov    r13,QWORD PTR [rsp+0x28]
  c107fc:	lea    rdx,[rsi+r13*1]
  c10800:	movzx  ecx,r14b
  c10804:	mov    rax,rcx
  c10807:	sub    rax,QWORD PTR [rsi+r13*1+0x30]
  c1080c:	jae    c111f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x18d3>
  c10812:	mov    rax,QWORD PTR [rdx+0x28]
  c10816:	shl    ecx,0x4
  c10819:	mov    rax,QWORD PTR [rax+rcx*1]
  c1081d:	jmp    c111f7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x18d7>
  c10822:	mov    rax,QWORD PTR [rsp+0x20]
  c10827:	add    rax,0x10
  c1082b:	mov    rsi,QWORD PTR [rax]
  c1082e:	cmp    QWORD PTR [rsp+0x8],rsi
  c10833:	jae    c19aad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa18d>
  c10839:	mov    rax,QWORD PTR [rsp+0x10]
  c1083e:	mov    rdx,QWORD PTR [rax]
  c10841:	mov    r13,QWORD PTR [rsp+0x28]
  c10846:	mov    rax,QWORD PTR [rdx+r13*1+0x50]
  c1084b:	cmp    rax,QWORD PTR [rsp+0x3c0]
  c10853:	jae    c17472 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b52>
  c10859:	add    rdx,r13
  c1085c:	mov    rcx,r12
  c1085f:	sub    rcx,QWORD PTR [rdx+0x30]
  c10863:	jae    c11668 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1d48>
  c10869:	mov    rcx,QWORD PTR [rdx+0x28]
  c1086d:	shl    r12d,0x4
  c10871:	mov    rcx,QWORD PTR [rcx+r12*1]
  c10875:	jmp    c1166c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1d4c>
  c1087a:	mov    rax,QWORD PTR [rsp+0x20]
  c1087f:	add    rax,0x10
  c10883:	mov    rsi,QWORD PTR [rax]
  c10886:	cmp    QWORD PTR [rsp+0x8],rsi
  c1088b:	jae    c199a4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa084>
  c10891:	mov    rbp,QWORD PTR [rsp+0x10]
  c10896:	mov    rsi,QWORD PTR [rbp+0x0]
  c1089a:	mov    r13,QWORD PTR [rsp+0x28]
  c1089f:	lea    rdx,[rsi+r13*1]
  c108a3:	movzx  ecx,r14b
  c108a7:	mov    rax,rcx
  c108aa:	sub    rax,QWORD PTR [rsi+r13*1+0x30]
  c108af:	jae    c11249 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1929>
  c108b5:	mov    rax,QWORD PTR [rdx+0x28]
  c108b9:	shl    ecx,0x4
  c108bc:	mov    rax,QWORD PTR [rax+rcx*1]
  c108c0:	jmp    c1124d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x192d>
  c108c5:	mov    rax,QWORD PTR [rsp+0x10]
  c108ca:	mov    rdx,QWORD PTR [rax]
  c108cd:	mov    rax,QWORD PTR [rsp+0x20]
  c108d2:	lea    rbp,[rax+0x10]
  c108d6:	mov    rcx,QWORD PTR [rbp+0x0]
  c108da:	mov    rax,QWORD PTR [rsp+0x38]
  c108df:	mov    r8,QWORD PTR [rax+0x8]
  c108e3:	mov    r9,QWORD PTR [rax+0x10]
  c108e7:	movzx  eax,r14b
  c108eb:	lea    rdi,[rsp+0x120]
  c108f3:	mov    rsi,QWORD PTR [rsp+0x1c0]
  c108fb:	push   rbx
  c108fc:	push   rax
  c108fd:	push   r12
  c108ff:	mov    r14,QWORD PTR [rsp+0x20]
  c10904:	push   r14
  c10906:	call   c0c820 <_RNvCsbxgXiyEKxkX_6bsl_vm12add_const_op>
  c1090b:	add    rsp,0x20
  c1090f:	cmp    BYTE PTR [rsp+0x120],0xff
  c10917:	jne    c196f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dd4>
  c1091d:	mov    rsi,QWORD PTR [rbp+0x0]
  c10921:	cmp    r14,rsi
  c10924:	jae    c19bbb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa29b>
  c1092a:	mov    rbx,rbp
  c1092d:	mov    rbp,QWORD PTR [rsp+0x10]
  c10932:	mov    rax,QWORD PTR [rbp+0x0]
  c10936:	mov    r13,QWORD PTR [rsp+0x28]
  c1093b:	inc    QWORD PTR [rax+r13*1+0x58]
  c10940:	mov    r12d,DWORD PTR [rsp+0x30]
  c10945:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c1094a:	mov    rax,QWORD PTR [rsp+0x20]
  c1094f:	add    rax,0x10
  c10953:	mov    rsi,QWORD PTR [rax]
  c10956:	cmp    QWORD PTR [rsp+0x8],rsi
  c1095b:	jae    c19a89 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa169>
  c10961:	mov    rbp,QWORD PTR [rsp+0x10]
  c10966:	mov    rsi,QWORD PTR [rbp+0x0]
  c1096a:	mov    r13,QWORD PTR [rsp+0x28]
  c1096f:	lea    rdx,[rsi+r13*1]
  c10973:	movzx  ecx,r14b
  c10977:	mov    rax,rcx
  c1097a:	sub    rax,QWORD PTR [rsi+r13*1+0x30]
  c1097f:	jae    c1129f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x197f>
  c10985:	mov    rax,QWORD PTR [rdx+0x28]
  c10989:	shl    ecx,0x4
  c1098c:	mov    rax,QWORD PTR [rax+rcx*1]
  c10990:	jmp    c112a3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1983>
  c10995:	mov    rcx,QWORD PTR [rsp+0x20]
  c1099a:	add    rcx,0x10
  c1099e:	mov    rsi,QWORD PTR [rcx]
  c109a1:	cmp    QWORD PTR [rsp+0x8],rsi
  c109a6:	jae    c199da <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0ba>
  c109ac:	mov    r11,QWORD PTR [rsp+0x10]
  c109b1:	mov    rdi,QWORD PTR [r11]
  c109b4:	mov    r10,QWORD PTR [rsp+0x28]
  c109b9:	lea    rsi,[rdi+r10*1]
  c109bd:	movzx  edx,r14b
  c109c1:	mov    rcx,rdx
  c109c4:	sub    rcx,QWORD PTR [rdi+r10*1+0x30]
  c109c9:	jae    c112f5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19d5>
  c109cf:	mov    rcx,QWORD PTR [rsi+0x28]
  c109d3:	shl    edx,0x4
  c109d6:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c109da:	jmp    c112f9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19d9>
  c109df:	mov    QWORD PTR [rsp+0x1b8],r15
  c109e7:	mov    rax,QWORD PTR [rsp+0x20]
  c109ec:	add    rax,0x10
  c109f0:	mov    rsi,QWORD PTR [rax]
  c109f3:	cmp    QWORD PTR [rsp+0x8],rsi
  c109f8:	jae    c19a1d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0fd>
  c109fe:	mov    rax,QWORD PTR [rsp+0x10]
  c10a03:	mov    rax,QWORD PTR [rax]
  c10a06:	mov    rdx,QWORD PTR [rsp+0x28]
  c10a0b:	mov    rcx,QWORD PTR [rax+rdx*1+0x30]
  c10a10:	add    rax,rdx
  c10a13:	mov    r15,r12
  c10a16:	sub    r15,rcx
  c10a19:	jae    c1134f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a2f>
  c10a1f:	mov    rdx,QWORD PTR [rax+0x28]
  c10a23:	shl    r12d,0x4
  c10a27:	mov    r15,QWORD PTR [rdx+r12*1]
  c10a2b:	jmp    c11353 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a33>
  c10a30:	mov    rax,QWORD PTR [rsp+0x20]
  c10a35:	add    rax,0x10
  c10a39:	mov    rsi,QWORD PTR [rax]
  c10a3c:	cmp    QWORD PTR [rsp+0x8],rsi
  c10a41:	jae    c19a9b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa17b>
  c10a47:	mov    rax,QWORD PTR [rsp+0x10]
  c10a4c:	mov    rdx,QWORD PTR [rax]
  c10a4f:	mov    r13,QWORD PTR [rsp+0x28]
  c10a54:	lea    rcx,[rdx+r13*1]
  c10a58:	mov    rax,r12
  c10a5b:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c10a60:	jae    c114d9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1bb9>
  c10a66:	mov    rax,QWORD PTR [rcx+0x28]
  c10a6a:	shl    r12d,0x4
  c10a6e:	mov    rax,QWORD PTR [rax+r12*1]
  c10a72:	jmp    c114dd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1bbd>
  c10a77:	mov    rax,QWORD PTR [rsp+0x20]
  c10a7c:	add    rax,0x10
  c10a80:	mov    rsi,QWORD PTR [rax]
  c10a83:	cmp    QWORD PTR [rsp+0x8],rsi
  c10a88:	jae    c199f9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0d9>
  c10a8e:	mov    rax,QWORD PTR [rsp+0x10]
  c10a93:	mov    rdx,QWORD PTR [rax]
  c10a96:	mov    r13,QWORD PTR [rsp+0x28]
  c10a9b:	mov    rax,QWORD PTR [rdx+r13*1+0x50]
  c10aa0:	cmp    rax,QWORD PTR [rsp+0x3c0]
  c10aa8:	jae    c17472 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b52>
  c10aae:	add    rdx,r13
  c10ab1:	mov    rcx,r12
  c10ab4:	sub    rcx,QWORD PTR [rdx+0x30]
  c10ab8:	jae    c116c5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1da5>
  c10abe:	mov    rcx,QWORD PTR [rdx+0x28]
  c10ac2:	shl    r12d,0x4
  c10ac6:	mov    rcx,QWORD PTR [rcx+r12*1]
  c10aca:	jmp    c116c9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1da9>
  c10acf:	add    rax,QWORD PTR [rdx+0x60]
  c10ad3:	mov    r14,QWORD PTR [rsp+0x8]
  c10ad8:	mov    rcx,QWORD PTR [rsp+0x38]
  c10add:	cmp    rax,QWORD PTR [rcx+0x10]
  c10ae1:	jae    c1761f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7cff>
  c10ae7:	mov    rdx,QWORD PTR [rcx+0x8]
  c10aeb:	lea    rax,[rax+rax*2]
  c10aef:	mov    ecx,DWORD PTR [rdx+rax*8]
  c10af2:	lea    esi,[rcx-0x2]
  c10af5:	cmp    rcx,0x2
  c10af9:	mov    edi,0x3
  c10afe:	cmovae edi,esi
  c10b01:	lea    rax,[rdx+rax*8]
  c10b05:	lea    rdx,[rip+0xffffffffff6b4db8]        # 2c58c4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf03>
  c10b0c:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c10b10:	add    rsi,rdx
  c10b13:	jmp    rsi
  c10b15:	mov    rdx,QWORD PTR [rax]
  c10b18:	mov    rsi,QWORD PTR [rax+0x8]
  c10b1c:	mov    rcx,QWORD PTR [rax+0x10]
  c10b20:	mov    rax,QWORD PTR [rsp+0x1b0]
  c10b28:	jmp    c11d2d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x240d>
  c10b2d:	add    rcx,QWORD PTR [rsi+0x60]
  c10b31:	mov    r14,QWORD PTR [rsp+0x8]
  c10b36:	mov    rdx,QWORD PTR [rsp+0x38]
  c10b3b:	cmp    rcx,QWORD PTR [rdx+0x10]
  c10b3f:	jae    c1764b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7d2b>
  c10b45:	mov    rsi,QWORD PTR [rdx+0x8]
  c10b49:	lea    rcx,[rcx+rcx*2]
  c10b4d:	mov    edx,DWORD PTR [rsi+rcx*8]
  c10b50:	lea    edi,[rdx-0x2]
  c10b53:	cmp    rdx,0x2
  c10b57:	mov    r8d,0x3
  c10b5d:	cmovae r8d,edi
  c10b61:	lea    rcx,[rsi+rcx*8]
  c10b65:	lea    rsi,[rip+0xffffffffff6b4c80]        # 2c57ec <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe2b>
  c10b6c:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c10b70:	add    rdi,rsi
  c10b73:	jmp    rdi
  c10b75:	mov    rsi,QWORD PTR [rcx]
  c10b78:	mov    rdi,QWORD PTR [rcx+0x8]
  c10b7c:	mov    rcx,QWORD PTR [rcx+0x10]
  c10b80:	jmp    c12215 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28f5>
  c10b85:	add    rcx,QWORD PTR [rbx+0x60]
  c10b89:	mov    rdx,QWORD PTR [rsp+0x38]
  c10b8e:	mov    r13,QWORD PTR [rdx+0x10]
  c10b92:	cmp    rcx,r13
  c10b95:	jae    c17883 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f63>
  c10b9b:	mov    QWORD PTR [rsp+0x1b8],r15
  c10ba3:	mov    r15,QWORD PTR [rdx+0x8]
  c10ba7:	lea    rcx,[rcx+rcx*2]
  c10bab:	mov    esi,DWORD PTR [r15+rcx*8]
  c10baf:	lea    edx,[rsi-0x2]
  c10bb2:	cmp    rsi,0x2
  c10bb6:	mov    edi,0x3
  c10bbb:	cmovae edi,edx
  c10bbe:	lea    rdx,[r15+rcx*8]
  c10bc2:	lea    rcx,[rip+0xffffffffff6b4edb]        # 2c5aa4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x10e3>
  c10bc9:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10bcd:	add    rdi,rcx
  c10bd0:	jmp    rdi
  c10bd2:	mov    rcx,QWORD PTR [rdx]
  c10bd5:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10bda:	mov    QWORD PTR [rsp+0x40],rcx
  c10bdf:	movdqu XMMWORD PTR [rsp+0x48],xmm0
  c10be5:	movzx  ecx,ax
  c10be8:	mov    rax,rcx
  c10beb:	sub    rax,rbp
  c10bee:	jae    c11722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e02>
  c10bf4:	mov    rax,QWORD PTR [rbx+0x28]
  c10bf8:	shl    ecx,0x4
  c10bfb:	mov    rax,QWORD PTR [rax+rcx*1]
  c10bff:	jmp    c11726 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e06>
  c10c04:	add    rcx,QWORD PTR [rbx+0x60]
  c10c08:	mov    rdx,QWORD PTR [rsp+0x38]
  c10c0d:	mov    r13,QWORD PTR [rdx+0x10]
  c10c11:	cmp    rcx,r13
  c10c14:	jae    c17492 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b72>
  c10c1a:	mov    QWORD PTR [rsp+0x1b8],r15
  c10c22:	mov    r15,QWORD PTR [rdx+0x8]
  c10c26:	lea    rcx,[rcx+rcx*2]
  c10c2a:	mov    esi,DWORD PTR [r15+rcx*8]
  c10c2e:	lea    edx,[rsi-0x2]
  c10c31:	cmp    rsi,0x2
  c10c35:	mov    edi,0x3
  c10c3a:	cmovae edi,edx
  c10c3d:	lea    rdx,[r15+rcx*8]
  c10c41:	lea    rcx,[rip+0xffffffffff6b4efc]        # 2c5b44 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1183>
  c10c48:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10c4c:	add    rdi,rcx
  c10c4f:	jmp    rdi
  c10c51:	mov    rcx,QWORD PTR [rdx]
  c10c54:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10c59:	mov    QWORD PTR [rsp+0x40],rcx
  c10c5e:	movdqu XMMWORD PTR [rsp+0x48],xmm0
  c10c64:	movzx  ecx,ax
  c10c67:	mov    rax,rcx
  c10c6a:	sub    rax,rbp
  c10c6d:	jae    c11767 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e47>
  c10c73:	mov    rax,QWORD PTR [rbx+0x28]
  c10c77:	shl    ecx,0x4
  c10c7a:	mov    rax,QWORD PTR [rax+rcx*1]
  c10c7e:	jmp    c1176b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e4b>
  c10c83:	add    rcx,QWORD PTR [rbx+0x60]
  c10c87:	mov    rdx,QWORD PTR [rsp+0x38]
  c10c8c:	mov    r13,QWORD PTR [rdx+0x10]
  c10c90:	cmp    rcx,r13
  c10c93:	jae    c17492 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b72>
  c10c99:	mov    QWORD PTR [rsp+0x1b8],r15
  c10ca1:	mov    r15,QWORD PTR [rdx+0x8]
  c10ca5:	lea    rcx,[rcx+rcx*2]
  c10ca9:	mov    esi,DWORD PTR [r15+rcx*8]
  c10cad:	lea    edx,[rsi-0x2]
  c10cb0:	cmp    rsi,0x2
  c10cb4:	mov    edi,0x3
  c10cb9:	cmovae edi,edx
  c10cbc:	lea    rdx,[r15+rcx*8]
  c10cc0:	lea    rcx,[rip+0xffffffffff6b4e2d]        # 2c5af4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1133>
  c10cc7:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10ccb:	add    rdi,rcx
  c10cce:	jmp    rdi
  c10cd0:	mov    rcx,QWORD PTR [rdx]
  c10cd3:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10cd8:	mov    QWORD PTR [rsp+0x40],rcx
  c10cdd:	movdqu XMMWORD PTR [rsp+0x48],xmm0
  c10ce3:	movzx  ecx,ax
  c10ce6:	mov    rax,rcx
  c10ce9:	sub    rax,rbp
  c10cec:	jae    c117ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e8c>
  c10cf2:	mov    rax,QWORD PTR [rbx+0x28]
  c10cf6:	shl    ecx,0x4
  c10cf9:	mov    rax,QWORD PTR [rax+rcx*1]
  c10cfd:	jmp    c117b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e90>
  c10d02:	add    rcx,QWORD PTR [rdx+0x60]
  c10d06:	mov    rdx,QWORD PTR [rsp+0x20]
  c10d0b:	lea    rbx,[rdx+0x10]
  c10d0f:	mov    r12d,DWORD PTR [rsp+0x30]
  c10d14:	mov    r9,QWORD PTR [rsp+0x38]
  c10d19:	cmp    rcx,QWORD PTR [r9+0x10]
  c10d1d:	jae    c177ff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7edf>
  c10d23:	mov    rsi,QWORD PTR [r9+0x8]
  c10d27:	lea    rcx,[rcx+rcx*2]
  c10d2b:	mov    edx,DWORD PTR [rsi+rcx*8]
  c10d2e:	lea    edi,[rdx-0x2]
  c10d31:	cmp    rdx,0x2
  c10d35:	mov    r8d,0x3
  c10d3b:	cmovae r8d,edi
  c10d3f:	lea    rcx,[rsi+rcx*8]
  c10d43:	lea    rsi,[rip+0xffffffffff6b4ba2]        # 2c58ec <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf2b>
  c10d4a:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c10d4e:	add    rdi,rsi
  c10d51:	jmp    rdi
  c10d53:	mov    r8,QWORD PTR [rcx]
  c10d56:	mov    rsi,QWORD PTR [rcx+0x8]
  c10d5a:	mov    rcx,QWORD PTR [rcx+0x10]
  c10d5e:	mov    rbp,QWORD PTR [rsp+0x10]
  c10d63:	jmp    c14e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x554c>
  c10d68:	add    rax,QWORD PTR [rcx+0x60]
  c10d6c:	mov    rcx,QWORD PTR [rsp+0x20]
  c10d71:	lea    rbx,[rcx+0x10]
  c10d75:	mov    r12d,DWORD PTR [rsp+0x30]
  c10d7a:	mov    rdx,QWORD PTR [rsp+0x38]
  c10d7f:	mov    rcx,QWORD PTR [rdx+0x8]
  c10d83:	and    r14b,0x1
  c10d87:	mov    BYTE PTR [rsp+0x124],r14b
  c10d8f:	mov    DWORD PTR [rsp+0x120],0x4
  c10d9a:	cmp    rax,QWORD PTR [rdx+0x10]
  c10d9e:	jae    c176cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7daf>
  c10da4:	lea    rax,[rax+rax*2]
  c10da8:	lea    r14,[rcx+rax*8]
  c10dac:	mov    eax,DWORD PTR [rcx+rax*8]
  c10daf:	mov    edx,eax
  c10db1:	sub    edx,0x2
  c10db4:	mov    ecx,0x3
  c10db9:	cmovae ecx,edx
  c10dbc:	cmp    ecx,0x8
  c10dbf:	ja     c13677 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d57>
  c10dc5:	mov    edx,0x1e7
  c10dca:	bt     edx,ecx
  c10dcd:	mov    rbp,QWORD PTR [rsp+0x10]
  c10dd2:	jae    c11a3d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x211d>
  c10dd8:	mov    rax,QWORD PTR [rsp+0x130]
  c10de0:	mov    QWORD PTR [r14+0x10],rax
  c10de4:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c10ded:	movdqu XMMWORD PTR [r14],xmm0
  c10df2:	mov    rsi,QWORD PTR [rbx]
  c10df5:	mov    r14,QWORD PTR [rsp+0x8]
  c10dfa:	cmp    r14,rsi
  c10dfd:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c10e03:	jmp    c19b36 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa216>
  c10e08:	add    rax,QWORD PTR [rcx+0x60]
  c10e0c:	mov    rcx,QWORD PTR [rsp+0x20]
  c10e11:	lea    rbx,[rcx+0x10]
  c10e15:	mov    r12d,DWORD PTR [rsp+0x30]
  c10e1a:	mov    rdx,QWORD PTR [rsp+0x38]
  c10e1f:	mov    rcx,QWORD PTR [rdx+0x8]
  c10e23:	mov    DWORD PTR [rsp+0x120],0x2
  c10e2e:	cmp    rax,QWORD PTR [rdx+0x10]
  c10e32:	jae    c1789d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f7d>
  c10e38:	lea    rax,[rax+rax*2]
  c10e3c:	lea    r14,[rcx+rax*8]
  c10e40:	mov    eax,DWORD PTR [rcx+rax*8]
  c10e43:	mov    edx,eax
  c10e45:	sub    edx,0x2
  c10e48:	mov    ecx,0x3
  c10e4d:	cmovae ecx,edx
  c10e50:	cmp    ecx,0x8
  c10e53:	ja     c139f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x40d4>
  c10e59:	mov    edx,0x1e7
  c10e5e:	bt     edx,ecx
  c10e61:	mov    rbp,QWORD PTR [rsp+0x10]
  c10e66:	jae    c11a6a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x214a>
  c10e6c:	mov    rax,QWORD PTR [rsp+0x130]
  c10e74:	mov    QWORD PTR [r14+0x10],rax
  c10e78:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c10e81:	movdqu XMMWORD PTR [r14],xmm0
  c10e86:	mov    rsi,QWORD PTR [rbx]
  c10e89:	mov    r14,QWORD PTR [rsp+0x8]
  c10e8e:	cmp    r14,rsi
  c10e91:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c10e97:	jmp    c19b56 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa236>
  c10e9c:	add    rcx,QWORD PTR [rbx+0x60]
  c10ea0:	mov    rdx,QWORD PTR [rsp+0x38]
  c10ea5:	mov    r10,QWORD PTR [rdx+0x10]
  c10ea9:	cmp    rcx,r10
  c10eac:	jae    c176d4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7db4>
  c10eb2:	mov    r14,QWORD PTR [rdx+0x8]
  c10eb6:	lea    rcx,[rcx+rcx*2]
  c10eba:	mov    esi,DWORD PTR [r14+rcx*8]
  c10ebe:	lea    edx,[rsi-0x2]
  c10ec1:	cmp    rsi,0x2
  c10ec5:	mov    edi,0x3
  c10eca:	cmovae edi,edx
  c10ecd:	lea    rdx,[r14+rcx*8]
  c10ed1:	lea    rcx,[rip+0xffffffffff6b4cbc]        # 2c5b94 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x11d3>
  c10ed8:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10edc:	add    rdi,rcx
  c10edf:	jmp    rdi
  c10ee1:	mov    rcx,QWORD PTR [rdx]
  c10ee4:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10ee9:	mov    QWORD PTR [rsp+0x40],rcx
  c10eee:	movdqu XMMWORD PTR [rsp+0x48],xmm0
  c10ef4:	mov    rcx,rax
  c10ef7:	sub    rcx,r9
  c10efa:	jae    c1189c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f7c>
  c10f00:	mov    rcx,QWORD PTR [rbx+0x28]
  c10f04:	shl    eax,0x4
  c10f07:	mov    rcx,QWORD PTR [rcx+rax*1]
  c10f0b:	jmp    c118a0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f80>
  c10f10:	add    rax,QWORD PTR [rcx+0x60]
  c10f14:	mov    rcx,QWORD PTR [rsp+0x20]
  c10f19:	lea    rbx,[rcx+0x10]
  c10f1d:	mov    r12d,DWORD PTR [rsp+0x30]
  c10f22:	mov    rdx,QWORD PTR [rsp+0x38]
  c10f27:	mov    rcx,QWORD PTR [rdx+0x8]
  c10f2b:	mov    DWORD PTR [rsp+0x120],0x3
  c10f36:	cmp    rax,QWORD PTR [rdx+0x10]
  c10f3a:	jae    c1779e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e7e>
  c10f40:	lea    rax,[rax+rax*2]
  c10f44:	lea    r14,[rcx+rax*8]
  c10f48:	mov    eax,DWORD PTR [rcx+rax*8]
  c10f4b:	mov    edx,eax
  c10f4d:	sub    edx,0x2
  c10f50:	mov    ecx,0x3
  c10f55:	cmovae ecx,edx
  c10f58:	cmp    ecx,0x8
  c10f5b:	ja     c13a3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x411a>
  c10f61:	mov    edx,0x1e7
  c10f66:	bt     edx,ecx
  c10f69:	mov    rbp,QWORD PTR [rsp+0x10]
  c10f6e:	jae    c11a97 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2177>
  c10f74:	mov    rax,QWORD PTR [rsp+0x130]
  c10f7c:	mov    QWORD PTR [r14+0x10],rax
  c10f80:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c10f89:	movdqu XMMWORD PTR [r14],xmm0
  c10f8e:	mov    rsi,QWORD PTR [rbx]
  c10f91:	mov    r14,QWORD PTR [rsp+0x8]
  c10f96:	cmp    r14,rsi
  c10f99:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c10f9f:	jmp    c19bdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2bb>
  c10fa4:	add    rax,QWORD PTR [rcx+0x60]
  c10fa8:	mov    r10,QWORD PTR [rsp+0x20]
  c10fad:	lea    r12,[r10+0x10]
  c10fb1:	mov    r8,QWORD PTR [rsp+0x38]
  c10fb6:	cmp    rax,QWORD PTR [r8+0x10]
  c10fba:	jae    c177d3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7eb3>
  c10fc0:	mov    rdx,QWORD PTR [r8+0x8]
  c10fc4:	lea    rax,[rax+rax*2]
  c10fc8:	mov    ecx,DWORD PTR [rdx+rax*8]
  c10fcb:	lea    esi,[rcx-0x2]
  c10fce:	cmp    rcx,0x2
  c10fd2:	mov    edi,0x3
  c10fd7:	cmovae edi,esi
  c10fda:	lea    rax,[rdx+rax*8]
  c10fde:	lea    rdx,[rip+0xffffffffff6b4867]        # 2c584c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe8b>
  c10fe5:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c10fe9:	add    rsi,rdx
  c10fec:	jmp    rsi
  c10fee:	mov    rdi,QWORD PTR [rax]
  c10ff1:	mov    rdx,QWORD PTR [rax+0x8]
  c10ff5:	mov    rax,QWORD PTR [rax+0x10]
  c10ff9:	mov    rbp,QWORD PTR [rsp+0x10]
  c10ffe:	jmp    c1530c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59ec>
  c11003:	add    rdi,QWORD PTR [rax+0x60]
  c11007:	mov    rcx,QWORD PTR [rsp+0x38]
  c1100c:	mov    rsi,QWORD PTR [rcx+0x10]
  c11010:	cmp    rdi,rsi
  c11013:	jae    c178a2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f82>
  c11019:	mov    rcx,QWORD PTR [rcx+0x8]
  c1101d:	lea    rdi,[rdi+rdi*2]
  c11021:	mov    r11d,DWORD PTR [rcx+rdi*8]
  c11025:	lea    r8d,[r11-0x2]
  c11029:	cmp    r11,0x2
  c1102d:	mov    r9d,0x3
  c11033:	cmovae r9d,r8d
  c11037:	lea    r10,[rcx+rdi*8]
  c1103b:	lea    rdi,[rip+0xffffffffff6b4d0a]        # 2c5d4c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x138b>
  c11042:	movsxd r8,DWORD PTR [rdi+r9*4]
  c11046:	add    r8,rdi
  c11049:	jmp    r8
  c1104c:	mov    r8,QWORD PTR [r10]
  c1104f:	mov    rdi,QWORD PTR [r10+0x8]
  c11053:	mov    r9,QWORD PTR [r10+0x10]
  c11057:	mov    r10,r12
  c1105a:	sub    r10,rdx
  c1105d:	jae    c12a83 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3163>
  c11063:	mov    rax,QWORD PTR [rax+0x28]
  c11067:	shl    r12d,0x4
  c1106b:	mov    r10,QWORD PTR [rax+r12*1]
  c1106f:	jmp    c12a87 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3167>
  c11074:	add    rcx,QWORD PTR [r9+0x60]
  c11078:	mov    rdi,QWORD PTR [rsp+0x38]
  c1107d:	mov    r12d,DWORD PTR [rsp+0x30]
  c11082:	movzx  edx,r14b
  c11086:	mov    r8,rdx
  c11089:	sub    r8,rax
  c1108c:	jae    c1109b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x177b>
  c1108e:	mov    rax,QWORD PTR [r9+0x28]
  c11092:	shl    edx,0x4
  c11095:	mov    r8,QWORD PTR [rax+rdx*1]
  c11099:	jmp    c1109f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x177f>
  c1109b:	add    r8,QWORD PTR [r9+0x60]
  c1109f:	mov    r14,QWORD PTR [rsp+0x8]
  c110a4:	mov    rbp,QWORD PTR [rsp+0x10]
  c110a9:	mov    rsi,QWORD PTR [rdi+0x8]
  c110ad:	mov    rdx,QWORD PTR [rdi+0x10]
  c110b1:	add    r9,0x58
  c110b5:	sub    rsp,0x8
  c110b9:	lea    rdi,[rsp+0x128]
  c110c1:	push   rbx
  c110c2:	call   c0f6a0 <_RNvCsbxgXiyEKxkX_6bsl_vm24numeric_for_next_regular>
  c110c7:	add    rsp,0x10
  c110cb:	cmp    BYTE PTR [rsp+0x120],0xff
  c110d3:	jne    c196f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dd4>
  c110d9:	mov    rbx,QWORD PTR [rsp+0xf8]
  c110e1:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c110e6:	add    rcx,QWORD PTR [rsi+0x60]
  c110ea:	mov    rdi,QWORD PTR [rsp+0x8]
  c110ef:	mov    rdx,QWORD PTR [rsp+0x38]
  c110f4:	cmp    rcx,QWORD PTR [rdx+0x10]
  c110f8:	jae    c17677 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7d57>
  c110fe:	mov    rsi,QWORD PTR [rdx+0x8]
  c11102:	lea    rcx,[rcx+rcx*2]
  c11106:	mov    edx,DWORD PTR [rsi+rcx*8]
  c11109:	lea    r9d,[rdx-0x2]
  c1110d:	cmp    rdx,0x2
  c11111:	mov    r8d,0x3
  c11117:	cmovae r8d,r9d
  c1111b:	lea    rcx,[rsi+rcx*8]
  c1111f:	lea    rsi,[rip+0xffffffffff6b4abe]        # 2c5be4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1223>
  c11126:	movsxd r8,DWORD PTR [rsi+r8*4]
  c1112a:	add    r8,rsi
  c1112d:	jmp    r8
  c11130:	mov    r9,QWORD PTR [rcx]
  c11133:	mov    r8,QWORD PTR [rcx+0x8]
  c11137:	mov    rsi,QWORD PTR [rcx+0x10]
  c1113b:	jmp    c12d7d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x345d>
  c11140:	add    rax,QWORD PTR [rcx+0x60]
  c11144:	mov    r12d,DWORD PTR [rsp+0x30]
  c11149:	mov    rcx,QWORD PTR [rsp+0x38]
  c1114e:	cmp    rax,QWORD PTR [rcx+0x10]
  c11152:	jae    c17772 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e52>
  c11158:	mov    rdx,QWORD PTR [rcx+0x8]
  c1115c:	lea    rax,[rax+rax*2]
  c11160:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11163:	lea    esi,[rcx-0x2]
  c11166:	cmp    rcx,0x2
  c1116a:	mov    edi,0x3
  c1116f:	cmovae edi,esi
  c11172:	lea    rax,[rdx+rax*8]
  c11176:	lea    rdx,[rip+0xffffffffff6b48d7]        # 2c5a54 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1093>
  c1117d:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c11181:	add    rsi,rdx
  c11184:	jmp    rsi
  c11186:	mov    rdx,QWORD PTR [rax]
  c11189:	mov    rsi,QWORD PTR [rax+0x8]
  c1118d:	mov    rax,QWORD PTR [rax+0x10]
  c11191:	mov    rbp,QWORD PTR [rsp+0x10]
  c11196:	jmp    c15780 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e60>
  c1119b:	add    rcx,QWORD PTR [rsi+0x60]
  c1119f:	mov    rbx,QWORD PTR [rsp+0x8]
  c111a4:	mov    rdx,QWORD PTR [rsp+0x38]
  c111a9:	cmp    rcx,QWORD PTR [rdx+0x10]
  c111ad:	jae    c1782b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f0b>
  c111b3:	mov    rsi,QWORD PTR [rdx+0x8]
  c111b7:	lea    rcx,[rcx+rcx*2]
  c111bb:	mov    edx,DWORD PTR [rsi+rcx*8]
  c111be:	lea    edi,[rdx-0x2]
  c111c1:	cmp    rdx,0x2
  c111c5:	mov    r8d,0x3
  c111cb:	cmovae r8d,edi
  c111cf:	lea    rcx,[rsi+rcx*8]
  c111d3:	lea    rsi,[rip+0xffffffffff6b478a]        # 2c5964 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xfa3>
  c111da:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c111de:	add    rdi,rsi
  c111e1:	jmp    rdi
  c111e3:	mov    r8,QWORD PTR [rcx]
  c111e6:	mov    rdi,QWORD PTR [rcx+0x8]
  c111ea:	mov    rsi,QWORD PTR [rcx+0x10]
  c111ee:	jmp    c13002 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36e2>
  c111f3:	add    rax,QWORD PTR [rdx+0x60]
  c111f7:	mov    rbx,QWORD PTR [rsp+0x8]
  c111fc:	mov    rcx,QWORD PTR [rsp+0x38]
  c11201:	cmp    rax,QWORD PTR [rcx+0x10]
  c11205:	jae    c176ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7dce>
  c1120b:	mov    rdx,QWORD PTR [rcx+0x8]
  c1120f:	lea    rax,[rax+rax*2]
  c11213:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11216:	lea    esi,[rcx-0x2]
  c11219:	cmp    rcx,0x2
  c1121d:	mov    edi,0x3
  c11222:	cmovae edi,esi
  c11225:	lea    rax,[rdx+rax*8]
  c11229:	lea    rdx,[rip+0xffffffffff6b45f4]        # 2c5824 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe63>
  c11230:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c11234:	add    rsi,rdx
  c11237:	jmp    rsi
  c11239:	mov    rdx,QWORD PTR [rax]
  c1123c:	mov    rsi,QWORD PTR [rax+0x8]
  c11240:	mov    rax,QWORD PTR [rax+0x10]
  c11244:	jmp    c1315f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x383f>
  c11249:	add    rax,QWORD PTR [rdx+0x60]
  c1124d:	mov    rbx,QWORD PTR [rsp+0x8]
  c11252:	mov    rcx,QWORD PTR [rsp+0x38]
  c11257:	cmp    rax,QWORD PTR [rcx+0x10]
  c1125b:	jae    c1771a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7dfa>
  c11261:	mov    rdx,QWORD PTR [rcx+0x8]
  c11265:	lea    rax,[rax+rax*2]
  c11269:	mov    ecx,DWORD PTR [rdx+rax*8]
  c1126c:	lea    esi,[rcx-0x2]
  c1126f:	cmp    rcx,0x2
  c11273:	mov    edi,0x3
  c11278:	cmovae edi,esi
  c1127b:	lea    rax,[rdx+rax*8]
  c1127f:	lea    rdx,[rip+0xffffffffff6b49fe]        # 2c5c84 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x12c3>
  c11286:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c1128a:	add    rsi,rdx
  c1128d:	jmp    rsi
  c1128f:	mov    rdx,QWORD PTR [rax]
  c11292:	mov    rsi,QWORD PTR [rax+0x8]
  c11296:	mov    rax,QWORD PTR [rax+0x10]
  c1129a:	jmp    c1349c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b7c>
  c1129f:	add    rax,QWORD PTR [rdx+0x60]
  c112a3:	mov    rbx,QWORD PTR [rsp+0x8]
  c112a8:	mov    rcx,QWORD PTR [rsp+0x38]
  c112ad:	cmp    rax,QWORD PTR [rcx+0x10]
  c112b1:	jae    c17857 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f37>
  c112b7:	mov    rdx,QWORD PTR [rcx+0x8]
  c112bb:	lea    rax,[rax+rax*2]
  c112bf:	mov    ecx,DWORD PTR [rdx+rax*8]
  c112c2:	lea    esi,[rcx-0x2]
  c112c5:	cmp    rcx,0x2
  c112c9:	mov    edi,0x3
  c112ce:	cmovae edi,esi
  c112d1:	lea    rax,[rdx+rax*8]
  c112d5:	lea    rdx,[rip+0xffffffffff6b49d0]        # 2c5cac <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x12eb>
  c112dc:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c112e0:	add    rsi,rdx
  c112e3:	jmp    rsi
  c112e5:	mov    rdx,QWORD PTR [rax]
  c112e8:	mov    rsi,QWORD PTR [rax+0x8]
  c112ec:	mov    rax,QWORD PTR [rax+0x10]
  c112f0:	jmp    c13744 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e24>
  c112f5:	add    rcx,QWORD PTR [rsi+0x60]
  c112f9:	mov    rdi,QWORD PTR [rsp+0x8]
  c112fe:	mov    rdx,QWORD PTR [rsp+0x38]
  c11303:	cmp    rcx,QWORD PTR [rdx+0x10]
  c11307:	jae    c17746 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e26>
  c1130d:	mov    rsi,QWORD PTR [rdx+0x8]
  c11311:	lea    rcx,[rcx+rcx*2]
  c11315:	mov    edx,DWORD PTR [rsi+rcx*8]
  c11318:	lea    r9d,[rdx-0x2]
  c1131c:	cmp    rdx,0x2
  c11320:	mov    r8d,0x3
  c11326:	cmovae r8d,r9d
  c1132a:	lea    rcx,[rsi+rcx*8]
  c1132e:	lea    rsi,[rip+0xffffffffff6b48ff]        # 2c5c34 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1273>
  c11335:	movsxd r8,DWORD PTR [rsi+r8*4]
  c11339:	add    r8,rsi
  c1133c:	jmp    r8
  c1133f:	mov    r9,QWORD PTR [rcx]
  c11342:	mov    r8,QWORD PTR [rcx+0x8]
  c11346:	mov    rsi,QWORD PTR [rcx+0x10]
  c1134a:	jmp    c1394c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x402c>
  c1134f:	add    r15,QWORD PTR [rax+0x60]
  c11353:	mov    rbp,QWORD PTR [rsp+0x38]
  c11358:	movzx  edx,r14b
  c1135c:	mov    r12,rdx
  c1135f:	sub    r12,rcx
  c11362:	jae    c11371 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a51>
  c11364:	mov    rcx,QWORD PTR [rax+0x28]
  c11368:	shl    edx,0x4
  c1136b:	mov    r12,QWORD PTR [rcx+rdx*1]
  c1136f:	jmp    c11375 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a55>
  c11371:	add    r12,QWORD PTR [rax+0x60]
  c11375:	mov    r14,QWORD PTR [rsp+0x8]
  c1137a:	mov    rsi,QWORD PTR [rax]
  c1137d:	mov    rdx,QWORD PTR [rax+0x8]
  c11381:	mov    r9,QWORD PTR [rax+0x10]
  c11385:	mov    rcx,QWORD PTR [rax+0x18]
  c11389:	mov    QWORD PTR [rax],0x0
  c11390:	cmp    rsi,0x1
  c11394:	jne    c113af <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a8f>
  c11396:	mov    rsi,QWORD PTR [rsp+0x1b8]
  c1139e:	mov    rax,rsi
  c113a1:	cmp    rdx,rsi
  c113a4:	je     c11434 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1b14>
  c113aa:	jmp    c188ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8fce>
  c113af:	mov    rcx,QWORD PTR [rsp+0x20]
  c113b4:	lea    rax,[rcx+0x10]
  c113b8:	mov    rsi,QWORD PTR [rax]
  c113bb:	cmp    r14,rsi
  c113be:	jae    c19e86 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa566>
  c113c4:	lea    rax,[rcx+0x8]
  c113c8:	mov    rax,QWORD PTR [rax]
  c113cb:	mov    rsi,QWORD PTR [rbp+0x8]
  c113cf:	mov    rdx,QWORD PTR [rbp+0x10]
  c113d3:	mov    rcx,QWORD PTR [rsp+0x28]
  c113d8:	lea    rax,[rax+rcx*1+0x58]
  c113dd:	lea    rdi,[rsp+0x120]
  c113e5:	mov    rcx,r15
  c113e8:	mov    r8,r12
  c113eb:	mov    r9,QWORD PTR [rsp+0x1b8]
  c113f3:	push   rbx
  c113f4:	push   rax
  c113f5:	call   c0e560 <_RNvCsbxgXiyEKxkX_6bsl_vm21numeric_for_i64_start>
  c113fa:	add    rsp,0x10
  c113fe:	movzx  eax,BYTE PTR [rsp+0x120]
  c11406:	cmp    al,0xff
  c11408:	jne    c1890e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8fee>
  c1140e:	test   BYTE PTR [rsp+0x128],0x1
  c11416:	je     c19722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e02>
  c1141c:	mov    rax,QWORD PTR [rsp+0x130]
  c11424:	mov    r9,QWORD PTR [rsp+0x138]
  c1142c:	mov    rcx,QWORD PTR [rsp+0x140]
  c11434:	mov    rdx,r9
  c11437:	inc    rdx
  c1143a:	jo     c1969e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d7e>
  c11440:	cmp    rdx,rcx
  c11443:	jle    c118f1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1fd1>
  c11449:	mov    rax,QWORD PTR [rbp+0x8]
  c1144d:	mov    rcx,rdx
  c11450:	sar    rcx,0x3f
  c11454:	mov    QWORD PTR [rsp+0x120],0x0
  c11460:	mov    QWORD PTR [rsp+0x128],rdx
  c11468:	mov    QWORD PTR [rsp+0x130],rcx
  c11470:	cmp    r15,QWORD PTR [rbp+0x10]
  c11474:	mov    r13,QWORD PTR [rsp+0x28]
  c11479:	mov    rbx,QWORD PTR [rsp+0x20]
  c1147e:	mov    r12d,DWORD PTR [rsp+0x30]
  c11483:	jae    c18956 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9036>
  c11489:	lea    rcx,[r15+r15*2]
  c1148d:	lea    r15,[rax+rcx*8]
  c11491:	mov    rdi,r15
  c11494:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c11499:	mov    rax,QWORD PTR [rsp+0x130]
  c114a1:	mov    QWORD PTR [r15+0x10],rax
  c114a5:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c114ae:	movdqu XMMWORD PTR [r15],xmm0
  c114b3:	lea    rbp,[rbx+0x10]
  c114b7:	mov    rsi,QWORD PTR [rbp+0x0]
  c114bb:	cmp    r14,rsi
  c114be:	jae    c19efa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5da>
  c114c4:	mov    rdx,rbp
  c114c7:	lea    rbp,[rbx+0x8]
  c114cb:	mov    rax,QWORD PTR [rbp+0x0]
  c114cf:	inc    QWORD PTR [rax+r13*1+0x58]
  c114d4:	jmp    c1194b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x202b>
  c114d9:	add    rax,QWORD PTR [rcx+0x60]
  c114dd:	mov    r12d,DWORD PTR [rsp+0x30]
  c114e2:	mov    rcx,QWORD PTR [rsp+0x38]
  c114e7:	cmp    rax,QWORD PTR [rcx+0x10]
  c114eb:	jae    c176a3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7d83>
  c114f1:	mov    rdx,QWORD PTR [rcx+0x8]
  c114f5:	lea    rax,[rax+rax*2]
  c114f9:	mov    ecx,DWORD PTR [rdx+rax*8]
  c114fc:	lea    esi,[rcx-0x2]
  c114ff:	cmp    rcx,0x2
  c11503:	mov    edi,0x3
  c11508:	cmovae edi,esi
  c1150b:	lea    rax,[rdx+rax*8]
  c1150f:	lea    rdx,[rip+0xffffffffff6b4566]        # 2c5a7c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x10bb>
  c11516:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c1151a:	add    rsi,rdx
  c1151d:	jmp    rsi
  c1151f:	mov    rdx,QWORD PTR [rax]
  c11522:	mov    rsi,QWORD PTR [rax+0x8]
  c11526:	mov    rax,QWORD PTR [rax+0x10]
  c1152a:	mov    rbp,QWORD PTR [rsp+0x10]
  c1152f:	jmp    c15932 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6012>
  c11534:	lea    rdi,[rsp+0x80]
  c1153c:	call   c24f20 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs8as_slice>
  c11541:	mov    r14,QWORD PTR [rsp+0x8]
  c11546:	mov    r8,rdx
  c11549:	mov    ecx,ebx
  c1154b:	shr    ebx,0x8
  c1154e:	sub    rsp,0x8
  c11552:	movzx  esi,cl
  c11555:	movzx  edx,bl
  c11558:	lea    rdi,[rsp+0x128]
  c11560:	mov    rcx,rax
  c11563:	mov    r9,QWORD PTR [rsp+0x638]
  c1156b:	push   QWORD PTR [rsp+0x648]
  c11572:	call   c0eb80 <_RNvCsbxgXiyEKxkX_6bsl_vm24call_builtin_with_format>
  c11577:	add    rsp,0x10
  c1157b:	movzx  eax,BYTE PTR [rsp+0x120]
  c11583:	cmp    al,0xff
  c11585:	jne    c17980 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8060>
  c1158b:	lea    rcx,[rsp+0x124]
  c11593:	mov    rax,QWORD PTR [rcx+0x14]
  c11597:	lea    rdx,[rsp+0x47]
  c1159c:	mov    QWORD PTR [rdx+0x10],rax
  c115a0:	movups xmm0,XMMWORD PTR [rcx+0x4]
  c115a4:	movups XMMWORD PTR [rdx],xmm0
  c115a7:	movdqu xmm0,XMMWORD PTR [rdx]
  c115ab:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c115b4:	mov    rax,QWORD PTR [rdx+0x10]
  c115b8:	mov    QWORD PTR [rsp+0xe0],rax
  c115c0:	mov    rax,QWORD PTR [rsp+0x20]
  c115c5:	add    rax,0x10
  c115c9:	mov    rsi,QWORD PTR [rax]
  c115cc:	cmp    r14,rsi
  c115cf:	jae    c19c75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa355>
  c115d5:	mov    rdx,QWORD PTR [rbp+0x0]
  c115d9:	lea    rcx,[rdx+r13*1]
  c115dd:	mov    rax,r12
  c115e0:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c115e5:	jae    c1195b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x203b>
  c115eb:	mov    rax,QWORD PTR [rcx+0x28]
  c115ef:	shl    r12d,0x4
  c115f3:	mov    rax,QWORD PTR [rax+r12*1]
  c115f7:	jmp    c1195f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x203f>
  c115fc:	add    rax,QWORD PTR [rcx+0x60]
  c11600:	mov    rcx,QWORD PTR [rsp+0x20]
  c11605:	lea    rbx,[rcx+0x10]
  c11609:	mov    r12d,DWORD PTR [rsp+0x30]
  c1160e:	mov    rdx,QWORD PTR [rsp+0x1d8]
  c11616:	mov    rcx,QWORD PTR [rsp+0x38]
  c1161b:	cmp    rax,QWORD PTR [rcx+0x10]
  c1161f:	jae    c17904 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7fe4>
  c11625:	mov    rdx,QWORD PTR [rcx+0x8]
  c11629:	lea    rax,[rax+rax*2]
  c1162d:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11630:	lea    esi,[rcx-0x2]
  c11633:	cmp    rcx,0x2
  c11637:	mov    edi,0x3
  c1163c:	cmovae edi,esi
  c1163f:	lea    rax,[rdx+rax*8]
  c11643:	lea    rdx,[rip+0xffffffffff6b46b2]        # 2c5cfc <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x133b>
  c1164a:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c1164e:	add    rsi,rdx
  c11651:	jmp    rsi
  c11653:	mov    rdx,QWORD PTR [rax]
  c11656:	mov    rcx,QWORD PTR [rax+0x8]
  c1165a:	mov    rax,QWORD PTR [rax+0x10]
  c1165e:	mov    rbp,QWORD PTR [rsp+0x10]
  c11663:	jmp    c15c20 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6300>
  c11668:	add    rcx,QWORD PTR [rdx+0x60]
  c1166c:	mov    r12d,DWORD PTR [rsp+0x30]
  c11671:	mov    rdx,QWORD PTR [rsp+0x38]
  c11676:	cmp    rcx,QWORD PTR [rdx+0x10]
  c1167a:	jae    c17928 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8008>
  c11680:	mov    rsi,QWORD PTR [rdx+0x8]
  c11684:	lea    rcx,[rcx+rcx*2]
  c11688:	mov    edx,DWORD PTR [rsi+rcx*8]
  c1168b:	lea    edi,[rdx-0x2]
  c1168e:	cmp    rdx,0x2
  c11692:	mov    r8d,0x3
  c11698:	cmovae r8d,edi
  c1169c:	lea    rcx,[rsi+rcx*8]
  c116a0:	lea    rsi,[rip+0xffffffffff6b4385]        # 2c5a2c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x106b>
  c116a7:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c116ab:	add    rdi,rsi
  c116ae:	jmp    rdi
  c116b0:	mov    rsi,QWORD PTR [rcx]
  c116b3:	mov    rdi,QWORD PTR [rcx+0x8]
  c116b7:	mov    rcx,QWORD PTR [rcx+0x10]
  c116bb:	mov    rbp,QWORD PTR [rsp+0x10]
  c116c0:	jmp    c15d1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63fa>
  c116c5:	add    rcx,QWORD PTR [rdx+0x60]
  c116c9:	mov    r12d,DWORD PTR [rsp+0x30]
  c116ce:	mov    rdx,QWORD PTR [rsp+0x38]
  c116d3:	cmp    rcx,QWORD PTR [rdx+0x10]
  c116d7:	jae    c17954 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8034>
  c116dd:	mov    rsi,QWORD PTR [rdx+0x8]
  c116e1:	lea    rcx,[rcx+rcx*2]
  c116e5:	mov    edx,DWORD PTR [rsi+rcx*8]
  c116e8:	lea    edi,[rdx-0x2]
  c116eb:	cmp    rdx,0x2
  c116ef:	mov    r8d,0x3
  c116f5:	cmovae r8d,edi
  c116f9:	lea    rcx,[rsi+rcx*8]
  c116fd:	lea    rsi,[rip+0xffffffffff6b4300]        # 2c5a04 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1043>
  c11704:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c11708:	add    rdi,rsi
  c1170b:	jmp    rdi
  c1170d:	mov    rsi,QWORD PTR [rcx]
  c11710:	mov    rdi,QWORD PTR [rcx+0x8]
  c11714:	mov    rcx,QWORD PTR [rcx+0x10]
  c11718:	mov    rbp,QWORD PTR [rsp+0x10]
  c1171d:	jmp    c15e71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6551>
  c11722:	add    rax,QWORD PTR [rbx+0x60]
  c11726:	cmp    rax,r13
  c11729:	jae    c17a66 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8146>
  c1172f:	lea    rax,[rax+rax*2]
  c11733:	mov    edx,DWORD PTR [r15+rax*8]
  c11737:	lea    ecx,[rdx-0x2]
  c1173a:	cmp    rdx,0x2
  c1173e:	mov    esi,0x3
  c11743:	cmovae esi,ecx
  c11746:	lea    rcx,[r15+rax*8]
  c1174a:	lea    rax,[rip+0xffffffffff6b437b]        # 2c5acc <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x110b>
  c11751:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c11755:	add    rsi,rax
  c11758:	jmp    rsi
  c1175a:	mov    rax,QWORD PTR [rcx]
  c1175d:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c11762:	jmp    c16001 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66e1>
  c11767:	add    rax,QWORD PTR [rbx+0x60]
  c1176b:	cmp    rax,r13
  c1176e:	jae    c17a51 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8131>
  c11774:	lea    rax,[rax+rax*2]
  c11778:	mov    edx,DWORD PTR [r15+rax*8]
  c1177c:	lea    ecx,[rdx-0x2]
  c1177f:	cmp    rdx,0x2
  c11783:	mov    esi,0x3
  c11788:	cmovae esi,ecx
  c1178b:	lea    rcx,[r15+rax*8]
  c1178f:	lea    rax,[rip+0xffffffffff6b43d6]        # 2c5b6c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x11ab>
  c11796:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c1179a:	add    rsi,rax
  c1179d:	jmp    rsi
  c1179f:	mov    rax,QWORD PTR [rcx]
  c117a2:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c117a7:	jmp    c162bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x699b>
  c117ac:	add    rax,QWORD PTR [rbx+0x60]
  c117b0:	cmp    rax,r13
  c117b3:	jae    c17a1b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80fb>
  c117b9:	lea    rax,[rax+rax*2]
  c117bd:	mov    edx,DWORD PTR [r15+rax*8]
  c117c1:	lea    ecx,[rdx-0x2]
  c117c4:	cmp    rdx,0x2
  c117c8:	mov    esi,0x3
  c117cd:	cmovae esi,ecx
  c117d0:	lea    rcx,[r15+rax*8]
  c117d4:	lea    rax,[rip+0xffffffffff6b4341]        # 2c5b1c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x115b>
  c117db:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c117df:	add    rsi,rax
  c117e2:	jmp    rsi
  c117e4:	mov    rax,QWORD PTR [rcx]
  c117e7:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c117ec:	jmp    c16560 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c40>
  c117f1:	add    rax,QWORD PTR [rcx+0x60]
  c117f5:	mov    rcx,QWORD PTR [rsp+0x20]
  c117fa:	lea    rbx,[rcx+0x10]
  c117fe:	mov    r12d,DWORD PTR [rsp+0x30]
  c11803:	mov    rsi,QWORD PTR [rsp+0x38]
  c11808:	mov    rcx,QWORD PTR [rsi+0x8]
  c1180c:	mov    rdx,QWORD PTR [rsp+0x90]
  c11814:	mov    QWORD PTR [rsp+0x130],rdx
  c1181c:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c11825:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c1182e:	cmp    rax,QWORD PTR [rsi+0x10]
  c11832:	jae    c17a30 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8110>
  c11838:	lea    rax,[rax+rax*2]
  c1183c:	lea    r14,[rcx+rax*8]
  c11840:	mov    eax,DWORD PTR [rcx+rax*8]
  c11843:	mov    edx,eax
  c11845:	sub    edx,0x2
  c11848:	mov    ecx,0x3
  c1184d:	cmovae ecx,edx
  c11850:	cmp    ecx,0x8
  c11853:	ja     c13ff0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x46d0>
  c11859:	mov    edx,0x1e7
  c1185e:	bt     edx,ecx
  c11861:	mov    rbp,QWORD PTR [rsp+0x10]
  c11866:	jae    c11ac4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21a4>
  c1186c:	mov    rax,QWORD PTR [rsp+0x90]
  c11874:	mov    QWORD PTR [r14+0x10],rax
  c11878:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c11881:	movdqu XMMWORD PTR [r14],xmm0
  c11886:	mov    rsi,QWORD PTR [rbx]
  c11889:	mov    r14,QWORD PTR [rsp+0x8]
  c1188e:	cmp    r14,rsi
  c11891:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c11897:	jmp    c19c44 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa324>
  c1189c:	add    rcx,QWORD PTR [rbx+0x60]
  c118a0:	cmp    rcx,r10
  c118a3:	jae    c17a01 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80e1>
  c118a9:	lea    rax,[rcx+rcx*2]
  c118ad:	mov    edx,DWORD PTR [r14+rax*8]
  c118b1:	lea    ecx,[rdx-0x2]
  c118b4:	cmp    rdx,0x2
  c118b8:	mov    esi,0x3
  c118bd:	cmovae esi,ecx
  c118c0:	lea    rcx,[r14+rax*8]
  c118c4:	lea    rax,[rip+0xffffffffff6b42f1]        # 2c5bbc <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x11fb>
  c118cb:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c118cf:	add    rsi,rax
  c118d2:	mov    QWORD PTR [rsp+0x1e0],r9
  c118da:	mov    QWORD PTR [rsp+0x2a8],r10
  c118e2:	jmp    rsi
  c118e4:	mov    rax,QWORD PTR [rcx]
  c118e7:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c118ec:	jmp    c16805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ee5>
  c118f1:	mov    rdi,QWORD PTR [rsp+0x20]
  c118f6:	lea    r9,[rdi+0x10]
  c118fa:	mov    rsi,QWORD PTR [r9]
  c118fd:	cmp    r14,rsi
  c11900:	mov    r13,QWORD PTR [rsp+0x28]
  c11905:	mov    r12d,DWORD PTR [rsp+0x30]
  c1190a:	jae    c19ea6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa586>
  c11910:	lea    rbp,[rdi+0x8]
  c11914:	mov    rsi,QWORD PTR [rbp+0x0]
  c11918:	mov    QWORD PTR [rsi+r13*1],0x1
  c11920:	mov    QWORD PTR [rsi+r13*1+0x8],rax
  c11925:	mov    QWORD PTR [rsi+r13*1+0x10],rdx
  c1192a:	mov    QWORD PTR [rsi+r13*1+0x18],rcx
  c1192f:	mov    rsi,QWORD PTR [r9]
  c11932:	cmp    r14,rsi
  c11935:	jae    c19e96 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa576>
  c1193b:	mov    rdx,r9
  c1193e:	mov    rax,QWORD PTR [rbp+0x0]
  c11942:	movsx  rcx,bx
  c11946:	mov    QWORD PTR [rax+r13*1+0x58],rcx
  c1194b:	mov    r15,QWORD PTR [rsp+0x1b8]
  c11953:	mov    rbx,rdx
  c11956:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c1195b:	add    rax,QWORD PTR [rcx+0x60]
  c1195f:	mov    rcx,QWORD PTR [rsp+0x20]
  c11964:	lea    rbx,[rcx+0x10]
  c11968:	mov    r12d,DWORD PTR [rsp+0x30]
  c1196d:	mov    rsi,QWORD PTR [rsp+0x38]
  c11972:	mov    rcx,QWORD PTR [rsi+0x8]
  c11976:	mov    rdx,QWORD PTR [rsp+0xe0]
  c1197e:	mov    QWORD PTR [rsp+0x130],rdx
  c11986:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1198f:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c11998:	cmp    rax,QWORD PTR [rsi+0x10]
  c1199c:	jae    c17e9d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x857d>
  c119a2:	lea    rax,[rax+rax*2]
  c119a6:	lea    r14,[rcx+rax*8]
  c119aa:	mov    eax,DWORD PTR [rcx+rax*8]
  c119ad:	mov    edx,eax
  c119af:	sub    edx,0x2
  c119b2:	mov    ecx,0x3
  c119b7:	cmovae ecx,edx
  c119ba:	cmp    ecx,0x8
  c119bd:	ja     c14956 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5036>
  c119c3:	mov    edx,0x1e7
  c119c8:	bt     edx,ecx
  c119cb:	mov    rbp,QWORD PTR [rsp+0x10]
  c119d0:	jae    c11af1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21d1>
  c119d6:	mov    rax,QWORD PTR [rsp+0xe0]
  c119de:	mov    QWORD PTR [r14+0x10],rax
  c119e2:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c119eb:	movdqu XMMWORD PTR [r14],xmm0
  c119f0:	mov    rsi,QWORD PTR [rbx]
  c119f3:	mov    r14,QWORD PTR [rsp+0x8]
  c119f8:	cmp    r14,rsi
  c119fb:	jae    c19ce2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3c2>
  c11a01:	mov    rax,QWORD PTR [rbp+0x0]
  c11a05:	inc    QWORD PTR [rax+r13*1+0x58]
  c11a0a:	lea    rdi,[rsp+0x80]
  c11a12:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c11a17:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c11a1c:	inc    QWORD PTR [rax+0x58]
  c11a20:	mov    r14,QWORD PTR [rsp+0x8]
  c11a25:	mov    rax,QWORD PTR [rsp+0x20]
  c11a2a:	lea    rbx,[rax+0x10]
  c11a2e:	mov    r12d,DWORD PTR [rsp+0x30]
  c11a33:	mov    rbp,QWORD PTR [rsp+0x10]
  c11a38:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c11a3d:	cmp    ecx,0x3
  c11a40:	jne    c1290e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2fee>
  c11a46:	test   eax,eax
  c11a48:	je     c10dd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14b8>
  c11a4e:	mov    rax,QWORD PTR [r14+0x8]
  c11a52:	dec    QWORD PTR [rax]
  c11a55:	jne    c10dd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14b8>
  c11a5b:	lea    rdi,[r14+0x8]
  c11a5f:	call   QWORD PTR [rip+0x23be2b]        # e4d890 <_DYNAMIC+0x248>
  c11a65:	jmp    c10dd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14b8>
  c11a6a:	cmp    ecx,0x3
  c11a6d:	jne    c12b38 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3218>
  c11a73:	test   eax,eax
  c11a75:	je     c10e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x154c>
  c11a7b:	mov    rax,QWORD PTR [r14+0x8]
  c11a7f:	dec    QWORD PTR [rax]
  c11a82:	jne    c10e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x154c>
  c11a88:	lea    rdi,[r14+0x8]
  c11a8c:	call   QWORD PTR [rip+0x23bdfe]        # e4d890 <_DYNAMIC+0x248>
  c11a92:	jmp    c10e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x154c>
  c11a97:	cmp    ecx,0x3
  c11a9a:	jne    c12b75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3255>
  c11aa0:	test   eax,eax
  c11aa2:	je     c10f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1654>
  c11aa8:	mov    rax,QWORD PTR [r14+0x8]
  c11aac:	dec    QWORD PTR [rax]
  c11aaf:	jne    c10f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1654>
  c11ab5:	lea    rdi,[r14+0x8]
  c11ab9:	call   QWORD PTR [rip+0x23bdd1]        # e4d890 <_DYNAMIC+0x248>
  c11abf:	jmp    c10f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1654>
  c11ac4:	cmp    ecx,0x3
  c11ac7:	jne    c13f7c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x465c>
  c11acd:	test   eax,eax
  c11acf:	je     c1186c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f4c>
  c11ad5:	mov    rax,QWORD PTR [r14+0x8]
  c11ad9:	dec    QWORD PTR [rax]
  c11adc:	jne    c1186c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f4c>
  c11ae2:	lea    rdi,[r14+0x8]
  c11ae6:	call   QWORD PTR [rip+0x23bda4]        # e4d890 <_DYNAMIC+0x248>
  c11aec:	jmp    c1186c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f4c>
  c11af1:	cmp    ecx,0x3
  c11af4:	jne    c1493a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x501a>
  c11afa:	test   eax,eax
  c11afc:	je     c119d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20b6>
  c11b02:	mov    rax,QWORD PTR [r14+0x8]
  c11b06:	dec    QWORD PTR [rax]
  c11b09:	jne    c119d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20b6>
  c11b0f:	lea    rdi,[r14+0x8]
  c11b13:	call   QWORD PTR [rip+0x23bd77]        # e4d890 <_DYNAMIC+0x248>
  c11b19:	jmp    c119d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20b6>
  c11b1e:	mov    eax,0x8
  c11b23:	xor    ecx,ecx
  c11b25:	mov    r12,QWORD PTR [rsp+0x20]
  c11b2a:	mov    QWORD PTR [rsp+0x40],rcx
  c11b2f:	mov    QWORD PTR [rsp+0x548],rax
  c11b37:	mov    QWORD PTR [rsp+0x48],rax
  c11b3c:	mov    QWORD PTR [rsp+0x50],0x0
  c11b45:	mov    QWORD PTR [rsp+0x80],0x0
  c11b51:	mov    QWORD PTR [rsp+0x88],0x8
  c11b5d:	mov    QWORD PTR [rsp+0x90],0x0
  c11b69:	test   rbp,rbp
  c11b6c:	je     c11ba1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2281>
  c11b6e:	mov    rcx,QWORD PTR [rbx+0x8]
  c11b72:	shl    rbp,0x2
  c11b76:	mov    QWORD PTR [rsp+0x550],rbp
  c11b7e:	xor    edx,edx
  c11b80:	mov    QWORD PTR [rsp+0x2a8],rcx
  c11b88:	movzx  eax,BYTE PTR [rcx+rdx*1]
  c11b8c:	lea    rcx,[rip+0xffffffffff6b3e21]        # 2c59b4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xff3>
  c11b93:	movsxd rax,DWORD PTR [rcx+rax*4]
  c11b97:	add    rax,rcx
  c11b9a:	mov    r15,QWORD PTR [rsp+0x10]
  c11b9f:	jmp    rax
  c11ba1:	mov    r13,QWORD PTR [rsp+0x28]
  c11ba6:	jmp    c16e08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74e8>
  c11bab:	mov    rax,QWORD PTR [rcx+0x8]
  c11baf:	inc    QWORD PTR [rax]
  c11bb2:	mov    rdi,QWORD PTR [rsp+0x8]
  c11bb7:	mov    r13,QWORD PTR [rsp+0x28]
  c11bbc:	mov    r8,QWORD PTR [rsp+0x10]
  c11bc1:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c11bc7:	mov    QWORD PTR [rsp+0x88],rax
  c11bcf:	mov    DWORD PTR [rsp+0x80],0xb
  c11bda:	jmp    c103dc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabc>
  c11bdf:	mov    DWORD PTR [rsp+0x80],0x2
  c11bea:	jmp    c103cd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaad>
  c11bef:	mov    DWORD PTR [rsp+0x80],0x3
  c11bfa:	jmp    c103cd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaad>
  c11bff:	test   al,0x1
  c11c01:	mov    rdi,QWORD PTR [rsp+0x8]
  c11c06:	mov    r13,QWORD PTR [rsp+0x28]
  c11c0b:	mov    r8,QWORD PTR [rsp+0x10]
  c11c10:	je     c14d7d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x545d>
  c11c16:	mov    rdx,QWORD PTR [rcx+0x8]
  c11c1a:	inc    QWORD PTR [rdx]
  c11c1d:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c11c23:	mov    eax,0x1
  c11c28:	jmp    c14d88 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5468>
  c11c2d:	mov    rax,QWORD PTR [rcx+0x8]
  c11c31:	inc    QWORD PTR [rax]
  c11c34:	mov    rdi,QWORD PTR [rsp+0x8]
  c11c39:	mov    r13,QWORD PTR [rsp+0x28]
  c11c3e:	mov    r8,QWORD PTR [rsp+0x10]
  c11c43:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c11c49:	mov    QWORD PTR [rsp+0x88],rax
  c11c51:	mov    DWORD PTR [rsp+0x80],0x6
  c11c5c:	jmp    c103dc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabc>
  c11c61:	mov    rsi,QWORD PTR [rax+0x8]
  c11c65:	inc    QWORD PTR [rsi]
  c11c68:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c11c6e:	movabs rax,0xffffffff00000000
  c11c78:	mov    rdx,QWORD PTR [rsp+0x340]
  c11c80:	and    rdx,rax
  c11c83:	or     rdx,0xb
  c11c87:	jmp    c11d1d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x23fd>
  c11c8c:	movabs rax,0xffffffff00000000
  c11c96:	mov    rdx,QWORD PTR [rsp+0x340]
  c11c9e:	and    rdx,rax
  c11ca1:	or     rdx,0x2
  c11ca5:	jmp    c11cc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x23a0>
  c11ca7:	movabs rax,0xffffffff00000000
  c11cb1:	mov    rdx,QWORD PTR [rsp+0x340]
  c11cb9:	and    rdx,rax
  c11cbc:	or     rdx,0x3
  c11cc0:	mov    rax,QWORD PTR [rsp+0x1b0]
  c11cc8:	mov    rsi,QWORD PTR [rsp+0x490]
  c11cd0:	jmp    c11d25 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2405>
  c11cd2:	test   cl,0x1
  c11cd5:	je     c14dab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x548b>
  c11cdb:	mov    rsi,QWORD PTR [rax+0x8]
  c11cdf:	inc    QWORD PTR [rsi]
  c11ce2:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c11ce8:	mov    edx,0x1
  c11ced:	mov    rax,QWORD PTR [rsp+0x1b0]
  c11cf5:	jmp    c11d2d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x240d>
  c11cf7:	mov    rsi,QWORD PTR [rax+0x8]
  c11cfb:	inc    QWORD PTR [rsi]
  c11cfe:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c11d04:	movabs rax,0xffffffff00000000
  c11d0e:	mov    rdx,QWORD PTR [rsp+0x340]
  c11d16:	and    rdx,rax
  c11d19:	or     rdx,0x6
  c11d1d:	mov    rax,QWORD PTR [rsp+0x1b0]
  c11d25:	mov    rcx,QWORD PTR [rsp+0x258]
  c11d2d:	mov    QWORD PTR [rsp+0x100],rdx
  c11d35:	mov    QWORD PTR [rsp+0x108],rsi
  c11d3d:	mov    QWORD PTR [rsp+0x258],rcx
  c11d45:	mov    QWORD PTR [rsp+0x110],rcx
  c11d4d:	cmp    edx,0xb
  c11d50:	mov    QWORD PTR [rsp+0x340],rdx
  c11d58:	mov    QWORD PTR [rsp+0x490],rsi
  c11d60:	jne    c11ee7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x25c7>
  c11d66:	cmp    BYTE PTR [rsi+0x10],0xf
  c11d6a:	jne    c11ee7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x25c7>
  c11d70:	add    rsi,0x18
  c11d74:	mov    rax,QWORD PTR [rsp+0x388]
  c11d7c:	mov    rcx,QWORD PTR [rax]
  c11d7f:	test   rcx,rcx
  c11d82:	cmovne rcx,rax
  c11d86:	mov    rdx,QWORD PTR [rsp+0x380]
  c11d8e:	mov    rax,QWORD PTR [rdx]
  c11d91:	test   rax,rax
  c11d94:	cmovne rax,rdx
  c11d98:	mov    rdx,QWORD PTR [rsp+0x3a8]
  c11da0:	movq   xmm0,QWORD PTR [rdx]
  c11da4:	mov    rdx,QWORD PTR [rsp+0x3b0]
  c11dac:	movq   xmm1,QWORD PTR [rdx]
  c11db0:	punpcklqdq xmm1,xmm0
  c11db4:	mov    rdx,QWORD PTR [rsp+0x630]
  c11dbc:	mov    QWORD PTR [rsp+0x120],rdx
  c11dc4:	mov    rdx,QWORD PTR [rip+0x23bb9d]        # e4d968 <_DYNAMIC+0x320>
  c11dcb:	mov    QWORD PTR [rsp+0x128],rdx
  c11dd3:	mov    BYTE PTR [rsp+0x1a8],0x0
  c11ddb:	mov    rdx,QWORD PTR [rsp+0x640]
  c11de3:	movups xmm0,XMMWORD PTR [rdx]
  c11de6:	movups XMMWORD PTR [rsp+0x130],xmm0
  c11dee:	movdqu xmm0,XMMWORD PTR [rdx+0x10]
  c11df3:	movdqu XMMWORD PTR [rsp+0x140],xmm0
  c11dfc:	mov    rdx,QWORD PTR [rsp+0x398]
  c11e04:	mov    QWORD PTR [rsp+0x150],rdx
  c11e0c:	mov    rdx,QWORD PTR [rsp+0x3a0]
  c11e14:	mov    QWORD PTR [rsp+0x158],rdx
  c11e1c:	mov    rdx,QWORD PTR [rsp+0x390]
  c11e24:	mov    QWORD PTR [rsp+0x160],rdx
  c11e2c:	mov    QWORD PTR [rsp+0x168],rcx
  c11e34:	mov    QWORD PTR [rsp+0x170],0x0
  c11e40:	mov    QWORD PTR [rsp+0x180],0x0
  c11e4c:	pxor   xmm0,xmm0
  c11e50:	pcmpeqd xmm0,xmm1
  c11e54:	pshufd xmm1,xmm0,0xb1
  c11e59:	pand   xmm1,xmm0
  c11e5d:	pandn  xmm1,XMMWORD PTR [rsp+0x530]
  c11e66:	movdqu XMMWORD PTR [rsp+0x190],xmm1
  c11e6f:	mov    QWORD PTR [rsp+0x1a0],rax
  c11e77:	lea    rdi,[rsp+0x80]
  c11e7f:	lea    r9,[rsp+0x120]
  c11e87:	mov    rdx,QWORD PTR [rsp+0x4c8]
  c11e8f:	mov    ecx,ebx
  c11e91:	mov    r8,QWORD PTR [rsp+0x1c0]
  c11e99:	call   c37ca0 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7linking18component_prop_get>
  c11e9e:	movzx  eax,BYTE PTR [rsp+0x80]
  c11ea6:	cmp    al,0xff
  c11ea8:	jne    c18e2a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x950a>
  c11eae:	lea    rdx,[rsp+0x88]
  c11eb6:	mov    rax,QWORD PTR [rdx+0x10]
  c11eba:	lea    rcx,[rsp+0x47]
  c11ebf:	mov    QWORD PTR [rcx+0x10],rax
  c11ec3:	movups xmm0,XMMWORD PTR [rdx]
  c11ec6:	movups XMMWORD PTR [rcx],xmm0
  c11ec9:	movdqu xmm0,XMMWORD PTR [rcx]
  c11ecd:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c11ed6:	mov    rax,QWORD PTR [rcx+0x10]
  c11eda:	mov    QWORD PTR [rsp+0xe0],rax
  c11ee2:	jmp    c11ff6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x26d6>
  c11ee7:	mov    rcx,QWORD PTR [rsp+0x4e0]
  c11eef:	cmp    QWORD PTR [rsp+0x3c8],rcx
  c11ef7:	jae    c18627 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d07>
  c11efd:	cmp    r15,QWORD PTR [rax+0x10]
  c11f01:	jae    c18635 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d15>
  c11f07:	lea    rcx,[r15+r15*2]
  c11f0b:	shl    rcx,0x3
  c11f0f:	add    rcx,QWORD PTR [rax+0x8]
  c11f13:	lea    rdi,[rsp+0x80]
  c11f1b:	lea    rsi,[rsp+0x100]
  c11f23:	mov    edx,ebx
  c11f25:	call   QWORD PTR [rip+0x240f1d]        # e52e48 <_DYNAMIC+0x5800>
  c11f2b:	movzx  eax,BYTE PTR [rsp+0x80]
  c11f33:	cmp    eax,0xff
  c11f38:	je     c11fd5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x26b5>
  c11f3e:	cmp    eax,0x5
  c11f41:	jne    c18a9b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x917b>
  c11f47:	cmp    QWORD PTR [rsp+0x4d8],rbx
  c11f4f:	jbe    c18acb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x91ab>
  c11f55:	lea    rax,[rbx+rbx*2]
  c11f59:	mov    rcx,QWORD PTR [rsp+0x4d0]
  c11f61:	mov    rdx,QWORD PTR [rcx+rax*8+0x8]
  c11f66:	mov    rcx,QWORD PTR [rcx+rax*8+0x10]
  c11f6b:	lea    rdi,[rsp+0x120]
  c11f73:	lea    rsi,[rsp+0x100]
  c11f7b:	call   QWORD PTR [rip+0x240ecf]        # e52e50 <_DYNAMIC+0x5808>
  c11f81:	movzx  eax,BYTE PTR [rsp+0x120]
  c11f89:	cmp    al,0xff
  c11f8b:	jne    c18ae8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x91c8>
  c11f91:	lea    rcx,[rsp+0x124]
  c11f99:	mov    rax,QWORD PTR [rcx+0x14]
  c11f9d:	lea    rdx,[rsp+0x47]
  c11fa2:	mov    QWORD PTR [rdx+0x10],rax
  c11fa6:	movups xmm0,XMMWORD PTR [rcx+0x4]
  c11faa:	movups XMMWORD PTR [rdx],xmm0
  c11fad:	movdqu xmm0,XMMWORD PTR [rdx]
  c11fb1:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c11fba:	mov    rax,QWORD PTR [rdx+0x10]
  c11fbe:	mov    QWORD PTR [rsp+0xe0],rax
  c11fc6:	lea    rdi,[rsp+0x80]
  c11fce:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c11fd3:	jmp    c11ff6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x26d6>
  c11fd5:	lea    rcx,[rsp+0x88]
  c11fdd:	mov    rax,QWORD PTR [rcx+0x10]
  c11fe1:	mov    QWORD PTR [rsp+0xe0],rax
  c11fe9:	movdqu xmm0,XMMWORD PTR [rcx]
  c11fed:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c11ff6:	mov    rax,QWORD PTR [rsp+0x20]
  c11ffb:	add    rax,0x10
  c11fff:	mov    rsi,QWORD PTR [rax]
  c12002:	cmp    r14,rsi
  c12005:	jae    c19da6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa486>
  c1200b:	mov    rdx,QWORD PTR [rbp+0x0]
  c1200f:	lea    rcx,[rdx+r13*1]
  c12013:	mov    rax,r12
  c12016:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c1201b:	jae    c1202b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x270b>
  c1201d:	mov    rax,QWORD PTR [rcx+0x28]
  c12021:	shl    r12d,0x4
  c12025:	mov    rax,QWORD PTR [rax+r12*1]
  c12029:	jmp    c1202f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x270f>
  c1202b:	add    rax,QWORD PTR [rcx+0x60]
  c1202f:	mov    rcx,QWORD PTR [rsp+0x20]
  c12034:	lea    rbx,[rcx+0x10]
  c12038:	mov    r12d,DWORD PTR [rsp+0x30]
  c1203d:	mov    rsi,QWORD PTR [rsp+0x38]
  c12042:	mov    rcx,QWORD PTR [rsi+0x8]
  c12046:	mov    rdx,QWORD PTR [rsp+0xe0]
  c1204e:	mov    QWORD PTR [rsp+0x130],rdx
  c12056:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1205f:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c12068:	cmp    rax,QWORD PTR [rsi+0x10]
  c1206c:	jae    c1858a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c6a>
  c12072:	lea    rax,[rax+rax*2]
  c12076:	lea    r14,[rcx+rax*8]
  c1207a:	mov    eax,DWORD PTR [rcx+rax*8]
  c1207d:	mov    edx,eax
  c1207f:	sub    edx,0x2
  c12082:	mov    ecx,0x3
  c12087:	cmovae ecx,edx
  c1208a:	cmp    ecx,0x8
  c1208d:	ja     c14d30 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5410>
  c12093:	mov    edx,0x1e7
  c12098:	bt     edx,ecx
  c1209b:	mov    rbp,QWORD PTR [rsp+0x10]
  c120a0:	jae    c1212c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x280c>
  c120a6:	mov    rax,QWORD PTR [rsp+0xe0]
  c120ae:	mov    QWORD PTR [r14+0x10],rax
  c120b2:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c120bb:	movdqu XMMWORD PTR [r14],xmm0
  c120c0:	mov    rsi,QWORD PTR [rbx]
  c120c3:	mov    r14,QWORD PTR [rsp+0x8]
  c120c8:	cmp    r14,rsi
  c120cb:	jae    c19e4e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa52e>
  c120d1:	mov    rax,QWORD PTR [rbp+0x0]
  c120d5:	inc    QWORD PTR [rax+r13*1+0x58]
  c120da:	mov    eax,DWORD PTR [rsp+0x100]
  c120e1:	mov    edx,eax
  c120e3:	sub    edx,0x2
  c120e6:	mov    ecx,0x3
  c120eb:	cmovae ecx,edx
  c120ee:	cmp    ecx,0x8
  c120f1:	ja     c14d67 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5447>
  c120f7:	mov    edx,0x1e7
  c120fc:	bt     edx,ecx
  c120ff:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c12105:	cmp    ecx,0x3
  c12108:	jne    c14d51 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5431>
  c1210e:	test   eax,eax
  c12110:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c12116:	mov    rax,QWORD PTR [rsp+0x108]
  c1211e:	dec    QWORD PTR [rax]
  c12121:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c12127:	jmp    c16dad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x748d>
  c1212c:	cmp    ecx,0x3
  c1212f:	jne    c14d14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x53f4>
  c12135:	test   eax,eax
  c12137:	je     c120a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2786>
  c1213d:	mov    rax,QWORD PTR [r14+0x8]
  c12141:	dec    QWORD PTR [rax]
  c12144:	jne    c120a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2786>
  c1214a:	lea    rdi,[r14+0x8]
  c1214e:	call   QWORD PTR [rip+0x23b73c]        # e4d890 <_DYNAMIC+0x248>
  c12154:	jmp    c120a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2786>
  c12159:	mov    rdi,QWORD PTR [rcx+0x8]
  c1215d:	inc    QWORD PTR [rdi]
  c12160:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12166:	movabs rcx,0xffffffff00000000
  c12170:	mov    rsi,QWORD PTR [rsp+0x330]
  c12178:	and    rsi,rcx
  c1217b:	or     rsi,0xb
  c1217f:	jmp    c1220d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28ed>
  c12184:	movabs rcx,0xffffffff00000000
  c1218e:	mov    rsi,QWORD PTR [rsp+0x330]
  c12196:	and    rsi,rcx
  c12199:	or     rsi,0x2
  c1219d:	mov    rdi,QWORD PTR [rsp+0x478]
  c121a5:	jmp    c1220d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28ed>
  c121a7:	movabs rcx,0xffffffff00000000
  c121b1:	mov    rsi,QWORD PTR [rsp+0x330]
  c121b9:	and    rsi,rcx
  c121bc:	or     rsi,0x3
  c121c0:	mov    rdi,QWORD PTR [rsp+0x478]
  c121c8:	jmp    c1220d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28ed>
  c121ca:	test   dl,0x1
  c121cd:	je     c14dcd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54ad>
  c121d3:	mov    rdi,QWORD PTR [rcx+0x8]
  c121d7:	inc    QWORD PTR [rdi]
  c121da:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c121e0:	mov    esi,0x1
  c121e5:	jmp    c12215 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28f5>
  c121e7:	mov    rdi,QWORD PTR [rcx+0x8]
  c121eb:	inc    QWORD PTR [rdi]
  c121ee:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c121f4:	movabs rcx,0xffffffff00000000
  c121fe:	mov    rsi,QWORD PTR [rsp+0x330]
  c12206:	and    rsi,rcx
  c12209:	or     rsi,0x6
  c1220d:	mov    rcx,QWORD PTR [rsp+0x240]
  c12215:	mov    QWORD PTR [rsp+0x330],rsi
  c1221d:	mov    QWORD PTR [rsp+0x368],rsi
  c12225:	mov    QWORD PTR [rsp+0x478],rdi
  c1222d:	mov    QWORD PTR [rsp+0x370],rdi
  c12235:	mov    QWORD PTR [rsp+0x240],rcx
  c1223d:	mov    QWORD PTR [rsp+0x378],rcx
  c12245:	mov    rcx,QWORD PTR [rsp+0x20]
  c1224a:	add    rcx,0x10
  c1224e:	mov    rsi,QWORD PTR [rcx]
  c12251:	cmp    r14,rsi
  c12254:	jae    c19ba6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa286>
  c1225a:	mov    rcx,QWORD PTR [rsp+0x38]
  c1225f:	mov    rsi,QWORD PTR [rcx+0x8]
  c12263:	mov    rdx,QWORD PTR [rcx+0x10]
  c12267:	mov    rcx,QWORD PTR [r10]
  c1226a:	add    rcx,r9
  c1226d:	movzx  r8d,al
  c12271:	movzx  r9d,bl
  c12275:	lea    rdi,[rsp+0x120]
  c1227d:	call   c24680 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs4load>
  c12282:	mov    eax,DWORD PTR [rsp+0x120]
  c12289:	cmp    eax,0xffffffff
  c1228c:	je     c17ba7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8287>
  c12292:	shr    ebx,0x8
  c12295:	lea    rsi,[rsp+0x124]
  c1229d:	mov    ecx,DWORD PTR [rsi+0x30]
  c122a0:	mov    DWORD PTR [rsp+0x70],ecx
  c122a4:	movups xmm0,XMMWORD PTR [rsi]
  c122a7:	movups xmm1,XMMWORD PTR [rsi+0x10]
  c122ab:	movups xmm2,XMMWORD PTR [rsi+0x20]
  c122af:	movaps XMMWORD PTR [rsp+0x60],xmm2
  c122b4:	movaps XMMWORD PTR [rsp+0x50],xmm1
  c122b9:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c122be:	mov    rcx,QWORD PTR [rsi+0x44]
  c122c2:	lea    rdx,[rsp+0x84]
  c122ca:	mov    QWORD PTR [rdx+0x44],rcx
  c122ce:	movups xmm0,XMMWORD PTR [rsi+0x34]
  c122d2:	movups XMMWORD PTR [rdx+0x34],xmm0
  c122d6:	mov    ecx,DWORD PTR [rsp+0x70]
  c122da:	mov    DWORD PTR [rdx+0x30],ecx
  c122dd:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c122e3:	movdqa xmm1,XMMWORD PTR [rsp+0x50]
  c122e9:	movaps xmm2,XMMWORD PTR [rsp+0x60]
  c122ee:	movups XMMWORD PTR [rdx+0x20],xmm2
  c122f2:	movdqu XMMWORD PTR [rdx+0x10],xmm1
  c122f7:	movdqu XMMWORD PTR [rdx],xmm0
  c122fb:	mov    DWORD PTR [rsp+0x80],eax
  c12302:	cmp    DWORD PTR [rsp+0x368],0xb
  c1230a:	jne    c124bf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2b9f>
  c12310:	mov    rbp,QWORD PTR [rsp+0x370]
  c12318:	cmp    BYTE PTR [rbp+0x10],0xf
  c1231c:	jne    c124bf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2b9f>
  c12322:	mov    r13,r15
  c12325:	mov    rax,QWORD PTR [rsp+0x388]
  c1232d:	mov    rcx,QWORD PTR [rax]
  c12330:	test   rcx,rcx
  c12333:	cmovne rcx,rax
  c12337:	mov    rdx,QWORD PTR [rsp+0x380]
  c1233f:	mov    rax,QWORD PTR [rdx]
  c12342:	test   rax,rax
  c12345:	cmovne rax,rdx
  c12349:	mov    rdx,QWORD PTR [rsp+0x3a8]
  c12351:	movq   xmm0,QWORD PTR [rdx]
  c12355:	mov    rdx,QWORD PTR [rsp+0x3b0]
  c1235d:	movq   xmm1,QWORD PTR [rdx]
  c12361:	punpcklqdq xmm1,xmm0
  c12365:	mov    rdx,QWORD PTR [rsp+0x630]
  c1236d:	mov    QWORD PTR [rsp+0x120],rdx
  c12375:	mov    rdx,QWORD PTR [rip+0x23b5ec]        # e4d968 <_DYNAMIC+0x320>
  c1237c:	mov    QWORD PTR [rsp+0x128],rdx
  c12384:	mov    BYTE PTR [rsp+0x1a8],0x0
  c1238c:	mov    rdx,QWORD PTR [rsp+0x640]
  c12394:	movups xmm0,XMMWORD PTR [rdx]
  c12397:	movups XMMWORD PTR [rsp+0x130],xmm0
  c1239f:	movdqu xmm0,XMMWORD PTR [rdx+0x10]
  c123a4:	movdqu XMMWORD PTR [rsp+0x140],xmm0
  c123ad:	mov    rdx,QWORD PTR [rsp+0x398]
  c123b5:	mov    QWORD PTR [rsp+0x150],rdx
  c123bd:	mov    rdx,QWORD PTR [rsp+0x3a0]
  c123c5:	mov    QWORD PTR [rsp+0x158],rdx
  c123cd:	mov    rdx,QWORD PTR [rsp+0x390]
  c123d5:	mov    QWORD PTR [rsp+0x160],rdx
  c123dd:	mov    QWORD PTR [rsp+0x168],rcx
  c123e5:	mov    rcx,QWORD PTR [rsp+0x650]
  c123ed:	mov    QWORD PTR [rsp+0x170],rcx
  c123f5:	lea    rcx,[rip+0x224064]        # e36460 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x9c0>
  c123fc:	mov    QWORD PTR [rsp+0x178],rcx
  c12404:	mov    QWORD PTR [rsp+0x180],0x0
  c12410:	pxor   xmm0,xmm0
  c12414:	pcmpeqd xmm0,xmm1
  c12418:	pshufd xmm1,xmm0,0xb1
  c1241d:	pand   xmm1,xmm0
  c12421:	pandn  xmm1,XMMWORD PTR [rsp+0x530]
  c1242a:	movdqu XMMWORD PTR [rsp+0x190],xmm1
  c12433:	mov    QWORD PTR [rsp+0x1a0],rax
  c1243b:	movzx  edi,bl
  c1243e:	call   QWORD PTR [rip+0x240a14]        # e52e58 <_DYNAMIC+0x5810>
  c12444:	mov    rbx,rax
  c12447:	mov    r15,rdx
  c1244a:	lea    rdi,[rsp+0x80]
  c12452:	call   c24f20 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs8as_slice>
  c12457:	mov    r9,rdx
  c1245a:	add    rbp,0x18
  c1245e:	sub    rsp,0x8
  c12462:	lea    rdi,[rsp+0x48]
  c12467:	mov    rsi,rbp
  c1246a:	mov    rdx,rbx
  c1246d:	mov    rcx,r15
  c12470:	mov    r8,rax
  c12473:	lea    rax,[rsp+0x128]
  c1247b:	push   rax
  c1247c:	call   QWORD PTR [rip+0x2409de]        # e52e60 <_DYNAMIC+0x5818>
  c12482:	add    rsp,0x10
  c12486:	movzx  eax,BYTE PTR [rsp+0x40]
  c1248b:	cmp    al,0xff
  c1248d:	mov    rdi,QWORD PTR [rsp+0x28]
  c12492:	mov    rcx,QWORD PTR [rsp+0x20]
  c12497:	lea    rbp,[rcx+0x8]
  c1249b:	jne    c18f03 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x95e3>
  c124a1:	lea    rcx,[rsp+0x47]
  c124a6:	mov    rax,QWORD PTR [rcx+0x11]
  c124aa:	lea    rdx,[rsp+0xd7]
  c124b2:	mov    QWORD PTR [rdx+0x10],rax
  c124b6:	movups xmm0,XMMWORD PTR [rcx+0x1]
  c124ba:	jmp    c125ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2c8c>
  c124bf:	sub    eax,0xc
  c124c2:	mov    r8d,0x2
  c124c8:	cmovae r8d,eax
  c124cc:	lea    rax,[rip+0xffffffffff6b3341]        # 2c5814 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe53>
  c124d3:	movsxd rcx,DWORD PTR [rax+r8*4]
  c124d7:	add    rcx,rax
  c124da:	jmp    rcx
  c124dc:	mov    r13,r15
  c124df:	mov    ecx,0x8
  c124e4:	jmp    c1252b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2c0b>
  c124e6:	mov    r8,QWORD PTR [rsp+0xc8]
  c124ee:	cmp    r8,0x4
  c124f2:	jae    c1988c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f6c>
  c124f8:	mov    r13,r15
  c124fb:	lea    rcx,[rsp+0x80]
  c12503:	jmp    c1252b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2c0b>
  c12505:	mov    r13,r15
  c12508:	mov    rcx,QWORD PTR [rsp+0x90]
  c12510:	mov    r8,QWORD PTR [rsp+0x98]
  c12518:	jmp    c1252b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2c0b>
  c1251a:	mov    r13,r15
  c1251d:	mov    r8d,0x1
  c12523:	lea    rcx,[rsp+0x88]
  c1252b:	mov    rdx,QWORD PTR [rsp+0x638]
  c12533:	mov    rax,QWORD PTR [rdx+0x58]
  c12537:	mov    r10,QWORD PTR [rdx+0x60]
  c1253b:	mov    rdx,QWORD PTR [r10+0x10]
  c1253f:	dec    rdx
  c12542:	and    rdx,0xfffffffffffffff0
  c12546:	add    rax,rdx
  c12549:	add    rax,0x10
  c1254d:	movzx  esi,bl
  c12550:	lea    rdi,[rsp+0x120]
  c12558:	lea    rdx,[rsp+0x368]
  c12560:	mov    r9,QWORD PTR [rsp+0x630]
  c12568:	push   r10
  c1256a:	push   rax
  c1256b:	call   QWORD PTR [rip+0x2408f7]        # e52e68 <_DYNAMIC+0x5820>
  c12571:	add    rsp,0x10
  c12575:	movzx  eax,BYTE PTR [rsp+0x120]
  c1257d:	cmp    al,0xff
  c1257f:	mov    rdi,QWORD PTR [rsp+0x28]
  c12584:	mov    rcx,QWORD PTR [rsp+0x20]
  c12589:	lea    rbp,[rcx+0x8]
  c1258d:	jne    c18673 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d53>
  c12593:	lea    rcx,[rsp+0x124]
  c1259b:	mov    rax,QWORD PTR [rcx+0x14]
  c1259f:	lea    rdx,[rsp+0x47]
  c125a4:	mov    QWORD PTR [rdx+0x10],rax
  c125a8:	movups xmm0,XMMWORD PTR [rcx+0x4]
  c125ac:	movups XMMWORD PTR [rdx],xmm0
  c125af:	movdqu xmm0,XMMWORD PTR [rdx]
  c125b3:	movdqa XMMWORD PTR [rsp+0x100],xmm0
  c125bc:	mov    rax,QWORD PTR [rdx+0x10]
  c125c0:	mov    QWORD PTR [rsp+0x110],rax
  c125c8:	mov    rax,QWORD PTR [rsp+0x20]
  c125cd:	add    rax,0x10
  c125d1:	mov    rsi,QWORD PTR [rax]
  c125d4:	cmp    r14,rsi
  c125d7:	jae    c19d6a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa44a>
  c125dd:	mov    r15,r13
  c125e0:	mov    rdx,QWORD PTR [rbp+0x0]
  c125e4:	mov    r13,rdi
  c125e7:	lea    rcx,[rdx+rdi*1]
  c125eb:	mov    rax,r12
  c125ee:	sub    rax,QWORD PTR [rdx+rdi*1+0x30]
  c125f3:	jae    c12603 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2ce3>
  c125f5:	mov    rax,QWORD PTR [rcx+0x28]
  c125f9:	shl    r12d,0x4
  c125fd:	mov    rax,QWORD PTR [rax+r12*1]
  c12601:	jmp    c12607 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2ce7>
  c12603:	add    rax,QWORD PTR [rcx+0x60]
  c12607:	mov    rcx,QWORD PTR [rsp+0x20]
  c1260c:	lea    rbx,[rcx+0x10]
  c12610:	mov    r14,QWORD PTR [rsp+0x18]
  c12615:	mov    rsi,QWORD PTR [rsp+0x38]
  c1261a:	mov    rcx,QWORD PTR [rsi+0x8]
  c1261e:	mov    rdx,QWORD PTR [rsp+0x110]
  c12626:	mov    QWORD PTR [rsp+0x130],rdx
  c1262e:	movdqa xmm0,XMMWORD PTR [rsp+0x100]
  c12637:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c12640:	cmp    rax,QWORD PTR [rsi+0x10]
  c12644:	jae    c18519 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bf9>
  c1264a:	lea    rax,[rax+rax*2]
  c1264e:	lea    r14,[rcx+rax*8]
  c12652:	mov    eax,DWORD PTR [rcx+rax*8]
  c12655:	mov    edx,eax
  c12657:	sub    edx,0x2
  c1265a:	mov    ecx,0x3
  c1265f:	cmovae ecx,edx
  c12662:	cmp    ecx,0x8
  c12665:	ja     c14ca5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5385>
  c1266b:	mov    edx,0x1e7
  c12670:	bt     edx,ecx
  c12673:	jae    c1272e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2e0e>
  c12679:	mov    rax,QWORD PTR [rsp+0x110]
  c12681:	mov    QWORD PTR [r14+0x10],rax
  c12685:	movdqa xmm0,XMMWORD PTR [rsp+0x100]
  c1268e:	movdqu XMMWORD PTR [r14],xmm0
  c12693:	mov    rsi,QWORD PTR [rbx]
  c12696:	mov    r14,QWORD PTR [rsp+0x8]
  c1269b:	cmp    r14,rsi
  c1269e:	jae    c19e39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa519>
  c126a4:	mov    rax,QWORD PTR [rbp+0x0]
  c126a8:	inc    QWORD PTR [rax+r13*1+0x58]
  c126ad:	lea    rdi,[rsp+0x80]
  c126b5:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c126ba:	mov    rsi,rbp
  c126bd:	mov    eax,DWORD PTR [rsp+0x368]
  c126c4:	mov    edx,eax
  c126c6:	sub    edx,0x2
  c126c9:	mov    ecx,0x3
  c126ce:	cmovae ecx,edx
  c126d1:	cmp    ecx,0x8
  c126d4:	ja     c14cdf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x53bf>
  c126da:	mov    edx,0x1e7
  c126df:	bt     edx,ecx
  c126e2:	mov    rdx,QWORD PTR [rsp+0x20]
  c126e7:	lea    rbx,[rdx+0x10]
  c126eb:	mov    r12d,DWORD PTR [rsp+0x30]
  c126f0:	mov    rbp,rsi
  c126f3:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c126f9:	cmp    ecx,0x3
  c126fc:	jne    c14cc1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x53a1>
  c12702:	test   eax,eax
  c12704:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c1270a:	mov    rax,QWORD PTR [rsp+0x370]
  c12712:	dec    QWORD PTR [rax]
  c12715:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c1271b:	lea    rdi,[rsp+0x370]
  c12723:	call   QWORD PTR [rip+0x23b167]        # e4d890 <_DYNAMIC+0x248>
  c12729:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c1272e:	cmp    ecx,0x3
  c12731:	jne    c14c89 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5369>
  c12737:	test   eax,eax
  c12739:	je     c12679 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d59>
  c1273f:	mov    rax,QWORD PTR [r14+0x8]
  c12743:	dec    QWORD PTR [rax]
  c12746:	jne    c12679 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d59>
  c1274c:	lea    rdi,[r14+0x8]
  c12750:	call   QWORD PTR [rip+0x23b13a]        # e4d890 <_DYNAMIC+0x248>
  c12756:	jmp    c12679 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d59>
  c1275b:	mov    rcx,QWORD PTR [rdx+0x8]
  c1275f:	inc    QWORD PTR [rcx]
  c12762:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12768:	movq   xmm0,rcx
  c1276d:	mov    ecx,0xb
  c12772:	jmp    c10bda <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12ba>
  c12777:	mov    ecx,0x2
  c1277c:	jmp    c10bda <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12ba>
  c12781:	mov    ecx,0x3
  c12786:	jmp    c10bda <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12ba>
  c1278b:	mov    rcx,QWORD PTR [rdx+0x8]
  c1278f:	inc    QWORD PTR [rcx]
  c12792:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12798:	movq   xmm0,rcx
  c1279d:	mov    ecx,0xb
  c127a2:	jmp    c10c59 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1339>
  c127a7:	mov    ecx,0x2
  c127ac:	jmp    c10c59 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1339>
  c127b1:	mov    ecx,0x3
  c127b6:	jmp    c10c59 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1339>
  c127bb:	mov    rcx,QWORD PTR [rdx+0x8]
  c127bf:	inc    QWORD PTR [rcx]
  c127c2:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c127c8:	movq   xmm0,rcx
  c127cd:	mov    ecx,0xb
  c127d2:	jmp    c10cd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b8>
  c127d7:	mov    ecx,0x2
  c127dc:	jmp    c10cd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b8>
  c127e1:	mov    ecx,0x3
  c127e6:	jmp    c10cd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b8>
  c127eb:	mov    rsi,QWORD PTR [rcx+0x8]
  c127ef:	inc    QWORD PTR [rsi]
  c127f2:	mov    rbp,QWORD PTR [rsp+0x10]
  c127f7:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c127fd:	movabs rcx,0xffffffff00000000
  c12807:	mov    r8,QWORD PTR [rsp+0x320]
  c1280f:	and    r8,rcx
  c12812:	or     r8,0xb
  c12816:	jmp    c129ed <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x30cd>
  c1281b:	test   sil,0x1
  c1281f:	je     c14de7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54c7>
  c12825:	mov    rdi,QWORD PTR [rdx+0x8]
  c12829:	inc    QWORD PTR [rdi]
  c1282c:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12832:	mov    ecx,0x1
  c12837:	jmp    c14df9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54d9>
  c1283c:	movabs rcx,0xffffffff00000000
  c12846:	mov    r8,QWORD PTR [rsp+0x320]
  c1284e:	and    r8,rcx
  c12851:	or     r8,0x2
  c12855:	jmp    c12870 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2f50>
  c12857:	movabs rcx,0xffffffff00000000
  c12861:	mov    r8,QWORD PTR [rsp+0x320]
  c12869:	and    r8,rcx
  c1286c:	or     r8,0x3
  c12870:	mov    rsi,QWORD PTR [rsp+0x498]
  c12878:	mov    rcx,QWORD PTR [rsp+0x260]
  c12880:	mov    rbp,QWORD PTR [rsp+0x10]
  c12885:	jmp    c14e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x554c>
  c1288a:	test   sil,0x1
  c1288e:	je     c14e0c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54ec>
  c12894:	mov    rdi,QWORD PTR [rdx+0x8]
  c12898:	inc    QWORD PTR [rdi]
  c1289b:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c128a1:	mov    ecx,0x1
  c128a6:	jmp    c14e1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54fe>
  c128ab:	test   sil,0x1
  c128af:	je     c14e31 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5511>
  c128b5:	mov    rdi,QWORD PTR [rdx+0x8]
  c128b9:	inc    QWORD PTR [rdi]
  c128bc:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c128c2:	mov    ecx,0x1
  c128c7:	jmp    c14e43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5523>
  c128cc:	test   dl,0x1
  c128cf:	mov    rbp,QWORD PTR [rsp+0x10]
  c128d4:	je     c14e56 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5536>
  c128da:	mov    rsi,QWORD PTR [rcx+0x8]
  c128de:	inc    QWORD PTR [rsi]
  c128e1:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c128e7:	mov    r8d,0x1
  c128ed:	jmp    c14e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x554c>
  c128f2:	mov    rcx,QWORD PTR [rdx+0x8]
  c128f6:	inc    QWORD PTR [rcx]
  c128f9:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c128ff:	movq   xmm0,rcx
  c12904:	mov    ecx,0x6
  c12909:	jmp    c10bda <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12ba>
  c1290e:	mov    rax,QWORD PTR [r14+0x8]
  c12912:	dec    QWORD PTR [rax]
  c12915:	jne    c10dd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14b8>
  c1291b:	lea    rdi,[r14+0x8]
  c1291f:	call   QWORD PTR [rip+0x23af73]        # e4d898 <_DYNAMIC+0x250>
  c12925:	jmp    c10dd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14b8>
  c1292a:	mov    rcx,QWORD PTR [rdx+0x8]
  c1292e:	inc    QWORD PTR [rcx]
  c12931:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12937:	movq   xmm0,rcx
  c1293c:	mov    ecx,0x6
  c12941:	jmp    c10c59 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1339>
  c12946:	mov    rcx,QWORD PTR [rdx+0x8]
  c1294a:	inc    QWORD PTR [rcx]
  c1294d:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12953:	movq   xmm0,rcx
  c12958:	mov    ecx,0xb
  c1295d:	jmp    c10ee9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15c9>
  c12962:	mov    rcx,QWORD PTR [rdx+0x8]
  c12966:	inc    QWORD PTR [rcx]
  c12969:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1296f:	movq   xmm0,rcx
  c12974:	mov    ecx,0x6
  c12979:	jmp    c10cd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b8>
  c1297e:	mov    rdx,QWORD PTR [rax+0x8]
  c12982:	inc    QWORD PTR [rdx]
  c12985:	mov    rbp,QWORD PTR [rsp+0x10]
  c1298a:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12990:	movabs rax,0xffffffff00000000
  c1299a:	mov    rdi,QWORD PTR [rsp+0x318]
  c129a2:	and    rdi,rax
  c129a5:	or     rdi,0xb
  c129a9:	jmp    c12c56 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3336>
  c129ae:	mov    ecx,0x2
  c129b3:	jmp    c10ee9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15c9>
  c129b8:	mov    ecx,0x3
  c129bd:	jmp    c10ee9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15c9>
  c129c2:	mov    rsi,QWORD PTR [rcx+0x8]
  c129c6:	inc    QWORD PTR [rsi]
  c129c9:	mov    rbp,QWORD PTR [rsp+0x10]
  c129ce:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c129d4:	movabs rcx,0xffffffff00000000
  c129de:	mov    r8,QWORD PTR [rsp+0x320]
  c129e6:	and    r8,rcx
  c129e9:	or     r8,0x6
  c129ed:	mov    rcx,QWORD PTR [rsp+0x260]
  c129f5:	jmp    c14e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x554c>
  c129fa:	movabs rax,0xffffffff00000000
  c12a04:	mov    rdi,QWORD PTR [rsp+0x318]
  c12a0c:	and    rdi,rax
  c12a0f:	or     rdi,0x2
  c12a13:	jmp    c12a2e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x310e>
  c12a15:	movabs rax,0xffffffff00000000
  c12a1f:	mov    rdi,QWORD PTR [rsp+0x318]
  c12a27:	and    rdi,rax
  c12a2a:	or     rdi,0x3
  c12a2e:	mov    rdx,QWORD PTR [rsp+0x488]
  c12a36:	mov    rax,QWORD PTR [rsp+0x250]
  c12a3e:	mov    rbp,QWORD PTR [rsp+0x10]
  c12a43:	jmp    c1530c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59ec>
  c12a48:	mov    rdi,QWORD PTR [r10+0x8]
  c12a4c:	inc    QWORD PTR [rdi]
  c12a4f:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12a55:	mov    r8d,0xb
  c12a5b:	mov    r10,r12
  c12a5e:	sub    r10,rdx
  c12a61:	jb     c11063 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1743>
  c12a67:	jmp    c12a83 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3163>
  c12a69:	mov    r8d,0x2
  c12a6f:	jmp    c12a77 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3157>
  c12a71:	mov    r8d,0x3
  c12a77:	mov    r10,r12
  c12a7a:	sub    r10,rdx
  c12a7d:	jb     c11063 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1743>
  c12a83:	add    r10,QWORD PTR [rax+0x60]
  c12a87:	mov    rax,QWORD PTR [rsp+0x20]
  c12a8c:	lea    rbx,[rax+0x10]
  c12a90:	mov    r12d,DWORD PTR [rsp+0x30]
  c12a95:	mov    QWORD PTR [rsp+0x120],r8
  c12a9d:	mov    QWORD PTR [rsp+0x128],rdi
  c12aa5:	mov    QWORD PTR [rsp+0x130],r9
  c12aad:	cmp    r10,rsi
  c12ab0:	mov    rbp,QWORD PTR [rsp+0x10]
  c12ab5:	jae    c179c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80a8>
  c12abb:	lea    rax,[r10+r10*2]
  c12abf:	lea    r14,[rcx+rax*8]
  c12ac3:	mov    eax,DWORD PTR [rcx+rax*8]
  c12ac6:	mov    edx,eax
  c12ac8:	sub    edx,0x2
  c12acb:	mov    ecx,0x3
  c12ad0:	cmovae ecx,edx
  c12ad3:	cmp    ecx,0x8
  c12ad6:	ja     c14011 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x46f1>
  c12adc:	mov    edx,0x1e7
  c12ae1:	bt     edx,ecx
  c12ae4:	jae    c12b16 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31f6>
  c12ae6:	mov    rax,QWORD PTR [rsp+0x130]
  c12aee:	mov    QWORD PTR [r14+0x10],rax
  c12af2:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c12afb:	movdqu XMMWORD PTR [r14],xmm0
  c12b00:	mov    rsi,QWORD PTR [rbx]
  c12b03:	mov    r14,QWORD PTR [rsp+0x8]
  c12b08:	cmp    r14,rsi
  c12b0b:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c12b11:	jmp    c19cbd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa39d>
  c12b16:	cmp    ecx,0x3
  c12b19:	jne    c13fb8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4698>
  c12b1f:	test   eax,eax
  c12b21:	je     c12ae6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31c6>
  c12b23:	mov    rax,QWORD PTR [r14+0x8]
  c12b27:	dec    QWORD PTR [rax]
  c12b2a:	jne    c12ae6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31c6>
  c12b2c:	lea    rdi,[r14+0x8]
  c12b30:	call   QWORD PTR [rip+0x23ad5a]        # e4d890 <_DYNAMIC+0x248>
  c12b36:	jmp    c12ae6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31c6>
  c12b38:	mov    rax,QWORD PTR [r14+0x8]
  c12b3c:	dec    QWORD PTR [rax]
  c12b3f:	jne    c10e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x154c>
  c12b45:	lea    rdi,[r14+0x8]
  c12b49:	call   QWORD PTR [rip+0x23ad49]        # e4d898 <_DYNAMIC+0x250>
  c12b4f:	jmp    c10e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x154c>
  c12b54:	test   sil,0x1
  c12b58:	je     c152d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59b2>
  c12b5e:	mov    rdi,QWORD PTR [rdx+0x8]
  c12b62:	inc    QWORD PTR [rdi]
  c12b65:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12b6b:	mov    ecx,0x1
  c12b70:	jmp    c152e4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59c4>
  c12b75:	mov    rax,QWORD PTR [r14+0x8]
  c12b79:	dec    QWORD PTR [rax]
  c12b7c:	jne    c10f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1654>
  c12b82:	lea    rdi,[r14+0x8]
  c12b86:	call   QWORD PTR [rip+0x23ad0c]        # e4d898 <_DYNAMIC+0x250>
  c12b8c:	jmp    c10f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1654>
  c12b91:	test   cl,0x1
  c12b94:	mov    rbp,QWORD PTR [rsp+0x10]
  c12b99:	je     c152f7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59d7>
  c12b9f:	mov    rdx,QWORD PTR [rax+0x8]
  c12ba3:	inc    QWORD PTR [rdx]
  c12ba6:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12bac:	mov    edi,0x1
  c12bb1:	jmp    c1530c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59ec>
  c12bb6:	test   r11b,0x1
  c12bba:	je     c1572f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e0f>
  c12bc0:	mov    rdi,QWORD PTR [r10+0x8]
  c12bc4:	inc    QWORD PTR [rdi]
  c12bc7:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12bcd:	mov    r8d,0x1
  c12bd3:	mov    r10,r12
  c12bd6:	sub    r10,rdx
  c12bd9:	jb     c11063 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1743>
  c12bdf:	jmp    c12a83 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3163>
  c12be4:	mov    rcx,QWORD PTR [rdx+0x8]
  c12be8:	inc    QWORD PTR [rcx]
  c12beb:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12bf1:	movq   xmm0,rcx
  c12bf6:	mov    ecx,0x6
  c12bfb:	jmp    c10ee9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15c9>
  c12c00:	mov    r8,QWORD PTR [rcx+0x8]
  c12c04:	inc    QWORD PTR [r8]
  c12c07:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12c0d:	movabs rcx,0xffffffff00000000
  c12c17:	mov    r9,QWORD PTR [rsp+0x308]
  c12c1f:	and    r9,rcx
  c12c22:	or     r9,0xb
  c12c26:	jmp    c12d75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3455>
  c12c2b:	mov    rdx,QWORD PTR [rax+0x8]
  c12c2f:	inc    QWORD PTR [rdx]
  c12c32:	mov    rbp,QWORD PTR [rsp+0x10]
  c12c37:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12c3d:	movabs rax,0xffffffff00000000
  c12c47:	mov    rdi,QWORD PTR [rsp+0x318]
  c12c4f:	and    rdi,rax
  c12c52:	or     rdi,0x6
  c12c56:	mov    rax,QWORD PTR [rsp+0x250]
  c12c5e:	jmp    c1530c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59ec>
  c12c63:	movabs rcx,0xffffffff00000000
  c12c6d:	mov    r9,QWORD PTR [rsp+0x308]
  c12c75:	and    r9,rcx
  c12c78:	or     r9,0x2
  c12c7c:	mov    r8,QWORD PTR [rsp+0x468]
  c12c84:	jmp    c12d75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3455>
  c12c89:	movabs rcx,0xffffffff00000000
  c12c93:	mov    r9,QWORD PTR [rsp+0x308]
  c12c9b:	and    r9,rcx
  c12c9e:	or     r9,0x3
  c12ca2:	mov    r8,QWORD PTR [rsp+0x468]
  c12caa:	jmp    c12d75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3455>
  c12caf:	mov    rdi,QWORD PTR [r10+0x8]
  c12cb3:	inc    QWORD PTR [rdi]
  c12cb6:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12cbc:	mov    r8d,0x6
  c12cc2:	mov    r10,r12
  c12cc5:	sub    r10,rdx
  c12cc8:	jae    c12a83 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3163>
  c12cce:	jmp    c11063 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1743>
  c12cd3:	test   dl,0x1
  c12cd6:	je     c15753 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e33>
  c12cdc:	mov    r8,QWORD PTR [rcx+0x8]
  c12ce0:	inc    QWORD PTR [r8]
  c12ce3:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12ce9:	mov    r9d,0x1
  c12cef:	jmp    c12d7d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x345d>
  c12cf4:	mov    rsi,QWORD PTR [rax+0x8]
  c12cf8:	inc    QWORD PTR [rsi]
  c12cfb:	mov    rbp,QWORD PTR [rsp+0x10]
  c12d00:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12d06:	movabs rax,0xffffffff00000000
  c12d10:	mov    rdx,QWORD PTR [rsp+0x348]
  c12d18:	and    rdx,rax
  c12d1b:	or     rdx,0xb
  c12d1f:	jmp    c12fc7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36a7>
  c12d24:	mov    rdi,QWORD PTR [rcx+0x8]
  c12d28:	inc    QWORD PTR [rdi]
  c12d2b:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12d31:	movabs rcx,0xffffffff00000000
  c12d3b:	mov    r8,QWORD PTR [rsp+0x328]
  c12d43:	and    r8,rcx
  c12d46:	or     r8,0xb
  c12d4a:	jmp    c12ffa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36da>
  c12d4f:	mov    r8,QWORD PTR [rcx+0x8]
  c12d53:	inc    QWORD PTR [r8]
  c12d56:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12d5c:	movabs rcx,0xffffffff00000000
  c12d66:	mov    r9,QWORD PTR [rsp+0x308]
  c12d6e:	and    r9,rcx
  c12d71:	or     r9,0x6
  c12d75:	mov    rsi,QWORD PTR [rsp+0x280]
  c12d7d:	mov    QWORD PTR [rsp+0x40],r9
  c12d82:	mov    QWORD PTR [rsp+0x48],r8
  c12d87:	mov    QWORD PTR [rsp+0x280],rsi
  c12d8f:	mov    QWORD PTR [rsp+0x50],rsi
  c12d94:	mov    rcx,QWORD PTR [rsp+0x20]
  c12d99:	add    rcx,0x10
  c12d9d:	mov    rsi,QWORD PTR [rcx]
  c12da0:	cmp    rdi,rsi
  c12da3:	jae    c19c0b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2eb>
  c12da9:	mov    rsi,QWORD PTR [r11]
  c12dac:	lea    rdx,[rsi+r10*1]
  c12db0:	movzx  ecx,ax
  c12db3:	mov    rax,rcx
  c12db6:	sub    rax,QWORD PTR [rsi+r10*1+0x30]
  c12dbb:	jae    c12dca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x34aa>
  c12dbd:	mov    rax,QWORD PTR [rdx+0x28]
  c12dc1:	shl    ecx,0x4
  c12dc4:	mov    rax,QWORD PTR [rax+rcx*1]
  c12dc8:	jmp    c12dce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x34ae>
  c12dca:	add    rax,QWORD PTR [rdx+0x60]
  c12dce:	mov    rcx,QWORD PTR [rsp+0x38]
  c12dd3:	cmp    rax,QWORD PTR [rcx+0x10]
  c12dd7:	jae    c17aac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x818c>
  c12ddd:	mov    QWORD PTR [rsp+0x468],r8
  c12de5:	mov    rdx,QWORD PTR [rcx+0x8]
  c12de9:	lea    rax,[rax+rax*2]
  c12ded:	mov    ecx,DWORD PTR [rdx+rax*8]
  c12df0:	lea    esi,[rcx-0x2]
  c12df3:	cmp    rcx,0x2
  c12df7:	mov    r8d,0x3
  c12dfd:	cmovae r8d,esi
  c12e01:	lea    rax,[rdx+rax*8]
  c12e05:	lea    rdx,[rip+0xffffffffff6b2e00]        # 2c5c0c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x124b>
  c12e0c:	movsxd rsi,DWORD PTR [rdx+r8*4]
  c12e10:	add    rsi,rdx
  c12e13:	jmp    rsi
  c12e15:	mov    rdx,QWORD PTR [rax]
  c12e18:	mov    r8,QWORD PTR [rax+0x8]
  c12e1c:	mov    rax,QWORD PTR [rax+0x10]
  c12e20:	jmp    c14117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47f7>
  c12e25:	movabs rax,0xffffffff00000000
  c12e2f:	mov    rdx,QWORD PTR [rsp+0x348]
  c12e37:	and    rdx,rax
  c12e3a:	or     rdx,0x2
  c12e3e:	jmp    c12e59 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3539>
  c12e40:	movabs rax,0xffffffff00000000
  c12e4a:	mov    rdx,QWORD PTR [rsp+0x348]
  c12e52:	and    rdx,rax
  c12e55:	or     rdx,0x3
  c12e59:	mov    rsi,QWORD PTR [rsp+0x4a0]
  c12e61:	mov    rax,QWORD PTR [rsp+0x270]
  c12e69:	mov    rbp,QWORD PTR [rsp+0x10]
  c12e6e:	jmp    c15780 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e60>
  c12e73:	movabs rcx,0xffffffff00000000
  c12e7d:	mov    r8,QWORD PTR [rsp+0x328]
  c12e85:	and    r8,rcx
  c12e88:	or     r8,0x2
  c12e8c:	mov    rdi,QWORD PTR [rsp+0x460]
  c12e94:	jmp    c12ffa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36da>
  c12e99:	movabs rcx,0xffffffff00000000
  c12ea3:	mov    r8,QWORD PTR [rsp+0x328]
  c12eab:	and    r8,rcx
  c12eae:	or     r8,0x3
  c12eb2:	mov    rdi,QWORD PTR [rsp+0x460]
  c12eba:	jmp    c12ffa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36da>
  c12ebf:	mov    rsi,QWORD PTR [rax+0x8]
  c12ec3:	inc    QWORD PTR [rsi]
  c12ec6:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12ecc:	movabs rax,0xffffffff00000000
  c12ed6:	mov    rdx,QWORD PTR [rsp+0x338]
  c12ede:	and    rdx,rax
  c12ee1:	or     rdx,0xb
  c12ee5:	jmp    c13157 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3837>
  c12eea:	movabs rax,0xffffffff00000000
  c12ef4:	mov    rdx,QWORD PTR [rsp+0x338]
  c12efc:	and    rdx,rax
  c12eff:	or     rdx,0x2
  c12f03:	mov    rsi,QWORD PTR [rsp+0x480]
  c12f0b:	jmp    c13157 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3837>
  c12f10:	movabs rax,0xffffffff00000000
  c12f1a:	mov    rdx,QWORD PTR [rsp+0x338]
  c12f22:	and    rdx,rax
  c12f25:	or     rdx,0x3
  c12f29:	mov    rsi,QWORD PTR [rsp+0x480]
  c12f31:	jmp    c13157 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3837>
  c12f36:	test   cl,0x1
  c12f39:	mov    rbp,QWORD PTR [rsp+0x10]
  c12f3e:	je     c1576b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e4b>
  c12f44:	mov    rsi,QWORD PTR [rax+0x8]
  c12f48:	inc    QWORD PTR [rsi]
  c12f4b:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12f51:	mov    edx,0x1
  c12f56:	jmp    c15780 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e60>
  c12f5b:	test   dl,0x1
  c12f5e:	je     c1589f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f7f>
  c12f64:	mov    rdi,QWORD PTR [rcx+0x8]
  c12f68:	inc    QWORD PTR [rdi]
  c12f6b:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12f71:	mov    r8d,0x1
  c12f77:	jmp    c13002 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36e2>
  c12f7c:	test   cl,0x1
  c12f7f:	je     c158b7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f97>
  c12f85:	mov    rsi,QWORD PTR [rax+0x8]
  c12f89:	inc    QWORD PTR [rsi]
  c12f8c:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12f92:	mov    edx,0x1
  c12f97:	jmp    c1315f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x383f>
  c12f9c:	mov    rsi,QWORD PTR [rax+0x8]
  c12fa0:	inc    QWORD PTR [rsi]
  c12fa3:	mov    rbp,QWORD PTR [rsp+0x10]
  c12fa8:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12fae:	movabs rax,0xffffffff00000000
  c12fb8:	mov    rdx,QWORD PTR [rsp+0x348]
  c12fc0:	and    rdx,rax
  c12fc3:	or     rdx,0x6
  c12fc7:	mov    rax,QWORD PTR [rsp+0x270]
  c12fcf:	jmp    c15780 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e60>
  c12fd4:	mov    rdi,QWORD PTR [rcx+0x8]
  c12fd8:	inc    QWORD PTR [rdi]
  c12fdb:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c12fe1:	movabs rcx,0xffffffff00000000
  c12feb:	mov    r8,QWORD PTR [rsp+0x328]
  c12ff3:	and    r8,rcx
  c12ff6:	or     r8,0x6
  c12ffa:	mov    rsi,QWORD PTR [rsp+0x268]
  c13002:	mov    QWORD PTR [rsp+0x100],r8
  c1300a:	mov    QWORD PTR [rsp+0x108],rdi
  c13012:	mov    QWORD PTR [rsp+0x268],rsi
  c1301a:	mov    QWORD PTR [rsp+0x110],rsi
  c13022:	mov    rcx,QWORD PTR [rsp+0x20]
  c13027:	add    rcx,0x10
  c1302b:	mov    rsi,QWORD PTR [rcx]
  c1302e:	cmp    rbx,rsi
  c13031:	jae    c19c1d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2fd>
  c13037:	mov    rsi,QWORD PTR [rbp+0x0]
  c1303b:	lea    rdx,[rsi+r13*1]
  c1303f:	movzx  ecx,ax
  c13042:	mov    rax,rcx
  c13045:	sub    rax,QWORD PTR [rsi+r13*1+0x30]
  c1304a:	jae    c13059 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3739>
  c1304c:	mov    rax,QWORD PTR [rdx+0x28]
  c13050:	shl    ecx,0x4
  c13053:	mov    rax,QWORD PTR [rax+rcx*1]
  c13057:	jmp    c1305d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x373d>
  c13059:	add    rax,QWORD PTR [rdx+0x60]
  c1305d:	mov    rcx,QWORD PTR [rsp+0x38]
  c13062:	cmp    rax,QWORD PTR [rcx+0x10]
  c13066:	jae    c17b30 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8210>
  c1306c:	mov    QWORD PTR [rsp+0x460],rdi
  c13074:	mov    rdx,QWORD PTR [rcx+0x8]
  c13078:	lea    rax,[rax+rax*2]
  c1307c:	mov    ecx,DWORD PTR [rdx+rax*8]
  c1307f:	lea    esi,[rcx-0x2]
  c13082:	cmp    rcx,0x2
  c13086:	mov    edi,0x3
  c1308b:	cmovae edi,esi
  c1308e:	lea    rax,[rdx+rax*8]
  c13092:	lea    rdx,[rip+0xffffffffff6b28f3]        # 2c598c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xfcb>
  c13099:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c1309d:	add    rsi,rdx
  c130a0:	mov    QWORD PTR [rsp+0x328],r8
  c130a8:	jmp    rsi
  c130aa:	mov    rdx,QWORD PTR [rax]
  c130ad:	mov    rsi,QWORD PTR [rax+0x8]
  c130b1:	mov    rdi,QWORD PTR [rax+0x10]
  c130b5:	jmp    c143b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a90>
  c130ba:	mov    rsi,QWORD PTR [rax+0x8]
  c130be:	inc    QWORD PTR [rsi]
  c130c1:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c130c7:	movabs rax,0xffffffff00000000
  c130d1:	mov    rdx,QWORD PTR [rsp+0x358]
  c130d9:	and    rdx,rax
  c130dc:	or     rdx,0xb
  c130e0:	jmp    c13494 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b74>
  c130e5:	movabs rax,0xffffffff00000000
  c130ef:	mov    rdx,QWORD PTR [rsp+0x358]
  c130f7:	and    rdx,rax
  c130fa:	or     rdx,0x2
  c130fe:	mov    rsi,QWORD PTR [rsp+0x4b0]
  c13106:	jmp    c13494 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b74>
  c1310b:	movabs rax,0xffffffff00000000
  c13115:	mov    rdx,QWORD PTR [rsp+0x358]
  c1311d:	and    rdx,rax
  c13120:	or     rdx,0x3
  c13124:	mov    rsi,QWORD PTR [rsp+0x4b0]
  c1312c:	jmp    c13494 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b74>
  c13131:	mov    rsi,QWORD PTR [rax+0x8]
  c13135:	inc    QWORD PTR [rsi]
  c13138:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1313e:	movabs rax,0xffffffff00000000
  c13148:	mov    rdx,QWORD PTR [rsp+0x338]
  c13150:	and    rdx,rax
  c13153:	or     rdx,0x6
  c13157:	mov    rax,QWORD PTR [rsp+0x248]
  c1315f:	mov    QWORD PTR [rsp+0x338],rdx
  c13167:	mov    QWORD PTR [rsp+0x80],rdx
  c1316f:	mov    QWORD PTR [rsp+0x480],rsi
  c13177:	mov    QWORD PTR [rsp+0x88],rsi
  c1317f:	mov    QWORD PTR [rsp+0x248],rax
  c13187:	mov    QWORD PTR [rsp+0x90],rax
  c1318f:	lea    rdi,[rsp+0x120]
  c13197:	lea    rsi,[rsp+0x80]
  c1319f:	call   QWORD PTR [rip+0x23ec3b]        # e51de0 <_DYNAMIC+0x4798>
  c131a5:	movzx  ecx,BYTE PTR [rsp+0x120]
  c131ad:	cmp    cl,0xff
  c131b0:	jne    c17b5c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x823c>
  c131b6:	mov    rax,QWORD PTR [rsp+0x20]
  c131bb:	add    rax,0x10
  c131bf:	mov    rsi,QWORD PTR [rax]
  c131c2:	cmp    rbx,rsi
  c131c5:	jae    c19c54 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa334>
  c131cb:	mov    rdx,QWORD PTR [rbp+0x0]
  c131cf:	lea    rcx,[rdx+r13*1]
  c131d3:	mov    rax,r12
  c131d6:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c131db:	jae    c131eb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38cb>
  c131dd:	mov    rax,QWORD PTR [rcx+0x28]
  c131e1:	shl    r12d,0x4
  c131e5:	mov    rax,QWORD PTR [rax+r12*1]
  c131e9:	jmp    c131ef <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38cf>
  c131eb:	add    rax,QWORD PTR [rcx+0x60]
  c131ef:	mov    rcx,QWORD PTR [rsp+0x20]
  c131f4:	lea    rbx,[rcx+0x10]
  c131f8:	mov    r12d,DWORD PTR [rsp+0x30]
  c131fd:	mov    rdx,QWORD PTR [rsp+0x128]
  c13205:	mov    rsi,QWORD PTR [rsp+0x38]
  c1320a:	mov    rcx,QWORD PTR [rsi+0x8]
  c1320e:	mov    QWORD PTR [rsp+0x120],0x0
  c1321a:	mov    QWORD PTR [rsp+0x128],rdx
  c13222:	sar    rdx,0x3f
  c13226:	mov    QWORD PTR [rsp+0x130],rdx
  c1322e:	cmp    rax,QWORD PTR [rsi+0x10]
  c13232:	jae    c17f64 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8644>
  c13238:	lea    rax,[rax+rax*2]
  c1323c:	lea    r14,[rcx+rax*8]
  c13240:	mov    eax,DWORD PTR [rcx+rax*8]
  c13243:	mov    edx,eax
  c13245:	sub    edx,0x2
  c13248:	mov    ecx,0x3
  c1324d:	cmovae ecx,edx
  c13250:	cmp    ecx,0x8
  c13253:	ja     c14993 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5073>
  c13259:	mov    edx,0x1e7
  c1325e:	bt     edx,ecx
  c13261:	mov    rbp,QWORD PTR [rsp+0x10]
  c13266:	jae    c132f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39d2>
  c1326c:	mov    rax,QWORD PTR [rsp+0x130]
  c13274:	mov    QWORD PTR [r14+0x10],rax
  c13278:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c13281:	movdqu XMMWORD PTR [r14],xmm0
  c13286:	mov    rsi,QWORD PTR [rbx]
  c13289:	mov    r14,QWORD PTR [rsp+0x8]
  c1328e:	cmp    r14,rsi
  c13291:	jae    c19d07 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3e7>
  c13297:	mov    rax,QWORD PTR [rbp+0x0]
  c1329b:	inc    QWORD PTR [rax+r13*1+0x58]
  c132a0:	mov    eax,DWORD PTR [rsp+0x80]
  c132a7:	mov    edx,eax
  c132a9:	sub    edx,0x2
  c132ac:	mov    ecx,0x3
  c132b1:	cmovae ecx,edx
  c132b4:	cmp    ecx,0x8
  c132b7:	ja     c14a4c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x512c>
  c132bd:	mov    edx,0x1e7
  c132c2:	bt     edx,ecx
  c132c5:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c132cb:	cmp    ecx,0x3
  c132ce:	jne    c14a2e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x510e>
  c132d4:	test   eax,eax
  c132d6:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c132dc:	mov    rax,QWORD PTR [rsp+0x88]
  c132e4:	dec    QWORD PTR [rax]
  c132e7:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c132ed:	jmp    c15f8c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x666c>
  c132f2:	cmp    ecx,0x3
  c132f5:	jne    c14977 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5057>
  c132fb:	test   eax,eax
  c132fd:	je     c1326c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x394c>
  c13303:	mov    rax,QWORD PTR [r14+0x8]
  c13307:	dec    QWORD PTR [rax]
  c1330a:	jne    c1326c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x394c>
  c13310:	lea    rdi,[r14+0x8]
  c13314:	call   QWORD PTR [rip+0x23a576]        # e4d890 <_DYNAMIC+0x248>
  c1331a:	jmp    c1326c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x394c>
  c1331f:	test   cl,0x1
  c13322:	je     c158d1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5fb1>
  c13328:	mov    rsi,QWORD PTR [rax+0x8]
  c1332c:	inc    QWORD PTR [rsi]
  c1332f:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13335:	mov    edx,0x1
  c1333a:	jmp    c1349c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b7c>
  c1333f:	mov    rsi,QWORD PTR [rax+0x8]
  c13343:	inc    QWORD PTR [rsi]
  c13346:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1334c:	movabs rax,0xffffffff00000000
  c13356:	mov    rdx,QWORD PTR [rsp+0x360]
  c1335e:	and    rdx,rax
  c13361:	or     rdx,0xb
  c13365:	jmp    c1373c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e1c>
  c1336a:	mov    r8,QWORD PTR [rcx+0x8]
  c1336e:	inc    QWORD PTR [r8]
  c13371:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13377:	movabs rcx,0xffffffff00000000
  c13381:	mov    r9,QWORD PTR [rsp+0x310]
  c13389:	and    r9,rcx
  c1338c:	or     r9,0xb
  c13390:	jmp    c13944 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4024>
  c13395:	movabs rax,0xffffffff00000000
  c1339f:	mov    rdx,QWORD PTR [rsp+0x360]
  c133a7:	and    rdx,rax
  c133aa:	or     rdx,0x2
  c133ae:	mov    rsi,QWORD PTR [rsp+0x4b8]
  c133b6:	jmp    c1373c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e1c>
  c133bb:	movabs rax,0xffffffff00000000
  c133c5:	mov    rdx,QWORD PTR [rsp+0x360]
  c133cd:	and    rdx,rax
  c133d0:	or     rdx,0x3
  c133d4:	mov    rsi,QWORD PTR [rsp+0x4b8]
  c133dc:	jmp    c1373c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e1c>
  c133e1:	movabs rcx,0xffffffff00000000
  c133eb:	mov    r9,QWORD PTR [rsp+0x310]
  c133f3:	and    r9,rcx
  c133f6:	or     r9,0x2
  c133fa:	mov    r8,QWORD PTR [rsp+0x470]
  c13402:	jmp    c13944 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4024>
  c13407:	movabs rcx,0xffffffff00000000
  c13411:	mov    r9,QWORD PTR [rsp+0x310]
  c13419:	and    r9,rcx
  c1341c:	or     r9,0x3
  c13420:	mov    r8,QWORD PTR [rsp+0x470]
  c13428:	jmp    c13944 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4024>
  c1342d:	test   cl,0x1
  c13430:	je     c158eb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5fcb>
  c13436:	mov    rsi,QWORD PTR [rax+0x8]
  c1343a:	inc    QWORD PTR [rsi]
  c1343d:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13443:	mov    edx,0x1
  c13448:	jmp    c13744 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e24>
  c1344d:	test   dl,0x1
  c13450:	je     c15905 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5fe5>
  c13456:	mov    r8,QWORD PTR [rcx+0x8]
  c1345a:	inc    QWORD PTR [r8]
  c1345d:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13463:	mov    r9d,0x1
  c13469:	jmp    c1394c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x402c>
  c1346e:	mov    rsi,QWORD PTR [rax+0x8]
  c13472:	inc    QWORD PTR [rsi]
  c13475:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1347b:	movabs rax,0xffffffff00000000
  c13485:	mov    rdx,QWORD PTR [rsp+0x358]
  c1348d:	and    rdx,rax
  c13490:	or     rdx,0x6
  c13494:	mov    rax,QWORD PTR [rsp+0x290]
  c1349c:	mov    QWORD PTR [rsp+0x358],rdx
  c134a4:	mov    QWORD PTR [rsp+0x40],rdx
  c134a9:	mov    QWORD PTR [rsp+0x4b0],rsi
  c134b1:	mov    QWORD PTR [rsp+0x48],rsi
  c134b6:	mov    QWORD PTR [rsp+0x290],rax
  c134be:	mov    QWORD PTR [rsp+0x50],rax
  c134c3:	lea    rdi,[rsp+0x120]
  c134cb:	lea    rsi,[rsp+0x40]
  c134d0:	call   QWORD PTR [rip+0x23f99a]        # e52e70 <_DYNAMIC+0x5828>
  c134d6:	movzx  eax,BYTE PTR [rsp+0x120]
  c134de:	cmp    al,0xff
  c134e0:	jne    c174de <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7bbe>
  c134e6:	lea    rdx,[rsp+0x128]
  c134ee:	mov    rax,QWORD PTR [rdx+0x10]
  c134f2:	lea    rcx,[rsp+0x84]
  c134fa:	mov    QWORD PTR [rcx+0x13],rax
  c134fe:	movups xmm0,XMMWORD PTR [rdx]
  c13501:	movups XMMWORD PTR [rcx+0x3],xmm0
  c13505:	movdqu xmm0,XMMWORD PTR [rcx+0x3]
  c1350a:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c13513:	mov    rax,QWORD PTR [rcx+0x13]
  c13517:	mov    QWORD PTR [rsp+0xe0],rax
  c1351f:	mov    eax,DWORD PTR [rsp+0x40]
  c13523:	mov    edx,eax
  c13525:	sub    edx,0x2
  c13528:	mov    ecx,0x3
  c1352d:	cmovae ecx,edx
  c13530:	cmp    ecx,0x8
  c13533:	ja     c148fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4fde>
  c13539:	mov    edx,0x1e7
  c1353e:	bt     edx,ecx
  c13541:	jae    c13623 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d03>
  c13547:	mov    rax,QWORD PTR [rsp+0x20]
  c1354c:	add    rax,0x10
  c13550:	mov    rsi,QWORD PTR [rax]
  c13553:	cmp    rbx,rsi
  c13556:	jae    c19ca8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa388>
  c1355c:	mov    rdx,QWORD PTR [rbp+0x0]
  c13560:	lea    rcx,[rdx+r13*1]
  c13564:	mov    rax,r12
  c13567:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c1356c:	jae    c1357c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c5c>
  c1356e:	mov    rax,QWORD PTR [rcx+0x28]
  c13572:	shl    r12d,0x4
  c13576:	mov    rax,QWORD PTR [rax+r12*1]
  c1357a:	jmp    c13580 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c60>
  c1357c:	add    rax,QWORD PTR [rcx+0x60]
  c13580:	mov    rcx,QWORD PTR [rsp+0x20]
  c13585:	lea    rbx,[rcx+0x10]
  c13589:	mov    r12d,DWORD PTR [rsp+0x30]
  c1358e:	mov    rsi,QWORD PTR [rsp+0x38]
  c13593:	mov    rcx,QWORD PTR [rsi+0x8]
  c13597:	mov    rdx,QWORD PTR [rsp+0xe0]
  c1359f:	mov    QWORD PTR [rsp+0x130],rdx
  c135a7:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c135b0:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c135b9:	cmp    rax,QWORD PTR [rsi+0x10]
  c135bd:	jae    c17f97 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8677>
  c135c3:	lea    rax,[rax+rax*2]
  c135c7:	lea    r14,[rcx+rax*8]
  c135cb:	mov    eax,DWORD PTR [rcx+rax*8]
  c135ce:	mov    edx,eax
  c135d0:	sub    edx,0x2
  c135d3:	mov    ecx,0x3
  c135d8:	cmovae ecx,edx
  c135db:	cmp    ecx,0x8
  c135de:	ja     c149ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x50cc>
  c135e4:	mov    edx,0x1e7
  c135e9:	bt     edx,ecx
  c135ec:	mov    rbp,QWORD PTR [rsp+0x10]
  c135f1:	jae    c13652 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d32>
  c135f3:	mov    rax,QWORD PTR [rsp+0xe0]
  c135fb:	mov    QWORD PTR [r14+0x10],rax
  c135ff:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c13608:	movdqu XMMWORD PTR [r14],xmm0
  c1360d:	mov    rsi,QWORD PTR [rbx]
  c13610:	mov    r14,QWORD PTR [rsp+0x8]
  c13615:	cmp    r14,rsi
  c13618:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c1361e:	jmp    c19d5a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa43a>
  c13623:	cmp    ecx,0x3
  c13626:	jne    c145fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4cdd>
  c1362c:	test   eax,eax
  c1362e:	je     c13547 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c27>
  c13634:	mov    rax,QWORD PTR [rsp+0x48]
  c13639:	dec    QWORD PTR [rax]
  c1363c:	jne    c13547 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c27>
  c13642:	lea    rdi,[rsp+0x48]
  c13647:	call   QWORD PTR [rip+0x23a243]        # e4d890 <_DYNAMIC+0x248>
  c1364d:	jmp    c13547 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c27>
  c13652:	cmp    ecx,0x3
  c13655:	jne    c149b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5094>
  c1365b:	test   eax,eax
  c1365d:	je     c135f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3cd3>
  c1365f:	mov    rax,QWORD PTR [r14+0x8]
  c13663:	dec    QWORD PTR [rax]
  c13666:	jne    c135f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3cd3>
  c13668:	lea    rdi,[r14+0x8]
  c1366c:	call   QWORD PTR [rip+0x23a21e]        # e4d890 <_DYNAMIC+0x248>
  c13672:	jmp    c135f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3cd3>
  c13677:	mov    rax,QWORD PTR [r14+0x8]
  c1367b:	dec    QWORD PTR [rax]
  c1367e:	mov    rbp,QWORD PTR [rsp+0x10]
  c13683:	jne    c10dd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14b8>
  c13689:	lea    rdi,[r14+0x8]
  c1368d:	call   QWORD PTR [rip+0x23a20d]        # e4d8a0 <_DYNAMIC+0x258>
  c13693:	jmp    c10dd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14b8>
  c13698:	mov    rsi,QWORD PTR [rax+0x8]
  c1369c:	inc    QWORD PTR [rsi]
  c1369f:	mov    rbp,QWORD PTR [rsp+0x10]
  c136a4:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c136aa:	movabs rax,0xffffffff00000000
  c136b4:	mov    rdx,QWORD PTR [rsp+0x350]
  c136bc:	and    rdx,rax
  c136bf:	or     rdx,0xb
  c136c3:	jmp    c13a86 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4166>
  c136c8:	movabs rax,0xffffffff00000000
  c136d2:	mov    rdx,QWORD PTR [rsp+0x350]
  c136da:	and    rdx,rax
  c136dd:	or     rdx,0x2
  c136e1:	jmp    c136fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ddc>
  c136e3:	movabs rax,0xffffffff00000000
  c136ed:	mov    rdx,QWORD PTR [rsp+0x350]
  c136f5:	and    rdx,rax
  c136f8:	or     rdx,0x3
  c136fc:	mov    rsi,QWORD PTR [rsp+0x4a8]
  c13704:	mov    rax,QWORD PTR [rsp+0x278]
  c1370c:	mov    rbp,QWORD PTR [rsp+0x10]
  c13711:	jmp    c15932 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6012>
  c13716:	mov    rsi,QWORD PTR [rax+0x8]
  c1371a:	inc    QWORD PTR [rsi]
  c1371d:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13723:	movabs rax,0xffffffff00000000
  c1372d:	mov    rdx,QWORD PTR [rsp+0x360]
  c13735:	and    rdx,rax
  c13738:	or     rdx,0x6
  c1373c:	mov    rax,QWORD PTR [rsp+0x298]
  c13744:	mov    QWORD PTR [rsp+0x360],rdx
  c1374c:	mov    QWORD PTR [rsp+0x40],rdx
  c13751:	mov    QWORD PTR [rsp+0x4b8],rsi
  c13759:	mov    QWORD PTR [rsp+0x48],rsi
  c1375e:	mov    QWORD PTR [rsp+0x298],rax
  c13766:	mov    QWORD PTR [rsp+0x50],rax
  c1376b:	lea    rdi,[rsp+0x120]
  c13773:	lea    rsi,[rsp+0x40]
  c13778:	call   c1abc0 <_RNvCsbxgXiyEKxkX_6bsl_vm6neg_op>
  c1377d:	movzx  eax,BYTE PTR [rsp+0x120]
  c13785:	cmp    al,0xff
  c13787:	jne    c174de <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7bbe>
  c1378d:	lea    rdx,[rsp+0x128]
  c13795:	mov    rax,QWORD PTR [rdx+0x10]
  c13799:	lea    rcx,[rsp+0x84]
  c137a1:	mov    QWORD PTR [rcx+0x13],rax
  c137a5:	movups xmm0,XMMWORD PTR [rdx]
  c137a8:	movups XMMWORD PTR [rcx+0x3],xmm0
  c137ac:	movdqu xmm0,XMMWORD PTR [rcx+0x3]
  c137b1:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c137ba:	mov    rax,QWORD PTR [rcx+0x13]
  c137be:	mov    QWORD PTR [rsp+0xe0],rax
  c137c6:	mov    eax,DWORD PTR [rsp+0x40]
  c137ca:	mov    edx,eax
  c137cc:	sub    edx,0x2
  c137cf:	mov    ecx,0x3
  c137d4:	cmovae ecx,edx
  c137d7:	cmp    ecx,0x8
  c137da:	ja     c1491c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ffc>
  c137e0:	mov    edx,0x1e7
  c137e5:	bt     edx,ecx
  c137e8:	jae    c138ca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3faa>
  c137ee:	mov    rax,QWORD PTR [rsp+0x20]
  c137f3:	add    rax,0x10
  c137f7:	mov    rsi,QWORD PTR [rax]
  c137fa:	cmp    rbx,rsi
  c137fd:	jae    c19c60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa340>
  c13803:	mov    rdx,QWORD PTR [rbp+0x0]
  c13807:	lea    rcx,[rdx+r13*1]
  c1380b:	mov    rax,r12
  c1380e:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c13813:	jae    c13823 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f03>
  c13815:	mov    rax,QWORD PTR [rcx+0x28]
  c13819:	shl    r12d,0x4
  c1381d:	mov    rax,QWORD PTR [rax+r12*1]
  c13821:	jmp    c13827 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f07>
  c13823:	add    rax,QWORD PTR [rcx+0x60]
  c13827:	mov    rcx,QWORD PTR [rsp+0x20]
  c1382c:	lea    rbx,[rcx+0x10]
  c13830:	mov    r12d,DWORD PTR [rsp+0x30]
  c13835:	mov    rsi,QWORD PTR [rsp+0x38]
  c1383a:	mov    rcx,QWORD PTR [rsi+0x8]
  c1383e:	mov    rdx,QWORD PTR [rsp+0xe0]
  c13846:	mov    QWORD PTR [rsp+0x130],rdx
  c1384e:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c13857:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c13860:	cmp    rax,QWORD PTR [rsi+0x10]
  c13864:	jae    c17f9c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x867c>
  c1386a:	lea    rax,[rax+rax*2]
  c1386e:	lea    r14,[rcx+rax*8]
  c13872:	mov    eax,DWORD PTR [rcx+rax*8]
  c13875:	mov    edx,eax
  c13877:	sub    edx,0x2
  c1387a:	mov    ecx,0x3
  c1387f:	cmovae ecx,edx
  c13882:	cmp    ecx,0x8
  c13885:	ja     c14a0d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x50ed>
  c1388b:	mov    edx,0x1e7
  c13890:	bt     edx,ecx
  c13893:	mov    rbp,QWORD PTR [rsp+0x10]
  c13898:	jae    c138f9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3fd9>
  c1389a:	mov    rax,QWORD PTR [rsp+0xe0]
  c138a2:	mov    QWORD PTR [r14+0x10],rax
  c138a6:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c138af:	movdqu XMMWORD PTR [r14],xmm0
  c138b4:	mov    rsi,QWORD PTR [rbx]
  c138b7:	mov    r14,QWORD PTR [rsp+0x8]
  c138bc:	cmp    r14,rsi
  c138bf:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c138c5:	jmp    c19d33 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa413>
  c138ca:	cmp    ecx,0x3
  c138cd:	jne    c1468f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4d6f>
  c138d3:	test   eax,eax
  c138d5:	je     c137ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ece>
  c138db:	mov    rax,QWORD PTR [rsp+0x48]
  c138e0:	dec    QWORD PTR [rax]
  c138e3:	jne    c137ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ece>
  c138e9:	lea    rdi,[rsp+0x48]
  c138ee:	call   QWORD PTR [rip+0x239f9c]        # e4d890 <_DYNAMIC+0x248>
  c138f4:	jmp    c137ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ece>
  c138f9:	cmp    ecx,0x3
  c138fc:	jne    c149d0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x50b0>
  c13902:	test   eax,eax
  c13904:	je     c1389a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f7a>
  c13906:	mov    rax,QWORD PTR [r14+0x8]
  c1390a:	dec    QWORD PTR [rax]
  c1390d:	jne    c1389a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f7a>
  c1390f:	lea    rdi,[r14+0x8]
  c13913:	call   QWORD PTR [rip+0x239f77]        # e4d890 <_DYNAMIC+0x248>
  c13919:	jmp    c1389a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f7a>
  c1391e:	mov    r8,QWORD PTR [rcx+0x8]
  c13922:	inc    QWORD PTR [r8]
  c13925:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1392b:	movabs rcx,0xffffffff00000000
  c13935:	mov    r9,QWORD PTR [rsp+0x310]
  c1393d:	and    r9,rcx
  c13940:	or     r9,0x6
  c13944:	mov    rsi,QWORD PTR [rsp+0x288]
  c1394c:	mov    QWORD PTR [rsp+0x40],r9
  c13951:	mov    QWORD PTR [rsp+0x48],r8
  c13956:	mov    QWORD PTR [rsp+0x288],rsi
  c1395e:	mov    QWORD PTR [rsp+0x50],rsi
  c13963:	mov    rcx,QWORD PTR [rsp+0x20]
  c13968:	add    rcx,0x10
  c1396c:	mov    rsi,QWORD PTR [rcx]
  c1396f:	cmp    rdi,rsi
  c13972:	jae    c19b94 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa274>
  c13978:	mov    rsi,QWORD PTR [r11]
  c1397b:	lea    rdx,[rsi+r10*1]
  c1397f:	movzx  ecx,ax
  c13982:	mov    rax,rcx
  c13985:	sub    rax,QWORD PTR [rsi+r10*1+0x30]
  c1398a:	jae    c13999 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4079>
  c1398c:	mov    rax,QWORD PTR [rdx+0x28]
  c13990:	shl    ecx,0x4
  c13993:	mov    rax,QWORD PTR [rax+rcx*1]
  c13997:	jmp    c1399d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x407d>
  c13999:	add    rax,QWORD PTR [rdx+0x60]
  c1399d:	mov    rcx,QWORD PTR [rsp+0x38]
  c139a2:	cmp    rax,QWORD PTR [rcx+0x10]
  c139a6:	jae    c17a80 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8160>
  c139ac:	mov    QWORD PTR [rsp+0x470],r8
  c139b4:	mov    rdx,QWORD PTR [rcx+0x8]
  c139b8:	lea    rax,[rax+rax*2]
  c139bc:	mov    ecx,DWORD PTR [rdx+rax*8]
  c139bf:	lea    esi,[rcx-0x2]
  c139c2:	cmp    rcx,0x2
  c139c6:	mov    r8d,0x3
  c139cc:	cmovae r8d,esi
  c139d0:	lea    rax,[rdx+rax*8]
  c139d4:	lea    rdx,[rip+0xffffffffff6b2281]        # 2c5c5c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x129b>
  c139db:	movsxd rsi,DWORD PTR [rdx+r8*4]
  c139df:	add    rsi,rdx
  c139e2:	jmp    rsi
  c139e4:	mov    rdx,QWORD PTR [rax]
  c139e7:	mov    r8,QWORD PTR [rax+0x8]
  c139eb:	mov    rax,QWORD PTR [rax+0x10]
  c139ef:	jmp    c146f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4dd8>
  c139f4:	mov    rax,QWORD PTR [r14+0x8]
  c139f8:	dec    QWORD PTR [rax]
  c139fb:	mov    rbp,QWORD PTR [rsp+0x10]
  c13a00:	jne    c10e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x154c>
  c13a06:	lea    rdi,[r14+0x8]
  c13a0a:	call   QWORD PTR [rip+0x239e90]        # e4d8a0 <_DYNAMIC+0x258>
  c13a10:	jmp    c10e6c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x154c>
  c13a15:	test   cl,0x1
  c13a18:	mov    rbp,QWORD PTR [rsp+0x10]
  c13a1d:	je     c1591d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ffd>
  c13a23:	mov    rsi,QWORD PTR [rax+0x8]
  c13a27:	inc    QWORD PTR [rsi]
  c13a2a:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13a30:	mov    edx,0x1
  c13a35:	jmp    c15932 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6012>
  c13a3a:	mov    rax,QWORD PTR [r14+0x8]
  c13a3e:	dec    QWORD PTR [rax]
  c13a41:	mov    rbp,QWORD PTR [rsp+0x10]
  c13a46:	jne    c10f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1654>
  c13a4c:	lea    rdi,[r14+0x8]
  c13a50:	call   QWORD PTR [rip+0x239e4a]        # e4d8a0 <_DYNAMIC+0x258>
  c13a56:	jmp    c10f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1654>
  c13a5b:	mov    rsi,QWORD PTR [rax+0x8]
  c13a5f:	inc    QWORD PTR [rsi]
  c13a62:	mov    rbp,QWORD PTR [rsp+0x10]
  c13a67:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13a6d:	movabs rax,0xffffffff00000000
  c13a77:	mov    rdx,QWORD PTR [rsp+0x350]
  c13a7f:	and    rdx,rax
  c13a82:	or     rdx,0x6
  c13a86:	mov    rax,QWORD PTR [rsp+0x278]
  c13a8e:	jmp    c15932 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6012>
  c13a93:	mov    rbx,QWORD PTR [rax+0x8]
  c13a97:	inc    QWORD PTR [rbx]
  c13a9a:	mov    rdi,QWORD PTR [rsp+0x8]
  c13a9f:	mov    rdx,QWORD PTR [rsp+0x10]
  c13aa4:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13aaa:	movabs rax,0xffffffff00000000
  c13ab4:	mov    r13,QWORD PTR [rsp+0x2e0]
  c13abc:	and    r13,rax
  c13abf:	or     r13,0xb
  c13ac3:	jmp    c13b76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4256>
  c13ac8:	movabs rax,0xffffffff00000000
  c13ad2:	mov    r13,QWORD PTR [rsp+0x2e0]
  c13ada:	and    r13,rax
  c13add:	or     r13,0x2
  c13ae1:	jmp    c13afc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41dc>
  c13ae3:	movabs rax,0xffffffff00000000
  c13aed:	mov    r13,QWORD PTR [rsp+0x2e0]
  c13af5:	and    r13,rax
  c13af8:	or     r13,0x3
  c13afc:	mov    rdi,QWORD PTR [rsp+0x8]
  c13b01:	mov    rbx,QWORD PTR [rsp+0x438]
  c13b09:	mov    r8,QWORD PTR [rsp+0x218]
  c13b11:	mov    rdx,QWORD PTR [rsp+0x10]
  c13b16:	jmp    c15a99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6179>
  c13b1b:	test   cl,0x1
  c13b1e:	mov    rdi,QWORD PTR [rsp+0x8]
  c13b23:	mov    rdx,QWORD PTR [rsp+0x10]
  c13b28:	je     c15a86 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6166>
  c13b2e:	mov    rbx,QWORD PTR [rax+0x8]
  c13b32:	inc    QWORD PTR [rbx]
  c13b35:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13b3b:	mov    r13d,0x1
  c13b41:	jmp    c15a99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6179>
  c13b46:	mov    rbx,QWORD PTR [rax+0x8]
  c13b4a:	inc    QWORD PTR [rbx]
  c13b4d:	mov    rdi,QWORD PTR [rsp+0x8]
  c13b52:	mov    rdx,QWORD PTR [rsp+0x10]
  c13b57:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13b5d:	movabs rax,0xffffffff00000000
  c13b67:	mov    r13,QWORD PTR [rsp+0x2e0]
  c13b6f:	and    r13,rax
  c13b72:	or     r13,0x6
  c13b76:	mov    r8,QWORD PTR [rsp+0x218]
  c13b7e:	jmp    c15a99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6179>
  c13b83:	mov    rcx,QWORD PTR [rax+0x8]
  c13b87:	inc    QWORD PTR [rcx]
  c13b8a:	mov    rbp,QWORD PTR [rsp+0x10]
  c13b8f:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13b95:	movabs rax,0xffffffff00000000
  c13b9f:	mov    rdx,QWORD PTR [rsp+0x2d8]
  c13ba7:	and    rdx,rax
  c13baa:	or     rdx,0xb
  c13bae:	jmp    c13c51 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4331>
  c13bb3:	movabs rax,0xffffffff00000000
  c13bbd:	mov    rdx,QWORD PTR [rsp+0x2d8]
  c13bc5:	and    rdx,rax
  c13bc8:	or     rdx,0x2
  c13bcc:	jmp    c13be7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x42c7>
  c13bce:	movabs rax,0xffffffff00000000
  c13bd8:	mov    rdx,QWORD PTR [rsp+0x2d8]
  c13be0:	and    rdx,rax
  c13be3:	or     rdx,0x3
  c13be7:	mov    rcx,QWORD PTR [rsp+0x430]
  c13bef:	mov    rax,QWORD PTR [rsp+0x1d8]
  c13bf7:	mov    rbp,QWORD PTR [rsp+0x10]
  c13bfc:	jmp    c15c20 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6300>
  c13c01:	test   cl,0x1
  c13c04:	mov    rbp,QWORD PTR [rsp+0x10]
  c13c09:	je     c15c08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62e8>
  c13c0f:	mov    rcx,QWORD PTR [rax+0x8]
  c13c13:	inc    QWORD PTR [rcx]
  c13c16:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13c1c:	mov    edx,0x1
  c13c21:	jmp    c15c1d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62fd>
  c13c26:	mov    rcx,QWORD PTR [rax+0x8]
  c13c2a:	inc    QWORD PTR [rcx]
  c13c2d:	mov    rbp,QWORD PTR [rsp+0x10]
  c13c32:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13c38:	movabs rax,0xffffffff00000000
  c13c42:	mov    rdx,QWORD PTR [rsp+0x2d8]
  c13c4a:	and    rdx,rax
  c13c4d:	or     rdx,0x6
  c13c51:	mov    rax,QWORD PTR [rsp+0x1d8]
  c13c59:	jmp    c15c20 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6300>
  c13c5e:	mov    rdi,QWORD PTR [rcx+0x8]
  c13c62:	inc    QWORD PTR [rdi]
  c13c65:	mov    rbp,QWORD PTR [rsp+0x10]
  c13c6a:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13c70:	movabs rcx,0xffffffff00000000
  c13c7a:	mov    rsi,QWORD PTR [rsp+0x2d0]
  c13c82:	and    rsi,rcx
  c13c85:	or     rsi,0xb
  c13c89:	jmp    c13d2c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x440c>
  c13c8e:	movabs rcx,0xffffffff00000000
  c13c98:	mov    rsi,QWORD PTR [rsp+0x2d0]
  c13ca0:	and    rsi,rcx
  c13ca3:	or     rsi,0x2
  c13ca7:	jmp    c13cc2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x43a2>
  c13ca9:	movabs rcx,0xffffffff00000000
  c13cb3:	mov    rsi,QWORD PTR [rsp+0x2d0]
  c13cbb:	and    rsi,rcx
  c13cbe:	or     rsi,0x3
  c13cc2:	mov    rdi,QWORD PTR [rsp+0x428]
  c13cca:	mov    rcx,QWORD PTR [rsp+0x210]
  c13cd2:	mov    rbp,QWORD PTR [rsp+0x10]
  c13cd7:	jmp    c15d1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63fa>
  c13cdc:	test   dl,0x1
  c13cdf:	mov    rbp,QWORD PTR [rsp+0x10]
  c13ce4:	je     c15d05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63e5>
  c13cea:	mov    rdi,QWORD PTR [rcx+0x8]
  c13cee:	inc    QWORD PTR [rdi]
  c13cf1:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13cf7:	mov    esi,0x1
  c13cfc:	jmp    c15d1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63fa>
  c13d01:	mov    rdi,QWORD PTR [rcx+0x8]
  c13d05:	inc    QWORD PTR [rdi]
  c13d08:	mov    rbp,QWORD PTR [rsp+0x10]
  c13d0d:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13d13:	movabs rcx,0xffffffff00000000
  c13d1d:	mov    rsi,QWORD PTR [rsp+0x2d0]
  c13d25:	and    rsi,rcx
  c13d28:	or     rsi,0x6
  c13d2c:	mov    rcx,QWORD PTR [rsp+0x210]
  c13d34:	jmp    c15d1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63fa>
  c13d39:	mov    rdi,QWORD PTR [rcx+0x8]
  c13d3d:	inc    QWORD PTR [rdi]
  c13d40:	mov    rbp,QWORD PTR [rsp+0x10]
  c13d45:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13d4b:	movabs rcx,0xffffffff00000000
  c13d55:	mov    rsi,QWORD PTR [rsp+0x2c8]
  c13d5d:	and    rsi,rcx
  c13d60:	or     rsi,0xb
  c13d64:	jmp    c13e07 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44e7>
  c13d69:	movabs rcx,0xffffffff00000000
  c13d73:	mov    rsi,QWORD PTR [rsp+0x2c8]
  c13d7b:	and    rsi,rcx
  c13d7e:	or     rsi,0x2
  c13d82:	jmp    c13d9d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x447d>
  c13d84:	movabs rcx,0xffffffff00000000
  c13d8e:	mov    rsi,QWORD PTR [rsp+0x2c8]
  c13d96:	and    rsi,rcx
  c13d99:	or     rsi,0x3
  c13d9d:	mov    rdi,QWORD PTR [rsp+0x420]
  c13da5:	mov    rcx,QWORD PTR [rsp+0x208]
  c13dad:	mov    rbp,QWORD PTR [rsp+0x10]
  c13db2:	jmp    c15e71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6551>
  c13db7:	test   dl,0x1
  c13dba:	mov    rbp,QWORD PTR [rsp+0x10]
  c13dbf:	je     c15e5c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x653c>
  c13dc5:	mov    rdi,QWORD PTR [rcx+0x8]
  c13dc9:	inc    QWORD PTR [rdi]
  c13dcc:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13dd2:	mov    esi,0x1
  c13dd7:	jmp    c15e71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6551>
  c13ddc:	mov    rdi,QWORD PTR [rcx+0x8]
  c13de0:	inc    QWORD PTR [rdi]
  c13de3:	mov    rbp,QWORD PTR [rsp+0x10]
  c13de8:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13dee:	movabs rcx,0xffffffff00000000
  c13df8:	mov    rsi,QWORD PTR [rsp+0x2c8]
  c13e00:	and    rsi,rcx
  c13e03:	or     rsi,0x6
  c13e07:	mov    rcx,QWORD PTR [rsp+0x208]
  c13e0f:	jmp    c15e71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6551>
  c13e14:	mov    rax,QWORD PTR [rcx+0x8]
  c13e18:	inc    QWORD PTR [rax]
  c13e1b:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13e21:	movq   xmm0,rax
  c13e26:	mov    eax,0xb
  c13e2b:	jmp    c16001 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66e1>
  c13e30:	mov    eax,0x2
  c13e35:	jmp    c13e3c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x451c>
  c13e37:	mov    eax,0x3
  c13e3c:	jmp    c16001 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66e1>
  c13e41:	mov    rax,QWORD PTR [rcx+0x8]
  c13e45:	inc    QWORD PTR [rax]
  c13e48:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13e4e:	movq   xmm0,rax
  c13e53:	mov    eax,0xb
  c13e58:	jmp    c162bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x699b>
  c13e5d:	mov    eax,0x2
  c13e62:	jmp    c13e69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4549>
  c13e64:	mov    eax,0x3
  c13e69:	jmp    c162bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x699b>
  c13e6e:	mov    rax,QWORD PTR [rcx+0x8]
  c13e72:	inc    QWORD PTR [rax]
  c13e75:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13e7b:	movq   xmm0,rax
  c13e80:	mov    eax,0xb
  c13e85:	jmp    c16560 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c40>
  c13e8a:	mov    eax,0x2
  c13e8f:	jmp    c13e96 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4576>
  c13e91:	mov    eax,0x3
  c13e96:	jmp    c16560 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c40>
  c13e9b:	test   dl,0x1
  c13e9e:	je     c15fe1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c1>
  c13ea4:	mov    rsi,QWORD PTR [rcx+0x8]
  c13ea8:	inc    QWORD PTR [rsi]
  c13eab:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13eb1:	mov    eax,0x1
  c13eb6:	jmp    c15ff3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66d3>
  c13ebb:	test   dl,0x1
  c13ebe:	je     c1629b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x697b>
  c13ec4:	mov    rsi,QWORD PTR [rcx+0x8]
  c13ec8:	inc    QWORD PTR [rsi]
  c13ecb:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13ed1:	mov    eax,0x1
  c13ed6:	jmp    c162ad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x698d>
  c13edb:	test   dl,0x1
  c13ede:	je     c16540 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c20>
  c13ee4:	mov    rsi,QWORD PTR [rcx+0x8]
  c13ee8:	inc    QWORD PTR [rsi]
  c13eeb:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13ef1:	mov    eax,0x1
  c13ef6:	jmp    c16552 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c32>
  c13efb:	mov    rax,QWORD PTR [rcx+0x8]
  c13eff:	inc    QWORD PTR [rax]
  c13f02:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13f08:	movq   xmm0,rax
  c13f0d:	mov    eax,0x6
  c13f12:	jmp    c16001 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66e1>
  c13f17:	mov    rax,QWORD PTR [rcx+0x8]
  c13f1b:	inc    QWORD PTR [rax]
  c13f1e:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13f24:	movq   xmm0,rax
  c13f29:	mov    eax,0x6
  c13f2e:	jmp    c162bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x699b>
  c13f33:	mov    rax,QWORD PTR [rcx+0x8]
  c13f37:	inc    QWORD PTR [rax]
  c13f3a:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13f40:	movq   xmm0,rax
  c13f45:	mov    eax,0xb
  c13f4a:	jmp    c16805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ee5>
  c13f4f:	mov    rax,QWORD PTR [rcx+0x8]
  c13f53:	inc    QWORD PTR [rax]
  c13f56:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13f5c:	movq   xmm0,rax
  c13f61:	mov    eax,0x6
  c13f66:	jmp    c16560 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c40>
  c13f6b:	mov    eax,0x2
  c13f70:	jmp    c13f77 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4657>
  c13f72:	mov    eax,0x3
  c13f77:	jmp    c16805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ee5>
  c13f7c:	mov    rax,QWORD PTR [r14+0x8]
  c13f80:	dec    QWORD PTR [rax]
  c13f83:	jne    c1186c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f4c>
  c13f89:	lea    rdi,[r14+0x8]
  c13f8d:	call   QWORD PTR [rip+0x239905]        # e4d898 <_DYNAMIC+0x250>
  c13f93:	jmp    c1186c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f4c>
  c13f98:	test   dl,0x1
  c13f9b:	je     c167e5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ec5>
  c13fa1:	mov    rsi,QWORD PTR [rcx+0x8]
  c13fa5:	inc    QWORD PTR [rsi]
  c13fa8:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13fae:	mov    eax,0x1
  c13fb3:	jmp    c167f7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ed7>
  c13fb8:	mov    rax,QWORD PTR [r14+0x8]
  c13fbc:	dec    QWORD PTR [rax]
  c13fbf:	jne    c12ae6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31c6>
  c13fc5:	lea    rdi,[r14+0x8]
  c13fc9:	call   QWORD PTR [rip+0x2398c9]        # e4d898 <_DYNAMIC+0x250>
  c13fcf:	jmp    c12ae6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31c6>
  c13fd4:	mov    rax,QWORD PTR [rcx+0x8]
  c13fd8:	inc    QWORD PTR [rax]
  c13fdb:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c13fe1:	movq   xmm0,rax
  c13fe6:	mov    eax,0x6
  c13feb:	jmp    c16805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ee5>
  c13ff0:	mov    rax,QWORD PTR [r14+0x8]
  c13ff4:	dec    QWORD PTR [rax]
  c13ff7:	mov    rbp,QWORD PTR [rsp+0x10]
  c13ffc:	jne    c1186c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f4c>
  c14002:	lea    rdi,[r14+0x8]
  c14006:	call   QWORD PTR [rip+0x239894]        # e4d8a0 <_DYNAMIC+0x258>
  c1400c:	jmp    c1186c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f4c>
  c14011:	mov    rax,QWORD PTR [r14+0x8]
  c14015:	dec    QWORD PTR [rax]
  c14018:	jne    c12ae6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31c6>
  c1401e:	lea    rdi,[r14+0x8]
  c14022:	call   QWORD PTR [rip+0x239878]        # e4d8a0 <_DYNAMIC+0x258>
  c14028:	jmp    c12ae6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x31c6>
  c1402d:	mov    r8,QWORD PTR [rax+0x8]
  c14031:	inc    QWORD PTR [r8]
  c14034:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1403a:	movabs rax,0xffffffff00000000
  c14044:	mov    rdx,QWORD PTR [rsp+0x2e8]
  c1404c:	and    rdx,rax
  c1404f:	or     rdx,0xb
  c14053:	jmp    c1410f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ef>
  c14058:	movabs rax,0xffffffff00000000
  c14062:	mov    rdx,QWORD PTR [rsp+0x2e8]
  c1406a:	and    rdx,rax
  c1406d:	or     rdx,0x2
  c14071:	mov    r8,QWORD PTR [rsp+0x440]
  c14079:	jmp    c1410f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ef>
  c1407e:	movabs rax,0xffffffff00000000
  c14088:	mov    rdx,QWORD PTR [rsp+0x2e8]
  c14090:	and    rdx,rax
  c14093:	or     rdx,0x3
  c14097:	mov    r8,QWORD PTR [rsp+0x440]
  c1409f:	jmp    c1410f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ef>
  c140a1:	test   cl,0x1
  c140a4:	je     c16bb3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7293>
  c140aa:	mov    r8,QWORD PTR [rax+0x8]
  c140ae:	inc    QWORD PTR [r8]
  c140b1:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c140b7:	mov    edx,0x1
  c140bc:	jmp    c14117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47f7>
  c140be:	mov    rsi,QWORD PTR [rax+0x8]
  c140c2:	inc    QWORD PTR [rsi]
  c140c5:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c140cb:	movabs rax,0xffffffff00000000
  c140d5:	mov    rdx,QWORD PTR [rsp+0x300]
  c140dd:	and    rdx,rax
  c140e0:	or     rdx,0xb
  c140e4:	jmp    c143a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a88>
  c140e9:	mov    r8,QWORD PTR [rax+0x8]
  c140ed:	inc    QWORD PTR [r8]
  c140f0:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c140f6:	movabs rax,0xffffffff00000000
  c14100:	mov    rdx,QWORD PTR [rsp+0x2e8]
  c14108:	and    rdx,rax
  c1410b:	or     rdx,0x6
  c1410f:	mov    rax,QWORD PTR [rsp+0x230]
  c14117:	mov    QWORD PTR [rsp+0x80],rdx
  c1411f:	mov    QWORD PTR [rsp+0x88],r8
  c14127:	mov    QWORD PTR [rsp+0x230],rax
  c1412f:	mov    QWORD PTR [rsp+0x90],rax
  c14137:	mov    rax,QWORD PTR [rsp+0x20]
  c1413c:	add    rax,0x10
  c14140:	mov    rsi,QWORD PTR [rax]
  c14143:	cmp    rdi,rsi
  c14146:	jae    c19ccd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3ad>
  c1414c:	mov    rcx,QWORD PTR [r11]
  c1414f:	lea    rax,[rcx+r10*1]
  c14153:	mov    rbx,r12
  c14156:	sub    rbx,QWORD PTR [rcx+r10*1+0x30]
  c1415b:	mov    QWORD PTR [rsp+0x308],r9
  c14163:	mov    QWORD PTR [rsp+0x2e8],rdx
  c1416b:	mov    QWORD PTR [rsp+0x440],r8
  c14173:	mov    r13,r15
  c14176:	jae    c14186 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4866>
  c14178:	mov    rax,QWORD PTR [rax+0x28]
  c1417c:	shl    r12d,0x4
  c14180:	mov    rbx,QWORD PTR [rax+r12*1]
  c14184:	jmp    c1418a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x486a>
  c14186:	add    rbx,QWORD PTR [rax+0x60]
  c1418a:	mov    r12,QWORD PTR [rsp+0x20]
  c1418f:	lea    rbp,[r12+0x10]
  c14194:	mov    rax,QWORD PTR [rsp+0x38]
  c14199:	mov    r15,QWORD PTR [rax+0x8]
  c1419d:	mov    r14,QWORD PTR [rax+0x10]
  c141a1:	lea    rdi,[rsp+0x40]
  c141a6:	lea    rsi,[rsp+0x80]
  c141ae:	call   QWORD PTR [rip+0x23ecc4]        # e52e78 <_DYNAMIC+0x5830>
  c141b4:	xor    al,0x1
  c141b6:	mov    BYTE PTR [rsp+0x124],al
  c141bd:	mov    DWORD PTR [rsp+0x120],0x4
  c141c8:	cmp    rbx,r14
  c141cb:	jae    c181ba <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x889a>
  c141d1:	lea    rax,[rbx+rbx*2]
  c141d5:	lea    r14,[r15+rax*8]
  c141d9:	mov    eax,DWORD PTR [r15+rax*8]
  c141dd:	mov    edx,eax
  c141df:	sub    edx,0x2
  c141e2:	mov    ecx,0x3
  c141e7:	cmovae ecx,edx
  c141ea:	cmp    ecx,0x8
  c141ed:	ja     c14a9a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x517a>
  c141f3:	mov    edx,0x1e7
  c141f8:	bt     edx,ecx
  c141fb:	mov    r15,r13
  c141fe:	mov    r12d,DWORD PTR [rsp+0x30]
  c14203:	mov    r13,QWORD PTR [rsp+0x28]
  c14208:	mov    rbx,rbp
  c1420b:	jae    c142bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x499d>
  c14211:	mov    rax,QWORD PTR [rsp+0x130]
  c14219:	mov    QWORD PTR [r14+0x10],rax
  c1421d:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c14226:	movdqu XMMWORD PTR [r14],xmm0
  c1422b:	mov    rsi,QWORD PTR [rbx]
  c1422e:	mov    r14,QWORD PTR [rsp+0x8]
  c14233:	cmp    r14,rsi
  c14236:	jae    c19d8f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa46f>
  c1423c:	mov    rbp,QWORD PTR [rsp+0x10]
  c14241:	mov    rax,QWORD PTR [rbp+0x0]
  c14245:	inc    QWORD PTR [rax+r13*1+0x58]
  c1424a:	mov    eax,DWORD PTR [rsp+0x80]
  c14251:	mov    edx,eax
  c14253:	sub    edx,0x2
  c14256:	mov    ecx,0x3
  c1425b:	cmovae ecx,edx
  c1425e:	cmp    ecx,0x8
  c14261:	ja     c14b3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x521a>
  c14267:	mov    edx,0x1e7
  c1426c:	bt     edx,ecx
  c1426f:	jae    c142ea <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x49ca>
  c14271:	mov    eax,DWORD PTR [rsp+0x40]
  c14275:	mov    edx,eax
  c14277:	sub    edx,0x2
  c1427a:	mov    ecx,0x3
  c1427f:	cmovae ecx,edx
  c14282:	cmp    ecx,0x8
  c14285:	ja     c14bb2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5292>
  c1428b:	mov    edx,0x1e7
  c14290:	bt     edx,ecx
  c14293:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14299:	cmp    ecx,0x3
  c1429c:	jne    c14b82 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5262>
  c142a2:	test   eax,eax
  c142a4:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c142aa:	mov    rax,QWORD PTR [rsp+0x48]
  c142af:	dec    QWORD PTR [rax]
  c142b2:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c142b8:	jmp    c1521e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58fe>
  c142bd:	cmp    ecx,0x3
  c142c0:	jne    c14a62 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5142>
  c142c6:	test   eax,eax
  c142c8:	je     c14211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x48f1>
  c142ce:	mov    rax,QWORD PTR [r14+0x8]
  c142d2:	dec    QWORD PTR [rax]
  c142d5:	jne    c14211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x48f1>
  c142db:	lea    rdi,[r14+0x8]
  c142df:	call   QWORD PTR [rip+0x2395ab]        # e4d890 <_DYNAMIC+0x248>
  c142e5:	jmp    c14211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x48f1>
  c142ea:	cmp    ecx,0x3
  c142ed:	jne    c14af2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51d2>
  c142f3:	test   eax,eax
  c142f5:	je     c14271 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4951>
  c142fb:	mov    rax,QWORD PTR [rsp+0x88]
  c14303:	dec    QWORD PTR [rax]
  c14306:	jne    c14271 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4951>
  c1430c:	lea    rdi,[rsp+0x88]
  c14314:	call   QWORD PTR [rip+0x239576]        # e4d890 <_DYNAMIC+0x248>
  c1431a:	jmp    c14271 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4951>
  c1431f:	movabs rax,0xffffffff00000000
  c14329:	mov    rdx,QWORD PTR [rsp+0x300]
  c14331:	and    rdx,rax
  c14334:	or     rdx,0x2
  c14338:	mov    rsi,QWORD PTR [rsp+0x458]
  c14340:	jmp    c143a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a88>
  c14342:	movabs rax,0xffffffff00000000
  c1434c:	mov    rdx,QWORD PTR [rsp+0x300]
  c14354:	and    rdx,rax
  c14357:	or     rdx,0x3
  c1435b:	mov    rsi,QWORD PTR [rsp+0x458]
  c14363:	jmp    c143a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a88>
  c14365:	test   cl,0x1
  c14368:	je     c16bcd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72ad>
  c1436e:	mov    rsi,QWORD PTR [rax+0x8]
  c14372:	inc    QWORD PTR [rsi]
  c14375:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1437b:	mov    edx,0x1
  c14380:	jmp    c143b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a90>
  c14382:	mov    rsi,QWORD PTR [rax+0x8]
  c14386:	inc    QWORD PTR [rsi]
  c14389:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1438f:	movabs rax,0xffffffff00000000
  c14399:	mov    rdx,QWORD PTR [rsp+0x300]
  c143a1:	and    rdx,rax
  c143a4:	or     rdx,0x6
  c143a8:	mov    rdi,QWORD PTR [rsp+0x228]
  c143b0:	mov    QWORD PTR [rsp+0x300],rdx
  c143b8:	mov    QWORD PTR [rsp+0xd0],rdx
  c143c0:	mov    QWORD PTR [rsp+0x458],rsi
  c143c8:	mov    QWORD PTR [rsp+0xd8],rsi
  c143d0:	mov    QWORD PTR [rsp+0x228],rdi
  c143d8:	mov    QWORD PTR [rsp+0xe0],rdi
  c143e0:	lea    rdi,[rsp+0x120]
  c143e8:	lea    rsi,[rsp+0x100]
  c143f0:	lea    rdx,[rsp+0xd0]
  c143f8:	mov    rcx,QWORD PTR [rsp+0x630]
  c14400:	call   QWORD PTR [rip+0x23d9e2]        # e51de8 <_DYNAMIC+0x47a0>
  c14406:	movzx  eax,BYTE PTR [rsp+0x120]
  c1440e:	cmp    al,0xff
  c14410:	jne    c1812c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x880c>
  c14416:	lea    rdx,[rsp+0x124]
  c1441e:	mov    rax,QWORD PTR [rdx+0x14]
  c14422:	lea    rcx,[rsp+0x84]
  c1442a:	mov    QWORD PTR [rcx+0x13],rax
  c1442e:	movups xmm0,XMMWORD PTR [rdx+0x4]
  c14432:	movups XMMWORD PTR [rcx+0x3],xmm0
  c14436:	movdqu xmm0,XMMWORD PTR [rcx+0x3]
  c1443b:	movdqa XMMWORD PTR [rsp+0x40],xmm0
  c14441:	mov    rax,QWORD PTR [rcx+0x13]
  c14445:	mov    QWORD PTR [rsp+0x50],rax
  c1444a:	mov    rax,QWORD PTR [rsp+0x20]
  c1444f:	add    rax,0x10
  c14453:	mov    rsi,QWORD PTR [rax]
  c14456:	cmp    rbx,rsi
  c14459:	jae    c19d1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3fe>
  c1445f:	mov    rdx,QWORD PTR [rbp+0x0]
  c14463:	lea    rcx,[rdx+r13*1]
  c14467:	mov    rax,r12
  c1446a:	sub    rax,QWORD PTR [rdx+r13*1+0x30]
  c1446f:	jae    c1447f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4b5f>
  c14471:	mov    rax,QWORD PTR [rcx+0x28]
  c14475:	shl    r12d,0x4
  c14479:	mov    rax,QWORD PTR [rax+r12*1]
  c1447d:	jmp    c14483 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4b63>
  c1447f:	add    rax,QWORD PTR [rcx+0x60]
  c14483:	mov    rcx,QWORD PTR [rsp+0x20]
  c14488:	lea    rbx,[rcx+0x10]
  c1448c:	mov    r12d,DWORD PTR [rsp+0x30]
  c14491:	mov    rsi,QWORD PTR [rsp+0x38]
  c14496:	mov    rcx,QWORD PTR [rsi+0x8]
  c1449a:	mov    rdx,QWORD PTR [rsp+0x50]
  c1449f:	mov    QWORD PTR [rsp+0x130],rdx
  c144a7:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c144ad:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c144b6:	cmp    rax,QWORD PTR [rsi+0x10]
  c144ba:	jae    c184df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bbf>
  c144c0:	lea    rax,[rax+rax*2]
  c144c4:	lea    r14,[rcx+rax*8]
  c144c8:	mov    eax,DWORD PTR [rcx+rax*8]
  c144cb:	mov    edx,eax
  c144cd:	sub    edx,0x2
  c144d0:	mov    ecx,0x3
  c144d5:	cmovae ecx,edx
  c144d8:	cmp    ecx,0x8
  c144db:	ja     c14bf4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x52d4>
  c144e1:	mov    edx,0x1e7
  c144e6:	bt     edx,ecx
  c144e9:	mov    rbp,QWORD PTR [rsp+0x10]
  c144ee:	jae    c1459b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c7b>
  c144f4:	mov    rax,QWORD PTR [rsp+0x50]
  c144f9:	mov    QWORD PTR [r14+0x10],rax
  c144fd:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c14503:	movdqu XMMWORD PTR [r14],xmm0
  c14508:	mov    rsi,QWORD PTR [rbx]
  c1450b:	mov    r14,QWORD PTR [rsp+0x8]
  c14510:	cmp    r14,rsi
  c14513:	jae    c19e24 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa504>
  c14519:	mov    rax,QWORD PTR [rbp+0x0]
  c1451d:	inc    QWORD PTR [rax+r13*1+0x58]
  c14522:	mov    eax,DWORD PTR [rsp+0xd0]
  c14529:	mov    edx,eax
  c1452b:	sub    edx,0x2
  c1452e:	mov    ecx,0x3
  c14533:	cmovae ecx,edx
  c14536:	cmp    ecx,0x8
  c14539:	ja     c14c39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5319>
  c1453f:	mov    edx,0x1e7
  c14544:	bt     edx,ecx
  c14547:	jae    c145c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ca8>
  c14549:	mov    eax,DWORD PTR [rsp+0x100]
  c14550:	mov    edx,eax
  c14552:	sub    edx,0x2
  c14555:	mov    ecx,0x3
  c1455a:	cmovae ecx,edx
  c1455d:	cmp    ecx,0x8
  c14560:	ja     c14c73 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5353>
  c14566:	mov    edx,0x1e7
  c1456b:	bt     edx,ecx
  c1456e:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14574:	cmp    ecx,0x3
  c14577:	jne    c14c5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x533d>
  c1457d:	test   eax,eax
  c1457f:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14585:	mov    rax,QWORD PTR [rsp+0x108]
  c1458d:	dec    QWORD PTR [rax]
  c14590:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14596:	jmp    c16dad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x748d>
  c1459b:	cmp    ecx,0x3
  c1459e:	jne    c14bd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x52b8>
  c145a4:	test   eax,eax
  c145a6:	je     c144f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4bd4>
  c145ac:	mov    rax,QWORD PTR [r14+0x8]
  c145b0:	dec    QWORD PTR [rax]
  c145b3:	jne    c144f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4bd4>
  c145b9:	lea    rdi,[r14+0x8]
  c145bd:	call   QWORD PTR [rip+0x2392cd]        # e4d890 <_DYNAMIC+0x248>
  c145c3:	jmp    c144f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4bd4>
  c145c8:	cmp    ecx,0x3
  c145cb:	jne    c14c15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x52f5>
  c145d1:	test   eax,eax
  c145d3:	je     c14549 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c29>
  c145d9:	mov    rax,QWORD PTR [rsp+0xd8]
  c145e1:	dec    QWORD PTR [rax]
  c145e4:	jne    c14549 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c29>
  c145ea:	lea    rdi,[rsp+0xd8]
  c145f2:	call   QWORD PTR [rip+0x239298]        # e4d890 <_DYNAMIC+0x248>
  c145f8:	jmp    c14549 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c29>
  c145fd:	mov    rax,QWORD PTR [rsp+0x48]
  c14602:	dec    QWORD PTR [rax]
  c14605:	jne    c13547 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c27>
  c1460b:	lea    rdi,[rsp+0x48]
  c14610:	call   QWORD PTR [rip+0x239282]        # e4d898 <_DYNAMIC+0x250>
  c14616:	jmp    c13547 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c27>
  c1461b:	mov    r8,QWORD PTR [rax+0x8]
  c1461f:	inc    QWORD PTR [r8]
  c14622:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c14628:	movabs rax,0xffffffff00000000
  c14632:	mov    rdx,QWORD PTR [rsp+0x2f0]
  c1463a:	and    rdx,rax
  c1463d:	or     rdx,0xb
  c14641:	jmp    c146f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4dd0>
  c14646:	movabs rax,0xffffffff00000000
  c14650:	mov    rdx,QWORD PTR [rsp+0x2f0]
  c14658:	and    rdx,rax
  c1465b:	or     rdx,0x2
  c1465f:	mov    r8,QWORD PTR [rsp+0x448]
  c14667:	jmp    c146f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4dd0>
  c1466c:	movabs rax,0xffffffff00000000
  c14676:	mov    rdx,QWORD PTR [rsp+0x2f0]
  c1467e:	and    rdx,rax
  c14681:	or     rdx,0x3
  c14685:	mov    r8,QWORD PTR [rsp+0x448]
  c1468d:	jmp    c146f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4dd0>
  c1468f:	mov    rax,QWORD PTR [rsp+0x48]
  c14694:	dec    QWORD PTR [rax]
  c14697:	jne    c137ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ece>
  c1469d:	lea    rdi,[rsp+0x48]
  c146a2:	call   QWORD PTR [rip+0x2391f0]        # e4d898 <_DYNAMIC+0x250>
  c146a8:	jmp    c137ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ece>
  c146ad:	test   cl,0x1
  c146b0:	je     c16be4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72c4>
  c146b6:	mov    r8,QWORD PTR [rax+0x8]
  c146ba:	inc    QWORD PTR [r8]
  c146bd:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c146c3:	mov    edx,0x1
  c146c8:	jmp    c146f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4dd8>
  c146ca:	mov    r8,QWORD PTR [rax+0x8]
  c146ce:	inc    QWORD PTR [r8]
  c146d1:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c146d7:	movabs rax,0xffffffff00000000
  c146e1:	mov    rdx,QWORD PTR [rsp+0x2f0]
  c146e9:	and    rdx,rax
  c146ec:	or     rdx,0x6
  c146f0:	mov    rax,QWORD PTR [rsp+0x238]
  c146f8:	mov    QWORD PTR [rsp+0x80],rdx
  c14700:	mov    QWORD PTR [rsp+0x88],r8
  c14708:	mov    QWORD PTR [rsp+0x238],rax
  c14710:	mov    QWORD PTR [rsp+0x90],rax
  c14718:	mov    rax,QWORD PTR [rsp+0x20]
  c1471d:	add    rax,0x10
  c14721:	mov    rsi,QWORD PTR [rax]
  c14724:	cmp    rdi,rsi
  c14727:	jae    c19cd9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3b9>
  c1472d:	mov    rcx,QWORD PTR [r11]
  c14730:	lea    rax,[rcx+r10*1]
  c14734:	mov    rbx,r12
  c14737:	sub    rbx,QWORD PTR [rcx+r10*1+0x30]
  c1473c:	mov    QWORD PTR [rsp+0x310],r9
  c14744:	mov    QWORD PTR [rsp+0x2f0],rdx
  c1474c:	mov    QWORD PTR [rsp+0x448],r8
  c14754:	mov    r13,r15
  c14757:	jae    c14767 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4e47>
  c14759:	mov    rax,QWORD PTR [rax+0x28]
  c1475d:	shl    r12d,0x4
  c14761:	mov    rbx,QWORD PTR [rax+r12*1]
  c14765:	jmp    c1476b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4e4b>
  c14767:	add    rbx,QWORD PTR [rax+0x60]
  c1476b:	mov    r12,QWORD PTR [rsp+0x20]
  c14770:	lea    rbp,[r12+0x10]
  c14775:	mov    rax,QWORD PTR [rsp+0x38]
  c1477a:	mov    r15,QWORD PTR [rax+0x8]
  c1477e:	mov    r14,QWORD PTR [rax+0x10]
  c14782:	lea    rdi,[rsp+0x40]
  c14787:	lea    rsi,[rsp+0x80]
  c1478f:	call   QWORD PTR [rip+0x23e6e3]        # e52e78 <_DYNAMIC+0x5830>
  c14795:	mov    BYTE PTR [rsp+0x124],al
  c1479c:	mov    DWORD PTR [rsp+0x120],0x4
  c147a7:	cmp    rbx,r14
  c147aa:	jae    c18180 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8860>
  c147b0:	lea    rax,[rbx+rbx*2]
  c147b4:	lea    r14,[r15+rax*8]
  c147b8:	mov    eax,DWORD PTR [r15+rax*8]
  c147bc:	mov    edx,eax
  c147be:	sub    edx,0x2
  c147c1:	mov    ecx,0x3
  c147c6:	cmovae ecx,edx
  c147c9:	cmp    ecx,0x8
  c147cc:	ja     c14ac6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51a6>
  c147d2:	mov    edx,0x1e7
  c147d7:	bt     edx,ecx
  c147da:	mov    r15,r13
  c147dd:	mov    r12d,DWORD PTR [rsp+0x30]
  c147e2:	mov    r13,QWORD PTR [rsp+0x28]
  c147e7:	mov    rbx,rbp
  c147ea:	jae    c1489c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f7c>
  c147f0:	mov    rax,QWORD PTR [rsp+0x130]
  c147f8:	mov    QWORD PTR [r14+0x10],rax
  c147fc:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c14805:	movdqu XMMWORD PTR [r14],xmm0
  c1480a:	mov    rsi,QWORD PTR [rbx]
  c1480d:	mov    r14,QWORD PTR [rsp+0x8]
  c14812:	cmp    r14,rsi
  c14815:	jae    c19d43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa423>
  c1481b:	mov    rbp,QWORD PTR [rsp+0x10]
  c14820:	mov    rax,QWORD PTR [rbp+0x0]
  c14824:	inc    QWORD PTR [rax+r13*1+0x58]
  c14829:	mov    eax,DWORD PTR [rsp+0x80]
  c14830:	mov    edx,eax
  c14832:	sub    edx,0x2
  c14835:	mov    ecx,0x3
  c1483a:	cmovae ecx,edx
  c1483d:	cmp    ecx,0x8
  c14840:	ja     c14b5e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x523e>
  c14846:	mov    edx,0x1e7
  c1484b:	bt     edx,ecx
  c1484e:	jae    c148c9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4fa9>
  c14850:	mov    eax,DWORD PTR [rsp+0x40]
  c14854:	mov    edx,eax
  c14856:	sub    edx,0x2
  c14859:	mov    ecx,0x3
  c1485e:	cmovae ecx,edx
  c14861:	cmp    ecx,0x8
  c14864:	ja     c14bc5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x52a5>
  c1486a:	mov    edx,0x1e7
  c1486f:	bt     edx,ecx
  c14872:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14878:	cmp    ecx,0x3
  c1487b:	jne    c14b9a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x527a>
  c14881:	test   eax,eax
  c14883:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14889:	mov    rax,QWORD PTR [rsp+0x48]
  c1488e:	dec    QWORD PTR [rax]
  c14891:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14897:	jmp    c1521e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58fe>
  c1489c:	cmp    ecx,0x3
  c1489f:	jne    c14a7e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x515e>
  c148a5:	test   eax,eax
  c148a7:	je     c147f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ed0>
  c148ad:	mov    rax,QWORD PTR [r14+0x8]
  c148b1:	dec    QWORD PTR [rax]
  c148b4:	jne    c147f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ed0>
  c148ba:	lea    rdi,[r14+0x8]
  c148be:	call   QWORD PTR [rip+0x238fcc]        # e4d890 <_DYNAMIC+0x248>
  c148c4:	jmp    c147f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ed0>
  c148c9:	cmp    ecx,0x3
  c148cc:	jne    c14b16 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51f6>
  c148d2:	test   eax,eax
  c148d4:	je     c14850 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f30>
  c148da:	mov    rax,QWORD PTR [rsp+0x88]
  c148e2:	dec    QWORD PTR [rax]
  c148e5:	jne    c14850 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f30>
  c148eb:	lea    rdi,[rsp+0x88]
  c148f3:	call   QWORD PTR [rip+0x238f97]        # e4d890 <_DYNAMIC+0x248>
  c148f9:	jmp    c14850 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f30>
  c148fe:	mov    rax,QWORD PTR [rsp+0x48]
  c14903:	dec    QWORD PTR [rax]
  c14906:	jne    c13547 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c27>
  c1490c:	lea    rdi,[rsp+0x48]
  c14911:	call   QWORD PTR [rip+0x238f89]        # e4d8a0 <_DYNAMIC+0x258>
  c14917:	jmp    c13547 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c27>
  c1491c:	mov    rax,QWORD PTR [rsp+0x48]
  c14921:	dec    QWORD PTR [rax]
  c14924:	jne    c137ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ece>
  c1492a:	lea    rdi,[rsp+0x48]
  c1492f:	call   QWORD PTR [rip+0x238f6b]        # e4d8a0 <_DYNAMIC+0x258>
  c14935:	jmp    c137ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ece>
  c1493a:	mov    rax,QWORD PTR [r14+0x8]
  c1493e:	dec    QWORD PTR [rax]
  c14941:	jne    c119d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20b6>
  c14947:	lea    rdi,[r14+0x8]
  c1494b:	call   QWORD PTR [rip+0x238f47]        # e4d898 <_DYNAMIC+0x250>
  c14951:	jmp    c119d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20b6>
  c14956:	mov    rax,QWORD PTR [r14+0x8]
  c1495a:	dec    QWORD PTR [rax]
  c1495d:	mov    rbp,QWORD PTR [rsp+0x10]
  c14962:	jne    c119d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20b6>
  c14968:	lea    rdi,[r14+0x8]
  c1496c:	call   QWORD PTR [rip+0x238f2e]        # e4d8a0 <_DYNAMIC+0x258>
  c14972:	jmp    c119d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20b6>
  c14977:	mov    rax,QWORD PTR [r14+0x8]
  c1497b:	dec    QWORD PTR [rax]
  c1497e:	jne    c1326c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x394c>
  c14984:	lea    rdi,[r14+0x8]
  c14988:	call   QWORD PTR [rip+0x238f0a]        # e4d898 <_DYNAMIC+0x250>
  c1498e:	jmp    c1326c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x394c>
  c14993:	mov    rax,QWORD PTR [r14+0x8]
  c14997:	dec    QWORD PTR [rax]
  c1499a:	mov    rbp,QWORD PTR [rsp+0x10]
  c1499f:	jne    c1326c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x394c>
  c149a5:	lea    rdi,[r14+0x8]
  c149a9:	call   QWORD PTR [rip+0x238ef1]        # e4d8a0 <_DYNAMIC+0x258>
  c149af:	jmp    c1326c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x394c>
  c149b4:	mov    rax,QWORD PTR [r14+0x8]
  c149b8:	dec    QWORD PTR [rax]
  c149bb:	jne    c135f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3cd3>
  c149c1:	lea    rdi,[r14+0x8]
  c149c5:	call   QWORD PTR [rip+0x238ecd]        # e4d898 <_DYNAMIC+0x250>
  c149cb:	jmp    c135f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3cd3>
  c149d0:	mov    rax,QWORD PTR [r14+0x8]
  c149d4:	dec    QWORD PTR [rax]
  c149d7:	jne    c1389a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f7a>
  c149dd:	lea    rdi,[r14+0x8]
  c149e1:	call   QWORD PTR [rip+0x238eb1]        # e4d898 <_DYNAMIC+0x250>
  c149e7:	jmp    c1389a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f7a>
  c149ec:	mov    rax,QWORD PTR [r14+0x8]
  c149f0:	dec    QWORD PTR [rax]
  c149f3:	mov    rbp,QWORD PTR [rsp+0x10]
  c149f8:	jne    c135f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3cd3>
  c149fe:	lea    rdi,[r14+0x8]
  c14a02:	call   QWORD PTR [rip+0x238e98]        # e4d8a0 <_DYNAMIC+0x258>
  c14a08:	jmp    c135f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3cd3>
  c14a0d:	mov    rax,QWORD PTR [r14+0x8]
  c14a11:	dec    QWORD PTR [rax]
  c14a14:	mov    rbp,QWORD PTR [rsp+0x10]
  c14a19:	jne    c1389a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f7a>
  c14a1f:	lea    rdi,[r14+0x8]
  c14a23:	call   QWORD PTR [rip+0x238e77]        # e4d8a0 <_DYNAMIC+0x258>
  c14a29:	jmp    c1389a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f7a>
  c14a2e:	mov    rax,QWORD PTR [rsp+0x88]
  c14a36:	dec    QWORD PTR [rax]
  c14a39:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14a3f:	lea    rdi,[rsp+0x88]
  c14a47:	jmp    c16dd9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b9>
  c14a4c:	mov    rax,QWORD PTR [rsp+0x88]
  c14a54:	dec    QWORD PTR [rax]
  c14a57:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14a5d:	jmp    c15fce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66ae>
  c14a62:	mov    rax,QWORD PTR [r14+0x8]
  c14a66:	dec    QWORD PTR [rax]
  c14a69:	jne    c14211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x48f1>
  c14a6f:	lea    rdi,[r14+0x8]
  c14a73:	call   QWORD PTR [rip+0x238e1f]        # e4d898 <_DYNAMIC+0x250>
  c14a79:	jmp    c14211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x48f1>
  c14a7e:	mov    rax,QWORD PTR [r14+0x8]
  c14a82:	dec    QWORD PTR [rax]
  c14a85:	jne    c147f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ed0>
  c14a8b:	lea    rdi,[r14+0x8]
  c14a8f:	call   QWORD PTR [rip+0x238e03]        # e4d898 <_DYNAMIC+0x250>
  c14a95:	jmp    c147f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ed0>
  c14a9a:	mov    rax,QWORD PTR [r14+0x8]
  c14a9e:	dec    QWORD PTR [rax]
  c14aa1:	mov    r15,r13
  c14aa4:	mov    r12d,DWORD PTR [rsp+0x30]
  c14aa9:	mov    r13,QWORD PTR [rsp+0x28]
  c14aae:	mov    rbx,rbp
  c14ab1:	jne    c14211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x48f1>
  c14ab7:	lea    rdi,[r14+0x8]
  c14abb:	call   QWORD PTR [rip+0x238ddf]        # e4d8a0 <_DYNAMIC+0x258>
  c14ac1:	jmp    c14211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x48f1>
  c14ac6:	mov    rax,QWORD PTR [r14+0x8]
  c14aca:	dec    QWORD PTR [rax]
  c14acd:	mov    r15,r13
  c14ad0:	mov    r12d,DWORD PTR [rsp+0x30]
  c14ad5:	mov    r13,QWORD PTR [rsp+0x28]
  c14ada:	mov    rbx,rbp
  c14add:	jne    c147f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ed0>
  c14ae3:	lea    rdi,[r14+0x8]
  c14ae7:	call   QWORD PTR [rip+0x238db3]        # e4d8a0 <_DYNAMIC+0x258>
  c14aed:	jmp    c147f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ed0>
  c14af2:	mov    rax,QWORD PTR [rsp+0x88]
  c14afa:	dec    QWORD PTR [rax]
  c14afd:	jne    c14271 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4951>
  c14b03:	lea    rdi,[rsp+0x88]
  c14b0b:	call   QWORD PTR [rip+0x238d87]        # e4d898 <_DYNAMIC+0x250>
  c14b11:	jmp    c14271 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4951>
  c14b16:	mov    rax,QWORD PTR [rsp+0x88]
  c14b1e:	dec    QWORD PTR [rax]
  c14b21:	jne    c14850 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f30>
  c14b27:	lea    rdi,[rsp+0x88]
  c14b2f:	call   QWORD PTR [rip+0x238d63]        # e4d898 <_DYNAMIC+0x250>
  c14b35:	jmp    c14850 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f30>
  c14b3a:	mov    rax,QWORD PTR [rsp+0x88]
  c14b42:	dec    QWORD PTR [rax]
  c14b45:	jne    c14271 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4951>
  c14b4b:	lea    rdi,[rsp+0x88]
  c14b53:	call   QWORD PTR [rip+0x238d47]        # e4d8a0 <_DYNAMIC+0x258>
  c14b59:	jmp    c14271 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4951>
  c14b5e:	mov    rax,QWORD PTR [rsp+0x88]
  c14b66:	dec    QWORD PTR [rax]
  c14b69:	jne    c14850 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f30>
  c14b6f:	lea    rdi,[rsp+0x88]
  c14b77:	call   QWORD PTR [rip+0x238d23]        # e4d8a0 <_DYNAMIC+0x258>
  c14b7d:	jmp    c14850 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f30>
  c14b82:	mov    rax,QWORD PTR [rsp+0x48]
  c14b87:	dec    QWORD PTR [rax]
  c14b8a:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14b90:	lea    rdi,[rsp+0x48]
  c14b95:	jmp    c16dd9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b9>
  c14b9a:	mov    rax,QWORD PTR [rsp+0x48]
  c14b9f:	dec    QWORD PTR [rax]
  c14ba2:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14ba8:	lea    rdi,[rsp+0x48]
  c14bad:	jmp    c16dd9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b9>
  c14bb2:	mov    rax,QWORD PTR [rsp+0x48]
  c14bb7:	dec    QWORD PTR [rax]
  c14bba:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14bc0:	jmp    c152c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59a2>
  c14bc5:	mov    rax,QWORD PTR [rsp+0x48]
  c14bca:	dec    QWORD PTR [rax]
  c14bcd:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14bd3:	jmp    c152c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59a2>
  c14bd8:	mov    rax,QWORD PTR [r14+0x8]
  c14bdc:	dec    QWORD PTR [rax]
  c14bdf:	jne    c144f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4bd4>
  c14be5:	lea    rdi,[r14+0x8]
  c14be9:	call   QWORD PTR [rip+0x238ca9]        # e4d898 <_DYNAMIC+0x250>
  c14bef:	jmp    c144f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4bd4>
  c14bf4:	mov    rax,QWORD PTR [r14+0x8]
  c14bf8:	dec    QWORD PTR [rax]
  c14bfb:	mov    rbp,QWORD PTR [rsp+0x10]
  c14c00:	jne    c144f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4bd4>
  c14c06:	lea    rdi,[r14+0x8]
  c14c0a:	call   QWORD PTR [rip+0x238c90]        # e4d8a0 <_DYNAMIC+0x258>
  c14c10:	jmp    c144f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4bd4>
  c14c15:	mov    rax,QWORD PTR [rsp+0xd8]
  c14c1d:	dec    QWORD PTR [rax]
  c14c20:	jne    c14549 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c29>
  c14c26:	lea    rdi,[rsp+0xd8]
  c14c2e:	call   QWORD PTR [rip+0x238c64]        # e4d898 <_DYNAMIC+0x250>
  c14c34:	jmp    c14549 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c29>
  c14c39:	mov    rax,QWORD PTR [rsp+0xd8]
  c14c41:	dec    QWORD PTR [rax]
  c14c44:	jne    c14549 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c29>
  c14c4a:	lea    rdi,[rsp+0xd8]
  c14c52:	call   QWORD PTR [rip+0x238c48]        # e4d8a0 <_DYNAMIC+0x258>
  c14c58:	jmp    c14549 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c29>
  c14c5d:	mov    rax,QWORD PTR [rsp+0x108]
  c14c65:	dec    QWORD PTR [rax]
  c14c68:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14c6e:	jmp    c16dd1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b1>
  c14c73:	mov    rax,QWORD PTR [rsp+0x108]
  c14c7b:	dec    QWORD PTR [rax]
  c14c7e:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14c84:	jmp    c16df5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74d5>
  c14c89:	mov    rax,QWORD PTR [r14+0x8]
  c14c8d:	dec    QWORD PTR [rax]
  c14c90:	jne    c12679 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d59>
  c14c96:	lea    rdi,[r14+0x8]
  c14c9a:	call   QWORD PTR [rip+0x238bf8]        # e4d898 <_DYNAMIC+0x250>
  c14ca0:	jmp    c12679 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d59>
  c14ca5:	mov    rax,QWORD PTR [r14+0x8]
  c14ca9:	dec    QWORD PTR [rax]
  c14cac:	jne    c12679 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d59>
  c14cb2:	lea    rdi,[r14+0x8]
  c14cb6:	call   QWORD PTR [rip+0x238be4]        # e4d8a0 <_DYNAMIC+0x258>
  c14cbc:	jmp    c12679 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d59>
  c14cc1:	mov    rax,QWORD PTR [rsp+0x370]
  c14cc9:	dec    QWORD PTR [rax]
  c14ccc:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14cd2:	lea    rdi,[rsp+0x370]
  c14cda:	jmp    c16dd9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b9>
  c14cdf:	mov    rax,QWORD PTR [rsp+0x370]
  c14ce7:	dec    QWORD PTR [rax]
  c14cea:	mov    rax,QWORD PTR [rsp+0x20]
  c14cef:	lea    rbx,[rax+0x10]
  c14cf3:	mov    r12d,DWORD PTR [rsp+0x30]
  c14cf8:	mov    rbp,rsi
  c14cfb:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14d01:	lea    rdi,[rsp+0x370]
  c14d09:	call   QWORD PTR [rip+0x238b91]        # e4d8a0 <_DYNAMIC+0x258>
  c14d0f:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14d14:	mov    rax,QWORD PTR [r14+0x8]
  c14d18:	dec    QWORD PTR [rax]
  c14d1b:	jne    c120a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2786>
  c14d21:	lea    rdi,[r14+0x8]
  c14d25:	call   QWORD PTR [rip+0x238b6d]        # e4d898 <_DYNAMIC+0x250>
  c14d2b:	jmp    c120a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2786>
  c14d30:	mov    rax,QWORD PTR [r14+0x8]
  c14d34:	dec    QWORD PTR [rax]
  c14d37:	mov    rbp,QWORD PTR [rsp+0x10]
  c14d3c:	jne    c120a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2786>
  c14d42:	lea    rdi,[r14+0x8]
  c14d46:	call   QWORD PTR [rip+0x238b54]        # e4d8a0 <_DYNAMIC+0x258>
  c14d4c:	jmp    c120a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2786>
  c14d51:	mov    rax,QWORD PTR [rsp+0x108]
  c14d59:	dec    QWORD PTR [rax]
  c14d5c:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14d62:	jmp    c16dd1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b1>
  c14d67:	mov    rax,QWORD PTR [rsp+0x108]
  c14d6f:	dec    QWORD PTR [rax]
  c14d72:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c14d78:	jmp    c16df5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74d5>
  c14d7d:	mov    esi,DWORD PTR [rcx+0x4]
  c14d80:	mov    rdx,QWORD PTR [rcx+0x8]
  c14d84:	mov    rcx,QWORD PTR [rcx+0x10]
  c14d88:	mov    DWORD PTR [rsp+0x80],eax
  c14d8f:	mov    DWORD PTR [rsp+0x84],esi
  c14d96:	mov    QWORD PTR [rsp+0x88],rdx
  c14d9e:	mov    QWORD PTR [rsp+0x90],rcx
  c14da6:	jmp    c103dc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabc>
  c14dab:	mov    rsi,QWORD PTR [rax+0x8]
  c14daf:	mov    rdi,QWORD PTR [rax+0x10]
  c14db3:	mov    edx,DWORD PTR [rax+0x4]
  c14db6:	shl    rdx,0x20
  c14dba:	or     rdx,rcx
  c14dbd:	mov    rcx,rdi
  c14dc0:	mov    rax,QWORD PTR [rsp+0x1b0]
  c14dc8:	jmp    c11d2d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x240d>
  c14dcd:	mov    rdi,QWORD PTR [rcx+0x8]
  c14dd1:	mov    r8,QWORD PTR [rcx+0x10]
  c14dd5:	mov    esi,DWORD PTR [rcx+0x4]
  c14dd8:	mov    rcx,r8
  c14ddb:	shl    rsi,0x20
  c14ddf:	or     rsi,rdx
  c14de2:	jmp    c12215 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28f5>
  c14de7:	mov    rdi,QWORD PTR [rdx+0x8]
  c14deb:	mov    r8,QWORD PTR [rdx+0x10]
  c14def:	mov    ecx,DWORD PTR [rdx+0x4]
  c14df2:	shl    rcx,0x20
  c14df6:	or     rcx,rsi
  c14df9:	movq   xmm1,r8
  c14dfe:	movq   xmm0,rdi
  c14e03:	punpcklqdq xmm0,xmm1
  c14e07:	jmp    c10bda <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12ba>
  c14e0c:	mov    rdi,QWORD PTR [rdx+0x8]
  c14e10:	mov    r8,QWORD PTR [rdx+0x10]
  c14e14:	mov    ecx,DWORD PTR [rdx+0x4]
  c14e17:	shl    rcx,0x20
  c14e1b:	or     rcx,rsi
  c14e1e:	movq   xmm1,r8
  c14e23:	movq   xmm0,rdi
  c14e28:	punpcklqdq xmm0,xmm1
  c14e2c:	jmp    c10c59 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1339>
  c14e31:	mov    rdi,QWORD PTR [rdx+0x8]
  c14e35:	mov    r8,QWORD PTR [rdx+0x10]
  c14e39:	mov    ecx,DWORD PTR [rdx+0x4]
  c14e3c:	shl    rcx,0x20
  c14e40:	or     rcx,rsi
  c14e43:	movq   xmm1,r8
  c14e48:	movq   xmm0,rdi
  c14e4d:	punpcklqdq xmm0,xmm1
  c14e51:	jmp    c10cd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13b8>
  c14e56:	mov    rsi,QWORD PTR [rcx+0x8]
  c14e5a:	mov    rdi,QWORD PTR [rcx+0x10]
  c14e5e:	mov    r8d,DWORD PTR [rcx+0x4]
  c14e62:	mov    rcx,rdi
  c14e65:	shl    r8,0x20
  c14e69:	or     r8,rdx
  c14e6c:	mov    QWORD PTR [rsp+0x40],r8
  c14e71:	mov    QWORD PTR [rsp+0x498],rsi
  c14e79:	mov    QWORD PTR [rsp+0x48],rsi
  c14e7e:	mov    QWORD PTR [rsp+0x260],rcx
  c14e86:	mov    QWORD PTR [rsp+0x50],rcx
  c14e8b:	mov    rsi,QWORD PTR [rbx]
  c14e8e:	cmp    QWORD PTR [rsp+0x8],rsi
  c14e93:	jae    c19b66 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa246>
  c14e99:	mov    rdi,QWORD PTR [rbp+0x0]
  c14e9d:	lea    rsi,[rdi+r13*1]
  c14ea1:	movzx  edx,r14b
  c14ea5:	mov    rcx,rdx
  c14ea8:	sub    rcx,QWORD PTR [rdi+r13*1+0x30]
  c14ead:	jae    c14ebc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x559c>
  c14eaf:	mov    rcx,QWORD PTR [rsi+0x28]
  c14eb3:	shl    edx,0x4
  c14eb6:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c14eba:	jmp    c14ec0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x55a0>
  c14ebc:	add    rcx,QWORD PTR [rsi+0x60]
  c14ec0:	mov    r14,QWORD PTR [rsp+0x8]
  c14ec5:	cmp    rcx,QWORD PTR [r9+0x10]
  c14ec9:	jae    c17ad8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x81b8>
  c14ecf:	mov    QWORD PTR [rsp+0x320],r8
  c14ed7:	mov    rsi,QWORD PTR [r9+0x8]
  c14edb:	lea    rcx,[rcx+rcx*2]
  c14edf:	mov    edx,DWORD PTR [rsi+rcx*8]
  c14ee2:	lea    edi,[rdx-0x2]
  c14ee5:	cmp    rdx,0x2
  c14ee9:	mov    r8d,0x3
  c14eef:	cmovae r8d,edi
  c14ef3:	lea    rcx,[rsi+rcx*8]
  c14ef7:	lea    rsi,[rip+0xffffffffff6b0a16]        # 2c5914 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf53>
  c14efe:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c14f02:	add    rdi,rsi
  c14f05:	jmp    rdi
  c14f07:	mov    r8,QWORD PTR [rcx]
  c14f0a:	mov    rdi,QWORD PTR [rcx+0x8]
  c14f0e:	mov    rsi,QWORD PTR [rcx+0x10]
  c14f12:	jmp    c14fd4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56b4>
  c14f17:	mov    rdi,QWORD PTR [rcx+0x8]
  c14f1b:	inc    QWORD PTR [rdi]
  c14f1e:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c14f24:	movabs rcx,0xffffffff00000000
  c14f2e:	mov    r8,QWORD PTR [rsp+0x2c0]
  c14f36:	and    r8,rcx
  c14f39:	or     r8,0xb
  c14f3d:	jmp    c14fcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56ac>
  c14f42:	movabs rcx,0xffffffff00000000
  c14f4c:	mov    r8,QWORD PTR [rsp+0x2c0]
  c14f54:	and    r8,rcx
  c14f57:	or     r8,0x2
  c14f5b:	mov    rdi,QWORD PTR [rsp+0x418]
  c14f63:	jmp    c14fcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56ac>
  c14f65:	movabs rcx,0xffffffff00000000
  c14f6f:	mov    r8,QWORD PTR [rsp+0x2c0]
  c14f77:	and    r8,rcx
  c14f7a:	or     r8,0x3
  c14f7e:	mov    rdi,QWORD PTR [rsp+0x418]
  c14f86:	jmp    c14fcc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56ac>
  c14f88:	test   dl,0x1
  c14f8b:	je     c16b84 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7264>
  c14f91:	mov    rdi,QWORD PTR [rcx+0x8]
  c14f95:	inc    QWORD PTR [rdi]
  c14f98:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c14f9e:	mov    r8d,0x1
  c14fa4:	jmp    c14fd4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56b4>
  c14fa6:	mov    rdi,QWORD PTR [rcx+0x8]
  c14faa:	inc    QWORD PTR [rdi]
  c14fad:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c14fb3:	movabs rcx,0xffffffff00000000
  c14fbd:	mov    r8,QWORD PTR [rsp+0x2c0]
  c14fc5:	and    r8,rcx
  c14fc8:	or     r8,0x6
  c14fcc:	mov    rsi,QWORD PTR [rsp+0x220]
  c14fd4:	mov    QWORD PTR [rsp+0x80],r8
  c14fdc:	mov    QWORD PTR [rsp+0x88],rdi
  c14fe4:	mov    QWORD PTR [rsp+0x220],rsi
  c14fec:	mov    QWORD PTR [rsp+0x90],rsi
  c14ff4:	mov    rsi,QWORD PTR [rbx]
  c14ff7:	cmp    r14,rsi
  c14ffa:	jae    c19c8a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa36a>
  c15000:	mov    rsi,QWORD PTR [rbp+0x0]
  c15004:	lea    rdx,[rsi+r13*1]
  c15008:	movzx  ecx,ax
  c1500b:	mov    rax,rcx
  c1500e:	sub    rax,QWORD PTR [rsi+r13*1+0x30]
  c15013:	jae    c15022 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5702>
  c15015:	mov    rax,QWORD PTR [rdx+0x28]
  c15019:	shl    ecx,0x4
  c1501c:	mov    rax,QWORD PTR [rax+rcx*1]
  c15020:	jmp    c15026 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5706>
  c15022:	add    rax,QWORD PTR [rdx+0x60]
  c15026:	cmp    rax,QWORD PTR [r9+0x10]
  c1502a:	jae    c18100 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x87e0>
  c15030:	mov    QWORD PTR [rsp+0x418],rdi
  c15038:	mov    rdx,QWORD PTR [r9+0x8]
  c1503c:	lea    rax,[rax+rax*2]
  c15040:	mov    ecx,DWORD PTR [rdx+rax*8]
  c15043:	lea    esi,[rcx-0x2]
  c15046:	cmp    rcx,0x2
  c1504a:	mov    edi,0x3
  c1504f:	cmovae edi,esi
  c15052:	lea    rax,[rdx+rax*8]
  c15056:	lea    rdx,[rip+0xffffffffff6b08df]        # 2c593c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf7b>
  c1505d:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c15061:	add    rsi,rdx
  c15064:	mov    QWORD PTR [rsp+0x2c0],r8
  c1506c:	jmp    rsi
  c1506e:	mov    rdx,QWORD PTR [rax]
  c15071:	mov    rsi,QWORD PTR [rax+0x8]
  c15075:	mov    rdi,QWORD PTR [rax+0x10]
  c15079:	jmp    c1513a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x581a>
  c1507e:	mov    rsi,QWORD PTR [rax+0x8]
  c15082:	inc    QWORD PTR [rsi]
  c15085:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1508b:	movabs rax,0xffffffff00000000
  c15095:	mov    rdx,QWORD PTR [rsp+0x2b8]
  c1509d:	and    rdx,rax
  c150a0:	or     rdx,0xb
  c150a4:	jmp    c15132 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5812>
  c150a9:	movabs rax,0xffffffff00000000
  c150b3:	mov    rdx,QWORD PTR [rsp+0x2b8]
  c150bb:	and    rdx,rax
  c150be:	or     rdx,0x2
  c150c2:	mov    rsi,QWORD PTR [rsp+0x410]
  c150ca:	jmp    c15132 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5812>
  c150cc:	movabs rax,0xffffffff00000000
  c150d6:	mov    rdx,QWORD PTR [rsp+0x2b8]
  c150de:	and    rdx,rax
  c150e1:	or     rdx,0x3
  c150e5:	mov    rsi,QWORD PTR [rsp+0x410]
  c150ed:	jmp    c15132 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5812>
  c150ef:	test   cl,0x1
  c150f2:	je     c16bfe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72de>
  c150f8:	mov    rsi,QWORD PTR [rax+0x8]
  c150fc:	inc    QWORD PTR [rsi]
  c150ff:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c15105:	mov    edx,0x1
  c1510a:	jmp    c1513a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x581a>
  c1510c:	mov    rsi,QWORD PTR [rax+0x8]
  c15110:	inc    QWORD PTR [rsi]
  c15113:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c15119:	movabs rax,0xffffffff00000000
  c15123:	mov    rdx,QWORD PTR [rsp+0x2b8]
  c1512b:	and    rdx,rax
  c1512e:	or     rdx,0x6
  c15132:	mov    rdi,QWORD PTR [rsp+0x200]
  c1513a:	mov    QWORD PTR [rsp+0x2b8],rdx
  c15142:	mov    QWORD PTR [rsp+0x5d0],rdx
  c1514a:	mov    QWORD PTR [rsp+0x410],rsi
  c15152:	mov    QWORD PTR [rsp+0x5d8],rsi
  c1515a:	mov    QWORD PTR [rsp+0x200],rdi
  c15162:	mov    QWORD PTR [rsp+0x5e0],rdi
  c1516a:	lea    rdi,[rsp+0x120]
  c15172:	lea    rsi,[rsp+0x40]
  c15177:	lea    rdx,[rsp+0x80]
  c1517f:	lea    rcx,[rsp+0x5d0]
  c15187:	call   QWORD PTR [rip+0x23dcf3]        # e52e80 <_DYNAMIC+0x5838>
  c1518d:	cmp    BYTE PTR [rsp+0x120],0xff
  c15195:	jne    c18542 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c22>
  c1519b:	mov    rsi,QWORD PTR [rbx]
  c1519e:	cmp    r14,rsi
  c151a1:	jae    c19e0d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4ed>
  c151a7:	mov    rax,QWORD PTR [rbp+0x0]
  c151ab:	inc    QWORD PTR [rax+r13*1+0x58]
  c151b0:	mov    eax,DWORD PTR [rsp+0x80]
  c151b7:	mov    edx,eax
  c151b9:	sub    edx,0x2
  c151bc:	mov    ecx,0x3
  c151c1:	cmovae ecx,edx
  c151c4:	cmp    ecx,0x8
  c151c7:	ja     c15278 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5958>
  c151cd:	mov    edx,0x1e7
  c151d2:	bt     edx,ecx
  c151d5:	jae    c1522e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x590e>
  c151d7:	mov    eax,DWORD PTR [rsp+0x40]
  c151db:	mov    edx,eax
  c151dd:	sub    edx,0x2
  c151e0:	mov    ecx,0x3
  c151e5:	cmovae ecx,edx
  c151e8:	cmp    ecx,0x8
  c151eb:	ja     c152b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5994>
  c151f1:	mov    edx,0x1e7
  c151f6:	bt     edx,ecx
  c151f9:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c151ff:	cmp    ecx,0x3
  c15202:	jne    c1529c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x597c>
  c15208:	test   eax,eax
  c1520a:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15210:	mov    rax,QWORD PTR [rsp+0x48]
  c15215:	dec    QWORD PTR [rax]
  c15218:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c1521e:	lea    rdi,[rsp+0x48]
  c15223:	call   QWORD PTR [rip+0x238667]        # e4d890 <_DYNAMIC+0x248>
  c15229:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c1522e:	cmp    ecx,0x3
  c15231:	jne    c15254 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5934>
  c15233:	test   eax,eax
  c15235:	je     c151d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58b7>
  c15237:	mov    rax,QWORD PTR [rsp+0x88]
  c1523f:	dec    QWORD PTR [rax]
  c15242:	jne    c151d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58b7>
  c15244:	lea    rdi,[rsp+0x88]
  c1524c:	call   QWORD PTR [rip+0x23863e]        # e4d890 <_DYNAMIC+0x248>
  c15252:	jmp    c151d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58b7>
  c15254:	mov    rax,QWORD PTR [rsp+0x88]
  c1525c:	dec    QWORD PTR [rax]
  c1525f:	jne    c151d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58b7>
  c15265:	lea    rdi,[rsp+0x88]
  c1526d:	call   QWORD PTR [rip+0x238625]        # e4d898 <_DYNAMIC+0x250>
  c15273:	jmp    c151d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58b7>
  c15278:	mov    rax,QWORD PTR [rsp+0x88]
  c15280:	dec    QWORD PTR [rax]
  c15283:	jne    c151d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58b7>
  c15289:	lea    rdi,[rsp+0x88]
  c15291:	call   QWORD PTR [rip+0x238609]        # e4d8a0 <_DYNAMIC+0x258>
  c15297:	jmp    c151d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58b7>
  c1529c:	mov    rax,QWORD PTR [rsp+0x48]
  c152a1:	dec    QWORD PTR [rax]
  c152a4:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c152aa:	lea    rdi,[rsp+0x48]
  c152af:	jmp    c16dd9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b9>
  c152b4:	mov    rax,QWORD PTR [rsp+0x48]
  c152b9:	dec    QWORD PTR [rax]
  c152bc:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c152c2:	lea    rdi,[rsp+0x48]
  c152c7:	call   QWORD PTR [rip+0x2385d3]        # e4d8a0 <_DYNAMIC+0x258>
  c152cd:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c152d2:	mov    rdi,QWORD PTR [rdx+0x8]
  c152d6:	mov    r8,QWORD PTR [rdx+0x10]
  c152da:	mov    ecx,DWORD PTR [rdx+0x4]
  c152dd:	shl    rcx,0x20
  c152e1:	or     rcx,rsi
  c152e4:	movq   xmm1,r8
  c152e9:	movq   xmm0,rdi
  c152ee:	punpcklqdq xmm0,xmm1
  c152f2:	jmp    c10ee9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15c9>
  c152f7:	mov    rdx,QWORD PTR [rax+0x8]
  c152fb:	mov    rsi,QWORD PTR [rax+0x10]
  c152ff:	mov    edi,DWORD PTR [rax+0x4]
  c15302:	shl    rdi,0x20
  c15306:	or     rdi,rcx
  c15309:	mov    rax,rsi
  c1530c:	mov    QWORD PTR [rsp+0x100],rdi
  c15314:	mov    QWORD PTR [rsp+0x488],rdx
  c1531c:	mov    QWORD PTR [rsp+0x108],rdx
  c15324:	mov    QWORD PTR [rsp+0x250],rax
  c1532c:	mov    QWORD PTR [rsp+0x110],rax
  c15334:	mov    rsi,QWORD PTR [r12]
  c15338:	cmp    QWORD PTR [rsp+0x8],rsi
  c1533d:	jae    c19b7d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa25d>
  c15343:	mov    rsi,QWORD PTR [rbp+0x0]
  c15347:	lea    rdx,[rsi+r13*1]
  c1534b:	movzx  ecx,r14b
  c1534f:	mov    rax,rcx
  c15352:	sub    rax,QWORD PTR [rsi+r13*1+0x30]
  c15357:	jae    c15366 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a46>
  c15359:	mov    rax,QWORD PTR [rdx+0x28]
  c1535d:	shl    ecx,0x4
  c15360:	mov    rax,QWORD PTR [rax+rcx*1]
  c15364:	jmp    c1536a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a4a>
  c15366:	add    rax,QWORD PTR [rdx+0x60]
  c1536a:	cmp    rax,QWORD PTR [r8+0x10]
  c1536e:	jae    c17b04 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x81e4>
  c15374:	mov    QWORD PTR [rsp+0x318],rdi
  c1537c:	mov    rdx,QWORD PTR [r8+0x8]
  c15380:	lea    rax,[rax+rax*2]
  c15384:	mov    ecx,DWORD PTR [rdx+rax*8]
  c15387:	lea    esi,[rcx-0x2]
  c1538a:	cmp    rcx,0x2
  c1538e:	mov    edi,0x3
  c15393:	cmovae edi,esi
  c15396:	lea    rax,[rdx+rax*8]
  c1539a:	lea    rdx,[rip+0xffffffffff6b04d3]        # 2c5874 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xeb3>
  c153a1:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c153a5:	add    rsi,rdx
  c153a8:	jmp    rsi
  c153aa:	mov    rdi,QWORD PTR [rax]
  c153ad:	mov    r8,QWORD PTR [rax+0x8]
  c153b1:	mov    rdx,QWORD PTR [rax+0x10]
  c153b5:	jmp    c15476 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b56>
  c153ba:	mov    r8,QWORD PTR [rax+0x8]
  c153be:	inc    QWORD PTR [r8]
  c153c1:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c153c7:	movabs rax,0xffffffff00000000
  c153d1:	mov    rdi,QWORD PTR [rsp+0x2f8]
  c153d9:	and    rdi,rax
  c153dc:	or     rdi,0xb
  c153e0:	jmp    c1546e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b4e>
  c153e5:	movabs rax,0xffffffff00000000
  c153ef:	mov    rdi,QWORD PTR [rsp+0x2f8]
  c153f7:	and    rdi,rax
  c153fa:	or     rdi,0x2
  c153fe:	mov    r8,QWORD PTR [rsp+0x450]
  c15406:	jmp    c1546e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b4e>
  c15408:	movabs rax,0xffffffff00000000
  c15412:	mov    rdi,QWORD PTR [rsp+0x2f8]
  c1541a:	and    rdi,rax
  c1541d:	or     rdi,0x3
  c15421:	mov    r8,QWORD PTR [rsp+0x450]
  c15429:	jmp    c1546e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b4e>
  c1542b:	test   cl,0x1
  c1542e:	je     c16b9c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x727c>
  c15434:	mov    r8,QWORD PTR [rax+0x8]
  c15438:	inc    QWORD PTR [r8]
  c1543b:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c15441:	mov    edi,0x1
  c15446:	jmp    c15476 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b56>
  c15448:	mov    r8,QWORD PTR [rax+0x8]
  c1544c:	inc    QWORD PTR [r8]
  c1544f:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c15455:	movabs rax,0xffffffff00000000
  c1545f:	mov    rdi,QWORD PTR [rsp+0x2f8]
  c15467:	and    rdi,rax
  c1546a:	or     rdi,0x6
  c1546e:	mov    rdx,QWORD PTR [rsp+0x1d0]
  c15476:	mov    QWORD PTR [rsp+0xd0],rdi
  c1547e:	mov    QWORD PTR [rsp+0xd8],r8
  c15486:	mov    QWORD PTR [rsp+0xe0],rdx
  c1548e:	cmp    DWORD PTR [rsp+0x100],0xb
  c15496:	mov    QWORD PTR [rsp+0x2f8],rdi
  c1549e:	mov    QWORD PTR [rsp+0x450],r8
  c154a6:	jne    c15637 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d17>
  c154ac:	mov    rsi,QWORD PTR [rsp+0x108]
  c154b4:	cmp    BYTE PTR [rsi+0x10],0xf
  c154b8:	jne    c15637 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d17>
  c154be:	mov    QWORD PTR [rsp+0x1d0],rdx
  c154c6:	add    rsi,0x18
  c154ca:	mov    rax,QWORD PTR [rsp+0x388]
  c154d2:	mov    rcx,QWORD PTR [rax]
  c154d5:	test   rcx,rcx
  c154d8:	cmovne rcx,rax
  c154dc:	mov    rdx,QWORD PTR [rsp+0x380]
  c154e4:	mov    rax,QWORD PTR [rdx]
  c154e7:	test   rax,rax
  c154ea:	cmovne rax,rdx
  c154ee:	mov    rdx,QWORD PTR [rsp+0x3a8]
  c154f6:	movq   xmm0,QWORD PTR [rdx]
  c154fa:	mov    rdx,QWORD PTR [rsp+0x3b0]
  c15502:	movq   xmm1,QWORD PTR [rdx]
  c15506:	punpcklqdq xmm1,xmm0
  c1550a:	mov    rdx,QWORD PTR [rsp+0x630]
  c15512:	mov    QWORD PTR [rsp+0x120],rdx
  c1551a:	mov    rdx,QWORD PTR [rip+0x238447]        # e4d968 <_DYNAMIC+0x320>
  c15521:	mov    QWORD PTR [rsp+0x128],rdx
  c15529:	mov    BYTE PTR [rsp+0x1a8],0x0
  c15531:	mov    rdx,QWORD PTR [rsp+0x640]
  c15539:	movups xmm0,XMMWORD PTR [rdx]
  c1553c:	movups XMMWORD PTR [rsp+0x130],xmm0
  c15544:	movdqu xmm0,XMMWORD PTR [rdx+0x10]
  c15549:	movdqu XMMWORD PTR [rsp+0x140],xmm0
  c15552:	mov    rdx,QWORD PTR [rsp+0x398]
  c1555a:	mov    QWORD PTR [rsp+0x150],rdx
  c15562:	mov    rdx,QWORD PTR [rsp+0x3a0]
  c1556a:	mov    QWORD PTR [rsp+0x158],rdx
  c15572:	mov    rdx,QWORD PTR [rsp+0x390]
  c1557a:	mov    QWORD PTR [rsp+0x160],rdx
  c15582:	mov    QWORD PTR [rsp+0x168],rcx
  c1558a:	mov    QWORD PTR [rsp+0x170],0x0
  c15596:	mov    QWORD PTR [rsp+0x180],0x0
  c155a2:	pxor   xmm0,xmm0
  c155a6:	pcmpeqd xmm0,xmm1
  c155aa:	pshufd xmm1,xmm0,0xb1
  c155af:	pand   xmm1,xmm0
  c155b3:	pandn  xmm1,XMMWORD PTR [rsp+0x530]
  c155bc:	movdqu XMMWORD PTR [rsp+0x190],xmm1
  c155c5:	mov    QWORD PTR [rsp+0x1a0],rax
  c155cd:	mov    rax,QWORD PTR [rsp+0xe0]
  c155d5:	mov    QWORD PTR [rsp+0x50],rax
  c155da:	movdqu xmm0,XMMWORD PTR [rsp+0xd0]
  c155e3:	movdqa XMMWORD PTR [rsp+0x40],xmm0
  c155e9:	sub    rsp,0x8
  c155ed:	lea    rax,[rsp+0x128]
  c155f5:	lea    rdi,[rsp+0x88]
  c155fd:	lea    r8,[rsp+0x48]
  c15602:	mov    rdx,QWORD PTR [rsp+0x4d0]
  c1560a:	mov    ecx,ebx
  c1560c:	mov    r9,QWORD PTR [rsp+0x1c8]
  c15614:	push   rax
  c15615:	call   c37dc0 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7linking18component_prop_set>
  c1561a:	add    rsp,0x10
  c1561e:	cmp    BYTE PTR [rsp+0x80],0xff
  c15626:	jne    c18f68 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9648>
  c1562c:	mov    rbx,r12
  c1562f:	xor    r14d,r14d
  c15632:	jmp    c16d35 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7415>
  c15637:	cmp    QWORD PTR [rsp+0x4d8],rbx
  c1563f:	jbe    c18656 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d36>
  c15645:	mov    r9,rdx
  c15648:	lea    rax,[rbx+rbx*2]
  c1564c:	mov    rsi,QWORD PTR [rsp+0x4d0]
  c15654:	mov    rbp,QWORD PTR [rsi+rax*8+0x8]
  c15659:	mov    ecx,edi
  c1565b:	sub    ecx,0x2
  c1565e:	mov    edx,0x3
  c15663:	cmovae edx,ecx
  c15666:	mov    r14,QWORD PTR [rsi+rax*8+0x10]
  c1566b:	lea    rax,[rip+0xffffffffff6b022a]        # 2c589c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xedb>
  c15672:	movsxd rcx,DWORD PTR [rax+rdx*4]
  c15676:	add    rcx,rax
  c15679:	jmp    rcx
  c1567b:	mov    rax,QWORD PTR [rsp+0xe0]
  c15683:	mov    QWORD PTR [rsp+0x130],rax
  c1568b:	movdqu xmm0,XMMWORD PTR [rsp+0xd0]
  c15694:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c1569d:	mov    rax,QWORD PTR [rsp+0x1b0]
  c156a5:	mov    rdx,r9
  c156a8:	jmp    c16c44 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7324>
  c156ad:	inc    QWORD PTR [r8]
  c156b0:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c156b6:	mov    rdx,r9
  c156b9:	mov    QWORD PTR [rsp+0x128],r8
  c156c1:	mov    DWORD PTR [rsp+0x120],0xb
  c156cc:	jmp    c16c3c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x731c>
  c156d1:	mov    DWORD PTR [rsp+0x120],0x2
  c156dc:	jmp    c1569d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d7d>
  c156de:	mov    DWORD PTR [rsp+0x120],0x3
  c156e9:	jmp    c1569d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d7d>
  c156eb:	test   dil,0x1
  c156ef:	mov    rdx,r9
  c156f2:	je     c16c15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72f5>
  c156f8:	inc    QWORD PTR [r8]
  c156fb:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c15701:	mov    ecx,0x1
  c15706:	jmp    c16c1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72fe>
  c1570b:	inc    QWORD PTR [r8]
  c1570e:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c15714:	mov    rdx,r9
  c15717:	mov    QWORD PTR [rsp+0x128],r8
  c1571f:	mov    DWORD PTR [rsp+0x120],0x6
  c1572a:	jmp    c16c3c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x731c>
  c1572f:	mov    rdi,QWORD PTR [r10+0x8]
  c15733:	mov    r9,QWORD PTR [r10+0x10]
  c15737:	mov    r8d,DWORD PTR [r10+0x4]
  c1573b:	shl    r8,0x20
  c1573f:	or     r8,r11
  c15742:	mov    r10,r12
  c15745:	sub    r10,rdx
  c15748:	jb     c11063 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1743>
  c1574e:	jmp    c12a83 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3163>
  c15753:	mov    r8,QWORD PTR [rcx+0x8]
  c15757:	mov    rsi,QWORD PTR [rcx+0x10]
  c1575b:	mov    r9d,DWORD PTR [rcx+0x4]
  c1575f:	shl    r9,0x20
  c15763:	or     r9,rdx
  c15766:	jmp    c12d7d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x345d>
  c1576b:	mov    rsi,QWORD PTR [rax+0x8]
  c1576f:	mov    rdi,QWORD PTR [rax+0x10]
  c15773:	mov    edx,DWORD PTR [rax+0x4]
  c15776:	shl    rdx,0x20
  c1577a:	or     rdx,rcx
  c1577d:	mov    rax,rdi
  c15780:	mov    QWORD PTR [rsp+0x348],rdx
  c15788:	mov    QWORD PTR [rsp+0x80],rdx
  c15790:	mov    QWORD PTR [rsp+0x4a0],rsi
  c15798:	mov    QWORD PTR [rsp+0x88],rsi
  c157a0:	mov    QWORD PTR [rsp+0x270],rax
  c157a8:	mov    QWORD PTR [rsp+0x90],rax
  c157b0:	lea    rdi,[rsp+0x120]
  c157b8:	lea    rsi,[rsp+0x80]
  c157c0:	call   QWORD PTR [rip+0x23c71a]        # e51ee0 <_DYNAMIC+0x4898>
  c157c6:	movzx  eax,BYTE PTR [rsp+0x120]
  c157ce:	movzx  ebx,BYTE PTR [rsp+0x121]
  c157d6:	cmp    al,0xff
  c157d8:	jne    c174a7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b87>
  c157de:	mov    eax,DWORD PTR [rsp+0x80]
  c157e5:	mov    edx,eax
  c157e7:	sub    edx,0x2
  c157ea:	mov    ecx,0x3
  c157ef:	cmovae ecx,edx
  c157f2:	cmp    ecx,0x8
  c157f5:	ja     c1587b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f5b>
  c157fb:	mov    edx,0x1e7
  c15800:	bt     edx,ecx
  c15803:	jae    c15838 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f18>
  c15805:	mov    rax,QWORD PTR [rsp+0xf8]
  c1580d:	mov    rsi,QWORD PTR [rax]
  c15810:	test   bl,0x1
  c15813:	je     c15825 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f05>
  c15815:	cmp    QWORD PTR [rsp+0x8],rsi
  c1581a:	jb     c159f6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60d6>
  c15820:	jmp    c19eb6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa596>
  c15825:	mov    r14,QWORD PTR [rsp+0x8]
  c1582a:	cmp    r14,rsi
  c1582d:	jb     c159d5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60b5>
  c15833:	jmp    c19eea <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5ca>
  c15838:	cmp    ecx,0x3
  c1583b:	jne    c1585e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5f3e>
  c1583d:	test   eax,eax
  c1583f:	je     c15805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ee5>
  c15841:	mov    rax,QWORD PTR [rsp+0x88]
  c15849:	dec    QWORD PTR [rax]
  c1584c:	jne    c15805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ee5>
  c1584e:	lea    rdi,[rsp+0x88]
  c15856:	call   QWORD PTR [rip+0x238034]        # e4d890 <_DYNAMIC+0x248>
  c1585c:	jmp    c15805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ee5>
  c1585e:	mov    rax,QWORD PTR [rsp+0x88]
  c15866:	dec    QWORD PTR [rax]
  c15869:	jne    c15805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ee5>
  c1586b:	lea    rdi,[rsp+0x88]
  c15873:	call   QWORD PTR [rip+0x23801f]        # e4d898 <_DYNAMIC+0x250>
  c15879:	jmp    c15805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ee5>
  c1587b:	mov    rax,QWORD PTR [rsp+0x88]
  c15883:	dec    QWORD PTR [rax]
  c15886:	jne    c15805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ee5>
  c1588c:	lea    rdi,[rsp+0x88]
  c15894:	call   QWORD PTR [rip+0x238006]        # e4d8a0 <_DYNAMIC+0x258>
  c1589a:	jmp    c15805 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ee5>
  c1589f:	mov    rdi,QWORD PTR [rcx+0x8]
  c158a3:	mov    rsi,QWORD PTR [rcx+0x10]
  c158a7:	mov    r8d,DWORD PTR [rcx+0x4]
  c158ab:	shl    r8,0x20
  c158af:	or     r8,rdx
  c158b2:	jmp    c13002 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36e2>
  c158b7:	mov    rsi,QWORD PTR [rax+0x8]
  c158bb:	mov    rdi,QWORD PTR [rax+0x10]
  c158bf:	mov    edx,DWORD PTR [rax+0x4]
  c158c2:	shl    rdx,0x20
  c158c6:	or     rdx,rcx
  c158c9:	mov    rax,rdi
  c158cc:	jmp    c1315f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x383f>
  c158d1:	mov    rsi,QWORD PTR [rax+0x8]
  c158d5:	mov    rdi,QWORD PTR [rax+0x10]
  c158d9:	mov    edx,DWORD PTR [rax+0x4]
  c158dc:	shl    rdx,0x20
  c158e0:	or     rdx,rcx
  c158e3:	mov    rax,rdi
  c158e6:	jmp    c1349c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3b7c>
  c158eb:	mov    rsi,QWORD PTR [rax+0x8]
  c158ef:	mov    rdi,QWORD PTR [rax+0x10]
  c158f3:	mov    edx,DWORD PTR [rax+0x4]
  c158f6:	shl    rdx,0x20
  c158fa:	or     rdx,rcx
  c158fd:	mov    rax,rdi
  c15900:	jmp    c13744 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e24>
  c15905:	mov    r8,QWORD PTR [rcx+0x8]
  c15909:	mov    rsi,QWORD PTR [rcx+0x10]
  c1590d:	mov    r9d,DWORD PTR [rcx+0x4]
  c15911:	shl    r9,0x20
  c15915:	or     r9,rdx
  c15918:	jmp    c1394c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x402c>
  c1591d:	mov    rsi,QWORD PTR [rax+0x8]
  c15921:	mov    rdi,QWORD PTR [rax+0x10]
  c15925:	mov    edx,DWORD PTR [rax+0x4]
  c15928:	shl    rdx,0x20
  c1592c:	or     rdx,rcx
  c1592f:	mov    rax,rdi
  c15932:	mov    QWORD PTR [rsp+0x350],rdx
  c1593a:	mov    QWORD PTR [rsp+0x80],rdx
  c15942:	mov    QWORD PTR [rsp+0x4a8],rsi
  c1594a:	mov    QWORD PTR [rsp+0x88],rsi
  c15952:	mov    QWORD PTR [rsp+0x278],rax
  c1595a:	mov    QWORD PTR [rsp+0x90],rax
  c15962:	lea    rdi,[rsp+0x120]
  c1596a:	lea    rsi,[rsp+0x80]
  c15972:	call   QWORD PTR [rip+0x23c568]        # e51ee0 <_DYNAMIC+0x4898>
  c15978:	movzx  eax,BYTE PTR [rsp+0x120]
  c15980:	movzx  ebx,BYTE PTR [rsp+0x121]
  c15988:	cmp    al,0xff
  c1598a:	jne    c174a7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b87>
  c15990:	mov    eax,DWORD PTR [rsp+0x80]
  c15997:	mov    edx,eax
  c15999:	sub    edx,0x2
  c1599c:	mov    ecx,0x3
  c159a1:	cmovae ecx,edx
  c159a4:	cmp    ecx,0x8
  c159a7:	ja     c15a62 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6142>
  c159ad:	mov    edx,0x1e7
  c159b2:	bt     edx,ecx
  c159b5:	jae    c15a15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60f5>
  c159b7:	mov    rax,QWORD PTR [rsp+0xf8]
  c159bf:	mov    rsi,QWORD PTR [rax]
  c159c2:	test   bl,0x1
  c159c5:	je     c159eb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60cb>
  c159c7:	mov    r14,QWORD PTR [rsp+0x8]
  c159cc:	cmp    r14,rsi
  c159cf:	jae    c19ec8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5a8>
  c159d5:	mov    rax,QWORD PTR [rbp+0x0]
  c159d9:	inc    QWORD PTR [rax+r13*1+0x58]
  c159de:	mov    rbx,QWORD PTR [rsp+0xf8]
  c159e6:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c159eb:	cmp    QWORD PTR [rsp+0x8],rsi
  c159f0:	jae    c19ed8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5b8>
  c159f6:	mov    rax,QWORD PTR [rbp+0x0]
  c159fa:	movsx  rcx,r14w
  c159fe:	mov    QWORD PTR [rax+r13*1+0x58],rcx
  c15a03:	mov    r14,QWORD PTR [rsp+0x8]
  c15a08:	mov    rbx,QWORD PTR [rsp+0xf8]
  c15a10:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15a15:	cmp    ecx,0x3
  c15a18:	jne    c15a3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x611e>
  c15a1a:	test   eax,eax
  c15a1c:	je     c159b7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6097>
  c15a1e:	mov    rax,QWORD PTR [rsp+0x88]
  c15a26:	dec    QWORD PTR [rax]
  c15a29:	jne    c159b7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6097>
  c15a2b:	lea    rdi,[rsp+0x88]
  c15a33:	call   QWORD PTR [rip+0x237e57]        # e4d890 <_DYNAMIC+0x248>
  c15a39:	jmp    c159b7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6097>
  c15a3e:	mov    rax,QWORD PTR [rsp+0x88]
  c15a46:	dec    QWORD PTR [rax]
  c15a49:	jne    c159b7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6097>
  c15a4f:	lea    rdi,[rsp+0x88]
  c15a57:	call   QWORD PTR [rip+0x237e3b]        # e4d898 <_DYNAMIC+0x250>
  c15a5d:	jmp    c159b7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6097>
  c15a62:	mov    rax,QWORD PTR [rsp+0x88]
  c15a6a:	dec    QWORD PTR [rax]
  c15a6d:	jne    c159b7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6097>
  c15a73:	lea    rdi,[rsp+0x88]
  c15a7b:	call   QWORD PTR [rip+0x237e1f]        # e4d8a0 <_DYNAMIC+0x258>
  c15a81:	jmp    c159b7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6097>
  c15a86:	mov    rbx,QWORD PTR [rax+0x8]
  c15a8a:	mov    r8,QWORD PTR [rax+0x10]
  c15a8e:	mov    r13d,DWORD PTR [rax+0x4]
  c15a92:	shl    r13,0x20
  c15a96:	or     r13,rcx
  c15a99:	mov    QWORD PTR [rsp+0x80],r13
  c15aa1:	mov    QWORD PTR [rsp+0x88],rbx
  c15aa9:	mov    QWORD PTR [rsp+0x90],r8
  c15ab1:	mov    rax,QWORD PTR [rsp+0x20]
  c15ab6:	add    rax,0x10
  c15aba:	mov    rsi,QWORD PTR [rax]
  c15abd:	cmp    rdi,rsi
  c15ac0:	jae    c19c96 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa376>
  c15ac6:	mov    rdx,QWORD PTR [rdx]
  c15ac9:	mov    rsi,QWORD PTR [rsp+0x28]
  c15ace:	lea    rcx,[rdx+rsi*1]
  c15ad2:	mov    rax,r12
  c15ad5:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c15ada:	jae    c15aea <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x61ca>
  c15adc:	mov    rax,QWORD PTR [rcx+0x28]
  c15ae0:	shl    r12d,0x4
  c15ae4:	mov    rax,QWORD PTR [rax+r12*1]
  c15ae8:	jmp    c15aee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x61ce>
  c15aea:	add    rax,QWORD PTR [rcx+0x60]
  c15aee:	mov    r12d,DWORD PTR [rsp+0x30]
  c15af3:	mov    rsi,QWORD PTR [rsp+0x38]
  c15af8:	mov    rcx,QWORD PTR [rsi+0x8]
  c15afc:	mov    rdx,QWORD PTR [rsp+0x90]
  c15b04:	mov    QWORD PTR [rsp+0x130],rdx
  c15b0c:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c15b15:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c15b1e:	cmp    rax,QWORD PTR [rsi+0x10]
  c15b22:	jae    c17f31 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8611>
  c15b28:	mov    QWORD PTR [rsp+0x218],r8
  c15b30:	lea    rax,[rax+rax*2]
  c15b34:	lea    r14,[rcx+rax*8]
  c15b38:	mov    eax,DWORD PTR [rcx+rax*8]
  c15b3b:	mov    edx,eax
  c15b3d:	sub    edx,0x2
  c15b40:	mov    ecx,0x3
  c15b45:	cmovae ecx,edx
  c15b48:	cmp    ecx,0x8
  c15b4b:	ja     c15be7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62c7>
  c15b51:	mov    edx,0x1e7
  c15b56:	bt     edx,ecx
  c15b59:	mov    rbp,QWORD PTR [rsp+0x10]
  c15b5e:	jae    c15bb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6291>
  c15b60:	mov    QWORD PTR [rsp+0x2e0],r13
  c15b68:	mov    QWORD PTR [rsp+0x438],rbx
  c15b70:	mov    rax,QWORD PTR [rsp+0x90]
  c15b78:	mov    QWORD PTR [r14+0x10],rax
  c15b7c:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c15b85:	movdqu XMMWORD PTR [r14],xmm0
  c15b8a:	mov    rbx,QWORD PTR [rsp+0xf8]
  c15b92:	mov    rsi,QWORD PTR [rbx]
  c15b95:	mov    r14,QWORD PTR [rsp+0x8]
  c15b9a:	cmp    r14,rsi
  c15b9d:	jae    c19cf7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3d7>
  c15ba3:	mov    rax,QWORD PTR [rbp+0x0]
  c15ba7:	mov    r13,QWORD PTR [rsp+0x28]
  c15bac:	jmp    c16964 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7044>
  c15bb1:	cmp    ecx,0x3
  c15bb4:	jne    c15bcf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62af>
  c15bb6:	test   eax,eax
  c15bb8:	je     c15b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6240>
  c15bba:	mov    rax,QWORD PTR [r14+0x8]
  c15bbe:	dec    QWORD PTR [rax]
  c15bc1:	jne    c15b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6240>
  c15bc3:	lea    rdi,[r14+0x8]
  c15bc7:	call   QWORD PTR [rip+0x237cc3]        # e4d890 <_DYNAMIC+0x248>
  c15bcd:	jmp    c15b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6240>
  c15bcf:	mov    rax,QWORD PTR [r14+0x8]
  c15bd3:	dec    QWORD PTR [rax]
  c15bd6:	jne    c15b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6240>
  c15bd8:	lea    rdi,[r14+0x8]
  c15bdc:	call   QWORD PTR [rip+0x237cb6]        # e4d898 <_DYNAMIC+0x250>
  c15be2:	jmp    c15b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6240>
  c15be7:	mov    rax,QWORD PTR [r14+0x8]
  c15beb:	dec    QWORD PTR [rax]
  c15bee:	mov    rbp,QWORD PTR [rsp+0x10]
  c15bf3:	jne    c15b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6240>
  c15bf9:	lea    rdi,[r14+0x8]
  c15bfd:	call   QWORD PTR [rip+0x237c9d]        # e4d8a0 <_DYNAMIC+0x258>
  c15c03:	jmp    c15b60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6240>
  c15c08:	mov    rsi,QWORD PTR [rax+0x8]
  c15c0c:	mov    rdi,QWORD PTR [rax+0x10]
  c15c10:	mov    edx,DWORD PTR [rax+0x4]
  c15c13:	shl    rdx,0x20
  c15c17:	or     rdx,rcx
  c15c1a:	mov    rcx,rsi
  c15c1d:	mov    rax,rdi
  c15c20:	mov    QWORD PTR [rsp+0x500],rdx
  c15c28:	mov    QWORD PTR [rsp+0x508],rcx
  c15c30:	mov    QWORD PTR [rsp+0x1d8],rax
  c15c38:	mov    QWORD PTR [rsp+0x510],rax
  c15c40:	mov    rax,QWORD PTR [rsp+0x1c8]
  c15c48:	cmp    QWORD PTR [rax+0x10],r14
  c15c4c:	jbe    c17f04 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85e4>
  c15c52:	mov    QWORD PTR [rsp+0x430],rcx
  c15c5a:	mov    QWORD PTR [rsp+0x2d8],rdx
  c15c62:	mov    rax,QWORD PTR [rax+0x8]
  c15c66:	lea    rcx,[r14+r14*2]
  c15c6a:	lea    r14,[rax+rcx*8]
  c15c6e:	mov    eax,DWORD PTR [rax+rcx*8]
  c15c71:	mov    edx,eax
  c15c73:	sub    edx,0x2
  c15c76:	mov    ecx,0x3
  c15c7b:	cmovae ecx,edx
  c15c7e:	cmp    ecx,0x8
  c15c81:	ja     c15cf0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63d0>
  c15c83:	mov    edx,0x1e7
  c15c88:	bt     edx,ecx
  c15c8b:	jae    c15cbd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x639d>
  c15c8d:	mov    rax,QWORD PTR [rsp+0x510]
  c15c95:	mov    QWORD PTR [r14+0x10],rax
  c15c99:	movdqu xmm0,XMMWORD PTR [rsp+0x500]
  c15ca2:	movdqu XMMWORD PTR [r14],xmm0
  c15ca7:	mov    rsi,QWORD PTR [rbx]
  c15caa:	mov    r14,QWORD PTR [rsp+0x8]
  c15caf:	cmp    r14,rsi
  c15cb2:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c15cb8:	jmp    c19d7f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa45f>
  c15cbd:	cmp    ecx,0x3
  c15cc0:	jne    c15cdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63bb>
  c15cc2:	test   eax,eax
  c15cc4:	je     c15c8d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x636d>
  c15cc6:	mov    rax,QWORD PTR [r14+0x8]
  c15cca:	dec    QWORD PTR [rax]
  c15ccd:	jne    c15c8d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x636d>
  c15ccf:	lea    rdi,[r14+0x8]
  c15cd3:	call   QWORD PTR [rip+0x237bb7]        # e4d890 <_DYNAMIC+0x248>
  c15cd9:	jmp    c15c8d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x636d>
  c15cdb:	mov    rax,QWORD PTR [r14+0x8]
  c15cdf:	dec    QWORD PTR [rax]
  c15ce2:	jne    c15c8d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x636d>
  c15ce4:	lea    rdi,[r14+0x8]
  c15ce8:	call   QWORD PTR [rip+0x237baa]        # e4d898 <_DYNAMIC+0x250>
  c15cee:	jmp    c15c8d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x636d>
  c15cf0:	mov    rax,QWORD PTR [r14+0x8]
  c15cf4:	dec    QWORD PTR [rax]
  c15cf7:	jne    c15c8d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x636d>
  c15cf9:	lea    rdi,[r14+0x8]
  c15cfd:	call   QWORD PTR [rip+0x237b9d]        # e4d8a0 <_DYNAMIC+0x258>
  c15d03:	jmp    c15c8d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x636d>
  c15d05:	mov    rdi,QWORD PTR [rcx+0x8]
  c15d09:	mov    r8,QWORD PTR [rcx+0x10]
  c15d0d:	mov    esi,DWORD PTR [rcx+0x4]
  c15d10:	mov    rcx,r8
  c15d13:	shl    rsi,0x20
  c15d17:	or     rsi,rdx
  c15d1a:	imul   rax,rax,0xc8
  c15d21:	add    rax,QWORD PTR [rsp+0x3b8]
  c15d29:	mov    QWORD PTR [rsp+0x120],rsi
  c15d31:	mov    QWORD PTR [rsp+0x128],rdi
  c15d39:	mov    QWORD PTR [rsp+0x130],rcx
  c15d41:	cmp    QWORD PTR [rax+0x28],r14
  c15d45:	jbe    c17ed7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85b7>
  c15d4b:	mov    QWORD PTR [rsp+0x210],rcx
  c15d53:	mov    QWORD PTR [rsp+0x428],rdi
  c15d5b:	mov    QWORD PTR [rsp+0x2d0],rsi
  c15d63:	lea    rsi,[r14+r14*2]
  c15d67:	shl    esi,0x3
  c15d6a:	add    rsi,QWORD PTR [rax+0x20]
  c15d6e:	lea    rdi,[rsp+0x120]
  c15d76:	call   QWORD PTR [rip+0x23d0fc]        # e52e78 <_DYNAMIC+0x5830>
  c15d7c:	mov    rcx,QWORD PTR [rsp+0xf8]
  c15d84:	mov    rsi,QWORD PTR [rcx]
  c15d87:	test   al,al
  c15d89:	mov    r14,QWORD PTR [rsp+0x8]
  c15d8e:	je     c15da4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6484>
  c15d90:	cmp    r14,rsi
  c15d93:	jae    c19f13 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5f3>
  c15d99:	mov    rax,QWORD PTR [rbp+0x0]
  c15d9d:	inc    QWORD PTR [rax+r13*1+0x58]
  c15da2:	jmp    c15dba <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x649a>
  c15da4:	cmp    r14,rsi
  c15da7:	jae    c19f0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5ea>
  c15dad:	mov    rax,QWORD PTR [rbp+0x0]
  c15db1:	movsx  rcx,bx
  c15db5:	mov    QWORD PTR [rax+r13*1+0x58],rcx
  c15dba:	mov    rbx,QWORD PTR [rsp+0xf8]
  c15dc2:	mov    eax,DWORD PTR [rsp+0x120]
  c15dc9:	mov    edx,eax
  c15dcb:	sub    edx,0x2
  c15dce:	mov    ecx,0x3
  c15dd3:	cmovae ecx,edx
  c15dd6:	cmp    ecx,0x8
  c15dd9:	ja     c15e38 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6518>
  c15ddb:	mov    edx,0x1e7
  c15de0:	bt     edx,ecx
  c15de3:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15de9:	cmp    ecx,0x3
  c15dec:	jne    c15e1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64fa>
  c15dee:	test   eax,eax
  c15df0:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15df6:	mov    rax,QWORD PTR [rsp+0x128]
  c15dfe:	dec    QWORD PTR [rax]
  c15e01:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15e07:	lea    rdi,[rsp+0x128]
  c15e0f:	call   QWORD PTR [rip+0x237a7b]        # e4d890 <_DYNAMIC+0x248>
  c15e15:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15e1a:	mov    rax,QWORD PTR [rsp+0x128]
  c15e22:	dec    QWORD PTR [rax]
  c15e25:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15e2b:	lea    rdi,[rsp+0x128]
  c15e33:	jmp    c16dd9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b9>
  c15e38:	mov    rax,QWORD PTR [rsp+0x128]
  c15e40:	dec    QWORD PTR [rax]
  c15e43:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15e49:	lea    rdi,[rsp+0x128]
  c15e51:	call   QWORD PTR [rip+0x237a49]        # e4d8a0 <_DYNAMIC+0x258>
  c15e57:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15e5c:	mov    rdi,QWORD PTR [rcx+0x8]
  c15e60:	mov    r8,QWORD PTR [rcx+0x10]
  c15e64:	mov    esi,DWORD PTR [rcx+0x4]
  c15e67:	mov    rcx,r8
  c15e6a:	shl    rsi,0x20
  c15e6e:	or     rsi,rdx
  c15e71:	imul   rax,rax,0xc8
  c15e78:	add    rax,QWORD PTR [rsp+0x3b8]
  c15e80:	mov    QWORD PTR [rsp+0x80],rsi
  c15e88:	mov    QWORD PTR [rsp+0x88],rdi
  c15e90:	mov    QWORD PTR [rsp+0x90],rcx
  c15e98:	cmp    QWORD PTR [rax+0x28],r14
  c15e9c:	jbe    c17f11 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85f1>
  c15ea2:	mov    QWORD PTR [rsp+0x208],rcx
  c15eaa:	mov    QWORD PTR [rsp+0x420],rdi
  c15eb2:	mov    QWORD PTR [rsp+0x2c8],rsi
  c15eba:	lea    rdx,[r14+r14*2]
  c15ebe:	shl    edx,0x3
  c15ec1:	add    rdx,QWORD PTR [rax+0x20]
  c15ec5:	lea    rcx,[rip+0xffffffffff6b0827]        # 2c66f3 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x370>
  c15ecc:	lea    rdi,[rsp+0x120]
  c15ed4:	lea    rsi,[rsp+0x80]
  c15edc:	mov    r8d,0x1
  c15ee2:	call   QWORD PTR [rip+0x239500]        # e4f3e8 <_DYNAMIC+0x1da0>
  c15ee8:	movzx  ecx,BYTE PTR [rsp+0x120]
  c15ef0:	movzx  eax,BYTE PTR [rsp+0x121]
  c15ef8:	cmp    cl,0xff
  c15efb:	mov    r14,QWORD PTR [rsp+0x8]
  c15f00:	jne    c18214 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88f4>
  c15f06:	mov    rcx,QWORD PTR [rsp+0xf8]
  c15f0e:	mov    rsi,QWORD PTR [rcx]
  c15f11:	test   al,al
  c15f13:	js     c15f2d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x660d>
  c15f15:	cmp    r14,rsi
  c15f18:	jae    c19e7a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa55a>
  c15f1e:	mov    rax,QWORD PTR [rbp+0x0]
  c15f22:	movsx  rcx,bx
  c15f26:	mov    QWORD PTR [rax+r13*1+0x58],rcx
  c15f2b:	jmp    c15f3f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x661f>
  c15f2d:	cmp    r14,rsi
  c15f30:	jae    c19f2a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa60a>
  c15f36:	mov    rax,QWORD PTR [rbp+0x0]
  c15f3a:	inc    QWORD PTR [rax+r13*1+0x58]
  c15f3f:	mov    rbx,QWORD PTR [rsp+0xf8]
  c15f47:	mov    eax,DWORD PTR [rsp+0x80]
  c15f4e:	mov    edx,eax
  c15f50:	sub    edx,0x2
  c15f53:	mov    ecx,0x3
  c15f58:	cmovae ecx,edx
  c15f5b:	cmp    ecx,0x8
  c15f5e:	ja     c15fbd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x669d>
  c15f60:	mov    edx,0x1e7
  c15f65:	bt     edx,ecx
  c15f68:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15f6e:	cmp    ecx,0x3
  c15f71:	jne    c15f9f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x667f>
  c15f73:	test   eax,eax
  c15f75:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15f7b:	mov    rax,QWORD PTR [rsp+0x88]
  c15f83:	dec    QWORD PTR [rax]
  c15f86:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15f8c:	lea    rdi,[rsp+0x88]
  c15f94:	call   QWORD PTR [rip+0x2378f6]        # e4d890 <_DYNAMIC+0x248>
  c15f9a:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15f9f:	mov    rax,QWORD PTR [rsp+0x88]
  c15fa7:	dec    QWORD PTR [rax]
  c15faa:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15fb0:	lea    rdi,[rsp+0x88]
  c15fb8:	jmp    c16dd9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b9>
  c15fbd:	mov    rax,QWORD PTR [rsp+0x88]
  c15fc5:	dec    QWORD PTR [rax]
  c15fc8:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15fce:	lea    rdi,[rsp+0x88]
  c15fd6:	call   QWORD PTR [rip+0x2378c4]        # e4d8a0 <_DYNAMIC+0x258>
  c15fdc:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c15fe1:	mov    rsi,QWORD PTR [rcx+0x8]
  c15fe5:	mov    rdi,QWORD PTR [rcx+0x10]
  c15fe9:	mov    eax,DWORD PTR [rcx+0x4]
  c15fec:	shl    rax,0x20
  c15ff0:	or     rax,rdx
  c15ff3:	movq   xmm1,rdi
  c15ff8:	movq   xmm0,rsi
  c15ffd:	punpcklqdq xmm0,xmm1
  c16001:	mov    QWORD PTR [rsp+0x80],rax
  c16009:	movdqu XMMWORD PTR [rsp+0x88],xmm0
  c16012:	lea    rcx,[rip+0xffffffffff6b06de]        # 2c66f7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x374>
  c16019:	lea    rdi,[rsp+0x120]
  c16021:	lea    rsi,[rsp+0x40]
  c16026:	lea    rdx,[rsp+0x80]
  c1602e:	mov    r8d,0x2
  c16034:	call   QWORD PTR [rip+0x2393ae]        # e4f3e8 <_DYNAMIC+0x1da0>
  c1603a:	movzx  ecx,BYTE PTR [rsp+0x120]
  c16042:	movzx  r14d,BYTE PTR [rsp+0x121]
  c1604b:	cmp    cl,0xff
  c1604e:	jne    c17ff8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x86d8>
  c16054:	mov    rax,r12
  c16057:	sub    rax,rbp
  c1605a:	jae    c1606a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x674a>
  c1605c:	mov    rax,QWORD PTR [rbx+0x28]
  c16060:	shl    r12d,0x4
  c16064:	mov    rax,QWORD PTR [rax+r12*1]
  c16068:	jmp    c1606e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x674e>
  c1606a:	add    rax,QWORD PTR [rbx+0x60]
  c1606e:	mov    rcx,QWORD PTR [rsp+0x20]
  c16073:	lea    rbx,[rcx+0x10]
  c16077:	cmp    rax,r13
  c1607a:	jae    c18308 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89e8>
  c16080:	not    r14b
  c16083:	shr    r14b,0x7
  c16087:	lea    rax,[rax+rax*2]
  c1608b:	lea    r12,[r15+rax*8]
  c1608f:	mov    eax,DWORD PTR [r15+rax*8]
  c16093:	mov    edx,eax
  c16095:	sub    edx,0x2
  c16098:	mov    ecx,0x3
  c1609d:	cmovae ecx,edx
  c160a0:	cmp    ecx,0x8
  c160a3:	ja     c161d9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68b9>
  c160a9:	mov    edx,0x1e7
  c160ae:	bt     edx,ecx
  c160b1:	mov    rdx,QWORD PTR [rsp+0x20]
  c160b6:	lea    rbp,[rdx+0x8]
  c160ba:	mov    r15,QWORD PTR [rsp+0x1b8]
  c160c2:	jae    c1613c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x681c>
  c160c4:	mov    DWORD PTR [r12],0x4
  c160cc:	mov    BYTE PTR [r12+0x4],r14b
  c160d1:	mov    eax,DWORD PTR [rsp+0x80]
  c160d8:	mov    edx,eax
  c160da:	sub    edx,0x2
  c160dd:	mov    ecx,0x3
  c160e2:	cmovae ecx,edx
  c160e5:	cmp    ecx,0x8
  c160e8:	ja     c1622c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x690c>
  c160ee:	mov    edx,0x1e7
  c160f3:	bt     edx,ecx
  c160f6:	mov    r14,QWORD PTR [rsp+0x8]
  c160fb:	mov    r13,QWORD PTR [rsp+0x28]
  c16100:	mov    r12d,DWORD PTR [rsp+0x30]
  c16105:	jae    c16167 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6847>
  c16107:	mov    eax,DWORD PTR [rsp+0x40]
  c1610b:	mov    edx,eax
  c1610d:	sub    edx,0x2
  c16110:	mov    ecx,0x3
  c16115:	cmovae ecx,edx
  c16118:	cmp    ecx,0x8
  c1611b:	ja     c1627d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x695d>
  c16121:	mov    edx,0x1e7
  c16126:	bt     edx,ecx
  c16129:	jae    c16194 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6874>
  c1612b:	mov    rsi,QWORD PTR [rbx]
  c1612e:	cmp    r14,rsi
  c16131:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c16137:	jmp    c19dcd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4ad>
  c1613c:	cmp    ecx,0x3
  c1613f:	jne    c161bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x689b>
  c16141:	test   eax,eax
  c16143:	je     c160c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67a4>
  c16149:	mov    rax,QWORD PTR [r12+0x8]
  c1614e:	dec    QWORD PTR [rax]
  c16151:	jne    c160c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67a4>
  c16157:	lea    rdi,[r12+0x8]
  c1615c:	call   QWORD PTR [rip+0x23772e]        # e4d890 <_DYNAMIC+0x248>
  c16162:	jmp    c160c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67a4>
  c16167:	cmp    ecx,0x3
  c1616a:	jne    c16208 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68e8>
  c16170:	test   eax,eax
  c16172:	je     c16107 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67e7>
  c16174:	mov    rax,QWORD PTR [rsp+0x88]
  c1617c:	dec    QWORD PTR [rax]
  c1617f:	jne    c16107 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67e7>
  c16181:	lea    rdi,[rsp+0x88]
  c16189:	call   QWORD PTR [rip+0x237701]        # e4d890 <_DYNAMIC+0x248>
  c1618f:	jmp    c16107 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67e7>
  c16194:	cmp    ecx,0x3
  c16197:	jne    c1625f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x693f>
  c1619d:	test   eax,eax
  c1619f:	je     c1612b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x680b>
  c161a1:	mov    rax,QWORD PTR [rsp+0x48]
  c161a6:	dec    QWORD PTR [rax]
  c161a9:	jne    c1612b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x680b>
  c161ab:	lea    rdi,[rsp+0x48]
  c161b0:	call   QWORD PTR [rip+0x2376da]        # e4d890 <_DYNAMIC+0x248>
  c161b6:	jmp    c1612b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x680b>
  c161bb:	mov    rax,QWORD PTR [r12+0x8]
  c161c0:	dec    QWORD PTR [rax]
  c161c3:	jne    c160c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67a4>
  c161c9:	lea    rdi,[r12+0x8]
  c161ce:	call   QWORD PTR [rip+0x2376c4]        # e4d898 <_DYNAMIC+0x250>
  c161d4:	jmp    c160c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67a4>
  c161d9:	mov    rax,QWORD PTR [r12+0x8]
  c161de:	dec    QWORD PTR [rax]
  c161e1:	mov    rax,QWORD PTR [rsp+0x20]
  c161e6:	lea    rbp,[rax+0x8]
  c161ea:	mov    r15,QWORD PTR [rsp+0x1b8]
  c161f2:	jne    c160c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67a4>
  c161f8:	lea    rdi,[r12+0x8]
  c161fd:	call   QWORD PTR [rip+0x23769d]        # e4d8a0 <_DYNAMIC+0x258>
  c16203:	jmp    c160c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67a4>
  c16208:	mov    rax,QWORD PTR [rsp+0x88]
  c16210:	dec    QWORD PTR [rax]
  c16213:	jne    c16107 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67e7>
  c16219:	lea    rdi,[rsp+0x88]
  c16221:	call   QWORD PTR [rip+0x237671]        # e4d898 <_DYNAMIC+0x250>
  c16227:	jmp    c16107 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67e7>
  c1622c:	mov    rax,QWORD PTR [rsp+0x88]
  c16234:	dec    QWORD PTR [rax]
  c16237:	mov    r14,QWORD PTR [rsp+0x8]
  c1623c:	mov    r13,QWORD PTR [rsp+0x28]
  c16241:	mov    r12d,DWORD PTR [rsp+0x30]
  c16246:	jne    c16107 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67e7>
  c1624c:	lea    rdi,[rsp+0x88]
  c16254:	call   QWORD PTR [rip+0x237646]        # e4d8a0 <_DYNAMIC+0x258>
  c1625a:	jmp    c16107 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67e7>
  c1625f:	mov    rax,QWORD PTR [rsp+0x48]
  c16264:	dec    QWORD PTR [rax]
  c16267:	jne    c1612b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x680b>
  c1626d:	lea    rdi,[rsp+0x48]
  c16272:	call   QWORD PTR [rip+0x237620]        # e4d898 <_DYNAMIC+0x250>
  c16278:	jmp    c1612b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x680b>
  c1627d:	mov    rax,QWORD PTR [rsp+0x48]
  c16282:	dec    QWORD PTR [rax]
  c16285:	jne    c1612b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x680b>
  c1628b:	lea    rdi,[rsp+0x48]
  c16290:	call   QWORD PTR [rip+0x23760a]        # e4d8a0 <_DYNAMIC+0x258>
  c16296:	jmp    c1612b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x680b>
  c1629b:	mov    rsi,QWORD PTR [rcx+0x8]
  c1629f:	mov    rdi,QWORD PTR [rcx+0x10]
  c162a3:	mov    eax,DWORD PTR [rcx+0x4]
  c162a6:	shl    rax,0x20
  c162aa:	or     rax,rdx
  c162ad:	movq   xmm1,rdi
  c162b2:	movq   xmm0,rsi
  c162b7:	punpcklqdq xmm0,xmm1
  c162bb:	mov    QWORD PTR [rsp+0x80],rax
  c162c3:	movdqu XMMWORD PTR [rsp+0x88],xmm0
  c162cc:	lea    rcx,[rip+0xffffffffff6b0421]        # 2c66f4 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x371>
  c162d3:	lea    rdi,[rsp+0x120]
  c162db:	lea    rsi,[rsp+0x40]
  c162e0:	lea    rdx,[rsp+0x80]
  c162e8:	mov    r8d,0x1
  c162ee:	call   QWORD PTR [rip+0x2390f4]        # e4f3e8 <_DYNAMIC+0x1da0>
  c162f4:	movzx  r14d,BYTE PTR [rsp+0x120]
  c162fd:	movzx  ecx,BYTE PTR [rsp+0x121]
  c16305:	cmp    r14b,0xff
  c16309:	jne    c17fa1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8681>
  c1630f:	mov    rax,r12
  c16312:	sub    rax,rbp
  c16315:	jae    c16325 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a05>
  c16317:	mov    rax,QWORD PTR [rbx+0x28]
  c1631b:	shl    r12d,0x4
  c1631f:	mov    rax,QWORD PTR [rax+r12*1]
  c16323:	jmp    c16329 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a09>
  c16325:	add    rax,QWORD PTR [rbx+0x60]
  c16329:	mov    rbx,QWORD PTR [rsp+0x20]
  c1632e:	mov    r12d,DWORD PTR [rsp+0x30]
  c16333:	test   cl,cl
  c16335:	setg   bpl
  c16339:	cmp    rax,r13
  c1633c:	jae    c18433 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b13>
  c16342:	lea    rax,[rax+rax*2]
  c16346:	lea    r14,[r15+rax*8]
  c1634a:	mov    eax,DWORD PTR [r15+rax*8]
  c1634e:	mov    edx,eax
  c16350:	sub    edx,0x2
  c16353:	mov    ecx,0x3
  c16358:	cmovae ecx,edx
  c1635b:	cmp    ecx,0x8
  c1635e:	ja     c16485 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b65>
  c16364:	mov    edx,0x1e7
  c16369:	bt     edx,ecx
  c1636c:	mov    r13,QWORD PTR [rsp+0x28]
  c16371:	mov    r15,QWORD PTR [rsp+0x1b8]
  c16379:	jae    c163f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ad0>
  c1637b:	mov    DWORD PTR [r14],0x4
  c16382:	mov    BYTE PTR [r14+0x4],bpl
  c16386:	mov    eax,DWORD PTR [rsp+0x80]
  c1638d:	mov    edx,eax
  c1638f:	sub    edx,0x2
  c16392:	mov    ecx,0x3
  c16397:	cmovae ecx,edx
  c1639a:	cmp    ecx,0x8
  c1639d:	ja     c164d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6bb2>
  c163a3:	mov    edx,0x1e7
  c163a8:	bt     edx,ecx
  c163ab:	mov    r14,QWORD PTR [rsp+0x8]
  c163b0:	lea    rbx,[rbx+0x10]
  c163b4:	mov    rbp,QWORD PTR [rsp+0x10]
  c163b9:	jae    c16415 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6af5>
  c163bb:	mov    eax,DWORD PTR [rsp+0x40]
  c163bf:	mov    edx,eax
  c163c1:	sub    edx,0x2
  c163c4:	mov    ecx,0x3
  c163c9:	cmovae ecx,edx
  c163cc:	cmp    ecx,0x8
  c163cf:	ja     c16522 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c02>
  c163d5:	mov    edx,0x1e7
  c163da:	bt     edx,ecx
  c163dd:	jae    c16442 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b22>
  c163df:	mov    rsi,QWORD PTR [rbx]
  c163e2:	cmp    r14,rsi
  c163e5:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c163eb:	jmp    c19ded <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4cd>
  c163f0:	cmp    ecx,0x3
  c163f3:	jne    c16469 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b49>
  c163f5:	test   eax,eax
  c163f7:	je     c1637b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a5b>
  c163f9:	mov    rax,QWORD PTR [r14+0x8]
  c163fd:	dec    QWORD PTR [rax]
  c16400:	jne    c1637b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a5b>
  c16406:	lea    rdi,[r14+0x8]
  c1640a:	call   QWORD PTR [rip+0x237480]        # e4d890 <_DYNAMIC+0x248>
  c16410:	jmp    c1637b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a5b>
  c16415:	cmp    ecx,0x3
  c16418:	jne    c164ae <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b8e>
  c1641e:	test   eax,eax
  c16420:	je     c163bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a9b>
  c16422:	mov    rax,QWORD PTR [rsp+0x88]
  c1642a:	dec    QWORD PTR [rax]
  c1642d:	jne    c163bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a9b>
  c1642f:	lea    rdi,[rsp+0x88]
  c16437:	call   QWORD PTR [rip+0x237453]        # e4d890 <_DYNAMIC+0x248>
  c1643d:	jmp    c163bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a9b>
  c16442:	cmp    ecx,0x3
  c16445:	jne    c16504 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6be4>
  c1644b:	test   eax,eax
  c1644d:	je     c163df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6abf>
  c1644f:	mov    rax,QWORD PTR [rsp+0x48]
  c16454:	dec    QWORD PTR [rax]
  c16457:	jne    c163df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6abf>
  c16459:	lea    rdi,[rsp+0x48]
  c1645e:	call   QWORD PTR [rip+0x23742c]        # e4d890 <_DYNAMIC+0x248>
  c16464:	jmp    c163df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6abf>
  c16469:	mov    rax,QWORD PTR [r14+0x8]
  c1646d:	dec    QWORD PTR [rax]
  c16470:	jne    c1637b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a5b>
  c16476:	lea    rdi,[r14+0x8]
  c1647a:	call   QWORD PTR [rip+0x237418]        # e4d898 <_DYNAMIC+0x250>
  c16480:	jmp    c1637b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a5b>
  c16485:	mov    rax,QWORD PTR [r14+0x8]
  c16489:	dec    QWORD PTR [rax]
  c1648c:	mov    r13,QWORD PTR [rsp+0x28]
  c16491:	mov    r15,QWORD PTR [rsp+0x1b8]
  c16499:	jne    c1637b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a5b>
  c1649f:	lea    rdi,[r14+0x8]
  c164a3:	call   QWORD PTR [rip+0x2373f7]        # e4d8a0 <_DYNAMIC+0x258>
  c164a9:	jmp    c1637b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a5b>
  c164ae:	mov    rax,QWORD PTR [rsp+0x88]
  c164b6:	dec    QWORD PTR [rax]
  c164b9:	jne    c163bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a9b>
  c164bf:	lea    rdi,[rsp+0x88]
  c164c7:	call   QWORD PTR [rip+0x2373cb]        # e4d898 <_DYNAMIC+0x250>
  c164cd:	jmp    c163bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a9b>
  c164d2:	mov    rax,QWORD PTR [rsp+0x88]
  c164da:	dec    QWORD PTR [rax]
  c164dd:	mov    r14,QWORD PTR [rsp+0x8]
  c164e2:	lea    rbx,[rbx+0x10]
  c164e6:	mov    rbp,QWORD PTR [rsp+0x10]
  c164eb:	jne    c163bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a9b>
  c164f1:	lea    rdi,[rsp+0x88]
  c164f9:	call   QWORD PTR [rip+0x2373a1]        # e4d8a0 <_DYNAMIC+0x258>
  c164ff:	jmp    c163bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a9b>
  c16504:	mov    rax,QWORD PTR [rsp+0x48]
  c16509:	dec    QWORD PTR [rax]
  c1650c:	jne    c163df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6abf>
  c16512:	lea    rdi,[rsp+0x48]
  c16517:	call   QWORD PTR [rip+0x23737b]        # e4d898 <_DYNAMIC+0x250>
  c1651d:	jmp    c163df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6abf>
  c16522:	mov    rax,QWORD PTR [rsp+0x48]
  c16527:	dec    QWORD PTR [rax]
  c1652a:	jne    c163df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6abf>
  c16530:	lea    rdi,[rsp+0x48]
  c16535:	call   QWORD PTR [rip+0x237365]        # e4d8a0 <_DYNAMIC+0x258>
  c1653b:	jmp    c163df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6abf>
  c16540:	mov    rsi,QWORD PTR [rcx+0x8]
  c16544:	mov    rdi,QWORD PTR [rcx+0x10]
  c16548:	mov    eax,DWORD PTR [rcx+0x4]
  c1654b:	shl    rax,0x20
  c1654f:	or     rax,rdx
  c16552:	movq   xmm1,rdi
  c16557:	movq   xmm0,rsi
  c1655c:	punpcklqdq xmm0,xmm1
  c16560:	mov    QWORD PTR [rsp+0x80],rax
  c16568:	movdqu XMMWORD PTR [rsp+0x88],xmm0
  c16571:	lea    rcx,[rip+0xffffffffff6b017d]        # 2c66f5 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x372>
  c16578:	lea    rdi,[rsp+0x120]
  c16580:	lea    rsi,[rsp+0x40]
  c16585:	lea    rdx,[rsp+0x80]
  c1658d:	mov    r8d,0x2
  c16593:	call   QWORD PTR [rip+0x238e4f]        # e4f3e8 <_DYNAMIC+0x1da0>
  c16599:	movzx  r14d,BYTE PTR [rsp+0x120]
  c165a2:	movzx  ecx,BYTE PTR [rsp+0x121]
  c165aa:	cmp    r14b,0xff
  c165ae:	jne    c18054 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8734>
  c165b4:	mov    rax,r12
  c165b7:	sub    rax,rbp
  c165ba:	jae    c165ca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6caa>
  c165bc:	mov    rax,QWORD PTR [rbx+0x28]
  c165c0:	shl    r12d,0x4
  c165c4:	mov    rax,QWORD PTR [rax+r12*1]
  c165c8:	jmp    c165ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6cae>
  c165ca:	add    rax,QWORD PTR [rbx+0x60]
  c165ce:	mov    rbx,QWORD PTR [rsp+0x20]
  c165d3:	mov    r12d,DWORD PTR [rsp+0x30]
  c165d8:	test   cl,cl
  c165da:	setle  bpl
  c165de:	cmp    rax,r13
  c165e1:	jae    c183b8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a98>
  c165e7:	lea    rax,[rax+rax*2]
  c165eb:	lea    r14,[r15+rax*8]
  c165ef:	mov    eax,DWORD PTR [r15+rax*8]
  c165f3:	mov    edx,eax
  c165f5:	sub    edx,0x2
  c165f8:	mov    ecx,0x3
  c165fd:	cmovae ecx,edx
  c16600:	cmp    ecx,0x8
  c16603:	ja     c1672a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e0a>
  c16609:	mov    edx,0x1e7
  c1660e:	bt     edx,ecx
  c16611:	mov    r13,QWORD PTR [rsp+0x28]
  c16616:	mov    r15,QWORD PTR [rsp+0x1b8]
  c1661e:	jae    c16695 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d75>
  c16620:	mov    DWORD PTR [r14],0x4
  c16627:	mov    BYTE PTR [r14+0x4],bpl
  c1662b:	mov    eax,DWORD PTR [rsp+0x80]
  c16632:	mov    edx,eax
  c16634:	sub    edx,0x2
  c16637:	mov    ecx,0x3
  c1663c:	cmovae ecx,edx
  c1663f:	cmp    ecx,0x8
  c16642:	ja     c16777 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e57>
  c16648:	mov    edx,0x1e7
  c1664d:	bt     edx,ecx
  c16650:	mov    r14,QWORD PTR [rsp+0x8]
  c16655:	lea    rbx,[rbx+0x10]
  c16659:	mov    rbp,QWORD PTR [rsp+0x10]
  c1665e:	jae    c166ba <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d9a>
  c16660:	mov    eax,DWORD PTR [rsp+0x40]
  c16664:	mov    edx,eax
  c16666:	sub    edx,0x2
  c16669:	mov    ecx,0x3
  c1666e:	cmovae ecx,edx
  c16671:	cmp    ecx,0x8
  c16674:	ja     c167c7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ea7>
  c1667a:	mov    edx,0x1e7
  c1667f:	bt     edx,ecx
  c16682:	jae    c166e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dc7>
  c16684:	mov    rsi,QWORD PTR [rbx]
  c16687:	cmp    r14,rsi
  c1668a:	jb     c16960 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7040>
  c16690:	jmp    c19dfd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4dd>
  c16695:	cmp    ecx,0x3
  c16698:	jne    c1670e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dee>
  c1669a:	test   eax,eax
  c1669c:	je     c16620 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d00>
  c1669e:	mov    rax,QWORD PTR [r14+0x8]
  c166a2:	dec    QWORD PTR [rax]
  c166a5:	jne    c16620 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d00>
  c166ab:	lea    rdi,[r14+0x8]
  c166af:	call   QWORD PTR [rip+0x2371db]        # e4d890 <_DYNAMIC+0x248>
  c166b5:	jmp    c16620 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d00>
  c166ba:	cmp    ecx,0x3
  c166bd:	jne    c16753 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e33>
  c166c3:	test   eax,eax
  c166c5:	je     c16660 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d40>
  c166c7:	mov    rax,QWORD PTR [rsp+0x88]
  c166cf:	dec    QWORD PTR [rax]
  c166d2:	jne    c16660 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d40>
  c166d4:	lea    rdi,[rsp+0x88]
  c166dc:	call   QWORD PTR [rip+0x2371ae]        # e4d890 <_DYNAMIC+0x248>
  c166e2:	jmp    c16660 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d40>
  c166e7:	cmp    ecx,0x3
  c166ea:	jne    c167a9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e89>
  c166f0:	test   eax,eax
  c166f2:	je     c16684 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d64>
  c166f4:	mov    rax,QWORD PTR [rsp+0x48]
  c166f9:	dec    QWORD PTR [rax]
  c166fc:	jne    c16684 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d64>
  c166fe:	lea    rdi,[rsp+0x48]
  c16703:	call   QWORD PTR [rip+0x237187]        # e4d890 <_DYNAMIC+0x248>
  c16709:	jmp    c16684 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d64>
  c1670e:	mov    rax,QWORD PTR [r14+0x8]
  c16712:	dec    QWORD PTR [rax]
  c16715:	jne    c16620 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d00>
  c1671b:	lea    rdi,[r14+0x8]
  c1671f:	call   QWORD PTR [rip+0x237173]        # e4d898 <_DYNAMIC+0x250>
  c16725:	jmp    c16620 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d00>
  c1672a:	mov    rax,QWORD PTR [r14+0x8]
  c1672e:	dec    QWORD PTR [rax]
  c16731:	mov    r13,QWORD PTR [rsp+0x28]
  c16736:	mov    r15,QWORD PTR [rsp+0x1b8]
  c1673e:	jne    c16620 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d00>
  c16744:	lea    rdi,[r14+0x8]
  c16748:	call   QWORD PTR [rip+0x237152]        # e4d8a0 <_DYNAMIC+0x258>
  c1674e:	jmp    c16620 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d00>
  c16753:	mov    rax,QWORD PTR [rsp+0x88]
  c1675b:	dec    QWORD PTR [rax]
  c1675e:	jne    c16660 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d40>
  c16764:	lea    rdi,[rsp+0x88]
  c1676c:	call   QWORD PTR [rip+0x237126]        # e4d898 <_DYNAMIC+0x250>
  c16772:	jmp    c16660 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d40>
  c16777:	mov    rax,QWORD PTR [rsp+0x88]
  c1677f:	dec    QWORD PTR [rax]
  c16782:	mov    r14,QWORD PTR [rsp+0x8]
  c16787:	lea    rbx,[rbx+0x10]
  c1678b:	mov    rbp,QWORD PTR [rsp+0x10]
  c16790:	jne    c16660 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d40>
  c16796:	lea    rdi,[rsp+0x88]
  c1679e:	call   QWORD PTR [rip+0x2370fc]        # e4d8a0 <_DYNAMIC+0x258>
  c167a4:	jmp    c16660 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d40>
  c167a9:	mov    rax,QWORD PTR [rsp+0x48]
  c167ae:	dec    QWORD PTR [rax]
  c167b1:	jne    c16684 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d64>
  c167b7:	lea    rdi,[rsp+0x48]
  c167bc:	call   QWORD PTR [rip+0x2370d6]        # e4d898 <_DYNAMIC+0x250>
  c167c2:	jmp    c16684 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d64>
  c167c7:	mov    rax,QWORD PTR [rsp+0x48]
  c167cc:	dec    QWORD PTR [rax]
  c167cf:	jne    c16684 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d64>
  c167d5:	lea    rdi,[rsp+0x48]
  c167da:	call   QWORD PTR [rip+0x2370c0]        # e4d8a0 <_DYNAMIC+0x258>
  c167e0:	jmp    c16684 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d64>
  c167e5:	mov    rsi,QWORD PTR [rcx+0x8]
  c167e9:	mov    rdi,QWORD PTR [rcx+0x10]
  c167ed:	mov    eax,DWORD PTR [rcx+0x4]
  c167f0:	shl    rax,0x20
  c167f4:	or     rax,rdx
  c167f7:	movq   xmm1,rdi
  c167fc:	movq   xmm0,rsi
  c16801:	punpcklqdq xmm0,xmm1
  c16805:	mov    r13,r15
  c16808:	mov    QWORD PTR [rsp+0x80],rax
  c16810:	movdqu XMMWORD PTR [rsp+0x88],xmm0
  c16819:	lea    rcx,[rip+0xffffffffff6afed3]        # 2c66f3 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x370>
  c16820:	lea    rdi,[rsp+0x120]
  c16828:	lea    rsi,[rsp+0x40]
  c1682d:	lea    rdx,[rsp+0x80]
  c16835:	mov    r8d,0x1
  c1683b:	call   QWORD PTR [rip+0x238ba7]        # e4f3e8 <_DYNAMIC+0x1da0>
  c16841:	movzx  r15d,BYTE PTR [rsp+0x120]
  c1684a:	movzx  ebp,BYTE PTR [rsp+0x121]
  c16852:	cmp    r15b,0xff
  c16856:	jne    c180ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x878b>
  c1685c:	mov    rax,r12
  c1685f:	sub    rax,QWORD PTR [rsp+0x1e0]
  c16867:	jae    c16877 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f57>
  c16869:	mov    rax,QWORD PTR [rbx+0x28]
  c1686d:	shl    r12d,0x4
  c16871:	mov    rax,QWORD PTR [rax+r12*1]
  c16875:	jmp    c1687b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f5b>
  c16877:	add    rax,QWORD PTR [rbx+0x60]
  c1687b:	mov    rbx,QWORD PTR [rsp+0x20]
  c16880:	mov    r12d,DWORD PTR [rsp+0x30]
  c16885:	cmp    rax,QWORD PTR [rsp+0x2a8]
  c1688d:	jae    c18258 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8938>
  c16893:	shr    bpl,0x7
  c16897:	mov    BYTE PTR [rsp+0x30],bpl
  c1689c:	lea    rax,[rax+rax*2]
  c168a0:	lea    r15,[r14+rax*8]
  c168a4:	mov    eax,DWORD PTR [r14+rax*8]
  c168a8:	mov    edx,eax
  c168aa:	sub    edx,0x2
  c168ad:	mov    ecx,0x3
  c168b2:	cmovae ecx,edx
  c168b5:	cmp    ecx,0x8
  c168b8:	ja     c16ac5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71a5>
  c168be:	mov    edx,0x1e7
  c168c3:	bt     edx,ecx
  c168c6:	mov    rbp,QWORD PTR [rsp+0x28]
  c168cb:	jae    c16a18 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x70f8>
  c168d1:	mov    DWORD PTR [r15],0x4
  c168d8:	movzx  eax,BYTE PTR [rsp+0x30]
  c168dd:	mov    BYTE PTR [r15+0x4],al
  c168e1:	mov    eax,DWORD PTR [rsp+0x80]
  c168e8:	mov    edx,eax
  c168ea:	sub    edx,0x2
  c168ed:	mov    ecx,0x3
  c168f2:	cmovae ecx,edx
  c168f5:	cmp    ecx,0x8
  c168f8:	ja     c16b0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71ea>
  c168fe:	mov    edx,0x1e7
  c16903:	bt     edx,ecx
  c16906:	mov    r14,QWORD PTR [rsp+0x8]
  c1690b:	lea    rbx,[rbx+0x8]
  c1690f:	mov    r15,r13
  c16912:	mov    r13,rbp
  c16915:	jae    c16a45 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7125>
  c1691b:	mov    eax,DWORD PTR [rsp+0x40]
  c1691f:	mov    edx,eax
  c16921:	sub    edx,0x2
  c16924:	mov    ecx,0x3
  c16929:	cmovae ecx,edx
  c1692c:	cmp    ecx,0x8
  c1692f:	ja     c16b5b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x723b>
  c16935:	mov    edx,0x1e7
  c1693a:	bt     edx,ecx
  c1693d:	mov    rbp,rbx
  c16940:	mov    rbx,QWORD PTR [rsp+0xf8]
  c16948:	jae    c16a7a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x715a>
  c1694e:	mov    rsi,QWORD PTR [rbx]
  c16951:	cmp    r14,rsi
  c16954:	jae    c19ddd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4bd>
  c1695a:	nop    WORD PTR [rax+rax*1+0x0]
  c16960:	mov    rax,QWORD PTR [rbp+0x0]
  c16964:	inc    QWORD PTR [rax+r13*1+0x58]
  c16969:	test   r12b,r12b
  c1696c:	je     c169c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x70a0>
  c1696e:	mov    rsi,QWORD PTR [rbx]
  c16971:	cmp    r14,rsi
  c16974:	jae    c198c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fa0>
  c1697a:	mov    rax,QWORD PTR [rbp+0x0]
  c1697e:	mov    r15,QWORD PTR [rax+r13*1+0x58]
  c16983:	cmp    r15,QWORD PTR [rsp+0x1f0]
  c1698b:	jae    c19722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e02>
  c16991:	dec    r12b
  c16994:	mov    r10,QWORD PTR [rsp+0x1e8]
  c1699c:	mov    DWORD PTR [rsp+0x30],r12d
  c169a1:	cmp    r15,QWORD PTR [rsp+0x1f0]
  c169a9:	jb     c0fc4c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x32c>
  c169af:	jmp    c198a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f88>
  c169b4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  c169c0:	cmp    BYTE PTR [rsp+0x648],0x0
  c169c8:	je     c19722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e02>
  c169ce:	mov    rax,QWORD PTR [rsp+0x580]
  c169d6:	cmp    QWORD PTR [rbx],rax
  c169d9:	jne    c19722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e02>
  c169df:	mov    rax,QWORD PTR [rbp+0x0]
  c169e3:	mov    rax,QWORD PTR [rax+r13*1+0x58]
  c169e8:	inc    r15
  c169eb:	cmp    rax,r15
  c169ee:	jne    c19722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e02>
  c169f4:	cmp    rax,QWORD PTR [rsp+0x1f0]
  c169fc:	jae    c19722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e02>
  c16a02:	cmp    rax,QWORD PTR [rsp+0x578]
  c16a0a:	jb     c0fc19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2f9>
  c16a10:	xor    r12d,r12d
  c16a13:	jmp    c0fc2e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x30e>
  c16a18:	cmp    ecx,0x3
  c16a1b:	jne    c16aa9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7189>
  c16a21:	test   eax,eax
  c16a23:	je     c168d1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fb1>
  c16a29:	mov    rax,QWORD PTR [r15+0x8]
  c16a2d:	dec    QWORD PTR [rax]
  c16a30:	jne    c168d1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fb1>
  c16a36:	lea    rdi,[r15+0x8]
  c16a3a:	call   QWORD PTR [rip+0x236e50]        # e4d890 <_DYNAMIC+0x248>
  c16a40:	jmp    c168d1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fb1>
  c16a45:	cmp    ecx,0x3
  c16a48:	jne    c16ae6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71c6>
  c16a4e:	test   eax,eax
  c16a50:	je     c1691b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ffb>
  c16a56:	mov    rax,QWORD PTR [rsp+0x88]
  c16a5e:	dec    QWORD PTR [rax]
  c16a61:	jne    c1691b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ffb>
  c16a67:	lea    rdi,[rsp+0x88]
  c16a6f:	call   QWORD PTR [rip+0x236e1b]        # e4d890 <_DYNAMIC+0x248>
  c16a75:	jmp    c1691b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ffb>
  c16a7a:	cmp    ecx,0x3
  c16a7d:	jne    c16b3d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x721d>
  c16a83:	test   eax,eax
  c16a85:	je     c1694e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x702e>
  c16a8b:	mov    rax,QWORD PTR [rsp+0x48]
  c16a90:	dec    QWORD PTR [rax]
  c16a93:	jne    c1694e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x702e>
  c16a99:	lea    rdi,[rsp+0x48]
  c16a9e:	call   QWORD PTR [rip+0x236dec]        # e4d890 <_DYNAMIC+0x248>
  c16aa4:	jmp    c1694e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x702e>
  c16aa9:	mov    rax,QWORD PTR [r15+0x8]
  c16aad:	dec    QWORD PTR [rax]
  c16ab0:	jne    c168d1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fb1>
  c16ab6:	lea    rdi,[r15+0x8]
  c16aba:	call   QWORD PTR [rip+0x236dd8]        # e4d898 <_DYNAMIC+0x250>
  c16ac0:	jmp    c168d1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fb1>
  c16ac5:	mov    rax,QWORD PTR [r15+0x8]
  c16ac9:	dec    QWORD PTR [rax]
  c16acc:	mov    rbp,QWORD PTR [rsp+0x28]
  c16ad1:	jne    c168d1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fb1>
  c16ad7:	lea    rdi,[r15+0x8]
  c16adb:	call   QWORD PTR [rip+0x236dbf]        # e4d8a0 <_DYNAMIC+0x258>
  c16ae1:	jmp    c168d1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fb1>
  c16ae6:	mov    rax,QWORD PTR [rsp+0x88]
  c16aee:	dec    QWORD PTR [rax]
  c16af1:	jne    c1691b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ffb>
  c16af7:	lea    rdi,[rsp+0x88]
  c16aff:	call   QWORD PTR [rip+0x236d93]        # e4d898 <_DYNAMIC+0x250>
  c16b05:	jmp    c1691b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ffb>
  c16b0a:	mov    rax,QWORD PTR [rsp+0x88]
  c16b12:	dec    QWORD PTR [rax]
  c16b15:	mov    r14,QWORD PTR [rsp+0x8]
  c16b1a:	lea    rbx,[rbx+0x8]
  c16b1e:	mov    r15,r13
  c16b21:	mov    r13,rbp
  c16b24:	jne    c1691b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ffb>
  c16b2a:	lea    rdi,[rsp+0x88]
  c16b32:	call   QWORD PTR [rip+0x236d68]        # e4d8a0 <_DYNAMIC+0x258>
  c16b38:	jmp    c1691b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ffb>
  c16b3d:	mov    rax,QWORD PTR [rsp+0x48]
  c16b42:	dec    QWORD PTR [rax]
  c16b45:	jne    c1694e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x702e>
  c16b4b:	lea    rdi,[rsp+0x48]
  c16b50:	call   QWORD PTR [rip+0x236d42]        # e4d898 <_DYNAMIC+0x250>
  c16b56:	jmp    c1694e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x702e>
  c16b5b:	mov    rax,QWORD PTR [rsp+0x48]
  c16b60:	dec    QWORD PTR [rax]
  c16b63:	mov    rbp,rbx
  c16b66:	mov    rbx,QWORD PTR [rsp+0xf8]
  c16b6e:	jne    c1694e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x702e>
  c16b74:	lea    rdi,[rsp+0x48]
  c16b79:	call   QWORD PTR [rip+0x236d21]        # e4d8a0 <_DYNAMIC+0x258>
  c16b7f:	jmp    c1694e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x702e>
  c16b84:	mov    rdi,QWORD PTR [rcx+0x8]
  c16b88:	mov    rsi,QWORD PTR [rcx+0x10]
  c16b8c:	mov    r8d,DWORD PTR [rcx+0x4]
  c16b90:	shl    r8,0x20
  c16b94:	or     r8,rdx
  c16b97:	jmp    c14fd4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56b4>
  c16b9c:	mov    r8,QWORD PTR [rax+0x8]
  c16ba0:	mov    rdx,QWORD PTR [rax+0x10]
  c16ba4:	mov    edi,DWORD PTR [rax+0x4]
  c16ba7:	shl    rdi,0x20
  c16bab:	or     rdi,rcx
  c16bae:	jmp    c15476 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b56>
  c16bb3:	mov    r8,QWORD PTR [rax+0x8]
  c16bb7:	mov    rsi,QWORD PTR [rax+0x10]
  c16bbb:	mov    edx,DWORD PTR [rax+0x4]
  c16bbe:	shl    rdx,0x20
  c16bc2:	or     rdx,rcx
  c16bc5:	mov    rax,rsi
  c16bc8:	jmp    c14117 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47f7>
  c16bcd:	mov    rsi,QWORD PTR [rax+0x8]
  c16bd1:	mov    rdi,QWORD PTR [rax+0x10]
  c16bd5:	mov    edx,DWORD PTR [rax+0x4]
  c16bd8:	shl    rdx,0x20
  c16bdc:	or     rdx,rcx
  c16bdf:	jmp    c143b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a90>
  c16be4:	mov    r8,QWORD PTR [rax+0x8]
  c16be8:	mov    rsi,QWORD PTR [rax+0x10]
  c16bec:	mov    edx,DWORD PTR [rax+0x4]
  c16bef:	shl    rdx,0x20
  c16bf3:	or     rdx,rcx
  c16bf6:	mov    rax,rsi
  c16bf9:	jmp    c146f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4dd8>
  c16bfe:	mov    rsi,QWORD PTR [rax+0x8]
  c16c02:	mov    rdi,QWORD PTR [rax+0x10]
  c16c06:	mov    edx,DWORD PTR [rax+0x4]
  c16c09:	shl    rdx,0x20
  c16c0d:	or     rdx,rcx
  c16c10:	jmp    c1513a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x581a>
  c16c15:	mov    rax,rdi
  c16c18:	shr    rax,0x20
  c16c1c:	mov    ecx,edi
  c16c1e:	mov    DWORD PTR [rsp+0x120],ecx
  c16c25:	mov    DWORD PTR [rsp+0x124],eax
  c16c2c:	mov    QWORD PTR [rsp+0x128],r8
  c16c34:	mov    QWORD PTR [rsp+0x130],rdx
  c16c3c:	mov    rax,QWORD PTR [rsp+0x1b0]
  c16c44:	mov    rcx,QWORD PTR [rsp+0x4e0]
  c16c4c:	cmp    QWORD PTR [rsp+0x3c8],rcx
  c16c54:	jae    c186b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d94>
  c16c5a:	cmp    r15,QWORD PTR [rax+0x10]
  c16c5e:	jae    c186c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8da2>
  c16c64:	mov    r12,r10
  c16c67:	mov    QWORD PTR [rsp+0x1d0],rdx
  c16c6f:	lea    r8,[r15+r15*2]
  c16c73:	shl    r8,0x3
  c16c77:	add    r8,QWORD PTR [rax+0x8]
  c16c7b:	lea    rdi,[rsp+0x80]
  c16c83:	lea    rsi,[rsp+0x100]
  c16c8b:	lea    rcx,[rsp+0x120]
  c16c93:	mov    edx,ebx
  c16c95:	call   QWORD PTR [rip+0x23c1ed]        # e52e88 <_DYNAMIC+0x5840>
  c16c9b:	movzx  eax,BYTE PTR [rsp+0x80]
  c16ca3:	cmp    al,0x5
  c16ca5:	setne  bl
  c16ca8:	je     c16cc3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x73a3>
  c16caa:	cmp    al,0xff
  c16cac:	lea    rcx,[r12+0x10]
  c16cb1:	mov    rbp,QWORD PTR [rsp+0x10]
  c16cb6:	mov    r14d,ebx
  c16cb9:	mov    rbx,rcx
  c16cbc:	je     c16d35 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7415>
  c16cbe:	jmp    c18b3d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x921d>
  c16cc3:	mov    rax,QWORD PTR [rsp+0xe0]
  c16ccb:	mov    QWORD PTR [rsp+0x50],rax
  c16cd0:	movdqu xmm0,XMMWORD PTR [rsp+0xd0]
  c16cd9:	movdqa XMMWORD PTR [rsp+0x40],xmm0
  c16cdf:	lea    rdi,[rsp+0x120]
  c16ce7:	lea    rsi,[rsp+0x100]
  c16cef:	lea    r8,[rsp+0x40]
  c16cf4:	mov    rdx,rbp
  c16cf7:	mov    rcx,r14
  c16cfa:	call   QWORD PTR [rip+0x23c190]        # e52e90 <_DYNAMIC+0x5848>
  c16d00:	cmp    BYTE PTR [rsp+0x120],0xff
  c16d08:	lea    rax,[r12+0x10]
  c16d0d:	jne    c18b6d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x924d>
  c16d13:	mov    r14d,ebx
  c16d16:	cmp    BYTE PTR [rsp+0x80],0xff
  c16d1e:	mov    rbp,QWORD PTR [rsp+0x10]
  c16d23:	mov    rbx,rax
  c16d26:	je     c16d35 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7415>
  c16d28:	lea    rdi,[rsp+0x80]
  c16d30:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.2691469935230288402>
  c16d35:	mov    rsi,QWORD PTR [rbx]
  c16d38:	cmp    QWORD PTR [rsp+0x8],rsi
  c16d3d:	mov    r12d,DWORD PTR [rsp+0x30]
  c16d42:	jae    c19e63 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa543>
  c16d48:	mov    rax,QWORD PTR [rbp+0x0]
  c16d4c:	inc    QWORD PTR [rax+r13*1+0x58]
  c16d51:	test   r14b,r14b
  c16d54:	je     c16d63 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7443>
  c16d56:	lea    rdi,[rsp+0xd0]
  c16d5e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c16d63:	mov    eax,DWORD PTR [rsp+0x100]
  c16d6a:	mov    edx,eax
  c16d6c:	sub    edx,0x2
  c16d6f:	mov    ecx,0x3
  c16d74:	cmovae ecx,edx
  c16d77:	cmp    ecx,0x8
  c16d7a:	mov    r14,QWORD PTR [rsp+0x8]
  c16d7f:	ja     c16de4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74c4>
  c16d81:	mov    edx,0x1e7
  c16d86:	bt     edx,ecx
  c16d89:	jb     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c16d8f:	cmp    ecx,0x3
  c16d92:	jne    c16dc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74a0>
  c16d94:	test   eax,eax
  c16d96:	je     c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c16d9c:	mov    rax,QWORD PTR [rsp+0x108]
  c16da4:	dec    QWORD PTR [rax]
  c16da7:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c16dad:	lea    rdi,[rsp+0x108]
  c16db5:	call   QWORD PTR [rip+0x236ad5]        # e4d890 <_DYNAMIC+0x248>
  c16dbb:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c16dc0:	mov    rax,QWORD PTR [rsp+0x108]
  c16dc8:	dec    QWORD PTR [rax]
  c16dcb:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c16dd1:	lea    rdi,[rsp+0x108]
  c16dd9:	call   QWORD PTR [rip+0x236ab9]        # e4d898 <_DYNAMIC+0x250>
  c16ddf:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c16de4:	mov    rax,QWORD PTR [rsp+0x108]
  c16dec:	dec    QWORD PTR [rax]
  c16def:	jne    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c16df5:	lea    rdi,[rsp+0x108]
  c16dfd:	call   QWORD PTR [rip+0x236a9d]        # e4d8a0 <_DYNAMIC+0x258>
  c16e03:	jmp    c16969 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7049>
  c16e08:	mov    rdx,QWORD PTR [rsp+0x1f8]
  c16e10:	movzx  eax,BYTE PTR [rdx+0xc5]
  c16e17:	xor    ecx,ecx
  c16e19:	sub    al,BYTE PTR [rdx+0xc3]
  c16e1f:	movzx  eax,al
  c16e22:	cmovb  eax,ecx
  c16e25:	mov    rbx,QWORD PTR [rdi+0x10]
  c16e29:	movzx  esi,al
  c16e2c:	add    rsi,rbx
  c16e2f:	mov    DWORD PTR [rsp+0x120],0x2
  c16e3a:	lea    rdx,[rsp+0x120]
  c16e42:	call   c33460 <_RNvMs1_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueE6resizeCsbxgXiyEKxkX_6bsl_vm>
  c16e47:	lea    rax,[r12+0x10]
  c16e4c:	mov    rbp,QWORD PTR [rax]
  c16e4f:	cmp    QWORD PTR [rsp+0x8],rbp
  c16e54:	jae    c19f41 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa621>
  c16e5a:	mov    rax,QWORD PTR [r12+0x8]
  c16e5f:	mov    ecx,DWORD PTR [rax+r13*1+0x70]
  c16e64:	mov    rdx,QWORD PTR [rsp+0x50]
  c16e69:	lea    rsi,[rsp+0x124]
  c16e71:	mov    QWORD PTR [rsi+0x2c],rdx
  c16e75:	movups xmm0,XMMWORD PTR [rsp+0x40]
  c16e7a:	movups XMMWORD PTR [rsi+0x1c],xmm0
  c16e7e:	mov    rdx,QWORD PTR [rsp+0x90]
  c16e86:	mov    QWORD PTR [rsi+0x44],rdx
  c16e8a:	movups xmm0,XMMWORD PTR [rsp+0x80]
  c16e92:	movups XMMWORD PTR [rsi+0x34],xmm0
  c16e96:	mov    DWORD PTR [rsp+0x190],ecx
  c16e9d:	mov    rcx,QWORD PTR [rsp+0x4c0]
  c16ea5:	mov    QWORD PTR [rsp+0x170],rcx
  c16ead:	mov    QWORD PTR [rsp+0x178],0x0
  c16eb9:	mov    QWORD PTR [rsp+0x180],rbx
  c16ec1:	mov    QWORD PTR [rsp+0x188],rbx
  c16ec9:	mov    BYTE PTR [rsp+0x194],r14b
  c16ed1:	mov    QWORD PTR [rsp+0x120],0x0
  c16edd:	cmp    rbp,QWORD PTR [r12]
  c16ee1:	mov    r14,QWORD PTR [rsp+0x8]
  c16ee6:	jne    c16ef9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x75d9>
  c16ee8:	mov    rdi,r12
  c16eeb:	call   QWORD PTR [rip+0x23bfa7]        # e52e98 <_DYNAMIC+0x5850>
  c16ef1:	mov    rax,QWORD PTR [rsp+0x10]
  c16ef6:	mov    rax,QWORD PTR [rax]
  c16ef9:	imul   rcx,rbp,0x78
  c16efd:	mov    rdx,QWORD PTR [rsp+0x190]
  c16f05:	mov    QWORD PTR [rax+rcx*1+0x70],rdx
  c16f0a:	movups xmm0,XMMWORD PTR [rsp+0x180]
  c16f12:	movups XMMWORD PTR [rax+rcx*1+0x60],xmm0
  c16f17:	movups xmm0,XMMWORD PTR [rsp+0x170]
  c16f1f:	movups XMMWORD PTR [rax+rcx*1+0x50],xmm0
  c16f24:	movups xmm0,XMMWORD PTR [rsp+0x160]
  c16f2c:	movups XMMWORD PTR [rax+rcx*1+0x40],xmm0
  c16f31:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c16f3a:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c16f43:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c16f4b:	movups xmm3,XMMWORD PTR [rsp+0x150]
  c16f53:	movups XMMWORD PTR [rax+rcx*1+0x30],xmm3
  c16f58:	movups XMMWORD PTR [rax+rcx*1+0x20],xmm2
  c16f5d:	movdqu XMMWORD PTR [rax+rcx*1+0x10],xmm1
  c16f63:	movdqu XMMWORD PTR [rax+rcx*1],xmm0
  c16f68:	inc    rbp
  c16f6b:	lea    rbx,[r12+0x10]
  c16f70:	mov    QWORD PTR [rbx],rbp
  c16f73:	jmp    c11a2e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x210e>
  c16f78:	inc    r13b
  c16f7b:	mov    rax,QWORD PTR [rsp+0x2a8]
  c16f83:	movzx  eax,BYTE PTR [rax+rdx*1]
  c16f87:	lea    rcx,[rip+0xffffffffff6aea26]        # 2c59b4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xff3>
  c16f8e:	movsxd rax,DWORD PTR [rcx+rax*4]
  c16f92:	add    rax,rcx
  c16f95:	mov    r12,QWORD PTR [rsp+0x20]
  c16f9a:	lea    r15,[r12+0x8]
  c16f9f:	jmp    rax
  c16fa1:	mov    QWORD PTR [rsp+0x1e0],rdx
  c16fa9:	lea    rax,[r12+0x10]
  c16fae:	mov    rbp,QWORD PTR [rax]
  c16fb1:	cmp    QWORD PTR [rsp+0x8],rbp
  c16fb6:	mov    rsi,QWORD PTR [rsp+0x28]
  c16fbb:	jae    c19903 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fe3>
  c16fc1:	mov    rdx,QWORD PTR [r15]
  c16fc4:	lea    rcx,[rdx+rsi*1]
  c16fc8:	movzx  eax,r13b
  c16fcc:	mov    r15,rax
  c16fcf:	sub    r15,QWORD PTR [rdx+rsi*1+0x30]
  c16fd4:	jb     c170e0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x77c0>
  c16fda:	add    r15,QWORD PTR [rcx+0x60]
  c16fde:	mov    bl,0x1
  c16fe0:	mov    rbp,QWORD PTR [rsp+0x50]
  c16fe5:	cmp    rbp,QWORD PTR [rsp+0x40]
  c16fea:	jne    c17301 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79e1>
  c16ff0:	jmp    c172f6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79d6>
  c16ff5:	mov    QWORD PTR [rsp+0x1e0],rdx
  c16ffd:	lea    rax,[r12+0x10]
  c17002:	mov    rbp,QWORD PTR [rax]
  c17005:	cmp    QWORD PTR [rsp+0x8],rbp
  c1700a:	mov    rsi,QWORD PTR [rsp+0x28]
  c1700f:	jae    c19915 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ff5>
  c17015:	mov    rdx,QWORD PTR [r15]
  c17018:	lea    rcx,[rdx+rsi*1]
  c1701c:	movzx  eax,r13b
  c17020:	mov    r15,rax
  c17023:	sub    r15,QWORD PTR [rdx+rsi*1+0x30]
  c17028:	jae    c17037 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7717>
  c1702a:	mov    rcx,QWORD PTR [rcx+0x28]
  c1702e:	shl    eax,0x4
  c17031:	mov    r15,QWORD PTR [rcx+rax*1]
  c17035:	jmp    c1703b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x771b>
  c17037:	add    r15,QWORD PTR [rcx+0x60]
  c1703b:	mov    rax,QWORD PTR [rsp+0x38]
  c17040:	cmp    r15,QWORD PTR [rax+0x10]
  c17044:	jae    c17435 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b15>
  c1704a:	mov    rax,QWORD PTR [rax+0x8]
  c1704e:	lea    rcx,[r15+r15*2]
  c17052:	lea    rbp,[rax+rcx*8]
  c17056:	mov    eax,DWORD PTR [rax+rcx*8]
  c17059:	mov    edx,eax
  c1705b:	sub    edx,0x2
  c1705e:	mov    ecx,0x3
  c17063:	cmovae ecx,edx
  c17066:	cmp    ecx,0x8
  c17069:	ja     c1736f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a4f>
  c1706f:	mov    edx,0x1e7
  c17074:	bt     edx,ecx
  c17077:	jae    c17177 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7857>
  c1707d:	mov    DWORD PTR [rbp+0x0],0x2
  c17084:	xor    ebx,ebx
  c17086:	mov    rbp,QWORD PTR [rsp+0x50]
  c1708b:	cmp    rbp,QWORD PTR [rsp+0x40]
  c17090:	je     c172f6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79d6>
  c17096:	jmp    c17301 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79e1>
  c1709b:	lea    rax,[r12+0x10]
  c170a0:	mov    rbp,QWORD PTR [rax]
  c170a3:	cmp    QWORD PTR [rsp+0x8],rbp
  c170a8:	mov    rsi,QWORD PTR [rsp+0x28]
  c170ad:	mov    rax,QWORD PTR [rsp+0x2a8]
  c170b5:	mov    QWORD PTR [rsp+0x1e0],rdx
  c170bd:	jae    c1990c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fec>
  c170c3:	mov    rdi,rdx
  c170c6:	mov    rdx,QWORD PTR [r15]
  c170c9:	lea    rcx,[rdx+rsi*1]
  c170cd:	movzx  eax,BYTE PTR [rax+rdi*1+0x1]
  c170d2:	mov    r15,rax
  c170d5:	sub    r15,QWORD PTR [rdx+rsi*1+0x30]
  c170da:	jae    c16fda <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x76ba>
  c170e0:	mov    rcx,QWORD PTR [rcx+0x28]
  c170e4:	shl    eax,0x4
  c170e7:	mov    r15,QWORD PTR [rcx+rax*1]
  c170eb:	mov    bl,0x1
  c170ed:	mov    rbp,QWORD PTR [rsp+0x50]
  c170f2:	cmp    rbp,QWORD PTR [rsp+0x40]
  c170f7:	jne    c17301 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79e1>
  c170fd:	jmp    c172f6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79d6>
  c17102:	mov    rax,QWORD PTR [rsp+0x2a8]
  c1710a:	mov    QWORD PTR [rsp+0x1e0],rdx
  c17112:	movzx  ebx,WORD PTR [rax+rdx*1+0x2]
  c17117:	mov    rax,QWORD PTR [rsp+0x1c8]
  c1711f:	cmp    QWORD PTR [rax+0x10],rbx
  c17123:	mov    rbp,QWORD PTR [rsp+0x38]
  c17128:	mov    r8,QWORD PTR [rsp+0x558]
  c17130:	jbe    c17408 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ae8>
  c17136:	mov    rdx,QWORD PTR [rax+0x8]
  c1713a:	lea    rsi,[rbx+rbx*2]
  c1713e:	mov    ecx,DWORD PTR [rdx+rsi*8]
  c17141:	mov    edi,ecx
  c17143:	sub    edi,0x2
  c17146:	mov    eax,0x3
  c1714b:	cmovb  edi,eax
  c1714e:	lea    rdx,[rdx+rsi*8]
  c17152:	lea    rsi,[rip+0xffffffffff6ae86f]        # 2c59c8 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1007>
  c17159:	movsxd rdi,DWORD PTR [rsi+rdi*4]
  c1715d:	add    rdi,rsi
  c17160:	jmp    rdi
  c17162:	mov    esi,DWORD PTR [rdx+0x4]
  c17165:	mov    r8,QWORD PTR [rdx+0x8]
  c17169:	mov    rdx,QWORD PTR [rdx+0x10]
  c1716d:	mov    eax,ecx
  c1716f:	mov    rcx,rsi
  c17172:	jmp    c17200 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x78e0>
  c17177:	cmp    ecx,0x3
  c1717a:	jne    c17353 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a33>
  c17180:	test   eax,eax
  c17182:	je     c1707d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x775d>
  c17188:	mov    rax,QWORD PTR [rbp+0x8]
  c1718c:	dec    QWORD PTR [rax]
  c1718f:	jne    c1707d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x775d>
  c17195:	lea    rdi,[rbp+0x8]
  c17199:	call   QWORD PTR [rip+0x2366f1]        # e4d890 <_DYNAMIC+0x248>
  c1719f:	jmp    c1707d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x775d>
  c171a4:	mov    r8,QWORD PTR [rdx+0x8]
  c171a8:	mov    eax,0xb
  c171ad:	jmp    c171e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x78c7>
  c171af:	mov    eax,0x2
  c171b4:	mov    rdx,QWORD PTR [rsp+0x2a0]
  c171bc:	mov    rcx,QWORD PTR [rsp+0x2b0]
  c171c4:	jmp    c17200 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x78e0>
  c171c6:	test   cl,0x1
  c171c9:	je     c17162 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7842>
  c171cb:	mov    r8,QWORD PTR [rdx+0x8]
  c171cf:	mov    eax,0x1
  c171d4:	inc    QWORD PTR [r8]
  c171d7:	jne    c17200 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x78e0>
  c171d9:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c171de:	mov    r8,QWORD PTR [rdx+0x8]
  c171e2:	mov    eax,0x6
  c171e7:	inc    QWORD PTR [r8]
  c171ea:	mov    rdx,QWORD PTR [rsp+0x2a0]
  c171f2:	mov    rcx,QWORD PTR [rsp+0x2b0]
  c171fa:	je     c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c17200:	mov    eax,eax
  c17202:	mov    QWORD PTR [rsp+0x2b0],rcx
  c1720a:	shl    rcx,0x20
  c1720e:	or     rcx,rax
  c17211:	mov    QWORD PTR [rsp+0x588],rcx
  c17219:	mov    QWORD PTR [rsp+0x558],r8
  c17221:	mov    QWORD PTR [rsp+0x590],r8
  c17229:	mov    QWORD PTR [rsp+0x2a0],rdx
  c17231:	mov    QWORD PTR [rsp+0x598],rdx
  c17239:	mov    r15,QWORD PTR [rbp+0x10]
  c1723d:	cmp    r15,QWORD PTR [rbp+0x0]
  c17241:	jne    c1724c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x792c>
  c17243:	mov    rdi,rbp
  c17246:	call   QWORD PTR [rip+0x238204]        # e4f450 <_DYNAMIC+0x1e08>
  c1724c:	mov    rax,QWORD PTR [rbp+0x8]
  c17250:	lea    rcx,[r15+r15*2]
  c17254:	mov    rdx,QWORD PTR [rsp+0x598]
  c1725c:	mov    QWORD PTR [rax+rcx*8+0x10],rdx
  c17261:	movdqu xmm0,XMMWORD PTR [rsp+0x588]
  c1726a:	movdqu XMMWORD PTR [rax+rcx*8],xmm0
  c1726f:	lea    rax,[r15+0x1]
  c17273:	mov    QWORD PTR [rbp+0x10],rax
  c17277:	lea    rax,[r12+0x10]
  c1727c:	mov    rbp,QWORD PTR [rax]
  c1727f:	cmp    QWORD PTR [rsp+0x8],rbp
  c17284:	jae    c1991e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ffe>
  c1728a:	lea    rax,[r12+0x8]
  c1728f:	mov    rax,QWORD PTR [rax]
  c17292:	mov    rcx,QWORD PTR [rsp+0x28]
  c17297:	mov    r12d,DWORD PTR [rax+rcx*1+0x70]
  c1729c:	mov    rbp,QWORD PTR [rsp+0x90]
  c172a4:	cmp    rbp,QWORD PTR [rsp+0x80]
  c172ac:	jne    c172bc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x799c>
  c172ae:	lea    rdi,[rsp+0x80]
  c172b6:	call   QWORD PTR [rip+0x23bbe4]        # e52ea0 <_DYNAMIC+0x5858>
  c172bc:	mov    rax,QWORD PTR [rsp+0x88]
  c172c4:	lea    rcx,[rbp*2+0x0]
  c172cc:	add    rcx,rbp
  c172cf:	mov    QWORD PTR [rax+rcx*8],r15
  c172d3:	mov    DWORD PTR [rax+rcx*8+0x8],r12d
  c172d8:	mov    QWORD PTR [rax+rcx*8+0x10],rbx
  c172dd:	inc    rbp
  c172e0:	mov    QWORD PTR [rsp+0x90],rbp
  c172e8:	mov    bl,0x1
  c172ea:	mov    rbp,QWORD PTR [rsp+0x50]
  c172ef:	cmp    rbp,QWORD PTR [rsp+0x40]
  c172f4:	jne    c17301 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79e1>
  c172f6:	lea    rdi,[rsp+0x40]
  c172fb:	call   QWORD PTR [rip+0x23bba7]        # e52ea8 <_DYNAMIC+0x5860>
  c17301:	mov    rax,QWORD PTR [rsp+0x48]
  c17306:	mov    rcx,rbp
  c17309:	shl    rcx,0x4
  c1730d:	mov    QWORD PTR [rax+rcx*1],r15
  c17311:	mov    BYTE PTR [rax+rcx*1+0x8],bl
  c17315:	inc    rbp
  c17318:	mov    QWORD PTR [rsp+0x50],rbp
  c1731d:	mov    rdx,QWORD PTR [rsp+0x1e0]
  c17325:	add    rdx,0x4
  c17329:	cmp    QWORD PTR [rsp+0x550],rdx
  c17331:	jne    c16f78 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7658>
  c17337:	mov    r13,QWORD PTR [rsp+0x28]
  c1733c:	mov    r12,QWORD PTR [rsp+0x20]
  c17341:	mov    rdi,QWORD PTR [rsp+0x38]
  c17346:	mov    r15,QWORD PTR [rsp+0x1b8]
  c1734e:	jmp    c16e08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74e8>
  c17353:	mov    rax,QWORD PTR [rbp+0x8]
  c17357:	dec    QWORD PTR [rax]
  c1735a:	jne    c1707d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x775d>
  c17360:	lea    rdi,[rbp+0x8]
  c17364:	call   QWORD PTR [rip+0x23652e]        # e4d898 <_DYNAMIC+0x250>
  c1736a:	jmp    c1707d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x775d>
  c1736f:	mov    rax,QWORD PTR [rbp+0x8]
  c17373:	dec    QWORD PTR [rax]
  c17376:	jne    c1707d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x775d>
  c1737c:	lea    rdi,[rbp+0x8]
  c17380:	call   QWORD PTR [rip+0x23651a]        # e4d8a0 <_DYNAMIC+0x258>
  c17386:	jmp    c1707d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x775d>
  c1738b:	mov    eax,DWORD PTR [rsp+0x128]
  c17392:	movups xmm0,XMMWORD PTR [rsp+0x12c]
  c1739a:	movaps XMMWORD PTR [rsp+0x3d0],xmm0
  c173a2:	mov    ecx,DWORD PTR [rsp+0x13c]
  c173a9:	mov    DWORD PTR [rsp+0x3e0],ecx
  c173b0:	cmp    eax,0xffffffff
  c173b3:	je     c173cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7aaf>
  c173b5:	mov    ecx,DWORD PTR [rsp+0x3e0]
  c173bc:	mov    DWORD PTR [rsp+0x50],ecx
  c173c0:	movaps xmm0,XMMWORD PTR [rsp+0x3d0]
  c173c8:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c173cd:	jmp    c173d4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ab4>
  c173cf:	mov    eax,0xc
  c173d4:	mov    DWORD PTR [rbx+0x8],eax
  c173d7:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c173dd:	movdqu XMMWORD PTR [rbx+0xc],xmm0
  c173e2:	mov    eax,DWORD PTR [rsp+0x50]
  c173e6:	mov    DWORD PTR [rbx+0x1c],eax
  c173e9:	mov    BYTE PTR [rbx],0xff
  c173ec:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c173f1:	xor    r15d,r15d
  c173f4:	mov    r12,QWORD PTR [rsp+0x548]
  c173fc:	mov    rdi,r15
  c173ff:	mov    rsi,r12
  c17402:	call   QWORD PTR [rip+0x236528]        # e4d930 <_DYNAMIC+0x2e8>
  c17408:	mov    rcx,QWORD PTR [rsp+0x18]
  c1740d:	mov    BYTE PTR [rcx],0x1f
  c17410:	lea    rax,[rip+0xffffffffff6aed01]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17417:	mov    QWORD PTR [rcx+0x8],rax
  c1741b:	mov    QWORD PTR [rcx+0x10],0x4f
  c17423:	mov    eax,0x18
  c17428:	mov    rdx,QWORD PTR [rsp+0x2a0]
  c17430:	jmp    c185d4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8cb4>
  c17435:	mov    rcx,QWORD PTR [rsp+0x18]
  c1743a:	mov    BYTE PTR [rcx],0x1f
  c1743d:	lea    rax,[rip+0xffffffffff6af4c8]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c17444:	mov    QWORD PTR [rcx+0x8],rax
  c17448:	mov    edx,0x4f
  c1744d:	jmp    c185cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8caf>
  c17452:	mov    rcx,QWORD PTR [rsp+0x18]
  c17457:	mov    BYTE PTR [rcx],0x1f
  c1745a:	lea    rax,[rip+0xffffffffff6af250]        # 2c66b1 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x32e>
  c17461:	mov    QWORD PTR [rcx+0x8],rax
  c17465:	mov    QWORD PTR [rcx+0x10],0x42
  c1746d:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17472:	mov    rcx,QWORD PTR [rsp+0x18]
  c17477:	mov    BYTE PTR [rcx],0x1f
  c1747a:	lea    rax,[rip+0xffffffffff6aee12]        # 2c6293 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x18d2>
  c17481:	mov    QWORD PTR [rcx+0x8],rax
  c17485:	mov    QWORD PTR [rcx+0x10],0x3a
  c1748d:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17492:	mov    r14b,0x1f
  c17495:	lea    rbx,[rip+0xffffffffff6aec7c]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1749c:	mov    r15d,0x4f
  c174a2:	jmp    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c174a7:	movdqu xmm0,XMMWORD PTR [rsp+0x122]
  c174b0:	movdqu xmm1,XMMWORD PTR [rsp+0x132]
  c174b9:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c174c1:	mov    rcx,QWORD PTR [rsp+0x18]
  c174c6:	movups XMMWORD PTR [rcx+0x20],xmm2
  c174ca:	movdqu XMMWORD PTR [rcx+0x12],xmm1
  c174cf:	movdqu XMMWORD PTR [rcx+0x2],xmm0
  c174d4:	mov    BYTE PTR [rcx],al
  c174d6:	mov    BYTE PTR [rcx+0x1],bl
  c174d9:	jmp    c18246 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8926>
  c174de:	movups xmm0,XMMWORD PTR [rsp+0x121]
  c174e6:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c174ef:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c174f7:	movdqu XMMWORD PTR [rsp+0x8f],xmm1
  c17500:	movaps XMMWORD PTR [rsp+0x80],xmm0
  c17508:	mov    rcx,QWORD PTR [rsp+0x18]
  c1750d:	movups XMMWORD PTR [rcx+0x20],xmm2
  c17511:	movups xmm0,XMMWORD PTR [rsp+0x8f]
  c17519:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1751d:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c17526:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1752b:	mov    BYTE PTR [rcx],al
  c1752d:	jmp    c1857b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c5b>
  c17532:	test   r13b,0x1
  c17536:	je     c18797 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e77>
  c1753c:	mov    r12,QWORD PTR [rsp+0x20]
  c17541:	lea    rax,[r12+0x10]
  c17546:	mov    rsi,QWORD PTR [rax]
  c17549:	mov    rdi,QWORD PTR [rsp+0x8]
  c1754e:	cmp    rdi,rsi
  c17551:	mov    rbx,QWORD PTR [rsp+0x18]
  c17556:	jae    c19f86 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa666>
  c1755c:	mov    rax,QWORD PTR [rsp+0x10]
  c17561:	mov    rsi,QWORD PTR [rax]
  c17564:	mov    rdi,QWORD PTR [rsp+0x28]
  c17569:	lea    rdx,[rsi+rdi*1]
  c1756d:	movzx  ecx,r14b
  c17571:	mov    rax,rcx
  c17574:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c17579:	mov    r14,QWORD PTR [rsp+0x38]
  c1757e:	mov    r15,QWORD PTR [rsp+0x1c8]
  c17586:	jae    c18c8d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x936d>
  c1758c:	mov    rax,QWORD PTR [rdx+0x28]
  c17590:	shl    ecx,0x4
  c17593:	mov    rax,QWORD PTR [rax+rcx*1]
  c17597:	jmp    c18c91 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9371>
  c1759c:	mov    rax,QWORD PTR [rsp+0xf8]
  c175a4:	mov    rsi,QWORD PTR [rax]
  c175a7:	cmp    QWORD PTR [rsp+0x8],rsi
  c175ac:	jae    c19f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa654>
  c175b2:	mov    rax,QWORD PTR [rsp+0x10]
  c175b7:	mov    rdi,QWORD PTR [rax]
  c175ba:	mov    rax,QWORD PTR [rsp+0x38]
  c175bf:	mov    rax,QWORD PTR [rax+0x10]
  c175c3:	mov    r8,QWORD PTR [rsp+0x28]
  c175c8:	lea    rsi,[rdi+r8*1]
  c175cc:	movzx  edx,r14b
  c175d0:	mov    rcx,rdx
  c175d3:	sub    rcx,QWORD PTR [rdi+r8*1+0x30]
  c175d8:	mov    rbx,QWORD PTR [rsp+0x18]
  c175dd:	jae    c187be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e9e>
  c175e3:	mov    rcx,QWORD PTR [rsi+0x28]
  c175e7:	shl    edx,0x4
  c175ea:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c175ee:	jmp    c187c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ea2>
  c175f3:	mov    rcx,QWORD PTR [rsp+0x18]
  c175f8:	mov    BYTE PTR [rcx],0x1f
  c175fb:	lea    rax,[rip+0xffffffffff6af155]        # 2c6757 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x3d4>
  c17602:	mov    QWORD PTR [rcx+0x8],rax
  c17606:	mov    QWORD PTR [rcx+0x10],0x5c
  c1760e:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17613:	lea    rax,[rip+0xffffffffff6aecb3]        # 2c62cd <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x190c>
  c1761a:	jmp    c17a44 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8124>
  c1761f:	mov    rcx,QWORD PTR [rsp+0x18]
  c17624:	mov    BYTE PTR [rcx],0x1f
  c17627:	lea    rax,[rip+0xffffffffff6aeaea]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1762e:	mov    QWORD PTR [rcx+0x8],rax
  c17632:	mov    QWORD PTR [rcx+0x10],0x4f
  c1763a:	mov    rax,QWORD PTR [rsp+0x258]
  c17642:	mov    QWORD PTR [rcx+0x18],rax
  c17646:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c1764b:	mov    rcx,QWORD PTR [rsp+0x18]
  c17650:	mov    BYTE PTR [rcx],0x1f
  c17653:	lea    rax,[rip+0xffffffffff6aeabe]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1765a:	mov    QWORD PTR [rcx+0x8],rax
  c1765e:	mov    QWORD PTR [rcx+0x10],0x4f
  c17666:	mov    rax,QWORD PTR [rsp+0x240]
  c1766e:	mov    QWORD PTR [rcx+0x18],rax
  c17672:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17677:	mov    rcx,QWORD PTR [rsp+0x18]
  c1767c:	mov    BYTE PTR [rcx],0x1f
  c1767f:	lea    rax,[rip+0xffffffffff6aea92]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17686:	mov    QWORD PTR [rcx+0x8],rax
  c1768a:	mov    QWORD PTR [rcx+0x10],0x4f
  c17692:	mov    rax,QWORD PTR [rsp+0x280]
  c1769a:	mov    QWORD PTR [rcx+0x18],rax
  c1769e:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c176a3:	mov    rcx,QWORD PTR [rsp+0x18]
  c176a8:	mov    BYTE PTR [rcx],0x1f
  c176ab:	lea    rax,[rip+0xffffffffff6aea66]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c176b2:	mov    QWORD PTR [rcx+0x8],rax
  c176b6:	mov    QWORD PTR [rcx+0x10],0x4f
  c176be:	mov    rax,QWORD PTR [rsp+0x278]
  c176c6:	mov    QWORD PTR [rcx+0x18],rax
  c176ca:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c176cf:	jmp    c18956 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9036>
  c176d4:	mov    r15b,0x1f
  c176d7:	lea    rbx,[rip+0xffffffffff6aea3a]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c176de:	mov    r12d,0x4f
  c176e4:	mov    r13,QWORD PTR [rsp+0x18]
  c176e9:	jmp    c182c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89a0>
  c176ee:	mov    rcx,QWORD PTR [rsp+0x18]
  c176f3:	mov    BYTE PTR [rcx],0x1f
  c176f6:	lea    rax,[rip+0xffffffffff6aea1b]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c176fd:	mov    QWORD PTR [rcx+0x8],rax
  c17701:	mov    QWORD PTR [rcx+0x10],0x4f
  c17709:	mov    rax,QWORD PTR [rsp+0x248]
  c17711:	mov    QWORD PTR [rcx+0x18],rax
  c17715:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c1771a:	mov    rcx,QWORD PTR [rsp+0x18]
  c1771f:	mov    BYTE PTR [rcx],0x1f
  c17722:	lea    rax,[rip+0xffffffffff6ae9ef]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17729:	mov    QWORD PTR [rcx+0x8],rax
  c1772d:	mov    QWORD PTR [rcx+0x10],0x4f
  c17735:	mov    rax,QWORD PTR [rsp+0x290]
  c1773d:	mov    QWORD PTR [rcx+0x18],rax
  c17741:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17746:	mov    rcx,QWORD PTR [rsp+0x18]
  c1774b:	mov    BYTE PTR [rcx],0x1f
  c1774e:	lea    rax,[rip+0xffffffffff6ae9c3]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17755:	mov    QWORD PTR [rcx+0x8],rax
  c17759:	mov    QWORD PTR [rcx+0x10],0x4f
  c17761:	mov    rax,QWORD PTR [rsp+0x288]
  c17769:	mov    QWORD PTR [rcx+0x18],rax
  c1776d:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17772:	mov    rcx,QWORD PTR [rsp+0x18]
  c17777:	mov    BYTE PTR [rcx],0x1f
  c1777a:	lea    rax,[rip+0xffffffffff6ae997]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17781:	mov    QWORD PTR [rcx+0x8],rax
  c17785:	mov    QWORD PTR [rcx+0x10],0x4f
  c1778d:	mov    rax,QWORD PTR [rsp+0x270]
  c17795:	mov    QWORD PTR [rcx+0x18],rax
  c17799:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c1779e:	jmp    c18956 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9036>
  c177a3:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c177ac:	movdqu xmm1,XMMWORD PTR [rsp+0x138]
  c177b5:	movups xmm2,XMMWORD PTR [rsp+0x148]
  c177bd:	movups XMMWORD PTR [rsp+0x64],xmm2
  c177c2:	movdqu XMMWORD PTR [rsp+0x54],xmm1
  c177c8:	movdqu XMMWORD PTR [rsp+0x44],xmm0
  c177ce:	jmp    c1970e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9dee>
  c177d3:	mov    rcx,QWORD PTR [rsp+0x18]
  c177d8:	mov    BYTE PTR [rcx],0x1f
  c177db:	lea    rax,[rip+0xffffffffff6ae936]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c177e2:	mov    QWORD PTR [rcx+0x8],rax
  c177e6:	mov    QWORD PTR [rcx+0x10],0x4f
  c177ee:	mov    rax,QWORD PTR [rsp+0x250]
  c177f6:	mov    QWORD PTR [rcx+0x18],rax
  c177fa:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c177ff:	mov    rcx,QWORD PTR [rsp+0x18]
  c17804:	mov    BYTE PTR [rcx],0x1f
  c17807:	lea    rax,[rip+0xffffffffff6ae90a]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1780e:	mov    QWORD PTR [rcx+0x8],rax
  c17812:	mov    QWORD PTR [rcx+0x10],0x4f
  c1781a:	mov    rax,QWORD PTR [rsp+0x260]
  c17822:	mov    QWORD PTR [rcx+0x18],rax
  c17826:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c1782b:	mov    rcx,QWORD PTR [rsp+0x18]
  c17830:	mov    BYTE PTR [rcx],0x1f
  c17833:	lea    rax,[rip+0xffffffffff6ae8de]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1783a:	mov    QWORD PTR [rcx+0x8],rax
  c1783e:	mov    QWORD PTR [rcx+0x10],0x4f
  c17846:	mov    rax,QWORD PTR [rsp+0x268]
  c1784e:	mov    QWORD PTR [rcx+0x18],rax
  c17852:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17857:	mov    rcx,QWORD PTR [rsp+0x18]
  c1785c:	mov    BYTE PTR [rcx],0x1f
  c1785f:	lea    rax,[rip+0xffffffffff6ae8b2]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17866:	mov    QWORD PTR [rcx+0x8],rax
  c1786a:	mov    QWORD PTR [rcx+0x10],0x4f
  c17872:	mov    rax,QWORD PTR [rsp+0x298]
  c1787a:	mov    QWORD PTR [rcx+0x18],rax
  c1787e:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17883:	mov    bpl,0x1f
  c17886:	lea    rbx,[rip+0xffffffffff6ae88b]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1788d:	mov    r15d,0x4f
  c17893:	mov    r13,QWORD PTR [rsp+0x18]
  c17898:	jmp    c18370 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a50>
  c1789d:	jmp    c18956 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9036>
  c178a2:	lea    rax,[rip+0xffffffffff6ae86f]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c178a9:	mov    rbx,QWORD PTR [rsp+0x18]
  c178ae:	jmp    c179f9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80d9>
  c178b3:	mov    rcx,QWORD PTR [rsp+0x18]
  c178b8:	mov    BYTE PTR [rcx],0x1f
  c178bb:	lea    rax,[rip+0xffffffffff6aeef1]        # 2c67b3 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x430>
  c178c2:	mov    QWORD PTR [rcx+0x8],rax
  c178c6:	mov    QWORD PTR [rcx+0x10],0x51
  c178ce:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c178d3:	mov    rdx,QWORD PTR [rsp+0x18]
  c178d8:	mov    BYTE PTR [rdx],0x1f
  c178db:	lea    rax,[rip+0xffffffffff6ae836]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c178e2:	mov    QWORD PTR [rdx+0x8],rax
  c178e6:	mov    QWORD PTR [rdx+0x10],0x4f
  c178ee:	mov    eax,0x18
  c178f3:	mov    rcx,QWORD PTR [rsp+0x218]
  c178fb:	mov    QWORD PTR [rdx+rax*1],rcx
  c178ff:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17904:	mov    rcx,QWORD PTR [rsp+0x18]
  c17909:	mov    BYTE PTR [rcx],0x1f
  c1790c:	lea    rax,[rip+0xffffffffff6ae805]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17913:	mov    QWORD PTR [rcx+0x8],rax
  c17917:	mov    QWORD PTR [rcx+0x10],0x4f
  c1791f:	mov    QWORD PTR [rcx+0x18],rdx
  c17923:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17928:	mov    rcx,QWORD PTR [rsp+0x18]
  c1792d:	mov    BYTE PTR [rcx],0x1f
  c17930:	lea    rax,[rip+0xffffffffff6ae7e1]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17937:	mov    QWORD PTR [rcx+0x8],rax
  c1793b:	mov    QWORD PTR [rcx+0x10],0x4f
  c17943:	mov    rax,QWORD PTR [rsp+0x210]
  c1794b:	mov    QWORD PTR [rcx+0x18],rax
  c1794f:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17954:	mov    rcx,QWORD PTR [rsp+0x18]
  c17959:	mov    BYTE PTR [rcx],0x1f
  c1795c:	lea    rax,[rip+0xffffffffff6ae7b5]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17963:	mov    QWORD PTR [rcx+0x8],rax
  c17967:	mov    QWORD PTR [rcx+0x10],0x4f
  c1796f:	mov    rax,QWORD PTR [rsp+0x208]
  c17977:	mov    QWORD PTR [rcx+0x18],rax
  c1797b:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17980:	movups xmm0,XMMWORD PTR [rsp+0x121]
  c17988:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c17991:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c17999:	movdqu XMMWORD PTR [rsp+0x4f],xmm1
  c1799f:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c179a4:	mov    rcx,QWORD PTR [rsp+0x18]
  c179a9:	movups XMMWORD PTR [rcx+0x20],xmm2
  c179ad:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c179b2:	movups XMMWORD PTR [rcx+0x10],xmm0
  c179b6:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c179bc:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c179c1:	mov    BYTE PTR [rcx],al
  c179c3:	jmp    c17ec5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85a5>
  c179c8:	mov    ecx,r8d
  c179cb:	sub    ecx,0x2
  c179ce:	mov    eax,0x3
  c179d3:	cmovae eax,ecx
  c179d6:	cmp    eax,0x8
  c179d9:	ja     c19305 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x99e5>
  c179df:	mov    ecx,0x1e7
  c179e4:	bt     ecx,eax
  c179e7:	mov    rbx,QWORD PTR [rsp+0x18]
  c179ec:	jae    c18f99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9679>
  c179f2:	lea    rax,[rip+0xffffffffff6aef13]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c179f9:	mov    BYTE PTR [rbx],0x1f
  c179fc:	jmp    c18d84 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9464>
  c17a01:	mov    r15b,0x1f
  c17a04:	lea    rbx,[rip+0xffffffffff6ae70d]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a0b:	mov    r12d,0x4f
  c17a11:	mov    r13,QWORD PTR [rsp+0x18]
  c17a16:	jmp    c18298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8978>
  c17a1b:	mov    r14b,0x1f
  c17a1e:	lea    rbx,[rip+0xffffffffff6ae6f3]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a25:	mov    r15d,0x4f
  c17a2b:	jmp    c183f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ad3>
  c17a30:	lea    rdi,[rsp+0x120]
  c17a38:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17a3d:	lea    rax,[rip+0xffffffffff6aeec8]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c17a44:	mov    rcx,QWORD PTR [rsp+0x18]
  c17a49:	mov    BYTE PTR [rcx],0x1f
  c17a4c:	jmp    c18972 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9052>
  c17a51:	mov    r14b,0x1f
  c17a54:	lea    rbx,[rip+0xffffffffff6ae6bd]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a5b:	mov    r15d,0x4f
  c17a61:	jmp    c1846e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b4e>
  c17a66:	mov    bpl,0x1f
  c17a69:	lea    rbx,[rip+0xffffffffff6ae6a8]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a70:	mov    r15d,0x4f
  c17a76:	mov    r13,QWORD PTR [rsp+0x18]
  c17a7b:	jmp    c18348 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a28>
  c17a80:	mov    rcx,QWORD PTR [rsp+0x18]
  c17a85:	mov    BYTE PTR [rcx],0x1f
  c17a88:	lea    rax,[rip+0xffffffffff6ae689]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a8f:	mov    QWORD PTR [rcx+0x8],rax
  c17a93:	mov    QWORD PTR [rcx+0x10],0x4f
  c17a9b:	mov    rax,QWORD PTR [rsp+0x238]
  c17aa3:	mov    QWORD PTR [rcx+0x18],rax
  c17aa7:	jmp    c181b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8895>
  c17aac:	mov    rcx,QWORD PTR [rsp+0x18]
  c17ab1:	mov    BYTE PTR [rcx],0x1f
  c17ab4:	lea    rax,[rip+0xffffffffff6ae65d]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17abb:	mov    QWORD PTR [rcx+0x8],rax
  c17abf:	mov    QWORD PTR [rcx+0x10],0x4f
  c17ac7:	mov    rax,QWORD PTR [rsp+0x230]
  c17acf:	mov    QWORD PTR [rcx+0x18],rax
  c17ad3:	jmp    c181ef <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88cf>
  c17ad8:	mov    rcx,QWORD PTR [rsp+0x18]
  c17add:	mov    BYTE PTR [rcx],0x1f
  c17ae0:	lea    rax,[rip+0xffffffffff6ae631]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17ae7:	mov    QWORD PTR [rcx+0x8],rax
  c17aeb:	mov    QWORD PTR [rcx+0x10],0x4f
  c17af3:	mov    rax,QWORD PTR [rsp+0x220]
  c17afb:	mov    QWORD PTR [rcx+0x18],rax
  c17aff:	jmp    c1857b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c5b>
  c17b04:	mov    rcx,QWORD PTR [rsp+0x18]
  c17b09:	mov    BYTE PTR [rcx],0x1f
  c17b0c:	lea    rax,[rip+0xffffffffff6ae605]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17b13:	mov    QWORD PTR [rcx+0x8],rax
  c17b17:	mov    QWORD PTR [rcx+0x10],0x4f
  c17b1f:	mov    rax,QWORD PTR [rsp+0x1d0]
  c17b27:	mov    QWORD PTR [rcx+0x18],rax
  c17b2b:	jmp    c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c17b30:	mov    rcx,QWORD PTR [rsp+0x18]
  c17b35:	mov    BYTE PTR [rcx],0x1f
  c17b38:	lea    rax,[rip+0xffffffffff6ae5d9]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17b3f:	mov    QWORD PTR [rcx+0x8],rax
  c17b43:	mov    QWORD PTR [rcx+0x10],0x4f
  c17b4b:	mov    rax,QWORD PTR [rsp+0x228]
  c17b53:	mov    QWORD PTR [rcx+0x18],rax
  c17b57:	jmp    c18514 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bf4>
  c17b5c:	mov    eax,DWORD PTR [rsp+0x121]
  c17b63:	mov    edx,DWORD PTR [rsp+0x124]
  c17b6a:	mov    rsi,QWORD PTR [rsp+0x18]
  c17b6f:	mov    DWORD PTR [rsi+0x4],edx
  c17b72:	mov    DWORD PTR [rsi+0x1],eax
  c17b75:	mov    rax,QWORD PTR [rsp+0x128]
  c17b7d:	movups xmm0,XMMWORD PTR [rsp+0x140]
  c17b85:	movups XMMWORD PTR [rsi+0x20],xmm0
  c17b89:	movdqu xmm0,XMMWORD PTR [rsp+0x130]
  c17b92:	movdqu XMMWORD PTR [rsi+0x10],xmm0
  c17b97:	mov    BYTE PTR [rsi],cl
  c17b99:	mov    ecx,0x8
  c17b9e:	mov    QWORD PTR [rsi+rcx*1],rax
  c17ba2:	jmp    c18246 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8926>
  c17ba7:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c17bb0:	movdqu xmm1,XMMWORD PTR [rsp+0x138]
  c17bb9:	movups xmm2,XMMWORD PTR [rsp+0x148]
  c17bc1:	movups XMMWORD PTR [rsp+0x64],xmm2
  c17bc6:	movdqu XMMWORD PTR [rsp+0x54],xmm1
  c17bcc:	movdqu XMMWORD PTR [rsp+0x44],xmm0
  c17bd2:	mov    rax,QWORD PTR [rsp+0x18]
  c17bd7:	movups XMMWORD PTR [rax+0x20],xmm2
  c17bdb:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c17be0:	movdqu XMMWORD PTR [rax],xmm0
  c17be4:	jmp    c18f56 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9636>
  c17be9:	mov    rax,QWORD PTR [rsp+0x1f8]
  c17bf1:	movzx  esi,BYTE PTR [rax+0xc5]
  c17bf8:	lea    rdi,[rsp+0x120]
  c17c00:	mov    ecx,0x8
  c17c05:	mov    r8d,0x18
  c17c0b:	xor    edx,edx
  c17c0d:	call   c4f740 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsbxgXiyEKxkX_6bsl_vm>
  c17c12:	mov    rdi,QWORD PTR [rsp+0x128]
  c17c1a:	cmp    BYTE PTR [rsp+0x120],0x0
  c17c22:	jne    c198e2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fc2>
  c17c28:	mov    rax,QWORD PTR [rsp+0x130]
  c17c30:	mov    QWORD PTR [rsp+0xd0],rdi
  c17c38:	mov    QWORD PTR [rsp+0xd8],rax
  c17c40:	mov    QWORD PTR [rsp+0xe0],0x0
  c17c4c:	mov    r15,QWORD PTR [rbx+0x10]
  c17c50:	lea    rdi,[rsp+0x120]
  c17c58:	mov    ecx,0x8
  c17c5d:	mov    r8d,0x10
  c17c63:	mov    rsi,r15
  c17c66:	xor    edx,edx
  c17c68:	call   c4f740 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsbxgXiyEKxkX_6bsl_vm>
  c17c6d:	mov    rdi,QWORD PTR [rsp+0x128]
  c17c75:	cmp    BYTE PTR [rsp+0x120],0x0
  c17c7d:	jne    c198f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9fd0>
  c17c83:	mov    rax,QWORD PTR [rsp+0x130]
  c17c8b:	mov    QWORD PTR [rsp+0x40],rdi
  c17c90:	mov    QWORD PTR [rsp+0x48],rax
  c17c95:	mov    QWORD PTR [rsp+0x50],0x0
  c17c9e:	mov    rbx,QWORD PTR [rbx+0x8]
  c17ca2:	shl    r15,0x2
  c17ca6:	mov    QWORD PTR [rsp+0x1f0],r15
  c17cae:	xor    ebp,ebp
  c17cb0:	lea    rax,[rip+0x21e4f1]        # e361a8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x708>
  c17cb7:	mov    QWORD PTR [rsp+0x1c0],rax
  c17cbf:	cmp    QWORD PTR [rsp+0x1f0],rbp
  c17cc7:	mov    r15,QWORD PTR [rsp+0x10]
  c17ccc:	je     c18983 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9063>
  c17cd2:	movzx  eax,BYTE PTR [rbx+rbp*1]
  c17cd6:	lea    rcx,[rip+0xffffffffff6add13]        # 2c59f0 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x102f>
  c17cdd:	movsxd rax,DWORD PTR [rcx+rax*4]
  c17ce1:	add    rax,rcx
  c17ce4:	mov    rdi,QWORD PTR [rsp+0x28]
  c17ce9:	jmp    rax
  c17ceb:	mov    rax,QWORD PTR [rsp+0xf8]
  c17cf3:	mov    rsi,QWORD PTR [rax]
  c17cf6:	cmp    QWORD PTR [rsp+0x8],rsi
  c17cfb:	jae    c19f4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa62d>
  c17d01:	mov    rsi,QWORD PTR [r15]
  c17d04:	lea    rdx,[rsi+rdi*1]
  c17d08:	movzx  ecx,r13b
  c17d0c:	mov    rax,rcx
  c17d0f:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c17d14:	jae    c17dbf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x849f>
  c17d1a:	mov    rax,QWORD PTR [rdx+0x28]
  c17d1e:	shl    ecx,0x4
  c17d21:	mov    rax,QWORD PTR [rax+rcx*1]
  c17d25:	jmp    c17dc3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x84a3>
  c17d2a:	movzx  eax,WORD PTR [rbx+rbp*1+0x2]
  c17d2f:	mov    rcx,QWORD PTR [rsp+0x1c8]
  c17d37:	cmp    QWORD PTR [rcx+0x10],rax
  c17d3b:	jbe    c19249 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9929>
  c17d41:	lea    rsi,[rax+rax*2]
  c17d45:	shl    esi,0x3
  c17d48:	add    rsi,QWORD PTR [rcx+0x8]
  c17d4c:	lea    rdi,[rsp+0x120]
  c17d54:	call   c25060 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c17d59:	mov    rax,QWORD PTR [rsp+0x120]
  c17d61:	mov    rcx,QWORD PTR [rsp+0x130]
  c17d69:	mov    QWORD PTR [rsp+0x30],rcx
  c17d6e:	jmp    c17e46 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8526>
  c17d73:	mov    DWORD PTR [rsp+0x518],0x2
  c17d7e:	xor    r12d,r12d
  c17d81:	jmp    c17e63 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8543>
  c17d86:	mov    rax,QWORD PTR [rsp+0xf8]
  c17d8e:	mov    rsi,QWORD PTR [rax]
  c17d91:	cmp    QWORD PTR [rsp+0x8],rsi
  c17d96:	jae    c19f5c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa63c>
  c17d9c:	mov    rsi,QWORD PTR [r15]
  c17d9f:	lea    rdx,[rsi+rdi*1]
  c17da3:	movzx  ecx,BYTE PTR [rbx+rbp*1+0x1]
  c17da8:	mov    rax,rcx
  c17dab:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c17db0:	jae    c17e02 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x84e2>
  c17db2:	mov    rax,QWORD PTR [rdx+0x28]
  c17db6:	shl    ecx,0x4
  c17db9:	mov    rax,QWORD PTR [rax+rcx*1]
  c17dbd:	jmp    c17e06 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x84e6>
  c17dbf:	add    rax,QWORD PTR [rdx+0x60]
  c17dc3:	mov    rcx,QWORD PTR [rsp+0x38]
  c17dc8:	cmp    rax,QWORD PTR [rcx+0x10]
  c17dcc:	jae    c19272 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9952>
  c17dd2:	mov    rcx,QWORD PTR [rcx+0x8]
  c17dd6:	lea    rax,[rax+rax*2]
  c17dda:	lea    rsi,[rcx+rax*8]
  c17dde:	lea    rdi,[rsp+0x120]
  c17de6:	call   c25060 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c17deb:	mov    rax,QWORD PTR [rsp+0x120]
  c17df3:	mov    rcx,QWORD PTR [rsp+0x130]
  c17dfb:	mov    QWORD PTR [rsp+0x20],rcx
  c17e00:	jmp    c17e46 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8526>
  c17e02:	add    rax,QWORD PTR [rdx+0x60]
  c17e06:	mov    rcx,QWORD PTR [rsp+0x38]
  c17e0b:	cmp    rax,QWORD PTR [rcx+0x10]
  c17e0f:	jae    c1929b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x997b>
  c17e15:	mov    rcx,QWORD PTR [rcx+0x8]
  c17e19:	lea    rax,[rax+rax*2]
  c17e1d:	lea    rsi,[rcx+rax*8]
  c17e21:	lea    rdi,[rsp+0x120]
  c17e29:	call   c25060 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c17e2e:	mov    rax,QWORD PTR [rsp+0x120]
  c17e36:	mov    rcx,QWORD PTR [rsp+0x130]
  c17e3e:	mov    QWORD PTR [rsp+0x1e8],rcx
  c17e46:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c17e4f:	mov    QWORD PTR [rsp+0x518],rax
  c17e57:	movdqu XMMWORD PTR [rsp+0x520],xmm0
  c17e60:	mov    r12b,0x1
  c17e63:	mov    r15,QWORD PTR [rsp+0xe0]
  c17e6b:	lea    rdi,[rsp+0xd0]
  c17e73:	lea    rsi,[rsp+0x518]
  c17e7b:	call   c24620 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueE8push_mutCsbxgXiyEKxkX_6bsl_vm>
  c17e80:	inc    r13b
  c17e83:	add    rbp,0x4
  c17e87:	movzx  edx,r12b
  c17e8b:	lea    rdi,[rsp+0x40]
  c17e90:	mov    rsi,r15
  c17e93:	call   c245c0 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCsbxgXiyEKxkX_6bsl_vm9ParamSlotE8push_mutBG_>
  c17e98:	jmp    c17cbf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x839f>
  c17e9d:	lea    rdi,[rsp+0x120]
  c17ea5:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17eaa:	mov    rcx,QWORD PTR [rsp+0x18]
  c17eaf:	mov    BYTE PTR [rcx],0x1f
  c17eb2:	lea    rax,[rip+0xffffffffff6aea53]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c17eb9:	mov    QWORD PTR [rcx+0x8],rax
  c17ebd:	mov    QWORD PTR [rcx+0x10],0x4f
  c17ec5:	lea    rdi,[rsp+0x80]
  c17ecd:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c17ed2:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17ed7:	mov    rcx,QWORD PTR [rsp+0x18]
  c17edc:	mov    BYTE PTR [rcx],0x1f
  c17edf:	lea    rax,[rip+0xffffffffff6ae3e7]        # 2c62cd <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x190c>
  c17ee6:	mov    QWORD PTR [rcx+0x8],rax
  c17eea:	mov    QWORD PTR [rcx+0x10],0x4f
  c17ef2:	lea    rdi,[rsp+0x120]
  c17efa:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17eff:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17f04:	lea    rdi,[rsp+0x500]
  c17f0c:	jmp    c1895e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x903e>
  c17f11:	mov    rcx,QWORD PTR [rsp+0x18]
  c17f16:	mov    BYTE PTR [rcx],0x1f
  c17f19:	lea    rax,[rip+0xffffffffff6ae3ad]        # 2c62cd <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x190c>
  c17f20:	mov    QWORD PTR [rcx+0x8],rax
  c17f24:	mov    QWORD PTR [rcx+0x10],0x4f
  c17f2c:	jmp    c18246 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8926>
  c17f31:	lea    rdi,[rsp+0x120]
  c17f39:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17f3e:	mov    rdx,QWORD PTR [rsp+0x18]
  c17f43:	mov    BYTE PTR [rdx],0x1f
  c17f46:	lea    rax,[rip+0xffffffffff6ae9bf]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c17f4d:	mov    QWORD PTR [rdx+0x8],rax
  c17f51:	mov    eax,0x4f
  c17f56:	mov    ecx,0x10
  c17f5b:	mov    QWORD PTR [rdx+rcx*1],rax
  c17f5f:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c17f64:	lea    rdi,[rsp+0x120]
  c17f6c:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17f71:	mov    rsi,QWORD PTR [rsp+0x18]
  c17f76:	mov    BYTE PTR [rsi],0x1f
  c17f79:	lea    rax,[rip+0xffffffffff6ae98c]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c17f80:	mov    QWORD PTR [rsi+0x8],rax
  c17f84:	mov    eax,0x4f
  c17f89:	mov    ecx,0x10
  c17f8e:	mov    QWORD PTR [rsi+rcx*1],rax
  c17f92:	jmp    c18246 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8926>
  c17f97:	jmp    c18956 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9036>
  c17f9c:	jmp    c18956 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9036>
  c17fa1:	mov    ebp,ecx
  c17fa3:	movzx  eax,WORD PTR [rsp+0x126]
  c17fab:	mov    WORD PTR [rsp+0x104],ax
  c17fb3:	mov    eax,DWORD PTR [rsp+0x122]
  c17fba:	mov    DWORD PTR [rsp+0x100],eax
  c17fc1:	mov    rbx,QWORD PTR [rsp+0x128]
  c17fc9:	mov    r15,QWORD PTR [rsp+0x130]
  c17fd1:	movdqu xmm0,XMMWORD PTR [rsp+0x138]
  c17fda:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c17fe3:	mov    rax,QWORD PTR [rsp+0x148]
  c17feb:	mov    QWORD PTR [rsp+0xe0],rax
  c17ff3:	jmp    c18443 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b23>
  c17ff8:	movzx  eax,WORD PTR [rsp+0x126]
  c18000:	mov    WORD PTR [rsp+0x104],ax
  c18008:	mov    eax,DWORD PTR [rsp+0x122]
  c1800f:	mov    DWORD PTR [rsp+0x100],eax
  c18016:	mov    rbx,QWORD PTR [rsp+0x128]
  c1801e:	mov    r15,QWORD PTR [rsp+0x130]
  c18026:	movdqu xmm0,XMMWORD PTR [rsp+0x138]
  c1802f:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c18038:	mov    rax,QWORD PTR [rsp+0x148]
  c18040:	mov    QWORD PTR [rsp+0xe0],rax
  c18048:	mov    r13,QWORD PTR [rsp+0x18]
  c1804d:	mov    ebp,ecx
  c1804f:	jmp    c1831d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89fd>
  c18054:	mov    ebp,ecx
  c18056:	movzx  eax,WORD PTR [rsp+0x126]
  c1805e:	mov    WORD PTR [rsp+0x104],ax
  c18066:	mov    eax,DWORD PTR [rsp+0x122]
  c1806d:	mov    DWORD PTR [rsp+0x100],eax
  c18074:	mov    rbx,QWORD PTR [rsp+0x128]
  c1807c:	mov    r15,QWORD PTR [rsp+0x130]
  c18084:	movdqu xmm0,XMMWORD PTR [rsp+0x138]
  c1808d:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c18096:	mov    rax,QWORD PTR [rsp+0x148]
  c1809e:	mov    QWORD PTR [rsp+0xe0],rax
  c180a6:	jmp    c183c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8aa8>
  c180ab:	movzx  eax,WORD PTR [rsp+0x126]
  c180b3:	mov    WORD PTR [rsp+0x104],ax
  c180bb:	mov    eax,DWORD PTR [rsp+0x122]
  c180c2:	mov    DWORD PTR [rsp+0x100],eax
  c180c9:	mov    rbx,QWORD PTR [rsp+0x128]
  c180d1:	mov    r12,QWORD PTR [rsp+0x130]
  c180d9:	movdqu xmm0,XMMWORD PTR [rsp+0x138]
  c180e2:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c180eb:	mov    rax,QWORD PTR [rsp+0x148]
  c180f3:	mov    QWORD PTR [rsp+0xe0],rax
  c180fb:	jmp    c18268 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8948>
  c18100:	mov    rcx,QWORD PTR [rsp+0x18]
  c18105:	mov    BYTE PTR [rcx],0x1f
  c18108:	lea    rax,[rip+0xffffffffff6ae009]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1810f:	mov    QWORD PTR [rcx+0x8],rax
  c18113:	mov    QWORD PTR [rcx+0x10],0x4f
  c1811b:	mov    rax,QWORD PTR [rsp+0x200]
  c18123:	mov    QWORD PTR [rcx+0x18],rax
  c18127:	jmp    c1856e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c4e>
  c1812c:	movups xmm0,XMMWORD PTR [rsp+0x121]
  c18134:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c1813d:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c18145:	movdqu XMMWORD PTR [rsp+0x8f],xmm1
  c1814e:	movaps XMMWORD PTR [rsp+0x80],xmm0
  c18156:	mov    rcx,QWORD PTR [rsp+0x18]
  c1815b:	movups XMMWORD PTR [rcx+0x20],xmm2
  c1815f:	movups xmm0,XMMWORD PTR [rsp+0x8f]
  c18167:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1816b:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c18174:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c18179:	mov    BYTE PTR [rcx],al
  c1817b:	jmp    c18507 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8be7>
  c18180:	lea    rdi,[rsp+0x120]
  c18188:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1818d:	mov    rcx,QWORD PTR [rsp+0x18]
  c18192:	mov    BYTE PTR [rcx],0x1f
  c18195:	lea    rax,[rip+0xffffffffff6ae770]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c1819c:	mov    QWORD PTR [rcx+0x8],rax
  c181a0:	mov    QWORD PTR [rcx+0x10],0x4f
  c181a8:	lea    rdi,[rsp+0x80]
  c181b0:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c181b5:	jmp    c1857b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c5b>
  c181ba:	lea    rdi,[rsp+0x120]
  c181c2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c181c7:	mov    rcx,QWORD PTR [rsp+0x18]
  c181cc:	mov    BYTE PTR [rcx],0x1f
  c181cf:	lea    rax,[rip+0xffffffffff6ae736]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c181d6:	mov    QWORD PTR [rcx+0x8],rax
  c181da:	mov    QWORD PTR [rcx+0x10],0x4f
  c181e2:	lea    rdi,[rsp+0x80]
  c181ea:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c181ef:	jmp    c1857b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c5b>
  c181f4:	mov    rcx,QWORD PTR [rsp+0x18]
  c181f9:	mov    BYTE PTR [rcx],0x23
  c181fc:	lea    rax,[rip+0xffffffffff6ae645]        # 2c6848 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x4c5>
  c18203:	mov    QWORD PTR [rcx+0x8],rax
  c18207:	mov    QWORD PTR [rcx+0x10],0x3f
  c1820f:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c18214:	movdqu xmm0,XMMWORD PTR [rsp+0x122]
  c1821d:	movdqu xmm1,XMMWORD PTR [rsp+0x132]
  c18226:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c1822e:	mov    rdx,QWORD PTR [rsp+0x18]
  c18233:	movups XMMWORD PTR [rdx+0x20],xmm2
  c18237:	movdqu XMMWORD PTR [rdx+0x12],xmm1
  c1823c:	movdqu XMMWORD PTR [rdx+0x2],xmm0
  c18241:	mov    BYTE PTR [rdx],cl
  c18243:	mov    BYTE PTR [rdx+0x1],al
  c18246:	lea    rdi,[rsp+0x80]
  c1824e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18253:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c18258:	mov    r15b,0x1f
  c1825b:	lea    rbx,[rip+0xffffffffff6ae6aa]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c18262:	mov    r12d,0x4f
  c18268:	mov    r13,QWORD PTR [rsp+0x18]
  c1826d:	mov    eax,DWORD PTR [rsp+0x80]
  c18274:	mov    edx,eax
  c18276:	sub    edx,0x2
  c18279:	mov    ecx,0x3
  c1827e:	cmovae ecx,edx
  c18281:	cmp    ecx,0x8
  c18284:	ja     c190c3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x97a3>
  c1828a:	mov    edx,0x1e7
  c1828f:	bt     edx,ecx
  c18292:	jae    c18a66 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9146>
  c18298:	mov    eax,DWORD PTR [rsp+0x40]
  c1829c:	mov    edx,eax
  c1829e:	sub    edx,0x2
  c182a1:	mov    ecx,0x3
  c182a6:	cmovae ecx,edx
  c182a9:	cmp    ecx,0x8
  c182ac:	ja     c18c33 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9313>
  c182b2:	mov    edx,0x1e7
  c182b7:	bt     edx,ecx
  c182ba:	jae    c1870a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dea>
  c182c0:	movzx  eax,WORD PTR [rsp+0x104]
  c182c8:	mov    WORD PTR [r13+0x6],ax
  c182cd:	mov    eax,DWORD PTR [rsp+0x100]
  c182d4:	mov    DWORD PTR [r13+0x2],eax
  c182d8:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c182e1:	movdqu XMMWORD PTR [r13+0x18],xmm0
  c182e7:	mov    rax,QWORD PTR [rsp+0xe0]
  c182ef:	mov    QWORD PTR [r13+0x28],rax
  c182f3:	mov    BYTE PTR [r13+0x0],r15b
  c182f7:	mov    BYTE PTR [r13+0x1],bpl
  c182fb:	mov    QWORD PTR [r13+0x8],rbx
  c182ff:	mov    QWORD PTR [r13+0x10],r12
  c18303:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c18308:	mov    bpl,0x1f
  c1830b:	lea    rbx,[rip+0xffffffffff6ae5fa]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c18312:	mov    r15d,0x4f
  c18318:	mov    r13,QWORD PTR [rsp+0x18]
  c1831d:	mov    eax,DWORD PTR [rsp+0x80]
  c18324:	mov    edx,eax
  c18326:	sub    edx,0x2
  c18329:	mov    ecx,0x3
  c1832e:	cmovae ecx,edx
  c18331:	cmp    ecx,0x8
  c18334:	ja     c1907b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x975b>
  c1833a:	mov    edx,0x1e7
  c1833f:	bt     edx,ecx
  c18342:	jae    c189fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x90dc>
  c18348:	mov    eax,DWORD PTR [rsp+0x40]
  c1834c:	mov    edx,eax
  c1834e:	sub    edx,0x2
  c18351:	mov    ecx,0x3
  c18356:	cmovae ecx,edx
  c18359:	cmp    ecx,0x8
  c1835c:	ja     c18c6f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x934f>
  c18362:	mov    edx,0x1e7
  c18367:	bt     edx,ecx
  c1836a:	jae    c18768 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e48>
  c18370:	movzx  eax,WORD PTR [rsp+0x104]
  c18378:	mov    WORD PTR [r13+0x6],ax
  c1837d:	mov    eax,DWORD PTR [rsp+0x100]
  c18384:	mov    DWORD PTR [r13+0x2],eax
  c18388:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c18391:	movdqu XMMWORD PTR [r13+0x18],xmm0
  c18397:	mov    rax,QWORD PTR [rsp+0xe0]
  c1839f:	mov    QWORD PTR [r13+0x28],rax
  c183a3:	mov    BYTE PTR [r13+0x0],bpl
  c183a7:	mov    BYTE PTR [r13+0x1],r14b
  c183ab:	mov    QWORD PTR [r13+0x8],rbx
  c183af:	mov    QWORD PTR [r13+0x10],r15
  c183b3:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c183b8:	mov    r14b,0x1f
  c183bb:	lea    rbx,[rip+0xffffffffff6ae54a]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c183c2:	mov    r15d,0x4f
  c183c8:	mov    eax,DWORD PTR [rsp+0x80]
  c183cf:	mov    edx,eax
  c183d1:	sub    edx,0x2
  c183d4:	mov    ecx,0x3
  c183d9:	cmovae ecx,edx
  c183dc:	cmp    ecx,0x8
  c183df:	ja     c1909f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x977f>
  c183e5:	mov    edx,0x1e7
  c183ea:	bt     edx,ecx
  c183ed:	jae    c18a31 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9111>
  c183f3:	mov    eax,DWORD PTR [rsp+0x40]
  c183f7:	mov    edx,eax
  c183f9:	sub    edx,0x2
  c183fc:	mov    ecx,0x3
  c18401:	cmovae ecx,edx
  c18404:	cmp    ecx,0x8
  c18407:	ja     c18c23 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9303>
  c1840d:	mov    edx,0x1e7
  c18412:	bt     edx,ecx
  c18415:	jb     c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18417:	cmp    ecx,0x3
  c1841a:	jne    c18bb9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9299>
  c18420:	test   eax,eax
  c18422:	je     c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18424:	mov    rax,QWORD PTR [rsp+0x48]
  c18429:	dec    QWORD PTR [rax]
  c1842c:	jne    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c1842e:	jmp    c18758 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e38>
  c18433:	mov    r14b,0x1f
  c18436:	lea    rbx,[rip+0xffffffffff6ae4cf]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c1843d:	mov    r15d,0x4f
  c18443:	mov    eax,DWORD PTR [rsp+0x80]
  c1844a:	mov    edx,eax
  c1844c:	sub    edx,0x2
  c1844f:	mov    ecx,0x3
  c18454:	cmovae ecx,edx
  c18457:	cmp    ecx,0x8
  c1845a:	ja     c19057 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9737>
  c18460:	mov    edx,0x1e7
  c18465:	bt     edx,ecx
  c18468:	jae    c189c7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x90a7>
  c1846e:	mov    eax,DWORD PTR [rsp+0x40]
  c18472:	mov    edx,eax
  c18474:	sub    edx,0x2
  c18477:	mov    ecx,0x3
  c1847c:	cmovae ecx,edx
  c1847f:	cmp    ecx,0x8
  c18482:	ja     c18c51 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9331>
  c18488:	mov    edx,0x1e7
  c1848d:	bt     edx,ecx
  c18490:	jae    c18739 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e19>
  c18496:	movzx  eax,WORD PTR [rsp+0x104]
  c1849e:	mov    rcx,QWORD PTR [rsp+0x18]
  c184a3:	mov    WORD PTR [rcx+0x6],ax
  c184a7:	mov    eax,DWORD PTR [rsp+0x100]
  c184ae:	mov    DWORD PTR [rcx+0x2],eax
  c184b1:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c184ba:	movdqu XMMWORD PTR [rcx+0x18],xmm0
  c184bf:	mov    rax,QWORD PTR [rsp+0xe0]
  c184c7:	mov    QWORD PTR [rcx+0x28],rax
  c184cb:	mov    BYTE PTR [rcx],r14b
  c184ce:	mov    BYTE PTR [rcx+0x1],bpl
  c184d2:	mov    QWORD PTR [rcx+0x8],rbx
  c184d6:	mov    QWORD PTR [rcx+0x10],r15
  c184da:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c184df:	lea    rdi,[rsp+0x120]
  c184e7:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c184ec:	mov    rcx,QWORD PTR [rsp+0x18]
  c184f1:	mov    BYTE PTR [rcx],0x1f
  c184f4:	lea    rax,[rip+0xffffffffff6ae411]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c184fb:	mov    QWORD PTR [rcx+0x8],rax
  c184ff:	mov    QWORD PTR [rcx+0x10],0x4f
  c18507:	lea    rdi,[rsp+0xd0]
  c1850f:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18514:	jmp    c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c18519:	lea    rdi,[rsp+0x120]
  c18521:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18526:	mov    BYTE PTR [r14],0x1f
  c1852a:	lea    rax,[rip+0xffffffffff6ae3db]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c18531:	mov    QWORD PTR [r14+0x8],rax
  c18535:	mov    QWORD PTR [r14+0x10],0x4f
  c1853d:	jmp    c18f49 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9629>
  c18542:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c1854b:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c18554:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c1855c:	mov    rax,QWORD PTR [rsp+0x18]
  c18561:	movups XMMWORD PTR [rax+0x20],xmm2
  c18565:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1856a:	movdqu XMMWORD PTR [rax],xmm0
  c1856e:	lea    rdi,[rsp+0x80]
  c18576:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1857b:	lea    rdi,[rsp+0x40]
  c18580:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18585:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c1858a:	lea    rdi,[rsp+0x120]
  c18592:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18597:	mov    rcx,QWORD PTR [rsp+0x18]
  c1859c:	mov    BYTE PTR [rcx],0x1f
  c1859f:	lea    rax,[rip+0xffffffffff6ae366]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c185a6:	mov    QWORD PTR [rcx+0x8],rax
  c185aa:	mov    QWORD PTR [rcx+0x10],0x4f
  c185b2:	jmp    c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c185b7:	mov    rcx,QWORD PTR [rsp+0x18]
  c185bc:	mov    BYTE PTR [rcx],0x1f
  c185bf:	lea    rax,[rip+0xffffffffff6ae23e]        # 2c6804 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x481>
  c185c6:	mov    QWORD PTR [rcx+0x8],rax
  c185ca:	mov    edx,0x44
  c185cf:	mov    eax,0x10
  c185d4:	mov    QWORD PTR [rcx+rax*1],rdx
  c185d8:	mov    rax,QWORD PTR [rsp+0x80]
  c185e0:	test   rax,rax
  c185e3:	je     c18600 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ce0>
  c185e5:	mov    rdi,QWORD PTR [rsp+0x88]
  c185ed:	shl    rax,0x3
  c185f1:	lea    rsi,[rax+rax*2]
  c185f5:	mov    edx,0x8
  c185fa:	call   QWORD PTR [rip+0x235288]        # e4d888 <_DYNAMIC+0x240>
  c18600:	mov    rsi,QWORD PTR [rsp+0x40]
  c18605:	test   rsi,rsi
  c18608:	je     c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c1860e:	mov    rdi,QWORD PTR [rsp+0x48]
  c18613:	shl    rsi,0x4
  c18617:	mov    edx,0x8
  c1861c:	call   QWORD PTR [rip+0x235266]        # e4d888 <_DYNAMIC+0x240>
  c18622:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c18627:	lea    rax,[rip+0xffffffffff6adbdf]        # 2c620d <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x184c>
  c1862e:	mov    ecx,0x41
  c18633:	jmp    c18641 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d21>
  c18635:	lea    rax,[rip+0xffffffffff6adc12]        # 2c624e <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x188d>
  c1863c:	mov    ecx,0x45
  c18641:	mov    rdx,QWORD PTR [rsp+0x18]
  c18646:	mov    BYTE PTR [rdx],0x1f
  c18649:	mov    QWORD PTR [rdx+0x8],rax
  c1864d:	mov    QWORD PTR [rdx+0x10],rcx
  c18651:	jmp    c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c18656:	mov    rcx,QWORD PTR [rsp+0x18]
  c1865b:	mov    BYTE PTR [rcx],0x1f
  c1865e:	lea    rax,[rip+0xffffffffff6adb51]        # 2c61b6 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x17f5>
  c18665:	mov    QWORD PTR [rcx+0x8],rax
  c18669:	mov    QWORD PTR [rcx+0x10],0x57
  c18671:	jmp    c186eb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dcb>
  c18673:	movups xmm0,XMMWORD PTR [rsp+0x121]
  c1867b:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c18684:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c1868c:	movdqu XMMWORD PTR [rsp+0x4f],xmm1
  c18692:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c18697:	mov    rcx,QWORD PTR [rsp+0x18]
  c1869c:	movups XMMWORD PTR [rcx+0x20],xmm2
  c186a0:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c186a5:	movups XMMWORD PTR [rcx+0x10],xmm0
  c186a9:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c186af:	jmp    c18f42 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9622>
  c186b4:	lea    rax,[rip+0xffffffffff6adb52]        # 2c620d <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x184c>
  c186bb:	mov    ecx,0x41
  c186c0:	jmp    c186ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dae>
  c186c2:	lea    rax,[rip+0xffffffffff6adb85]        # 2c624e <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x188d>
  c186c9:	mov    ecx,0x45
  c186ce:	mov    rdx,QWORD PTR [rsp+0x18]
  c186d3:	mov    BYTE PTR [rdx],0x1f
  c186d6:	mov    QWORD PTR [rdx+0x8],rax
  c186da:	mov    QWORD PTR [rdx+0x10],rcx
  c186de:	lea    rdi,[rsp+0x120]
  c186e6:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c186eb:	lea    rdi,[rsp+0xd0]
  c186f3:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c186f8:	lea    rdi,[rsp+0x100]
  c18700:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18705:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c1870a:	cmp    ecx,0x3
  c1870d:	jne    c18bc9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92a9>
  c18713:	test   eax,eax
  c18715:	je     c182c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89a0>
  c1871b:	mov    rax,QWORD PTR [rsp+0x48]
  c18720:	dec    QWORD PTR [rax]
  c18723:	jne    c182c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89a0>
  c18729:	lea    rdi,[rsp+0x48]
  c1872e:	call   QWORD PTR [rip+0x23515c]        # e4d890 <_DYNAMIC+0x248>
  c18734:	jmp    c182c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89a0>
  c18739:	cmp    ecx,0x3
  c1873c:	jne    c18be7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92c7>
  c18742:	test   eax,eax
  c18744:	je     c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c1874a:	mov    rax,QWORD PTR [rsp+0x48]
  c1874f:	dec    QWORD PTR [rax]
  c18752:	jne    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18758:	lea    rdi,[rsp+0x48]
  c1875d:	call   QWORD PTR [rip+0x23512d]        # e4d890 <_DYNAMIC+0x248>
  c18763:	jmp    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18768:	cmp    ecx,0x3
  c1876b:	jne    c18c05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92e5>
  c18771:	test   eax,eax
  c18773:	je     c18370 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a50>
  c18779:	mov    rax,QWORD PTR [rsp+0x48]
  c1877e:	dec    QWORD PTR [rax]
  c18781:	jne    c18370 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a50>
  c18787:	lea    rdi,[rsp+0x48]
  c1878c:	call   QWORD PTR [rip+0x2350fe]        # e4d890 <_DYNAMIC+0x248>
  c18792:	jmp    c18370 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a50>
  c18797:	mov    DWORD PTR [rsp+0x5b8],0x2
  c187a2:	mov    rbx,QWORD PTR [rsp+0x18]
  c187a7:	mov    r14,QWORD PTR [rsp+0x38]
  c187ac:	mov    r15,QWORD PTR [rsp+0x1c8]
  c187b4:	mov    r12,QWORD PTR [rsp+0x20]
  c187b9:	jmp    c18cd6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x93b6>
  c187be:	add    rcx,QWORD PTR [rsi+0x60]
  c187c2:	mov    r14,QWORD PTR [rsp+0x8]
  c187c7:	cmp    rcx,rax
  c187ca:	jae    c18d7a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x945a>
  c187d0:	mov    rax,QWORD PTR [rsp+0x38]
  c187d5:	mov    rax,QWORD PTR [rax+0x8]
  c187d9:	lea    rcx,[rcx+rcx*2]
  c187dd:	lea    rsi,[rax+rcx*8]
  c187e1:	lea    rdi,[rsp+0x120]
  c187e9:	call   c25060 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c187ee:	mov    rax,QWORD PTR [rsp+0x120]
  c187f6:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c187ff:	mov    QWORD PTR [rsp+0x100],rax
  c18807:	movdqu XMMWORD PTR [rsp+0x108],xmm0
  c18810:	lea    rdi,[rsp+0x120]
  c18818:	lea    rsi,[rsp+0x100]
  c18820:	call   QWORD PTR [rip+0x23a68a]        # e52eb0 <_DYNAMIC+0x5868>
  c18826:	cmp    DWORD PTR [rsp+0x120],0x1
  c1882e:	jne    c18de6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x94c6>
  c18834:	mov    rax,QWORD PTR [rsp+0x128]
  c1883c:	mov    rcx,QWORD PTR [rsp+0x650]
  c18844:	cmp    rax,QWORD PTR [rcx+0xa8]
  c1884b:	jne    c190e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x97c7>
  c18851:	mov    rax,QWORD PTR [rsp+0x130]
  c18859:	cmp    rax,QWORD PTR [rcx+0x88]
  c18860:	jae    c195cb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9cab>
  c18866:	lea    rbx,[rax+rax*2]
  c1886a:	shl    rbx,0x4
  c1886e:	add    rbx,QWORD PTR [rcx+0x80]
  c18875:	lea    rax,[rip+0xffffffffff6ae00b]        # 2c6887 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x504>
  c1887c:	mov    QWORD PTR [rsp+0x128],rax
  c18884:	mov    QWORD PTR [rsp+0x130],0x40
  c18890:	mov    BYTE PTR [rsp+0x120],0x1f
  c18898:	lea    rdi,[rsp+0x120]
  c188a0:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.2691469935230288402>
  c188a5:	movzx  eax,BYTE PTR [rbx]
  c188a8:	cmp    al,0xfe
  c188aa:	jne    c19618 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9cf8>
  c188b0:	add    rbx,0x8
  c188b4:	lea    rsi,[rsp+0x658]
  c188bc:	mov    rdi,rbx
  c188bf:	call   c3b9a0 <_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequejE8containsCsbxgXiyEKxkX_6bsl_vm>
  c188c4:	mov    r14,QWORD PTR [rsp+0x18]
  c188c9:	test   al,al
  c188cb:	jne    c188dd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8fbd>
  c188cd:	mov    rdi,rbx
  c188d0:	mov    rsi,QWORD PTR [rsp+0x4f0]
  c188d8:	call   c3b360 <_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequejE13push_back_mutCsbxgXiyEKxkX_6bsl_vm>
  c188dd:	mov    DWORD PTR [r14+0x8],0xf
  c188e5:	mov    BYTE PTR [r14],0xff
  c188e9:	jmp    c19887 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f67>
  c188ee:	mov    rcx,QWORD PTR [rsp+0x18]
  c188f3:	mov    BYTE PTR [rcx],0x1f
  c188f6:	lea    rax,[rip+0xffffffffff6addfc]        # 2c66f9 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x376>
  c188fd:	mov    QWORD PTR [rcx+0x8],rax
  c18901:	mov    QWORD PTR [rcx+0x10],0x5e
  c18909:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c1890e:	mov    ecx,DWORD PTR [rsp+0x121]
  c18915:	mov    edx,DWORD PTR [rsp+0x124]
  c1891c:	mov    rsi,QWORD PTR [rsp+0x18]
  c18921:	mov    DWORD PTR [rsi+0x4],edx
  c18924:	mov    DWORD PTR [rsi+0x1],ecx
  c18927:	mov    rcx,QWORD PTR [rsp+0x148]
  c1892f:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c18938:	movdqu xmm1,XMMWORD PTR [rsp+0x138]
  c18941:	mov    BYTE PTR [rsi],al
  c18943:	movdqu XMMWORD PTR [rsi+0x8],xmm0
  c18948:	movdqu XMMWORD PTR [rsi+0x18],xmm1
  c1894d:	mov    QWORD PTR [rsi+0x28],rcx
  c18951:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c18956:	lea    rdi,[rsp+0x120]
  c1895e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18963:	mov    rcx,QWORD PTR [rsp+0x18]
  c18968:	mov    BYTE PTR [rcx],0x1f
  c1896b:	lea    rax,[rip+0xffffffffff6adf9a]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c18972:	mov    QWORD PTR [rcx+0x8],rax
  c18976:	mov    QWORD PTR [rcx+0x10],0x4f
  c1897e:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c18983:	lea    rdi,[rsp+0xd0]
  c1898b:	mov    rsi,QWORD PTR [rsp+0x1f8]
  c18993:	call   c0daa0 <_RNvCsbxgXiyEKxkX_6bsl_vm18push_own_registers>
  c18998:	mov    r13,QWORD PTR [rsp+0x18]
  c1899d:	mov    rbp,QWORD PTR [rsp+0x38]
  c189a2:	mov    rax,QWORD PTR [rsp+0x1f8]
  c189aa:	cmp    BYTE PTR [rax+0xc0],0x0
  c189b1:	je     c18e72 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9552>
  c189b7:	mov    eax,0x2
  c189bc:	mov    r12d,0x2
  c189c2:	jmp    c1935b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9a3b>
  c189c7:	cmp    ecx,0x3
  c189ca:	jne    c18fc7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x96a7>
  c189d0:	test   eax,eax
  c189d2:	je     c1846e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b4e>
  c189d8:	mov    rax,QWORD PTR [rsp+0x88]
  c189e0:	dec    QWORD PTR [rax]
  c189e3:	jne    c1846e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b4e>
  c189e9:	lea    rdi,[rsp+0x88]
  c189f1:	call   QWORD PTR [rip+0x234e99]        # e4d890 <_DYNAMIC+0x248>
  c189f7:	jmp    c1846e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b4e>
  c189fc:	cmp    ecx,0x3
  c189ff:	jne    c18feb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x96cb>
  c18a05:	test   eax,eax
  c18a07:	je     c18348 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a28>
  c18a0d:	mov    rax,QWORD PTR [rsp+0x88]
  c18a15:	dec    QWORD PTR [rax]
  c18a18:	jne    c18348 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a28>
  c18a1e:	lea    rdi,[rsp+0x88]
  c18a26:	call   QWORD PTR [rip+0x234e64]        # e4d890 <_DYNAMIC+0x248>
  c18a2c:	jmp    c18348 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a28>
  c18a31:	cmp    ecx,0x3
  c18a34:	jne    c1900f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x96ef>
  c18a3a:	test   eax,eax
  c18a3c:	je     c183f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ad3>
  c18a42:	mov    rax,QWORD PTR [rsp+0x88]
  c18a4a:	dec    QWORD PTR [rax]
  c18a4d:	jne    c183f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ad3>
  c18a53:	lea    rdi,[rsp+0x88]
  c18a5b:	call   QWORD PTR [rip+0x234e2f]        # e4d890 <_DYNAMIC+0x248>
  c18a61:	jmp    c183f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ad3>
  c18a66:	cmp    ecx,0x3
  c18a69:	jne    c19033 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9713>
  c18a6f:	test   eax,eax
  c18a71:	je     c18298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8978>
  c18a77:	mov    rax,QWORD PTR [rsp+0x88]
  c18a7f:	dec    QWORD PTR [rax]
  c18a82:	jne    c18298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8978>
  c18a88:	lea    rdi,[rsp+0x88]
  c18a90:	call   QWORD PTR [rip+0x234dfa]        # e4d890 <_DYNAMIC+0x248>
  c18a96:	jmp    c18298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8978>
  c18a9b:	lea    rcx,[rsp+0x84]
  c18aa3:	movups xmm0,XMMWORD PTR [rcx+0x1c]
  c18aa7:	mov    rdx,QWORD PTR [rsp+0x18]
  c18aac:	movups XMMWORD PTR [rdx+0x20],xmm0
  c18ab0:	movdqu xmm0,XMMWORD PTR [rcx-0x3]
  c18ab5:	movdqu xmm1,XMMWORD PTR [rcx+0xc]
  c18aba:	movdqu XMMWORD PTR [rdx+0x1],xmm0
  c18abf:	movdqu XMMWORD PTR [rdx+0x10],xmm1
  c18ac4:	mov    BYTE PTR [rdx],al
  c18ac6:	jmp    c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c18acb:	mov    rcx,QWORD PTR [rsp+0x18]
  c18ad0:	mov    BYTE PTR [rcx],0x1f
  c18ad3:	lea    rax,[rip+0xffffffffff6ad6dc]        # 2c61b6 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x17f5>
  c18ada:	mov    QWORD PTR [rcx+0x8],rax
  c18ade:	mov    QWORD PTR [rcx+0x10],0x57
  c18ae6:	jmp    c18b2b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x920b>
  c18ae8:	movups xmm0,XMMWORD PTR [rsp+0x121]
  c18af0:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c18af9:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c18b01:	movdqu XMMWORD PTR [rsp+0x4f],xmm1
  c18b07:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c18b0c:	mov    rcx,QWORD PTR [rsp+0x18]
  c18b11:	movups XMMWORD PTR [rcx+0x20],xmm2
  c18b15:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c18b1a:	movups XMMWORD PTR [rcx+0x10],xmm0
  c18b1e:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c18b24:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c18b29:	mov    BYTE PTR [rcx],al
  c18b2b:	lea    rdi,[rsp+0x80]
  c18b33:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c18b38:	jmp    c18e6d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x954d>
  c18b3d:	lea    rcx,[rsp+0x84]
  c18b45:	movdqu xmm0,XMMWORD PTR [rcx-0x3]
  c18b4a:	movdqu xmm1,XMMWORD PTR [rcx+0xd]
  c18b4f:	movups xmm2,XMMWORD PTR [rcx+0x1c]
  c18b53:	mov    rcx,QWORD PTR [rsp+0x18]
  c18b58:	movups XMMWORD PTR [rcx+0x20],xmm2
  c18b5c:	movdqu XMMWORD PTR [rcx+0x11],xmm1
  c18b61:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c18b66:	mov    BYTE PTR [rcx],al
  c18b68:	jmp    c186eb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dcb>
  c18b6d:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c18b76:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c18b7f:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c18b87:	mov    rax,QWORD PTR [rsp+0x18]
  c18b8c:	movups XMMWORD PTR [rax+0x20],xmm2
  c18b90:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c18b95:	movdqu XMMWORD PTR [rax],xmm0
  c18b99:	cmp    BYTE PTR [rsp+0x80],0xff
  c18ba1:	je     c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c18ba7:	lea    rdi,[rsp+0x80]
  c18baf:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.2691469935230288402>
  c18bb4:	jmp    c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c18bb9:	mov    rax,QWORD PTR [rsp+0x48]
  c18bbe:	dec    QWORD PTR [rax]
  c18bc1:	jne    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18bc7:	jmp    c18bf5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92d5>
  c18bc9:	mov    rax,QWORD PTR [rsp+0x48]
  c18bce:	dec    QWORD PTR [rax]
  c18bd1:	jne    c182c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89a0>
  c18bd7:	lea    rdi,[rsp+0x48]
  c18bdc:	call   QWORD PTR [rip+0x234cb6]        # e4d898 <_DYNAMIC+0x250>
  c18be2:	jmp    c182c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89a0>
  c18be7:	mov    rax,QWORD PTR [rsp+0x48]
  c18bec:	dec    QWORD PTR [rax]
  c18bef:	jne    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18bf5:	lea    rdi,[rsp+0x48]
  c18bfa:	call   QWORD PTR [rip+0x234c98]        # e4d898 <_DYNAMIC+0x250>
  c18c00:	jmp    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18c05:	mov    rax,QWORD PTR [rsp+0x48]
  c18c0a:	dec    QWORD PTR [rax]
  c18c0d:	jne    c18370 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a50>
  c18c13:	lea    rdi,[rsp+0x48]
  c18c18:	call   QWORD PTR [rip+0x234c7a]        # e4d898 <_DYNAMIC+0x250>
  c18c1e:	jmp    c18370 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a50>
  c18c23:	mov    rax,QWORD PTR [rsp+0x48]
  c18c28:	dec    QWORD PTR [rax]
  c18c2b:	jne    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18c31:	jmp    c18c5f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x933f>
  c18c33:	mov    rax,QWORD PTR [rsp+0x48]
  c18c38:	dec    QWORD PTR [rax]
  c18c3b:	jne    c182c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89a0>
  c18c41:	lea    rdi,[rsp+0x48]
  c18c46:	call   QWORD PTR [rip+0x234c54]        # e4d8a0 <_DYNAMIC+0x258>
  c18c4c:	jmp    c182c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89a0>
  c18c51:	mov    rax,QWORD PTR [rsp+0x48]
  c18c56:	dec    QWORD PTR [rax]
  c18c59:	jne    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18c5f:	lea    rdi,[rsp+0x48]
  c18c64:	call   QWORD PTR [rip+0x234c36]        # e4d8a0 <_DYNAMIC+0x258>
  c18c6a:	jmp    c18496 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b76>
  c18c6f:	mov    rax,QWORD PTR [rsp+0x48]
  c18c74:	dec    QWORD PTR [rax]
  c18c77:	jne    c18370 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a50>
  c18c7d:	lea    rdi,[rsp+0x48]
  c18c82:	call   QWORD PTR [rip+0x234c18]        # e4d8a0 <_DYNAMIC+0x258>
  c18c88:	jmp    c18370 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a50>
  c18c8d:	add    rax,QWORD PTR [rdx+0x60]
  c18c91:	cmp    rax,QWORD PTR [r14+0x10]
  c18c95:	jae    c18d7a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x945a>
  c18c9b:	lea    rsi,[rax+rax*2]
  c18c9f:	shl    rsi,0x3
  c18ca3:	add    rsi,QWORD PTR [r14+0x8]
  c18ca7:	lea    rdi,[rsp+0x120]
  c18caf:	call   c25060 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c18cb4:	mov    rax,QWORD PTR [rsp+0x120]
  c18cbc:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c18cc5:	mov    QWORD PTR [rsp+0x5b8],rax
  c18ccd:	movdqu XMMWORD PTR [rsp+0x5c0],xmm0
  c18cd6:	mov    rax,QWORD PTR [rsp+0x620]
  c18cde:	mov    r9,QWORD PTR [rax+0x10]
  c18ce2:	sub    rsp,0x8
  c18ce6:	lea    rax,[rsp+0x5c0]
  c18cee:	lea    rdi,[rsp+0x128]
  c18cf6:	mov    rsi,r12
  c18cf9:	mov    rdx,r14
  c18cfc:	mov    rcx,r15
  c18cff:	mov    r8,QWORD PTR [rsp+0x500]
  c18d07:	push   rax
  c18d08:	call   c0dae0 <_RNvCsbxgXiyEKxkX_6bsl_vm20do_return_with_value>
  c18d0d:	add    rsp,0x10
  c18d11:	movzx  eax,BYTE PTR [rsp+0x120]
  c18d19:	cmp    al,0xff
  c18d1b:	je     c18d95 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9475>
  c18d1d:	mov    ecx,DWORD PTR [rsp+0x121]
  c18d24:	mov    edx,DWORD PTR [rsp+0x124]
  c18d2b:	mov    DWORD PTR [rbx+0x4],edx
  c18d2e:	mov    DWORD PTR [rbx+0x1],ecx
  c18d31:	mov    ecx,DWORD PTR [rsp+0x128]
  c18d38:	movups xmm0,XMMWORD PTR [rsp+0x12c]
  c18d40:	movaps XMMWORD PTR [rsp+0x3f0],xmm0
  c18d48:	mov    edx,DWORD PTR [rsp+0x13c]
  c18d4f:	mov    DWORD PTR [rsp+0x400],edx
  c18d56:	movups xmm0,XMMWORD PTR [rsp+0x140]
  c18d5e:	movups XMMWORD PTR [rbx+0x20],xmm0
  c18d62:	mov    edx,DWORD PTR [rsp+0x400]
  c18d69:	mov    DWORD PTR [rbx+0x1c],edx
  c18d6c:	movdqa xmm0,XMMWORD PTR [rsp+0x3f0]
  c18d75:	jmp    c0fab0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x190>
  c18d7a:	mov    BYTE PTR [rbx],0x1f
  c18d7d:	lea    rax,[rip+0xffffffffff6ad394]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c18d84:	mov    QWORD PTR [rbx+0x8],rax
  c18d88:	mov    QWORD PTR [rbx+0x10],0x4f
  c18d90:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c18d95:	mov    eax,DWORD PTR [rsp+0x128]
  c18d9c:	movups xmm0,XMMWORD PTR [rsp+0x12c]
  c18da4:	movaps XMMWORD PTR [rsp+0x3f0],xmm0
  c18dac:	mov    ecx,DWORD PTR [rsp+0x13c]
  c18db3:	mov    DWORD PTR [rsp+0x400],ecx
  c18dba:	cmp    eax,0xffffffff
  c18dbd:	je     c192c7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x99a7>
  c18dc3:	mov    ecx,DWORD PTR [rsp+0x400]
  c18dca:	mov    DWORD PTR [rsp+0x90],ecx
  c18dd1:	movaps xmm0,XMMWORD PTR [rsp+0x3f0]
  c18dd9:	movaps XMMWORD PTR [rsp+0x80],xmm0
  c18de1:	jmp    c192cc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x99ac>
  c18de6:	mov    rax,QWORD PTR [rsp+0xf8]
  c18dee:	mov    rsi,QWORD PTR [rax]
  c18df1:	cmp    r14,rsi
  c18df4:	mov    rbp,QWORD PTR [rsp+0x28]
  c18df9:	mov    rax,QWORD PTR [rsp+0x10]
  c18dfe:	jae    c19faa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa68a>
  c18e04:	mov    rdx,QWORD PTR [rax]
  c18e07:	lea    rcx,[rdx+rbp*1]
  c18e0b:	mov    rax,r12
  c18e0e:	sub    rax,QWORD PTR [rdx+rbp*1+0x30]
  c18e13:	jae    c1915d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x983d>
  c18e19:	mov    rax,QWORD PTR [rcx+0x28]
  c18e1d:	shl    r12d,0x4
  c18e21:	mov    rax,QWORD PTR [rax+r12*1]
  c18e25:	jmp    c19161 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9841>
  c18e2a:	movups xmm0,XMMWORD PTR [rsp+0x81]
  c18e32:	movdqu xmm1,XMMWORD PTR [rsp+0x90]
  c18e3b:	movups xmm2,XMMWORD PTR [rsp+0xa0]
  c18e43:	movdqu XMMWORD PTR [rsp+0x4f],xmm1
  c18e49:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c18e4e:	mov    rcx,QWORD PTR [rsp+0x18]
  c18e53:	movups XMMWORD PTR [rcx+0x20],xmm2
  c18e57:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c18e5c:	movups XMMWORD PTR [rcx+0x10],xmm0
  c18e60:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c18e66:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c18e6b:	mov    BYTE PTR [rcx],al
  c18e6d:	jmp    c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c18e72:	lea    rdi,[rsp+0x120]
  c18e7a:	mov    rsi,QWORD PTR [rsp+0x650]
  c18e82:	call   c49300 <_RNvMs0_NtCsbxgXiyEKxkX_6bsl_vm9schedulerNtB5_10AsyncState11new_promise>
  c18e87:	movzx  eax,BYTE PTR [rsp+0x120]
  c18e8f:	cmp    al,0xff
  c18e91:	je     c19326 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9a06>
  c18e97:	mov    ecx,DWORD PTR [rsp+0x121]
  c18e9e:	mov    edx,DWORD PTR [rsp+0x124]
  c18ea5:	mov    DWORD PTR [r13+0x4],edx
  c18ea9:	mov    DWORD PTR [r13+0x1],ecx
  c18ead:	mov    rcx,QWORD PTR [rsp+0x128]
  c18eb5:	mov    edx,DWORD PTR [rsp+0x130]
  c18ebc:	movdqu xmm0,XMMWORD PTR [rsp+0x134]
  c18ec5:	movdqa XMMWORD PTR [rsp+0x80],xmm0
  c18ece:	mov    esi,DWORD PTR [rsp+0x144]
  c18ed5:	mov    DWORD PTR [rsp+0x90],esi
  c18edc:	mov    rdi,QWORD PTR [rsp+0x148]
  c18ee4:	mov    DWORD PTR [r13+0x24],esi
  c18ee8:	movdqu XMMWORD PTR [r13+0x14],xmm0
  c18eee:	mov    BYTE PTR [r13+0x0],al
  c18ef2:	mov    QWORD PTR [r13+0x8],rcx
  c18ef6:	mov    DWORD PTR [r13+0x10],edx
  c18efa:	mov    QWORD PTR [r13+0x28],rdi
  c18efe:	jmp    c1959b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c7b>
  c18f03:	movups xmm0,XMMWORD PTR [rsp+0x41]
  c18f08:	movdqu xmm1,XMMWORD PTR [rsp+0x50]
  c18f0e:	movups xmm2,XMMWORD PTR [rsp+0x60]
  c18f13:	movdqu XMMWORD PTR [rsp+0xdf],xmm1
  c18f1c:	movaps XMMWORD PTR [rsp+0xd0],xmm0
  c18f24:	mov    rcx,QWORD PTR [rsp+0x18]
  c18f29:	movups XMMWORD PTR [rcx+0x20],xmm2
  c18f2d:	movups xmm0,XMMWORD PTR [rsp+0xdf]
  c18f35:	movups XMMWORD PTR [rcx+0x10],xmm0
  c18f39:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c18f42:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c18f47:	mov    BYTE PTR [rcx],al
  c18f49:	lea    rdi,[rsp+0x80]
  c18f51:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c18f56:	lea    rdi,[rsp+0x368]
  c18f5e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18f63:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c18f68:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c18f71:	movdqu xmm1,XMMWORD PTR [rsp+0x90]
  c18f7a:	movups xmm2,XMMWORD PTR [rsp+0xa0]
  c18f82:	mov    rax,QWORD PTR [rsp+0x18]
  c18f87:	movups XMMWORD PTR [rax+0x20],xmm2
  c18f8b:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c18f90:	movdqu XMMWORD PTR [rax],xmm0
  c18f94:	jmp    c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c18f99:	cmp    eax,0x3
  c18f9c:	jne    c192e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x99c9>
  c18fa2:	test   r8d,r8d
  c18fa5:	je     c179f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80d2>
  c18fab:	dec    QWORD PTR [rdi]
  c18fae:	jne    c179f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80d2>
  c18fb4:	lea    rdi,[rsp+0x128]
  c18fbc:	call   QWORD PTR [rip+0x2348ce]        # e4d890 <_DYNAMIC+0x248>
  c18fc2:	jmp    c179f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80d2>
  c18fc7:	mov    rax,QWORD PTR [rsp+0x88]
  c18fcf:	dec    QWORD PTR [rax]
  c18fd2:	jne    c1846e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b4e>
  c18fd8:	lea    rdi,[rsp+0x88]
  c18fe0:	call   QWORD PTR [rip+0x2348b2]        # e4d898 <_DYNAMIC+0x250>
  c18fe6:	jmp    c1846e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b4e>
  c18feb:	mov    rax,QWORD PTR [rsp+0x88]
  c18ff3:	dec    QWORD PTR [rax]
  c18ff6:	jne    c18348 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a28>
  c18ffc:	lea    rdi,[rsp+0x88]
  c19004:	call   QWORD PTR [rip+0x23488e]        # e4d898 <_DYNAMIC+0x250>
  c1900a:	jmp    c18348 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a28>
  c1900f:	mov    rax,QWORD PTR [rsp+0x88]
  c19017:	dec    QWORD PTR [rax]
  c1901a:	jne    c183f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ad3>
  c19020:	lea    rdi,[rsp+0x88]
  c19028:	call   QWORD PTR [rip+0x23486a]        # e4d898 <_DYNAMIC+0x250>
  c1902e:	jmp    c183f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ad3>
  c19033:	mov    rax,QWORD PTR [rsp+0x88]
  c1903b:	dec    QWORD PTR [rax]
  c1903e:	jne    c18298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8978>
  c19044:	lea    rdi,[rsp+0x88]
  c1904c:	call   QWORD PTR [rip+0x234846]        # e4d898 <_DYNAMIC+0x250>
  c19052:	jmp    c18298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8978>
  c19057:	mov    rax,QWORD PTR [rsp+0x88]
  c1905f:	dec    QWORD PTR [rax]
  c19062:	jne    c1846e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b4e>
  c19068:	lea    rdi,[rsp+0x88]
  c19070:	call   QWORD PTR [rip+0x23482a]        # e4d8a0 <_DYNAMIC+0x258>
  c19076:	jmp    c1846e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b4e>
  c1907b:	mov    rax,QWORD PTR [rsp+0x88]
  c19083:	dec    QWORD PTR [rax]
  c19086:	jne    c18348 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a28>
  c1908c:	lea    rdi,[rsp+0x88]
  c19094:	call   QWORD PTR [rip+0x234806]        # e4d8a0 <_DYNAMIC+0x258>
  c1909a:	jmp    c18348 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a28>
  c1909f:	mov    rax,QWORD PTR [rsp+0x88]
  c190a7:	dec    QWORD PTR [rax]
  c190aa:	jne    c183f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ad3>
  c190b0:	lea    rdi,[rsp+0x88]
  c190b8:	call   QWORD PTR [rip+0x2347e2]        # e4d8a0 <_DYNAMIC+0x258>
  c190be:	jmp    c183f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ad3>
  c190c3:	mov    rax,QWORD PTR [rsp+0x88]
  c190cb:	dec    QWORD PTR [rax]
  c190ce:	jne    c18298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8978>
  c190d4:	lea    rdi,[rsp+0x88]
  c190dc:	call   QWORD PTR [rip+0x2347be]        # e4d8a0 <_DYNAMIC+0x258>
  c190e2:	jmp    c18298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8978>
  c190e7:	call   QWORD PTR [rip+0x23485b]        # e4d948 <_DYNAMIC+0x300>
  c190ed:	mov    edi,0x45
  c190f2:	mov    esi,0x1
  c190f7:	call   QWORD PTR [rip+0x234853]        # e4d950 <_DYNAMIC+0x308>
  c190fd:	test   rax,rax
  c19100:	je     c19fe0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6c0>
  c19106:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6ad7ea]        # 2c68f7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x574>
  c1910d:	movups XMMWORD PTR [rax+0x30],xmm0
  c19111:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6ad7cf]        # 2c68e7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x564>
  c19118:	movups XMMWORD PTR [rax+0x20],xmm0
  c1911c:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6ad7b4]        # 2c68d7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x554>
  c19123:	movups XMMWORD PTR [rax+0x10],xmm0
  c19127:	movdqu xmm0,XMMWORD PTR [rip+0xffffffffff6ad798]        # 2c68c7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x544>
  c1912f:	movdqu XMMWORD PTR [rax],xmm0
  c19133:	movabs rcx,0x83d1bad081d183d1
  c1913d:	mov    QWORD PTR [rax+0x3d],rcx
  c19141:	mov    BYTE PTR [rbx],0x1e
  c19144:	mov    QWORD PTR [rbx+0x8],0x45
  c1914c:	mov    QWORD PTR [rbx+0x10],rax
  c19150:	mov    QWORD PTR [rbx+0x18],0x45
  c19158:	jmp    c19887 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f67>
  c1915d:	add    rax,QWORD PTR [rcx+0x60]
  c19161:	mov    r13,QWORD PTR [rsp+0xf8]
  c19169:	mov    rsi,QWORD PTR [rsp+0x38]
  c1916e:	mov    rcx,QWORD PTR [rsi+0x8]
  c19172:	mov    rdx,QWORD PTR [rsp+0x110]
  c1917a:	mov    QWORD PTR [rsp+0x90],rdx
  c19182:	movdqu xmm0,XMMWORD PTR [rsp+0x100]
  c1918b:	movdqa XMMWORD PTR [rsp+0x80],xmm0
  c19194:	cmp    rax,QWORD PTR [rsi+0x10]
  c19198:	jae    c1920d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x98ed>
  c1919a:	lea    rax,[rax+rax*2]
  c1919e:	lea    r15,[rcx+rax*8]
  c191a2:	mov    rax,QWORD PTR [rsp+0x110]
  c191aa:	mov    QWORD PTR [rsp+0x130],rax
  c191b2:	movups xmm0,XMMWORD PTR [rsp+0x100]
  c191ba:	movaps XMMWORD PTR [rsp+0x120],xmm0
  c191c2:	mov    rdi,r15
  c191c5:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c191ca:	mov    rax,QWORD PTR [rsp+0x130]
  c191d2:	mov    QWORD PTR [r15+0x10],rax
  c191d6:	movdqa xmm0,XMMWORD PTR [rsp+0x120]
  c191df:	movdqu XMMWORD PTR [r15],xmm0
  c191e4:	mov    rsi,QWORD PTR [r13+0x0]
  c191e8:	cmp    r14,rsi
  c191eb:	jae    c19ff2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6d2>
  c191f1:	mov    rax,QWORD PTR [rsp+0x10]
  c191f6:	mov    rax,QWORD PTR [rax]
  c191f9:	inc    QWORD PTR [rax+rbp*1+0x58]
  c191fe:	mov    DWORD PTR [rbx+0x8],0xd
  c19205:	mov    BYTE PTR [rbx],0xff
  c19208:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c1920d:	lea    rdi,[rsp+0x80]
  c19215:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1921a:	mov    BYTE PTR [rbx],0x1f
  c1921d:	lea    rax,[rip+0xffffffffff6ad6e8]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c19224:	jmp    c18d84 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9464>
  c19229:	mov    rcx,QWORD PTR [rsp+0x18]
  c1922e:	mov    BYTE PTR [rcx],0x1f
  c19231:	lea    rax,[rip+0xffffffffff6ad5cc]        # 2c6804 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x481>
  c19238:	mov    QWORD PTR [rcx+0x8],rax
  c1923c:	mov    QWORD PTR [rcx+0x10],0x44
  c19244:	jmp    c1959b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c7b>
  c19249:	mov    rcx,QWORD PTR [rsp+0x18]
  c1924e:	mov    BYTE PTR [rcx],0x1f
  c19251:	lea    rax,[rip+0xffffffffff6acec0]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c19258:	mov    QWORD PTR [rcx+0x8],rax
  c1925c:	mov    QWORD PTR [rcx+0x10],0x4f
  c19264:	mov    rax,QWORD PTR [rsp+0x30]
  c19269:	mov    QWORD PTR [rcx+0x18],rax
  c1926d:	jmp    c1959b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c7b>
  c19272:	mov    rcx,QWORD PTR [rsp+0x18]
  c19277:	mov    BYTE PTR [rcx],0x1f
  c1927a:	lea    rax,[rip+0xffffffffff6ace97]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c19281:	mov    QWORD PTR [rcx+0x8],rax
  c19285:	mov    QWORD PTR [rcx+0x10],0x4f
  c1928d:	mov    rax,QWORD PTR [rsp+0x20]
  c19292:	mov    QWORD PTR [rcx+0x18],rax
  c19296:	jmp    c1959b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c7b>
  c1929b:	mov    rcx,QWORD PTR [rsp+0x18]
  c192a0:	mov    BYTE PTR [rcx],0x1f
  c192a3:	lea    rax,[rip+0xffffffffff6ace6e]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c192aa:	mov    QWORD PTR [rcx+0x8],rax
  c192ae:	mov    QWORD PTR [rcx+0x10],0x4f
  c192b6:	mov    rax,QWORD PTR [rsp+0x1e8]
  c192be:	mov    QWORD PTR [rcx+0x18],rax
  c192c2:	jmp    c1959b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c7b>
  c192c7:	mov    eax,0xc
  c192cc:	mov    DWORD PTR [rbx+0x8],eax
  c192cf:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c192d8:	movdqu XMMWORD PTR [rbx+0xc],xmm0
  c192dd:	mov    eax,DWORD PTR [rsp+0x90]
  c192e4:	jmp    c173e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ac6>
  c192e9:	dec    QWORD PTR [rdi]
  c192ec:	jne    c179f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80d2>
  c192f2:	lea    rdi,[rsp+0x128]
  c192fa:	call   QWORD PTR [rip+0x234598]        # e4d898 <_DYNAMIC+0x250>
  c19300:	jmp    c179f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80d2>
  c19305:	dec    QWORD PTR [rdi]
  c19308:	mov    rbx,QWORD PTR [rsp+0x18]
  c1930d:	jne    c179f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80d2>
  c19313:	lea    rdi,[rsp+0x128]
  c1931b:	call   QWORD PTR [rip+0x23457f]        # e4d8a0 <_DYNAMIC+0x258>
  c19321:	jmp    c179f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80d2>
  c19326:	mov    rbx,QWORD PTR [rsp+0x128]
  c1932e:	mov    eax,DWORD PTR [rsp+0x130]
  c19335:	mov    ecx,DWORD PTR [rsp+0x144]
  c1933c:	movdqu xmm0,XMMWORD PTR [rsp+0x134]
  c19345:	movdqa XMMWORD PTR [rsp+0x5a0],xmm0
  c1934e:	mov    DWORD PTR [rsp+0x5b0],ecx
  c19355:	mov    r12d,0x1
  c1935b:	mov    DWORD PTR [rsp+0x80],eax
  c19362:	mov    eax,DWORD PTR [rsp+0x5b0]
  c19369:	mov    DWORD PTR [rsp+0x94],eax
  c19370:	movdqa xmm0,XMMWORD PTR [rsp+0x5a0]
  c19379:	movdqu XMMWORD PTR [rsp+0x84],xmm0
  c19382:	mov    rax,QWORD PTR [rsp+0xf8]
  c1938a:	mov    rsi,QWORD PTR [rax]
  c1938d:	cmp    QWORD PTR [rsp+0x8],rsi
  c19392:	jae    c19f93 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa673>
  c19398:	mov    rsi,QWORD PTR [r15]
  c1939b:	mov    rdi,QWORD PTR [rsp+0x28]
  c193a0:	lea    rdx,[rsi+rdi*1]
  c193a4:	movzx  ecx,r14b
  c193a8:	mov    rax,rcx
  c193ab:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c193b0:	jae    c193bf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9a9f>
  c193b2:	mov    rax,QWORD PTR [rdx+0x28]
  c193b6:	shl    ecx,0x4
  c193b9:	mov    rax,QWORD PTR [rax+rcx*1]
  c193bd:	jmp    c193c3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9aa3>
  c193bf:	add    rax,QWORD PTR [rdx+0x60]
  c193c3:	mov    r14,QWORD PTR [rsp+0x8]
  c193c8:	mov    rcx,QWORD PTR [rbp+0x8]
  c193cc:	mov    rdx,QWORD PTR [rsp+0x90]
  c193d4:	mov    QWORD PTR [rsp+0x130],rdx
  c193dc:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c193e5:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c193ee:	cmp    rax,QWORD PTR [rbp+0x10]
  c193f2:	jae    c19576 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c56>
  c193f8:	lea    rax,[rax+rax*2]
  c193fc:	lea    r15,[rcx+rax*8]
  c19400:	mov    rdi,r15
  c19403:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c19408:	mov    rax,QWORD PTR [rsp+0x90]
  c19410:	mov    QWORD PTR [r15+0x10],rax
  c19414:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c1941d:	movdqu XMMWORD PTR [r15],xmm0
  c19422:	mov    rax,QWORD PTR [rsp+0xf8]
  c1942a:	mov    rsi,QWORD PTR [rax]
  c1942d:	cmp    r14,rsi
  c19430:	jae    c19fbc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa69c>
  c19436:	mov    rax,QWORD PTR [rsp+0x10]
  c1943b:	mov    rax,QWORD PTR [rax]
  c1943e:	mov    rcx,QWORD PTR [rsp+0x28]
  c19443:	inc    QWORD PTR [rax+rcx*1+0x58]
  c19448:	call   c24fa0 <_RNvNtCscdodAO9FK5_5alloc5boxed14box_new_uninit>
  c1944d:	mov    r15,rax
  c19450:	mov    rax,QWORD PTR [rsp+0xf8]
  c19458:	mov    rsi,QWORD PTR [rax]
  c1945b:	cmp    r14,rsi
  c1945e:	jae    c19fce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6ae>
  c19464:	mov    rax,QWORD PTR [rsp+0x10]
  c19469:	mov    rax,QWORD PTR [rax]
  c1946c:	mov    rcx,QWORD PTR [rsp+0x28]
  c19471:	mov    eax,DWORD PTR [rax+rcx*1+0x70]
  c19475:	mov    rcx,QWORD PTR [rsp+0x1f8]
  c1947d:	movzx  ecx,BYTE PTR [rcx+0xc3]
  c19484:	mov    QWORD PTR [r15],0x0
  c1948b:	movups xmm0,XMMWORD PTR [rsp+0x40]
  c19490:	movups XMMWORD PTR [r15+0x20],xmm0
  c19495:	mov    rdx,QWORD PTR [rsp+0x50]
  c1949a:	mov    QWORD PTR [r15+0x30],rdx
  c1949e:	mov    QWORD PTR [r15+0x38],0x0
  c194a6:	mov    QWORD PTR [r15+0x40],0x8
  c194ae:	mov    QWORD PTR [r15+0x48],0x0
  c194b6:	mov    rdx,QWORD PTR [rsp+0x4c0]
  c194be:	mov    QWORD PTR [r15+0x50],rdx
  c194c2:	mov    QWORD PTR [r15+0x58],0x0
  c194ca:	mov    QWORD PTR [r15+0x60],rcx
  c194ce:	mov    QWORD PTR [r15+0x68],0x0
  c194d6:	mov    DWORD PTR [r15+0x70],eax
  c194da:	mov    BYTE PTR [r15+0x74],0x0
  c194df:	mov    rax,QWORD PTR [rsp+0xe0]
  c194e7:	mov    QWORD PTR [rsp+0x158],rax
  c194ef:	movdqu xmm0,XMMWORD PTR [rsp+0xd0]
  c194f8:	movdqu XMMWORD PTR [rsp+0x148],xmm0
  c19501:	mov    rdi,QWORD PTR [rsp+0x650]
  c19509:	mov    rax,QWORD PTR [rdi+0xb0]
  c19510:	mov    QWORD PTR [rsp+0x130],0x1
  c1951c:	mov    QWORD PTR [rsp+0x138],r15
  c19524:	mov    QWORD PTR [rsp+0x140],0x1
  c19530:	mov    DWORD PTR [rsp+0x160],0xffffffff
  c1953b:	mov    QWORD PTR [rsp+0x120],r12
  c19543:	mov    QWORD PTR [rsp+0x128],rbx
  c1954b:	mov    QWORD PTR [rsp+0x178],rax
  c19553:	lea    rsi,[rsp+0x120]
  c1955b:	call   c49220 <_RNvMs0_NtCsbxgXiyEKxkX_6bsl_vm9schedulerNtB5_10AsyncState11insert_task>
  c19560:	mov    DWORD PTR [r13+0x8],0xe
  c19568:	mov    QWORD PTR [r13+0x10],rax
  c1956c:	mov    BYTE PTR [r13+0x0],0xff
  c19571:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c19576:	lea    rdi,[rsp+0x120]
  c1957e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c19583:	mov    BYTE PTR [r13+0x0],0x1f
  c19588:	lea    rax,[rip+0xffffffffff6ad37d]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c1958f:	mov    QWORD PTR [r13+0x8],rax
  c19593:	mov    QWORD PTR [r13+0x10],0x4f
  c1959b:	mov    rsi,QWORD PTR [rsp+0x40]
  c195a0:	test   rsi,rsi
  c195a3:	je     c195b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9c99>
  c195a5:	mov    rdi,QWORD PTR [rsp+0x48]
  c195aa:	shl    rsi,0x4
  c195ae:	mov    edx,0x8
  c195b3:	call   QWORD PTR [rip+0x2342cf]        # e4d888 <_DYNAMIC+0x240>
  c195b9:	lea    rdi,[rsp+0xd0]
  c195c1:	call   c0a040 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueEECsbxgXiyEKxkX_6bsl_vm>
  c195c6:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c195cb:	lea    rax,[rip+0xffffffffff6ad2b5]        # 2c6887 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x504>
  c195d2:	mov    QWORD PTR [rsp+0x128],rax
  c195da:	mov    QWORD PTR [rsp+0x130],0x40
  c195e6:	movdqu xmm0,XMMWORD PTR [rsp+0x140]
  c195ef:	movdqu XMMWORD PTR [rbx+0x20],xmm0
  c195f4:	mov    rcx,QWORD PTR [rsp+0x130]
  c195fc:	mov    QWORD PTR [rbx+0x10],rcx
  c19600:	mov    rcx,QWORD PTR [rsp+0x138]
  c19608:	mov    QWORD PTR [rbx+0x18],rcx
  c1960c:	mov    BYTE PTR [rbx],0x1f
  c1960f:	mov    QWORD PTR [rbx+0x8],rax
  c19613:	jmp    c19887 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f67>
  c19618:	cmp    al,0xff
  c1961a:	je     c19743 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e23>
  c19620:	lea    rdi,[rsp+0x120]
  c19628:	mov    rsi,rbx
  c1962b:	call   c25100 <_RNvXs8_NtCs54fMbAdz0qV_6bsl_rt5errorNtB5_7RtErrorNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c19630:	mov    rcx,QWORD PTR [rsp+0x18]
  c19635:	movzx  eax,BYTE PTR [rsp+0x120]
  c1963d:	movups xmm0,XMMWORD PTR [rsp+0x121]
  c19645:	movaps XMMWORD PTR [rsp+0x80],xmm0
  c1964d:	movups xmm0,XMMWORD PTR [rsp+0x130]
  c19655:	movups XMMWORD PTR [rsp+0x8f],xmm0
  c1965d:	movups xmm0,XMMWORD PTR [rsp+0x140]
  c19665:	movups XMMWORD PTR [rcx+0x20],xmm0
  c19669:	movaps xmm0,XMMWORD PTR [rsp+0x80]
  c19671:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c19676:	movups xmm0,XMMWORD PTR [rsp+0x8f]
  c1967e:	movups XMMWORD PTR [rsp+0x4f],xmm0
  c19683:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c19688:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1968c:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c19692:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c19697:	mov    BYTE PTR [rcx],al
  c19699:	jmp    c19887 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f67>
  c1969e:	mov    rax,QWORD PTR [rsp+0xf8]
  c196a6:	mov    rsi,QWORD PTR [rax]
  c196a9:	cmp    r14,rsi
  c196ac:	jae    c1a002 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6e2>
  c196b2:	mov    rax,QWORD PTR [rsp+0x10]
  c196b7:	mov    rax,QWORD PTR [rax]
  c196ba:	mov    rcx,QWORD PTR [rsp+0x38]
  c196bf:	mov    rsi,QWORD PTR [rcx+0x8]
  c196c3:	mov    rdx,QWORD PTR [rcx+0x10]
  c196c7:	mov    rcx,QWORD PTR [rsp+0x28]
  c196cc:	lea    rax,[rax+rcx*1+0x58]
  c196d1:	lea    rdi,[rsp+0x120]
  c196d9:	mov    rcx,r15
  c196dc:	mov    r8,r12
  c196df:	push   rbx
  c196e0:	push   rax
  c196e1:	call   c0f560 <_RNvCsbxgXiyEKxkX_6bsl_vm24numeric_for_i64_overflow>
  c196e6:	add    rsp,0x10
  c196ea:	cmp    BYTE PTR [rsp+0x120],0xff
  c196f2:	je     c19722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e02>
  c196f4:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c196fd:	movdqu xmm1,XMMWORD PTR [rsp+0x130]
  c19706:	movups xmm2,XMMWORD PTR [rsp+0x140]
  c1970e:	mov    rax,QWORD PTR [rsp+0x18]
  c19713:	movups XMMWORD PTR [rax+0x20],xmm2
  c19717:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c1971c:	movdqu XMMWORD PTR [rax],xmm0
  c19720:	jmp    c19731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e11>
  c19722:	mov    rax,QWORD PTR [rsp+0x18]
  c19727:	mov    DWORD PTR [rax+0x8],0xc
  c1972e:	mov    BYTE PTR [rax],0xff
  c19731:	add    rsp,0x5e8
  c19738:	pop    rbx
  c19739:	pop    r12
  c1973b:	pop    r13
  c1973d:	pop    r14
  c1973f:	pop    r15
  c19741:	pop    rbp
  c19742:	ret
  c19743:	add    rbx,0x8
  c19747:	lea    rdi,[rsp+0x120]
  c1974f:	mov    rsi,rbx
  c19752:	call   c25060 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c19757:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c19760:	movdqu XMMWORD PTR [rsp+0x87],xmm0
  c19769:	mov    rax,QWORD PTR [rsp+0x130]
  c19771:	movdqu XMMWORD PTR [rsp+0x47],xmm0
  c19777:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c19780:	mov    QWORD PTR [rsp+0xe0],rax
  c19788:	mov    rax,QWORD PTR [rsp+0xf8]
  c19790:	mov    rsi,QWORD PTR [rax]
  c19793:	cmp    QWORD PTR [rsp+0x8],rsi
  c19798:	jae    c1a014 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6f4>
  c1979e:	mov    rax,QWORD PTR [rsp+0x10]
  c197a3:	mov    rdx,QWORD PTR [rax]
  c197a6:	mov    rsi,QWORD PTR [rsp+0x28]
  c197ab:	lea    rcx,[rdx+rsi*1]
  c197af:	mov    rax,r12
  c197b2:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c197b7:	jae    c197c7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ea7>
  c197b9:	mov    rax,QWORD PTR [rcx+0x28]
  c197bd:	shl    r12d,0x4
  c197c1:	mov    rax,QWORD PTR [rax+r12*1]
  c197c5:	jmp    c197cb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9eab>
  c197c7:	add    rax,QWORD PTR [rcx+0x60]
  c197cb:	mov    rsi,QWORD PTR [rsp+0x38]
  c197d0:	mov    rcx,QWORD PTR [rsi+0x8]
  c197d4:	mov    rdx,QWORD PTR [rsp+0xe0]
  c197dc:	mov    QWORD PTR [rsp+0x130],rdx
  c197e4:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c197ed:	movdqa XMMWORD PTR [rsp+0x120],xmm0
  c197f6:	cmp    rax,QWORD PTR [rsi+0x10]
  c197fa:	jae    c1985f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f3f>
  c197fc:	lea    rax,[rax+rax*2]
  c19800:	lea    r15,[rcx+rax*8]
  c19804:	mov    rdi,r15
  c19807:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1980c:	mov    rax,QWORD PTR [rsp+0xe0]
  c19814:	mov    QWORD PTR [r15+0x10],rax
  c19818:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c19821:	movdqu XMMWORD PTR [r15],xmm0
  c19826:	mov    rax,QWORD PTR [rsp+0xf8]
  c1982e:	mov    rsi,QWORD PTR [rax]
  c19831:	cmp    QWORD PTR [rsp+0x8],rsi
  c19836:	jae    c1a028 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa708>
  c1983c:	mov    rax,QWORD PTR [rsp+0x10]
  c19841:	mov    rax,QWORD PTR [rax]
  c19844:	mov    rcx,QWORD PTR [rsp+0x28]
  c19849:	inc    QWORD PTR [rax+rcx*1+0x58]
  c1984e:	mov    rax,QWORD PTR [rsp+0x18]
  c19853:	mov    DWORD PTR [rax+0x8],0xd
  c1985a:	mov    BYTE PTR [rax],0xff
  c1985d:	jmp    c19887 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f67>
  c1985f:	lea    rdi,[rsp+0x120]
  c19867:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1986c:	mov    rcx,QWORD PTR [rsp+0x18]
  c19871:	mov    BYTE PTR [rcx],0x1f
  c19874:	lea    rax,[rip+0xffffffffff6ad091]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.2691469935230288402+0x589>
  c1987b:	mov    QWORD PTR [rcx+0x8],rax
  c1987f:	mov    QWORD PTR [rcx+0x10],0x4f
  c19887:	jmp    c186f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dd8>
  c1988c:	lea    rcx,[rip+0x21d2dd]        # e36b70 <anon.c2b893ca1edaacc1e9ca389f72ce6453.253.llvm.2691469935230288402>
  c19893:	mov    edx,0x3
  c19898:	xor    edi,edi
  c1989a:	mov    rsi,r8
  c1989d:	call   QWORD PTR [rip+0x234105]        # e4d9a8 <_DYNAMIC+0x360>
  c198a3:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c198a8:	lea    rdx,[rip+0x21c281]        # e35b30 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x90>
  c198af:	mov    rdi,r15
  c198b2:	mov    rsi,QWORD PTR [rsp+0x1f0]
  c198ba:	call   QWORD PTR [rip+0x2340a0]        # e4d960 <_DYNAMIC+0x318>
  c198c0:	lea    rdx,[rip+0x21cbe9]        # e364b0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0xa10>
  c198c7:	mov    rdi,r14
  c198ca:	call   QWORD PTR [rip+0x234090]        # e4d960 <_DYNAMIC+0x318>
  c198d0:	lea    rdx,[rip+0x21c241]        # e35b18 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x78>
  c198d7:	mov    rdi,r11
  c198da:	xor    esi,esi
  c198dc:	call   QWORD PTR [rip+0x23407e]        # e4d960 <_DYNAMIC+0x318>
  c198e2:	mov    rsi,QWORD PTR [rsp+0x130]
  c198ea:	call   QWORD PTR [rip+0x234040]        # e4d930 <_DYNAMIC+0x2e8>
  c198f0:	mov    rsi,QWORD PTR [rsp+0x130]
  c198f8:	call   QWORD PTR [rip+0x234032]        # e4d930 <_DYNAMIC+0x2e8>
  c198fe:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19903:	lea    rdx,[rip+0x21c7de]        # e360e8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x648>
  c1990a:	jmp    c19925 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa005>
  c1990c:	lea    rdx,[rip+0x21c7ed]        # e36100 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x660>
  c19913:	jmp    c19925 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa005>
  c19915:	lea    rdx,[rip+0x21c814]        # e36130 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x690>
  c1991c:	jmp    c19925 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa005>
  c1991e:	lea    rdx,[rip+0x21c7f3]        # e36118 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x678>
  c19925:	mov    rdi,QWORD PTR [rsp+0x8]
  c1992a:	mov    rsi,rbp
  c1992d:	call   QWORD PTR [rip+0x23402d]        # e4d960 <_DYNAMIC+0x318>
  c19933:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19938:	lea    rdx,[rip+0x21c971]        # e362b0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x810>
  c1993f:	mov    rdi,QWORD PTR [rsp+0x8]
  c19944:	call   QWORD PTR [rip+0x234016]        # e4d960 <_DYNAMIC+0x318>
  c1994a:	lea    rdx,[rip+0x21c56f]        # e35ec0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x420>
  c19951:	mov    rdi,QWORD PTR [rsp+0x8]
  c19956:	call   QWORD PTR [rip+0x234004]        # e4d960 <_DYNAMIC+0x318>
  c1995c:	lea    rdx,[rip+0x21cb7d]        # e364e0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0xa40>
  c19963:	mov    rdi,QWORD PTR [rsp+0x8]
  c19968:	call   QWORD PTR [rip+0x233ff2]        # e4d960 <_DYNAMIC+0x318>
  c1996e:	lea    rdx,[rip+0x21c06b]        # e359e0 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c19975:	mov    rdi,QWORD PTR [rsp+0x8]
  c1997a:	call   QWORD PTR [rip+0x233fe0]        # e4d960 <_DYNAMIC+0x318>
  c19980:	lea    rdx,[rip+0x21c059]        # e359e0 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c19987:	mov    rdi,QWORD PTR [rsp+0x8]
  c1998c:	call   QWORD PTR [rip+0x233fce]        # e4d960 <_DYNAMIC+0x318>
  c19992:	lea    rdx,[rip+0x21ca97]        # e36430 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x990>
  c19999:	mov    rdi,QWORD PTR [rsp+0x8]
  c1999e:	call   QWORD PTR [rip+0x233fbc]        # e4d960 <_DYNAMIC+0x318>
  c199a4:	lea    rdx,[rip+0x21c3ad]        # e35d58 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x2b8>
  c199ab:	mov    rdi,QWORD PTR [rsp+0x8]
  c199b0:	call   QWORD PTR [rip+0x233faa]        # e4d960 <_DYNAMIC+0x318>
  c199b6:	lea    rdx,[rip+0x21c953]        # e36310 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x870>
  c199bd:	mov    rdi,QWORD PTR [rsp+0x8]
  c199c2:	call   QWORD PTR [rip+0x233f98]        # e4d960 <_DYNAMIC+0x318>
  c199c8:	lea    rdx,[rip+0x21c9d1]        # e363a0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x900>
  c199cf:	mov    rdi,QWORD PTR [rsp+0x8]
  c199d4:	call   QWORD PTR [rip+0x233f86]        # e4d960 <_DYNAMIC+0x318>
  c199da:	lea    rdx,[rip+0x21c3bf]        # e35da0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x300>
  c199e1:	mov    rdi,QWORD PTR [rsp+0x8]
  c199e6:	call   QWORD PTR [rip+0x233f74]        # e4d960 <_DYNAMIC+0x318>
  c199ec:	lea    rdx,[rip+0x21c25d]        # e35c50 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x1b0>
  c199f3:	call   QWORD PTR [rip+0x233f67]        # e4d960 <_DYNAMIC+0x318>
  c199f9:	lea    rdx,[rip+0x21c5b0]        # e35fb0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x510>
  c19a00:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a05:	call   QWORD PTR [rip+0x233f55]        # e4d960 <_DYNAMIC+0x318>
  c19a0b:	lea    rdx,[rip+0x21c5e6]        # e35ff8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x558>
  c19a12:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a17:	call   QWORD PTR [rip+0x233f43]        # e4d960 <_DYNAMIC+0x318>
  c19a1d:	lea    rdx,[rip+0x21c604]        # e36028 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x588>
  c19a24:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a29:	call   QWORD PTR [rip+0x233f31]        # e4d960 <_DYNAMIC+0x318>
  c19a2f:	lea    rdx,[rip+0x21c9b2]        # e363e8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x948>
  c19a36:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a3b:	call   QWORD PTR [rip+0x233f1f]        # e4d960 <_DYNAMIC+0x318>
  c19a41:	lea    rdx,[rip+0x21c4d8]        # e35f20 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x480>
  c19a48:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a4d:	call   QWORD PTR [rip+0x233f0d]        # e4d960 <_DYNAMIC+0x318>
  c19a53:	lea    rdx,[rip+0x21c3a6]        # e35e00 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x360>
  c19a5a:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a5f:	call   QWORD PTR [rip+0x233efb]        # e4d960 <_DYNAMIC+0x318>
  c19a65:	lea    rdx,[rip+0x21bf74]        # e359e0 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c19a6c:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a71:	call   QWORD PTR [rip+0x233ee9]        # e4d960 <_DYNAMIC+0x318>
  c19a77:	lea    rdx,[rip+0x21c7d2]        # e36250 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x7b0>
  c19a7e:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a83:	call   QWORD PTR [rip+0x233ed7]        # e4d960 <_DYNAMIC+0x318>
  c19a89:	lea    rdx,[rip+0x21c280]        # e35d10 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x270>
  c19a90:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a95:	call   QWORD PTR [rip+0x233ec5]        # e4d960 <_DYNAMIC+0x318>
  c19a9b:	lea    rdx,[rip+0x21c436]        # e35ed8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x438>
  c19aa2:	mov    rdi,QWORD PTR [rsp+0x8]
  c19aa7:	call   QWORD PTR [rip+0x233eb3]        # e4d960 <_DYNAMIC+0x318>
  c19aad:	lea    rdx,[rip+0x21c4b4]        # e35f68 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x4c8>
  c19ab4:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ab9:	call   QWORD PTR [rip+0x233ea1]        # e4d960 <_DYNAMIC+0x318>
  c19abf:	lea    rdx,[rip+0x21bf1a]        # e359e0 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c19ac6:	mov    rdi,QWORD PTR [rsp+0x8]
  c19acb:	call   QWORD PTR [rip+0x233e8f]        # e4d960 <_DYNAMIC+0x318>
  c19ad1:	lea    rdx,[rip+0x21c148]        # e35c20 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x180>
  c19ad8:	call   QWORD PTR [rip+0x233e82]        # e4d960 <_DYNAMIC+0x318>
  c19ade:	lea    rdx,[rip+0x21c873]        # e36358 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x8b8>
  c19ae5:	mov    rdi,QWORD PTR [rsp+0x8]
  c19aea:	call   QWORD PTR [rip+0x233e70]        # e4d960 <_DYNAMIC+0x318>
  c19af0:	lea    rdx,[rip+0x21c0f9]        # e35bf0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x150>
  c19af7:	mov    rdi,QWORD PTR [rsp+0x8]
  c19afc:	call   QWORD PTR [rip+0x233e5e]        # e4d960 <_DYNAMIC+0x318>
  c19b02:	lea    rdx,[rip+0x21c507]        # e36010 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x570>
  c19b09:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b0e:	call   QWORD PTR [rip+0x233e4c]        # e4d960 <_DYNAMIC+0x318>
  c19b14:	lea    rdx,[rip+0x21c075]        # e35b90 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0xf0>
  c19b1b:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b20:	call   QWORD PTR [rip+0x233e3a]        # e4d960 <_DYNAMIC+0x318>
  c19b26:	lea    rdx,[rip+0x21c153]        # e35c80 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x1e0>
  c19b2d:	mov    rdi,r14
  c19b30:	call   QWORD PTR [rip+0x233e2a]        # e4d960 <_DYNAMIC+0x318>
  c19b36:	lea    rdx,[rip+0x21c0cb]        # e35c08 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x168>
  c19b3d:	mov    rdi,r14
  c19b40:	call   QWORD PTR [rip+0x233e1a]        # e4d960 <_DYNAMIC+0x318>
  c19b46:	lea    rdx,[rip+0x21c17b]        # e35cc8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x228>
  c19b4d:	mov    rdi,r14
  c19b50:	call   QWORD PTR [rip+0x233e0a]        # e4d960 <_DYNAMIC+0x318>
  c19b56:	lea    rdx,[rip+0x21c0db]        # e35c38 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x198>
  c19b5d:	mov    rdi,r14
  c19b60:	call   QWORD PTR [rip+0x233dfa]        # e4d960 <_DYNAMIC+0x318>
  c19b66:	lea    rdx,[rip+0x21c75b]        # e362c8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x828>
  c19b6d:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b72:	call   QWORD PTR [rip+0x233de8]        # e4d960 <_DYNAMIC+0x318>
  c19b78:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19b7d:	lea    rdx,[rip+0x21c7ec]        # e36370 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x8d0>
  c19b84:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b89:	call   QWORD PTR [rip+0x233dd1]        # e4d960 <_DYNAMIC+0x318>
  c19b8f:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19b94:	lea    rdx,[rip+0x21c21d]        # e35db8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x318>
  c19b9b:	call   QWORD PTR [rip+0x233dbf]        # e4d960 <_DYNAMIC+0x318>
  c19ba1:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19ba6:	lea    rdx,[rip+0x21c89b]        # e36448 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x9a8>
  c19bad:	mov    rdi,r14
  c19bb0:	call   QWORD PTR [rip+0x233daa]        # e4d960 <_DYNAMIC+0x318>
  c19bb6:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19bbb:	lea    rdx,[rip+0x21c0d6]        # e35c98 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x1f8>
  c19bc2:	mov    rdi,r14
  c19bc5:	call   QWORD PTR [rip+0x233d95]        # e4d960 <_DYNAMIC+0x318>
  c19bcb:	lea    rdx,[rip+0x21c0de]        # e35cb0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x210>
  c19bd2:	mov    rdi,r14
  c19bd5:	call   QWORD PTR [rip+0x233d85]        # e4d960 <_DYNAMIC+0x318>
  c19bdb:	lea    rdx,[rip+0x21c086]        # e35c68 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x1c8>
  c19be2:	mov    rdi,r14
  c19be5:	call   QWORD PTR [rip+0x233d75]        # e4d960 <_DYNAMIC+0x318>
  c19beb:	lea    rdx,[rip+0x21c0ee]        # e35ce0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x240>
  c19bf2:	mov    rdi,r14
  c19bf5:	call   QWORD PTR [rip+0x233d65]        # e4d960 <_DYNAMIC+0x318>
  c19bfb:	lea    rdx,[rip+0x21c0f6]        # e35cf8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x258>
  c19c02:	mov    rdi,r14
  c19c05:	call   QWORD PTR [rip+0x233d55]        # e4d960 <_DYNAMIC+0x318>
  c19c0b:	lea    rdx,[rip+0x21c206]        # e35e18 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x378>
  c19c12:	call   QWORD PTR [rip+0x233d48]        # e4d960 <_DYNAMIC+0x318>
  c19c18:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19c1d:	lea    rdx,[rip+0x21c644]        # e36268 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x7c8>
  c19c24:	mov    rdi,rbx
  c19c27:	call   QWORD PTR [rip+0x233d33]        # e4d960 <_DYNAMIC+0x318>
  c19c2d:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19c32:	lea    rdx,[rip+0x21bf87]        # e35bc0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x120>
  c19c39:	call   QWORD PTR [rip+0x233d21]        # e4d960 <_DYNAMIC+0x318>
  c19c3f:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19c44:	lea    rdx,[rip+0x21bf8d]        # e35bd8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x138>
  c19c4b:	mov    rdi,r14
  c19c4e:	call   QWORD PTR [rip+0x233d0c]        # e4d960 <_DYNAMIC+0x318>
  c19c54:	lea    rdx,[rip+0x21c75d]        # e363b8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x918>
  c19c5b:	jmp    c19d0e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3ee>
  c19c60:	lea    rdx,[rip+0x21c0c1]        # e35d28 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x288>
  c19c67:	mov    rdi,rbx
  c19c6a:	call   QWORD PTR [rip+0x233cf0]        # e4d960 <_DYNAMIC+0x318>
  c19c70:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19c75:	lea    rdx,[rip+0x21c784]        # e36400 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x960>
  c19c7c:	mov    rdi,r14
  c19c7f:	call   QWORD PTR [rip+0x233cdb]        # e4d960 <_DYNAMIC+0x318>
  c19c85:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19c8a:	lea    rdx,[rip+0x21c64f]        # e362e0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x840>
  c19c91:	jmp    c19e14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4f4>
  c19c96:	lea    rdx,[rip+0x21bec3]        # e35b60 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0xc0>
  c19c9d:	call   QWORD PTR [rip+0x233cbd]        # e4d960 <_DYNAMIC+0x318>
  c19ca3:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19ca8:	lea    rdx,[rip+0x21c0c1]        # e35d70 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x2d0>
  c19caf:	mov    rdi,rbx
  c19cb2:	call   QWORD PTR [rip+0x233ca8]        # e4d960 <_DYNAMIC+0x318>
  c19cb8:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19cbd:	lea    rdx,[rip+0x21be84]        # e35b48 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0xa8>
  c19cc4:	mov    rdi,r14
  c19cc7:	call   QWORD PTR [rip+0x233c93]        # e4d960 <_DYNAMIC+0x318>
  c19ccd:	lea    rdx,[rip+0x21c15c]        # e35e30 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x390>
  c19cd4:	jmp    c19d96 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa476>
  c19cd9:	lea    rdx,[rip+0x21c0f0]        # e35dd0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x330>
  c19ce0:	jmp    c19d4a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa42a>
  c19ce2:	lea    rdx,[rip+0x21c72f]        # e36418 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x978>
  c19ce9:	mov    rdi,r14
  c19cec:	call   QWORD PTR [rip+0x233c6e]        # e4d960 <_DYNAMIC+0x318>
  c19cf2:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19cf7:	lea    rdx,[rip+0x21be7a]        # e35b78 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0xd8>
  c19cfe:	mov    rdi,r14
  c19d01:	call   QWORD PTR [rip+0x233c59]        # e4d960 <_DYNAMIC+0x318>
  c19d07:	lea    rdx,[rip+0x21c6c2]        # e363d0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x930>
  c19d0e:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d13:	call   QWORD PTR [rip+0x233c47]        # e4d960 <_DYNAMIC+0x318>
  c19d19:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19d1e:	lea    rdx,[rip+0x21c55b]        # e36280 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x7e0>
  c19d25:	mov    rdi,rbx
  c19d28:	call   QWORD PTR [rip+0x233c32]        # e4d960 <_DYNAMIC+0x318>
  c19d2e:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19d33:	lea    rdx,[rip+0x21c006]        # e35d40 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x2a0>
  c19d3a:	mov    rdi,r14
  c19d3d:	call   QWORD PTR [rip+0x233c1d]        # e4d960 <_DYNAMIC+0x318>
  c19d43:	lea    rdx,[rip+0x21c09e]        # e35de8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x348>
  c19d4a:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d4f:	call   QWORD PTR [rip+0x233c0b]        # e4d960 <_DYNAMIC+0x318>
  c19d55:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19d5a:	lea    rdx,[rip+0x21c027]        # e35d88 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x2e8>
  c19d61:	mov    rdi,r14
  c19d64:	call   QWORD PTR [rip+0x233bf6]        # e4d960 <_DYNAMIC+0x318>
  c19d6a:	lea    rdx,[rip+0x21c70f]        # e36480 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x9e0>
  c19d71:	mov    rdi,r14
  c19d74:	call   QWORD PTR [rip+0x233be6]        # e4d960 <_DYNAMIC+0x318>
  c19d7a:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19d7f:	lea    rdx,[rip+0x21be22]        # e35ba8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x108>
  c19d86:	mov    rdi,r14
  c19d89:	call   QWORD PTR [rip+0x233bd1]        # e4d960 <_DYNAMIC+0x318>
  c19d8f:	lea    rdx,[rip+0x21c0b2]        # e35e48 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x3a8>
  c19d96:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d9b:	call   QWORD PTR [rip+0x233bbf]        # e4d960 <_DYNAMIC+0x318>
  c19da1:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19da6:	lea    rdx,[rip+0x21c57b]        # e36328 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x888>
  c19dad:	mov    rdi,r14
  c19db0:	call   QWORD PTR [rip+0x233baa]        # e4d960 <_DYNAMIC+0x318>
  c19db6:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19dbb:	lea    rdx,[rip+0x21c2f6]        # e360b8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x618>
  c19dc2:	mov    rdi,QWORD PTR [rsp+0x8]
  c19dc7:	call   QWORD PTR [rip+0x233b93]        # e4d960 <_DYNAMIC+0x318>
  c19dcd:	lea    rdx,[rip+0x21c0d4]        # e35ea8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x408>
  c19dd4:	mov    rdi,r14
  c19dd7:	call   QWORD PTR [rip+0x233b83]        # e4d960 <_DYNAMIC+0x318>
  c19ddd:	lea    rdx,[rip+0x21c07c]        # e35e60 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x3c0>
  c19de4:	mov    rdi,r14
  c19de7:	call   QWORD PTR [rip+0x233b73]        # e4d960 <_DYNAMIC+0x318>
  c19ded:	lea    rdx,[rip+0x21c084]        # e35e78 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x3d8>
  c19df4:	mov    rdi,r14
  c19df7:	call   QWORD PTR [rip+0x233b63]        # e4d960 <_DYNAMIC+0x318>
  c19dfd:	lea    rdx,[rip+0x21c08c]        # e35e90 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x3f0>
  c19e04:	mov    rdi,r14
  c19e07:	call   QWORD PTR [rip+0x233b53]        # e4d960 <_DYNAMIC+0x318>
  c19e0d:	lea    rdx,[rip+0x21c4e4]        # e362f8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x858>
  c19e14:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e19:	call   QWORD PTR [rip+0x233b41]        # e4d960 <_DYNAMIC+0x318>
  c19e1f:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19e24:	lea    rdx,[rip+0x21c46d]        # e36298 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x7f8>
  c19e2b:	mov    rdi,r14
  c19e2e:	call   QWORD PTR [rip+0x233b2c]        # e4d960 <_DYNAMIC+0x318>
  c19e34:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19e39:	lea    rdx,[rip+0x21c658]        # e36498 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x9f8>
  c19e40:	mov    rdi,r14
  c19e43:	call   QWORD PTR [rip+0x233b17]        # e4d960 <_DYNAMIC+0x318>
  c19e49:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19e4e:	lea    rdx,[rip+0x21c4eb]        # e36340 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x8a0>
  c19e55:	mov    rdi,r14
  c19e58:	call   QWORD PTR [rip+0x233b02]        # e4d960 <_DYNAMIC+0x318>
  c19e5e:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19e63:	lea    rdx,[rip+0x21c51e]        # e36388 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x8e8>
  c19e6a:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e6f:	call   QWORD PTR [rip+0x233aeb]        # e4d960 <_DYNAMIC+0x318>
  c19e75:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19e7a:	lea    rdx,[rip+0x21c147]        # e35fc8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x528>
  c19e81:	jmp    c19f31 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa611>
  c19e86:	lea    rdx,[rip+0x21c1b3]        # e36040 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x5a0>
  c19e8d:	mov    rdi,r14
  c19e90:	call   QWORD PTR [rip+0x233aca]        # e4d960 <_DYNAMIC+0x318>
  c19e96:	lea    rdx,[rip+0x21c1eb]        # e36088 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x5e8>
  c19e9d:	mov    rdi,r14
  c19ea0:	call   QWORD PTR [rip+0x233aba]        # e4d960 <_DYNAMIC+0x318>
  c19ea6:	lea    rdx,[rip+0x21c1c3]        # e36070 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x5d0>
  c19ead:	mov    rdi,r14
  c19eb0:	call   QWORD PTR [rip+0x233aaa]        # e4d960 <_DYNAMIC+0x318>
  c19eb6:	lea    rdx,[rip+0x21c093]        # e35f50 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x4b0>
  c19ebd:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ec2:	call   QWORD PTR [rip+0x233a98]        # e4d960 <_DYNAMIC+0x318>
  c19ec8:	lea    rdx,[rip+0x21c039]        # e35f08 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x468>
  c19ecf:	mov    rdi,r14
  c19ed2:	call   QWORD PTR [rip+0x233a88]        # e4d960 <_DYNAMIC+0x318>
  c19ed8:	lea    rdx,[rip+0x21c011]        # e35ef0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x450>
  c19edf:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ee4:	call   QWORD PTR [rip+0x233a76]        # e4d960 <_DYNAMIC+0x318>
  c19eea:	lea    rdx,[rip+0x21c047]        # e35f38 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x498>
  c19ef1:	mov    rdi,r14
  c19ef4:	call   QWORD PTR [rip+0x233a66]        # e4d960 <_DYNAMIC+0x318>
  c19efa:	lea    rdx,[rip+0x21c157]        # e36058 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x5b8>
  c19f01:	mov    rdi,r14
  c19f04:	call   QWORD PTR [rip+0x233a56]        # e4d960 <_DYNAMIC+0x318>
  c19f0a:	lea    rdx,[rip+0x21c06f]        # e35f80 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x4e0>
  c19f11:	jmp    c19f1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5fa>
  c19f13:	lea    rdx,[rip+0x21c07e]        # e35f98 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x4f8>
  c19f1a:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f1f:	call   QWORD PTR [rip+0x233a3b]        # e4d960 <_DYNAMIC+0x318>
  c19f25:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19f2a:	lea    rdx,[rip+0x21c0af]        # e35fe0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x540>
  c19f31:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f36:	call   QWORD PTR [rip+0x233a24]        # e4d960 <_DYNAMIC+0x318>
  c19f3c:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19f41:	lea    rdx,[rip+0x21c188]        # e360d0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x630>
  c19f48:	jmp    c19925 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa005>
  c19f4d:	lea    rax,[rip+0x21c23c]        # e36190 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x6f0>
  c19f54:	mov    QWORD PTR [rsp+0x1c0],rax
  c19f5c:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f61:	mov    rdx,QWORD PTR [rsp+0x1c0]
  c19f69:	call   QWORD PTR [rip+0x2339f1]        # e4d960 <_DYNAMIC+0x318>
  c19f6f:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19f74:	lea    rdx,[rip+0x21c245]        # e361c0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x720>
  c19f7b:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f80:	call   QWORD PTR [rip+0x2339da]        # e4d960 <_DYNAMIC+0x318>
  c19f86:	lea    rdx,[rip+0x21c2ab]        # e36238 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x798>
  c19f8d:	call   QWORD PTR [rip+0x2339cd]        # e4d960 <_DYNAMIC+0x318>
  c19f93:	lea    rdx,[rip+0x21c1ae]        # e36148 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x6a8>
  c19f9a:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f9f:	call   QWORD PTR [rip+0x2339bb]        # e4d960 <_DYNAMIC+0x318>
  c19fa5:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19faa:	lea    rdx,[rip+0x21c257]        # e36208 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x768>
  c19fb1:	mov    rdi,r14
  c19fb4:	call   QWORD PTR [rip+0x2339a6]        # e4d960 <_DYNAMIC+0x318>
  c19fba:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19fbc:	lea    rdx,[rip+0x21c19d]        # e36160 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x6c0>
  c19fc3:	mov    rdi,r14
  c19fc6:	call   QWORD PTR [rip+0x233994]        # e4d960 <_DYNAMIC+0x318>
  c19fcc:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19fce:	lea    rdx,[rip+0x21c1a3]        # e36178 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x6d8>
  c19fd5:	mov    rdi,r14
  c19fd8:	call   QWORD PTR [rip+0x233982]        # e4d960 <_DYNAMIC+0x318>
  c19fde:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19fe0:	mov    edi,0x1
  c19fe5:	mov    esi,0x45
  c19fea:	call   QWORD PTR [rip+0x233940]        # e4d930 <_DYNAMIC+0x2e8>
  c19ff0:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c19ff2:	lea    rdx,[rip+0x21c227]        # e36220 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x780>
  c19ff9:	mov    rdi,r14
  c19ffc:	call   QWORD PTR [rip+0x23395e]        # e4d960 <_DYNAMIC+0x318>
  c1a002:	lea    rdx,[rip+0x21c097]        # e360a0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x600>
  c1a009:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a00e:	call   QWORD PTR [rip+0x23394c]        # e4d960 <_DYNAMIC+0x318>
  c1a014:	lea    rdx,[rip+0x21c1bd]        # e361d8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x738>
  c1a01b:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a020:	call   QWORD PTR [rip+0x23393a]        # e4d960 <_DYNAMIC+0x318>
  c1a026:	jmp    c1a03a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71a>
  c1a028:	lea    rdx,[rip+0x21c1c1]        # e361f0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.2691469935230288402+0x750>
  c1a02f:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a034:	call   QWORD PTR [rip+0x233926]        # e4d960 <_DYNAMIC+0x318>
  c1a03a:	ud2
  c1a03c:	mov    rbx,rax
  c1a03f:	mov    rax,QWORD PTR [rsp+0xe0]
  c1a047:	mov    QWORD PTR [r15+0x10],rax
  c1a04b:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1a054:	movdqu XMMWORD PTR [r15],xmm0
  c1a059:	jmp    c1a113 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa7f3>
  c1a05e:	jmp    c1a110 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa7f0>
  c1a063:	mov    rbx,rax
  c1a066:	lea    rdi,[rsp+0xd0]
  c1a06e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a073:	jmp    c1a113 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa7f3>
  c1a078:	mov    rbx,rax
  c1a07b:	mov    rax,QWORD PTR [rsp+0x130]
  c1a083:	mov    QWORD PTR [r15+0x10],rax
  c1a087:	movaps xmm0,XMMWORD PTR [rsp+0x120]
  c1a08f:	movups XMMWORD PTR [r15],xmm0
  c1a093:	mov    rdi,rbx
  c1a096:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a09b:	mov    rbx,rax
  c1a09e:	mov    esi,0x78
  c1a0a3:	mov    edx,0x8
  c1a0a8:	mov    rdi,r15
  c1a0ab:	call   QWORD PTR [rip+0x2337d7]        # e4d888 <_DYNAMIC+0x240>
  c1a0b1:	jmp    c1a432 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab12>
  c1a0b6:	mov    rbx,rax
  c1a0b9:	mov    rax,QWORD PTR [rsp+0x90]
  c1a0c1:	mov    QWORD PTR [r15+0x10],rax
  c1a0c5:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c1a0ce:	movdqu XMMWORD PTR [r15],xmm0
  c1a0d3:	jmp    c1a432 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab12>
  c1a0d8:	jmp    c1a171 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa851>
  c1a0dd:	jmp    c1a1a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa888>
  c1a0e2:	jmp    c1a1d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa8b2>
  c1a0e7:	jmp    c1a1a0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa880>
  c1a0ec:	jmp    c1a65e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad3e>
  c1a0f1:	mov    rbx,rax
  c1a0f4:	lea    rdi,[rsp+0x80]
  c1a0fc:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a101:	jmp    c1a432 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab12>
  c1a106:	jmp    c1a42f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab0f>
  c1a10b:	jmp    c1a673 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad53>
  c1a110:	mov    rbx,rax
  c1a113:	lea    rdi,[rsp+0x100]
  c1a11b:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a120:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a125:	jmp    c1a3f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaad0>
  c1a12a:	mov    rbx,rax
  c1a12d:	mov    rax,QWORD PTR [rsp+0x50]
  c1a132:	mov    QWORD PTR [r14+0x10],rax
  c1a136:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c1a13c:	movdqu XMMWORD PTR [r14],xmm0
  c1a141:	jmp    c1a596 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac76>
  c1a146:	mov    rbx,rax
  c1a149:	mov    DWORD PTR [r14],0x4
  c1a150:	mov    BYTE PTR [r14+0x4],bpl
  c1a154:	jmp    c1a4be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab9e>
  c1a159:	mov    rbx,rax
  c1a15c:	mov    DWORD PTR [r14],0x4
  c1a163:	mov    BYTE PTR [r14+0x4],bpl
  c1a167:	jmp    c1a537 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac17>
  c1a16c:	jmp    c1a63f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad1f>
  c1a171:	mov    rbx,rax
  c1a174:	jmp    c1a4f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabd0>
  c1a179:	jmp    c1a659 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad39>
  c1a17e:	mov    rbx,rax
  c1a181:	mov    rax,QWORD PTR [rsp+0xe0]
  c1a189:	mov    QWORD PTR [r14+0x10],rax
  c1a18d:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1a196:	movdqu XMMWORD PTR [r14],xmm0
  c1a19b:	jmp    c1a676 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad56>
  c1a1a0:	mov    rbx,rax
  c1a1a3:	jmp    c1a4cb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabab>
  c1a1a8:	mov    rbx,rax
  c1a1ab:	jmp    c1a544 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac24>
  c1a1b0:	mov    rbx,rax
  c1a1b3:	mov    rax,QWORD PTR [rsp+0x110]
  c1a1bb:	mov    QWORD PTR [r14+0x10],rax
  c1a1bf:	movdqa xmm0,XMMWORD PTR [rsp+0x100]
  c1a1c8:	movdqu XMMWORD PTR [r14],xmm0
  c1a1cd:	jmp    c1a79f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae7f>
  c1a1d2:	mov    rbx,rax
  c1a1d5:	jmp    c1a569 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac49>
  c1a1da:	mov    rbx,rax
  c1a1dd:	mov    DWORD PTR [r12],0x4
  c1a1e5:	mov    BYTE PTR [r12+0x4],r14b
  c1a1ea:	jmp    c1a55c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac3c>
  c1a1ef:	mov    rbx,rax
  c1a1f2:	mov    DWORD PTR [r15],0x4
  c1a1f9:	movzx  eax,BYTE PTR [rsp+0x30]
  c1a1fe:	mov    BYTE PTR [r15+0x4],al
  c1a202:	jmp    c1a4e3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabc3>
  c1a207:	jmp    c1a637 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad17>
  c1a20c:	jmp    c1a258 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa938>
  c1a20e:	mov    rbx,rax
  c1a211:	mov    rax,QWORD PTR [rsp+0x130]
  c1a219:	mov    QWORD PTR [r14+0x10],rax
  c1a21d:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c1a226:	movdqu XMMWORD PTR [r14],xmm0
  c1a22b:	jmp    c1a725 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae05>
  c1a230:	mov    rbx,rax
  c1a233:	mov    rax,QWORD PTR [rsp+0x510]
  c1a23b:	mov    QWORD PTR [r14+0x10],rax
  c1a23f:	movups xmm0,XMMWORD PTR [rsp+0x500]
  c1a247:	movups XMMWORD PTR [r14],xmm0
  c1a24b:	mov    rdi,rbx
  c1a24e:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a253:	jmp    c1a62f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad0f>
  c1a258:	mov    rbx,rax
  c1a25b:	mov    rax,QWORD PTR [rsp+0xe0]
  c1a263:	mov    QWORD PTR [r14+0x10],rax
  c1a267:	movaps xmm0,XMMWORD PTR [rsp+0xd0]
  c1a26f:	movups XMMWORD PTR [r14],xmm0
  c1a273:	mov    rdi,rbx
  c1a276:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a27b:	mov    rbx,rax
  c1a27e:	mov    rax,QWORD PTR [rsp+0x90]
  c1a286:	mov    QWORD PTR [r14+0x10],rax
  c1a28a:	movups xmm0,XMMWORD PTR [rsp+0x80]
  c1a292:	movups XMMWORD PTR [r14],xmm0
  c1a296:	mov    rdi,rbx
  c1a299:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a29e:	mov    rbx,rax
  c1a2a1:	mov    rax,QWORD PTR [rsp+0x130]
  c1a2a9:	mov    QWORD PTR [r14+0x10],rax
  c1a2ad:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c1a2b6:	movdqu XMMWORD PTR [r14],xmm0
  c1a2bb:	jmp    c1a706 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xade6>
  c1a2c0:	mov    rbx,rax
  c1a2c3:	mov    rax,QWORD PTR [rsp+0x130]
  c1a2cb:	mov    QWORD PTR [r14+0x10],rax
  c1a2cf:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c1a2d8:	movdqu XMMWORD PTR [r14],xmm0
  c1a2dd:	jmp    c1a6e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xadc7>
  c1a2e2:	mov    rbx,rax
  c1a2e5:	mov    rax,QWORD PTR [rsp+0xe0]
  c1a2ed:	mov    QWORD PTR [r14+0x10],rax
  c1a2f1:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1a2fa:	movdqu XMMWORD PTR [r14],xmm0
  c1a2ff:	jmp    c1a6ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad8b>
  c1a304:	mov    rbx,rax
  c1a307:	mov    rax,QWORD PTR [rsp+0x90]
  c1a30f:	mov    QWORD PTR [r14+0x10],rax
  c1a313:	movaps xmm0,XMMWORD PTR [rsp+0x80]
  c1a31b:	movups XMMWORD PTR [r14],xmm0
  c1a31f:	mov    rdi,rbx
  c1a322:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a327:	jmp    c1a50a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xabea>
  c1a32c:	jmp    c1a337 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa17>
  c1a32e:	jmp    c1a5a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac88>
  c1a333:	jmp    c1a337 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa17>
  c1a335:	jmp    c1a337 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaa17>
  c1a337:	mov    rbx,rax
  c1a33a:	mov    rax,QWORD PTR [rsp+0x130]
  c1a342:	mov    QWORD PTR [r14+0x10],rax
  c1a346:	movups xmm0,XMMWORD PTR [rsp+0x120]
  c1a34e:	movups XMMWORD PTR [r14],xmm0
  c1a352:	mov    rdi,rbx
  c1a355:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a35a:	mov    rbx,rax
  c1a35d:	lea    rdi,[rsp+0x120]
  c1a365:	call   c0a360 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm5FrameEBD_>
  c1a36a:	mov    rdi,rbx
  c1a36d:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a372:	jmp    c1a739 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae19>
  c1a377:	jmp    c1a42f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab0f>
  c1a37c:	mov    rbx,rax
  c1a37f:	mov    DWORD PTR [rbp+0x0],0x2
  c1a386:	jmp    c1a73c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae1c>
  c1a38b:	mov    rbx,rax
  c1a38e:	cmp    BYTE PTR [rsp+0x80],0xff
  c1a396:	je     c1a661 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad41>
  c1a39c:	lea    rdi,[rsp+0x80]
  c1a3a4:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.2691469935230288402>
  c1a3a9:	jmp    c1a661 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad41>
  c1a3ae:	mov    rbx,rax
  c1a3b1:	lea    rdi,[rsp+0x80]
  c1a3b9:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c1a3be:	jmp    c1a676 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad56>
  c1a3c3:	jmp    c1a65e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad3e>
  c1a3c8:	jmp    c1a65e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad3e>
  c1a3cd:	mov    rbx,rax
  c1a3d0:	mov    rax,QWORD PTR [rsp+0x130]
  c1a3d8:	mov    QWORD PTR [r15+0x10],rax
  c1a3dc:	movups xmm0,XMMWORD PTR [rsp+0x120]
  c1a3e4:	movups XMMWORD PTR [r15],xmm0
  c1a3e8:	mov    rdi,rbx
  c1a3eb:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a3f0:	mov    rbx,rax
  c1a3f3:	jmp    c1a401 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaae1>
  c1a3f5:	mov    rbx,rax
  c1a3f8:	test   r14b,r14b
  c1a3fb:	je     c1a661 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad41>
  c1a401:	lea    rdi,[rsp+0xd0]
  c1a409:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a40e:	jmp    c1a661 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad41>
  c1a413:	jmp    c1a459 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab39>
  c1a415:	mov    rbx,rax
  c1a418:	lea    rdi,[rsp+0xd0]
  c1a420:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a425:	jmp    c1a676 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad56>
  c1a42a:	jmp    c1a673 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad53>
  c1a42f:	mov    rbx,rax
  c1a432:	mov    rsi,QWORD PTR [rsp+0x40]
  c1a437:	test   rsi,rsi
  c1a43a:	je     c1a78d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae6d>
  c1a440:	mov    rdi,QWORD PTR [rsp+0x48]
  c1a445:	shl    rsi,0x4
  c1a449:	mov    edx,0x8
  c1a44e:	call   QWORD PTR [rip+0x233434]        # e4d888 <_DYNAMIC+0x240>
  c1a454:	jmp    c1a78d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae6d>
  c1a459:	mov    rbx,rax
  c1a45c:	lea    rdi,[rsp+0x80]
  c1a464:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a469:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a46e:	mov    rbx,rax
  c1a471:	lea    rdi,[rsp+0x100]
  c1a479:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a47e:	jmp    c1a79f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae7f>
  c1a483:	jmp    c1a6bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad9d>
  c1a488:	jmp    c1a4a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab86>
  c1a48a:	mov    rbx,rax
  c1a48d:	lea    rdi,[rsp+0x40]
  c1a492:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a497:	jmp    c1a596 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac76>
  c1a49c:	jmp    c1a79c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae7c>
  c1a4a1:	jmp    c1a593 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac73>
  c1a4a6:	mov    rbx,rax
  c1a4a9:	lea    rdi,[rsp+0x120]
  c1a4b1:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a4b6:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a4bb:	mov    rbx,rax
  c1a4be:	lea    rdi,[rsp+0x80]
  c1a4c6:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a4cb:	lea    rdi,[rsp+0x40]
  c1a4d0:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a4d5:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a4da:	call   QWORD PTR [rip+0x2333c8]        # e4d8a8 <_DYNAMIC+0x260>
  c1a4e0:	mov    rbx,rax
  c1a4e3:	lea    rdi,[rsp+0x80]
  c1a4eb:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a4f0:	lea    rdi,[rsp+0x40]
  c1a4f5:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a4fa:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a4ff:	call   QWORD PTR [rip+0x2333a3]        # e4d8a8 <_DYNAMIC+0x260>
  c1a505:	jmp    c1a6e4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xadc4>
  c1a50a:	mov    rbx,rax
  c1a50d:	lea    rdi,[rsp+0xd0]
  c1a515:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a51a:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a51f:	mov    rbx,rax
  c1a522:	lea    rdi,[rsp+0x80]
  c1a52a:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a52f:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a534:	mov    rbx,rax
  c1a537:	lea    rdi,[rsp+0x80]
  c1a53f:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a544:	lea    rdi,[rsp+0x40]
  c1a549:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a54e:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a553:	call   QWORD PTR [rip+0x23334f]        # e4d8a8 <_DYNAMIC+0x260>
  c1a559:	mov    rbx,rax
  c1a55c:	lea    rdi,[rsp+0x80]
  c1a564:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a569:	lea    rdi,[rsp+0x40]
  c1a56e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a573:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a578:	call   QWORD PTR [rip+0x23332a]        # e4d8a8 <_DYNAMIC+0x260>
  c1a57e:	mov    rbx,rax
  c1a581:	lea    rdi,[rsp+0xd0]
  c1a589:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a58e:	jmp    c1a6ab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad8b>
  c1a593:	mov    rbx,rax
  c1a596:	lea    rdi,[rsp+0xd0]
  c1a59e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a5a3:	jmp    c1a642 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad22>
  c1a5a8:	mov    rbx,rax
  c1a5ab:	lea    rdi,[rsp+0xd0]
  c1a5b3:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a5b8:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a5bd:	jmp    c1a703 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xade3>
  c1a5c2:	jmp    c1a6a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad88>
  c1a5c7:	mov    rbx,rax
  c1a5ca:	lea    rdi,[rsp+0x80]
  c1a5d2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a5d7:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a5dc:	mov    rbx,rax
  c1a5df:	lea    rdi,[rsp+0x40]
  c1a5e4:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a5e9:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a5ee:	jmp    c1a722 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae02>
  c1a5f3:	mov    rbx,rax
  c1a5f6:	lea    rdi,[rsp+0x80]
  c1a5fe:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a603:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a608:	mov    rbx,rax
  c1a60b:	lea    rdi,[rsp+0x40]
  c1a610:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a615:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a61a:	mov    rbx,rax
  c1a61d:	lea    rdi,[rsp+0x80]
  c1a625:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a62a:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a62f:	mov    rbx,rax
  c1a632:	jmp    c1a6f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xadd4>
  c1a637:	mov    rbx,rax
  c1a63a:	jmp    c1a713 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xadf3>
  c1a63f:	mov    rbx,rax
  c1a642:	lea    rdi,[rsp+0x100]
  c1a64a:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a64f:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a654:	jmp    c1a6dc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xadbc>
  c1a659:	mov    rbx,rax
  c1a65c:	jmp    c1a6cd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xadad>
  c1a65e:	mov    rbx,rax
  c1a661:	lea    rdi,[rsp+0x100]
  c1a669:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a66e:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a673:	mov    rbx,rax
  c1a676:	lea    rdi,[rsp+0x100]
  c1a67e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a683:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a688:	mov    rbx,rax
  c1a68b:	lea    rdi,[rsp+0x588]
  c1a693:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a698:	jmp    c1a73c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae1c>
  c1a69d:	call   QWORD PTR [rip+0x233205]        # e4d8a8 <_DYNAMIC+0x260>
  c1a6a3:	jmp    c1a79c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae7c>
  c1a6a8:	mov    rbx,rax
  c1a6ab:	lea    rdi,[rsp+0x80]
  c1a6b3:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1a6b8:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a6bd:	mov    rbx,rax
  c1a6c0:	lea    rdi,[rsp+0x80]
  c1a6c8:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a6cd:	lea    rdi,[rsp+0x40]
  c1a6d2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a6d7:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a6dc:	mov    rbx,rax
  c1a6df:	jmp    c1a7ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae8c>
  c1a6e4:	mov    rbx,rax
  c1a6e7:	lea    rdi,[rsp+0x80]
  c1a6ef:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a6f4:	lea    rdi,[rsp+0x40]
  c1a6f9:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a6fe:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a703:	mov    rbx,rax
  c1a706:	lea    rdi,[rsp+0x80]
  c1a70e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a713:	lea    rdi,[rsp+0x40]
  c1a718:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a71d:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a722:	mov    rbx,rax
  c1a725:	lea    rdi,[rsp+0x80]
  c1a72d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a732:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a737:	jmp    c1a739 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae19>
  c1a739:	mov    rbx,rax
  c1a73c:	mov    rax,QWORD PTR [rsp+0x80]
  c1a744:	test   rax,rax
  c1a747:	je     c1a764 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae44>
  c1a749:	mov    rdi,QWORD PTR [rsp+0x88]
  c1a751:	shl    rax,0x3
  c1a755:	lea    rsi,[rax+rax*2]
  c1a759:	mov    edx,0x8
  c1a75e:	call   QWORD PTR [rip+0x233124]        # e4d888 <_DYNAMIC+0x240>
  c1a764:	mov    rsi,QWORD PTR [rsp+0x40]
  c1a769:	test   rsi,rsi
  c1a76c:	je     c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a76e:	mov    rdi,QWORD PTR [rsp+0x48]
  c1a773:	shl    rsi,0x4
  c1a777:	mov    edx,0x8
  c1a77c:	call   QWORD PTR [rip+0x233106]        # e4d888 <_DYNAMIC+0x240>
  c1a782:	mov    rdi,rbx
  c1a785:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a78a:	mov    rbx,rax
  c1a78d:	lea    rdi,[rsp+0xd0]
  c1a795:	call   c0a040 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueEECsbxgXiyEKxkX_6bsl_vm>
  c1a79a:	jmp    c1a7b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae99>
  c1a79c:	mov    rbx,rax
  c1a79f:	lea    rdi,[rsp+0x80]
  c1a7a7:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1a7ac:	lea    rdi,[rsp+0x368]
  c1a7b4:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a7b9:	mov    rdi,rbx
  c1a7bc:	call   d9b3f0 <_Unwind_Resume@plt>
  c1a7c1:	call   QWORD PTR [rip+0x2330e1]        # e4d8a8 <_DYNAMIC+0x260>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
