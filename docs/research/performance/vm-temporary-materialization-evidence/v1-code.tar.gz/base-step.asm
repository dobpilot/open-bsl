
/home/kan/Документы/develop/open-bsl-materialization.UpSJarfM/base-target/release/bsl-cli:     file format elf64-x86-64


Disassembly of section .text:

0000000000c0f920 <_RNvCsbxgXiyEKxkX_6bsl_vm4step>:
  c0f920:	push   rbp
  c0f921:	push   r15
  c0f923:	push   r14
  c0f925:	push   r13
  c0f927:	push   r12
  c0f929:	push   rbx
  c0f92a:	sub    rsp,0x5f8
  c0f931:	mov    QWORD PTR [rsp+0x348],r8
  c0f939:	mov    r11,QWORD PTR [rsi+0x10]
  c0f93d:	mov    rax,r11
  c0f940:	sub    rax,0x1
  c0f944:	mov    QWORD PTR [rsp+0x8],rax
  c0f949:	jb     c199a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa081>
  c0f94f:	lea    r8,[rsi+0x8]
  c0f953:	mov    rax,QWORD PTR [r8]
  c0f956:	imul   r15,QWORD PTR [rsp+0x8],0x78
  c0f95c:	mov    rbx,QWORD PTR [rax+r15*1+0x50]
  c0f961:	mov    r14,QWORD PTR [rcx+0x28]
  c0f965:	cmp    rbx,r14
  c0f968:	jae    c0f9f3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xd3>
  c0f96e:	mov    r13,QWORD PTR [rsp+0x630]
  c0f976:	mov    r10,QWORD PTR [rax+r15*1+0x58]
  c0f97b:	mov    r12,QWORD PTR [rcx+0x20]
  c0f97f:	imul   rbp,rbx,0xc8
  c0f986:	mov    rax,QWORD PTR [r12+rbp*1+0x10]
  c0f98b:	cmp    r10,rax
  c0f98e:	jae    c0fa0e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xee>
  c0f990:	mov    QWORD PTR [rsp+0x20],r15
  c0f995:	add    rbp,r12
  c0f998:	mov    r15,QWORD PTR [rbp+0xb0]
  c0f99f:	mov    r13,QWORD PTR [rbp+0xb8]
  c0f9a6:	mov    QWORD PTR [rsp+0x580],r13
  c0f9ae:	cmp    r10,r13
  c0f9b1:	mov    QWORD PTR [rsp+0x10],rdi
  c0f9b6:	mov    QWORD PTR [rsp+0x1b8],r8
  c0f9be:	mov    QWORD PTR [rsp+0x28],rdx
  c0f9c3:	mov    QWORD PTR [rsp+0x1c8],r9
  c0f9cb:	mov    QWORD PTR [rsp+0x588],r15
  c0f9d3:	mov    QWORD PTR [rsp+0x3b0],r14
  c0f9db:	jae    c0fabc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19c>
  c0f9e1:	movzx  r15d,BYTE PTR [r15+r10*1]
  c0f9e6:	cmp    r15b,0x1
  c0f9ea:	adc    r15b,0xff
  c0f9ee:	jmp    c0fabf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19f>
  c0f9f3:	mov    BYTE PTR [rdi],0x1f
  c0f9f6:	lea    rax,[rip+0xffffffffff6b6896]        # 2c6293 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x18d2>
  c0f9fd:	mov    QWORD PTR [rdi+0x8],rax
  c0fa01:	mov    QWORD PTR [rdi+0x10],0x3a
  c0fa09:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c0fa0e:	mov    rbx,rdi
  c0fa11:	mov    DWORD PTR [rsp+0x80],0x2
  c0fa1c:	mov    r8,QWORD PTR [r13+0x0]
  c0fa20:	mov    rcx,r9
  c0fa23:	mov    r9,QWORD PTR [r13+0x10]
  c0fa27:	sub    rsp,0x8
  c0fa2b:	lea    rax,[rsp+0x88]
  c0fa33:	lea    rdi,[rsp+0x118]
  c0fa3b:	push   rax
  c0fa3c:	call   c0dae0 <_RNvCsbxgXiyEKxkX_6bsl_vm20do_return_with_value>
  c0fa41:	add    rsp,0x10
  c0fa45:	movzx  eax,BYTE PTR [rsp+0x110]
  c0fa4d:	cmp    al,0xff
  c0fa4f:	je     c17458 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b38>
  c0fa55:	mov    ecx,DWORD PTR [rsp+0x111]
  c0fa5c:	mov    edx,DWORD PTR [rsp+0x114]
  c0fa63:	mov    DWORD PTR [rbx+0x4],edx
  c0fa66:	mov    DWORD PTR [rbx+0x1],ecx
  c0fa69:	mov    ecx,DWORD PTR [rsp+0x118]
  c0fa70:	movups xmm0,XMMWORD PTR [rsp+0x11c]
  c0fa78:	movaps XMMWORD PTR [rsp+0x3c0],xmm0
  c0fa80:	mov    edx,DWORD PTR [rsp+0x12c]
  c0fa87:	mov    DWORD PTR [rsp+0x3d0],edx
  c0fa8e:	movups xmm0,XMMWORD PTR [rsp+0x130]
  c0fa96:	movups XMMWORD PTR [rbx+0x20],xmm0
  c0fa9a:	mov    edx,DWORD PTR [rsp+0x3d0]
  c0faa1:	mov    DWORD PTR [rbx+0x1c],edx
  c0faa4:	movdqa xmm0,XMMWORD PTR [rsp+0x3c0]
  c0faad:	movdqu XMMWORD PTR [rbx+0xc],xmm0
  c0fab2:	mov    BYTE PTR [rbx],al
  c0fab4:	mov    DWORD PTR [rbx+0x8],ecx
  c0fab7:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c0fabc:	xor    r15d,r15d
  c0fabf:	mov    r13,r10
  c0fac2:	mov    QWORD PTR [rsp+0x3a8],r12
  c0faca:	mov    QWORD PTR [rsp+0x30],rax
  c0facf:	mov    QWORD PTR [rsp+0x590],r11
  c0fad7:	mov    rax,QWORD PTR [rsp+0x668]
  c0fadf:	mov    QWORD PTR [rsp+0x4f0],rax
  c0fae7:	mov    QWORD PTR [rsp+0x18],rsi
  c0faec:	lea    rax,[rsi+0x10]
  c0faf0:	mov    QWORD PTR [rsp+0x1b0],rax
  c0faf8:	mov    rax,QWORD PTR [rsp+0x648]
  c0fb00:	lea    rdx,[rax+0x100]
  c0fb07:	lea    rsi,[rax+0x110]
  c0fb0e:	mov    QWORD PTR [rsp+0x3b8],rbx
  c0fb16:	lea    rdi,[rbx+rbx*2]
  c0fb1a:	shl    rdi,0x3
  c0fb1e:	mov    r8,QWORD PTR [rsp+0x348]
  c0fb26:	add    rdi,QWORD PTR [r8+0x8]
  c0fb2a:	mov    QWORD PTR [rsp+0x1a0],rdi
  c0fb32:	mov    QWORD PTR [rsp+0x398],rsi
  c0fb3a:	movq   xmm0,rsi
  c0fb3f:	mov    QWORD PTR [rsp+0x3a0],rdx
  c0fb47:	movq   xmm1,rdx
  c0fb4c:	punpcklqdq xmm1,xmm0
  c0fb50:	movdqa XMMWORD PTR [rsp+0x530],xmm1
  c0fb59:	lea    rdx,[rax+0x58]
  c0fb5d:	mov    QWORD PTR [rsp+0x390],rdx
  c0fb65:	lea    rdx,[rax+0x48]
  c0fb69:	mov    QWORD PTR [rsp+0x388],rdx
  c0fb71:	lea    rdx,[rax+0x68]
  c0fb75:	mov    QWORD PTR [rsp+0x380],rdx
  c0fb7d:	lea    rdx,[rax+0xf0]
  c0fb84:	mov    QWORD PTR [rsp+0x378],rdx
  c0fb8c:	lea    rdx,[rax+0x118]
  c0fb93:	mov    QWORD PTR [rsp+0x370],rdx
  c0fb9b:	mov    rdx,QWORD PTR [rcx+0x38]
  c0fb9f:	mov    QWORD PTR [rsp+0x4c8],rdx
  c0fba7:	mov    rdx,QWORD PTR [rcx+0x40]
  c0fbab:	mov    QWORD PTR [rsp+0x4d0],rdx
  c0fbb3:	mov    rdx,QWORD PTR [r8+0x10]
  c0fbb7:	mov    QWORD PTR [rsp+0x4d8],rdx
  c0fbbf:	lea    rax,[rax+0xb8]
  c0fbc6:	mov    QWORD PTR [rsp+0x4c0],rax
  c0fbce:	mov    rdx,QWORD PTR [rsp+0x630]
  c0fbd6:	mov    rax,QWORD PTR [rdx]
  c0fbd9:	mov    QWORD PTR [rsp+0x4f8],rax
  c0fbe1:	mov    rax,QWORD PTR [rdx+0x8]
  c0fbe5:	mov    QWORD PTR [rsp+0x578],rax
  c0fbed:	mov    QWORD PTR [rsp+0x1c0],rcx
  c0fbf5:	mov    rax,QWORD PTR [rcx+0x88]
  c0fbfc:	mov    QWORD PTR [rsp+0x4e0],rax
  c0fc04:	mov    QWORD PTR [rsp+0x4e8],rax
  c0fc0c:	mov    QWORD PTR [rsp+0x350],rbp
  c0fc14:	jmp    c0fc40 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x320>
  c0fc16:	movzx  r15d,BYTE PTR [rcx+rax*1]
  c0fc1b:	cmp    r15b,0x1
  c0fc1f:	adc    r15b,0xff
  c0fc23:	mov    r13,rax
  c0fc26:	cmp    r13,rbp
  c0fc29:	mov    rbp,QWORD PTR [rsp+0x350]
  c0fc31:	jae    c1997a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa05a>
  c0fc37:	nop    WORD PTR [rax+rax*1+0x0]
  c0fc40:	mov    rcx,QWORD PTR [rbp+0x8]
  c0fc44:	movzx  edx,BYTE PTR [rcx+r13*8]
  c0fc49:	movzx  r14d,BYTE PTR [rcx+r13*8+0x1]
  c0fc4f:	movzx  r12d,r14b
  c0fc53:	mov    r10,rbp
  c0fc56:	movzx  ebp,WORD PTR [rcx+r13*8+0x2]
  c0fc5c:	mov    eax,ebp
  c0fc5e:	shr    eax,0x8
  c0fc61:	mov    ebx,DWORD PTR [rcx+r13*8+0x4]
  c0fc66:	lea    rsi,[rip+0xffffffffff6b5a9f]        # 2c570c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xd4b>
  c0fc6d:	movsxd rdx,DWORD PTR [rsi+rdx*4]
  c0fc71:	add    rdx,rsi
  c0fc74:	jmp    rdx
  c0fc76:	mov    rsi,QWORD PTR [rcx+r13*8]
  c0fc7a:	lea    rdi,[rsp+0x110]
  c0fc82:	mov    rbx,QWORD PTR [rsp+0x18]
  c0fc87:	mov    rdx,rbx
  c0fc8a:	mov    rcx,QWORD PTR [rsp+0x28]
  c0fc8f:	mov    r8,QWORD PTR [rsp+0x1c0]
  c0fc97:	mov    r9,QWORD PTR [rsp+0x348]
  c0fc9f:	push   r10
  c0fca1:	push   QWORD PTR [rsp+0x3c0]
  c0fca8:	push   QWORD PTR [rsp+0x18]
  c0fcac:	push   QWORD PTR [rsp+0x508]
  c0fcb3:	push   QWORD PTR [rsp+0x680]
  c0fcba:	push   QWORD PTR [rsp+0x5a0]
  c0fcc1:	push   QWORD PTR [rsp+0x528]
  c0fcc8:	push   QWORD PTR [rsp+0x200]
  c0fccf:	push   QWORD PTR [rsp+0x680]
  c0fcd6:	push   QWORD PTR [rsp+0x698]
  c0fcdd:	push   QWORD PTR [rsp+0x698]
  c0fce4:	push   QWORD PTR [rsp+0x690]
  c0fceb:	call   c1aea0 <_RNvCsbxgXiyEKxkX_6bsl_vm9step_cold>
  c0fcf0:	add    rsp,0x60
  c0fcf4:	cmp    BYTE PTR [rsp+0x110],0xff
  c0fcfc:	jne    c197bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9d>
  c0fd02:	mov    r12,QWORD PTR [rsp+0x10]
  c0fd07:	lea    r14,[rbx+0x8]
  c0fd0b:	mov    rbp,QWORD PTR [rsp+0x30]
  c0fd10:	test   r15b,r15b
  c0fd13:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c0fd19:	cmp    BYTE PTR [rsp+0x658],0x0
  c0fd21:	je     c17445 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b25>
  c0fd27:	mov    rax,QWORD PTR [rsp+0x18]
  c0fd2c:	add    rax,0x10
  c0fd30:	mov    rcx,QWORD PTR [rsp+0x590]
  c0fd38:	cmp    QWORD PTR [rax],rcx
  c0fd3b:	mov    rcx,QWORD PTR [rsp+0x588]
  c0fd43:	jne    c17445 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b25>
  c0fd49:	mov    rax,QWORD PTR [r14]
  c0fd4c:	mov    rdx,QWORD PTR [rsp+0x20]
  c0fd51:	mov    rax,QWORD PTR [rax+rdx*1+0x58]
  c0fd56:	inc    r13
  c0fd59:	cmp    rax,r13
  c0fd5c:	jne    c17445 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b25>
  c0fd62:	cmp    rax,rbp
  c0fd65:	jae    c17445 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b25>
  c0fd6b:	cmp    rax,QWORD PTR [rsp+0x580]
  c0fd73:	jb     c0fc16 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2f6>
  c0fd79:	xor    r15d,r15d
  c0fd7c:	mov    r13,rax
  c0fd7f:	cmp    r13,rbp
  c0fd82:	mov    rbp,QWORD PTR [rsp+0x350]
  c0fd8a:	jb     c0fc40 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x320>
  c0fd90:	jmp    c1997a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa05a>
  c0fd95:	mov    rcx,QWORD PTR [rsp+0x18]
  c0fd9a:	lea    rax,[rcx+0x10]
  c0fd9e:	mov    rsi,QWORD PTR [rax]
  c0fda1:	cmp    QWORD PTR [rsp+0x8],rsi
  c0fda6:	jae    c19a2f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa10f>
  c0fdac:	lea    r14,[rcx+0x8]
  c0fdb0:	mov    rsi,QWORD PTR [r14]
  c0fdb3:	mov    rdi,QWORD PTR [rsp+0x20]
  c0fdb8:	lea    rdx,[rsi+rdi*1]
  c0fdbc:	movzx  ecx,bpl
  c0fdc0:	mov    rax,rcx
  c0fdc3:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c0fdc8:	jae    c10b4a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x122a>
  c0fdce:	mov    rax,QWORD PTR [rdx+0x28]
  c0fdd2:	shl    ecx,0x4
  c0fdd5:	mov    rax,QWORD PTR [rax+rcx*1]
  c0fdd9:	jmp    c10b4e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x122e>
  c0fdde:	mov    rcx,QWORD PTR [rsp+0x18]
  c0fde3:	lea    rax,[rcx+0x10]
  c0fde7:	mov    rsi,QWORD PTR [rax]
  c0fdea:	cmp    QWORD PTR [rsp+0x8],rsi
  c0fdef:	jae    c19b4f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa22f>
  c0fdf5:	lea    r14,[rcx+0x8]
  c0fdf9:	mov    rax,QWORD PTR [r14]
  c0fdfc:	movsx  rcx,bp
  c0fe00:	mov    rdx,QWORD PTR [rsp+0x20]
  c0fe05:	mov    QWORD PTR [rax+rdx*1+0x58],rcx
  c0fe0a:	jmp    c11a0f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20ef>
  c0fe0f:	mov    eax,ebx
  c0fe11:	shr    eax,0x10
  c0fe14:	cmp    QWORD PTR [r10+0x40],rax
  c0fe18:	jbe    c176aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7d8a>
  c0fe1e:	movzx  edx,bx
  c0fe21:	mov    rcx,QWORD PTR [rsp+0x3b0]
  c0fe29:	cmp    rcx,rdx
  c0fe2c:	mov    rcx,QWORD PTR [rsp+0x10]
  c0fe31:	jbe    c179c1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80a1>
  c0fe37:	lea    rbx,[rax+rax*2]
  c0fe3b:	shl    ebx,0x3
  c0fe3e:	mov    QWORD PTR [rsp+0x4b0],rdx
  c0fe46:	imul   rax,rdx,0xc8
  c0fe4d:	mov    rdx,QWORD PTR [rsp+0x3a8]
  c0fe55:	lea    rsi,[rdx+rax*1]
  c0fe59:	mov    QWORD PTR [rsp+0x1d8],rsi
  c0fe61:	mov    rsi,QWORD PTR [rsp+0x350]
  c0fe69:	add    rbx,QWORD PTR [rsi+0x38]
  c0fe6d:	cmp    BYTE PTR [rdx+rax*1+0xc1],0x0
  c0fe75:	jne    c17cc7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x83a7>
  c0fe7b:	mov    rax,QWORD PTR [rsp+0x18]
  c0fe80:	add    rax,0x10
  c0fe84:	mov    rsi,QWORD PTR [rax]
  c0fe87:	cmp    rsi,0x3e7
  c0fe8e:	ja     c182e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c6>
  c0fe94:	cmp    QWORD PTR [rsp+0x8],rsi
  c0fe99:	jae    c19f43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa623>
  c0fe9f:	mov    edx,r15d
  c0fea2:	mov    rax,QWORD PTR [rsp+0x18]
  c0fea7:	add    rax,0x8
  c0feab:	mov    rax,QWORD PTR [rax]
  c0feae:	mov    rcx,QWORD PTR [rsp+0x20]
  c0feb3:	inc    QWORD PTR [rax+rcx*1+0x58]
  c0feb8:	mov    rcx,QWORD PTR [rbx+0x10]
  c0febc:	mov    r12,rcx
  c0febf:	shl    r12,0x4
  c0fec3:	movabs rax,0xfffffffffffffff
  c0fecd:	mov    r15,rcx
  c0fed0:	cmp    rcx,rax
  c0fed3:	seta   al
  c0fed6:	movabs rcx,0x7ffffffffffffff8
  c0fee0:	cmp    r12,rcx
  c0fee3:	seta   cl
  c0fee6:	or     cl,al
  c0fee8:	jne    c174be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b9e>
  c0feee:	test   r12,r12
  c0fef1:	mov    QWORD PTR [rsp+0x1a8],r13
  c0fef9:	mov    DWORD PTR [rsp+0x3c],edx
  c0fefd:	je     c11b08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21e8>
  c0ff03:	call   QWORD PTR [rip+0x23dbb7]        # e4dac0 <_DYNAMIC+0x300>
  c0ff09:	mov    r13d,0x8
  c0ff0f:	mov    esi,0x8
  c0ff14:	mov    rdi,r12
  c0ff17:	call   QWORD PTR [rip+0x23dbab]        # e4dac8 <_DYNAMIC+0x308>
  c0ff1d:	test   rax,rax
  c0ff20:	je     c174c9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7ba9>
  c0ff26:	mov    rcx,r15
  c0ff29:	mov    r13,QWORD PTR [rsp+0x1a8]
  c0ff31:	mov    edx,DWORD PTR [rsp+0x3c]
  c0ff35:	jmp    c11b0f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21ef>
  c0ff3a:	mov    rdx,QWORD PTR [rsp+0x18]
  c0ff3f:	lea    rcx,[rdx+0x10]
  c0ff43:	mov    rsi,QWORD PTR [rcx]
  c0ff46:	cmp    QWORD PTR [rsp+0x8],rsi
  c0ff4b:	jae    c19af5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1d5>
  c0ff51:	lea    r14,[rdx+0x8]
  c0ff55:	mov    rdi,QWORD PTR [r14]
  c0ff58:	mov    r8,QWORD PTR [rsp+0x20]
  c0ff5d:	lea    rsi,[rdi+r8*1]
  c0ff61:	movzx  edx,bpl
  c0ff65:	mov    rcx,rdx
  c0ff68:	sub    rcx,QWORD PTR [rdi+r8*1+0x30]
  c0ff6d:	jae    c10ba8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1288>
  c0ff73:	mov    rcx,QWORD PTR [rsi+0x28]
  c0ff77:	shl    edx,0x4
  c0ff7a:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c0ff7e:	jmp    c10bac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x128c>
  c0ff83:	mov    rcx,QWORD PTR [rsp+0x18]
  c0ff88:	lea    r14,[rcx+0x8]
  c0ff8c:	mov    rsi,QWORD PTR [r14]
  c0ff8f:	lea    rbx,[rcx+0x10]
  c0ff93:	mov    rdx,QWORD PTR [rbx]
  c0ff96:	mov    rdi,QWORD PTR [rsp+0x28]
  c0ff9b:	mov    rcx,QWORD PTR [rdi+0x8]
  c0ff9f:	mov    r8,QWORD PTR [rdi+0x10]
  c0ffa3:	sub    rsp,0x8
  c0ffa7:	movzx  eax,al
  c0ffaa:	movzx  r10d,bpl
  c0ffae:	lea    rdi,[rsp+0x118]
  c0ffb6:	mov    r9,QWORD PTR [rsp+0x10]
  c0ffbb:	push   rax
  c0ffbc:	push   r10
  c0ffbe:	push   r12
  c0ffc0:	call   c1ab40 <_RNvCsbxgXiyEKxkX_6bsl_vm6add_op>
  c0ffc5:	add    rsp,0x20
  c0ffc9:	cmp    BYTE PTR [rsp+0x110],0xff
  c0ffd1:	jne    c197bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9d>
  c0ffd7:	mov    rsi,QWORD PTR [rbx]
  c0ffda:	cmp    QWORD PTR [rsp+0x8],rsi
  c0ffdf:	mov    r12,QWORD PTR [rsp+0x10]
  c0ffe4:	jb     c14128 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4808>
  c0ffea:	jmp    c19cc3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3a3>
  c0ffef:	mov    rcx,QWORD PTR [rsp+0x18]
  c0fff4:	lea    rax,[rcx+0x10]
  c0fff8:	mov    rsi,QWORD PTR [rax]
  c0fffb:	cmp    QWORD PTR [rsp+0x8],rsi
  c10000:	jae    c19ba9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa289>
  c10006:	lea    r14,[rcx+0x8]
  c1000a:	mov    rcx,QWORD PTR [r14]
  c1000d:	mov    rdx,QWORD PTR [rsp+0x20]
  c10012:	lea    rax,[rcx+rdx*1]
  c10016:	cmp    QWORD PTR [rcx+rdx*1+0x30],r12
  c1001b:	jbe    c10031 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x711>
  c1001d:	mov    rcx,QWORD PTR [rax+0x28]
  c10021:	shl    r12d,0x4
  c10025:	cmp    BYTE PTR [rcx+r12*1+0x8],0x0
  c1002b:	je     c11a0b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20eb>
  c10031:	movsx  rcx,bp
  c10035:	mov    QWORD PTR [rax+0x58],rcx
  c10039:	jmp    c11a0f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x20ef>
  c1003e:	mov    rcx,QWORD PTR [rsp+0x18]
  c10043:	lea    r14,[rcx+0x8]
  c10047:	mov    rsi,QWORD PTR [r14]
  c1004a:	lea    rbx,[rcx+0x10]
  c1004e:	mov    rdx,QWORD PTR [rbx]
  c10051:	mov    rdi,QWORD PTR [rsp+0x28]
  c10056:	mov    rcx,QWORD PTR [rdi+0x8]
  c1005a:	mov    r8,QWORD PTR [rdi+0x10]
  c1005e:	sub    rsp,0x8
  c10062:	movzx  eax,al
  c10065:	movzx  r10d,bpl
  c10069:	lea    rdi,[rsp+0x118]
  c10071:	mov    r9,QWORD PTR [rsp+0x10]
  c10076:	push   rax
  c10077:	push   r10
  c10079:	push   r12
  c1007b:	call   c082a0 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3remEB2_>
  c10080:	add    rsp,0x20
  c10084:	cmp    BYTE PTR [rsp+0x110],0xff
  c1008c:	jne    c197bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9d>
  c10092:	mov    rsi,QWORD PTR [rbx]
  c10095:	cmp    QWORD PTR [rsp+0x8],rsi
  c1009a:	mov    r12,QWORD PTR [rsp+0x10]
  c1009f:	jb     c14128 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4808>
  c100a5:	jmp    c19cd5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3b5>
  c100aa:	mov    rdi,QWORD PTR [rsp+0x18]
  c100af:	lea    rcx,[rdi+0x10]
  c100b3:	mov    rsi,QWORD PTR [rcx]
  c100b6:	cmp    QWORD PTR [rsp+0x8],rsi
  c100bb:	jae    c19aad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa18d>
  c100c1:	mov    rcx,QWORD PTR [rsp+0x28]
  c100c6:	mov    rsi,QWORD PTR [rcx+0x8]
  c100ca:	mov    rdx,QWORD PTR [rcx+0x10]
  c100ce:	lea    r14,[rdi+0x8]
  c100d2:	mov    rcx,QWORD PTR [r14]
  c100d5:	add    rcx,QWORD PTR [rsp+0x20]
  c100da:	movzx  r8d,bpl
  c100de:	movzx  r9d,al
  c100e2:	lea    rdi,[rsp+0x110]
  c100ea:	call   c247e0 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs4load>
  c100ef:	mov    eax,DWORD PTR [rsp+0x110]
  c100f6:	cmp    eax,0xffffffff
  c100f9:	je     c17956 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8036>
  c100ff:	lea    rsi,[rsp+0x114]
  c10107:	mov    ecx,DWORD PTR [rsi+0x30]
  c1010a:	mov    DWORD PTR [rsp+0x70],ecx
  c1010e:	movups xmm0,XMMWORD PTR [rsi]
  c10111:	movups xmm1,XMMWORD PTR [rsi+0x10]
  c10115:	movups xmm2,XMMWORD PTR [rsi+0x20]
  c10119:	movaps XMMWORD PTR [rsp+0x60],xmm2
  c1011e:	movaps XMMWORD PTR [rsp+0x50],xmm1
  c10123:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c10128:	mov    rcx,QWORD PTR [rsi+0x44]
  c1012c:	lea    rdx,[rsp+0x84]
  c10134:	mov    QWORD PTR [rdx+0x44],rcx
  c10138:	movups xmm0,XMMWORD PTR [rsi+0x34]
  c1013c:	movups XMMWORD PTR [rdx+0x34],xmm0
  c10140:	mov    ecx,DWORD PTR [rsp+0x70]
  c10144:	mov    DWORD PTR [rdx+0x30],ecx
  c10147:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c1014d:	movdqa xmm1,XMMWORD PTR [rsp+0x50]
  c10153:	movaps xmm2,XMMWORD PTR [rsp+0x60]
  c10158:	movups XMMWORD PTR [rdx+0x20],xmm2
  c1015c:	movdqu XMMWORD PTR [rdx+0x10],xmm1
  c10161:	movdqu XMMWORD PTR [rdx],xmm0
  c10165:	mov    DWORD PTR [rsp+0x80],eax
  c1016c:	cmp    bl,0x2c
  c1016f:	jne    c11544 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1c24>
  c10175:	xor    esi,esi
  c10177:	mov    rax,QWORD PTR [rsp+0x638]
  c1017f:	cmp    DWORD PTR [rax],0xffffffff
  c10182:	cmovne rsi,rax
  c10186:	lea    rdi,[rsp+0x110]
  c1018e:	call   c0d980 <_RNvCsbxgXiyEKxkX_6bsl_vm18current_error_info>
  c10193:	mov    rbp,QWORD PTR [rsp+0x30]
  c10198:	jmp    c1158b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1c6b>
  c1019d:	mov    rcx,QWORD PTR [rsp+0x18]
  c101a2:	lea    r14,[rcx+0x8]
  c101a6:	mov    rsi,QWORD PTR [r14]
  c101a9:	lea    rbx,[rcx+0x10]
  c101ad:	mov    rdx,QWORD PTR [rbx]
  c101b0:	mov    rdi,QWORD PTR [rsp+0x28]
  c101b5:	mov    rcx,QWORD PTR [rdi+0x8]
  c101b9:	mov    r8,QWORD PTR [rdi+0x10]
  c101bd:	sub    rsp,0x8
  c101c1:	movzx  eax,al
  c101c4:	movzx  r10d,bpl
  c101c8:	lea    rdi,[rsp+0x118]
  c101d0:	mov    r9,QWORD PTR [rsp+0x10]
  c101d5:	push   rax
  c101d6:	push   r10
  c101d8:	push   r12
  c101da:	call   c06f20 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3divEB2_>
  c101df:	add    rsp,0x20
  c101e3:	cmp    BYTE PTR [rsp+0x110],0xff
  c101eb:	jne    c197bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9d>
  c101f1:	mov    rsi,QWORD PTR [rbx]
  c101f4:	cmp    QWORD PTR [rsp+0x8],rsi
  c101f9:	mov    r12,QWORD PTR [rsp+0x10]
  c101fe:	jb     c14128 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4808>
  c10204:	jmp    c19d4b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa42b>
  c10209:	mov    rdx,QWORD PTR [rsp+0x18]
  c1020e:	lea    rcx,[rdx+0x10]
  c10212:	mov    rsi,QWORD PTR [rcx]
  c10215:	cmp    QWORD PTR [rsp+0x8],rsi
  c1021a:	jae    c19b07 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1e7>
  c10220:	lea    rcx,[rdx+0x8]
  c10224:	mov    rbx,QWORD PTR [rcx]
  c10227:	movzx  edx,bpl
  c1022b:	mov    rcx,QWORD PTR [rsp+0x20]
  c10230:	mov    r9,QWORD PTR [rbx+rcx*1+0x30]
  c10235:	add    rbx,rcx
  c10238:	mov    rcx,rdx
  c1023b:	sub    rcx,r9
  c1023e:	mov    QWORD PTR [rsp+0x1a8],r13
  c10246:	mov    DWORD PTR [rsp+0x3c],r15d
  c1024b:	jae    c10bfb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12db>
  c10251:	mov    rcx,QWORD PTR [rbx+0x28]
  c10255:	shl    edx,0x4
  c10258:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1025c:	jmp    c10bff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x12df>
  c10261:	mov    rdx,QWORD PTR [rsp+0x18]
  c10266:	lea    rcx,[rdx+0x10]
  c1026a:	mov    rsi,QWORD PTR [rcx]
  c1026d:	cmp    QWORD PTR [rsp+0x8],rsi
  c10272:	jae    c19b85 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa265>
  c10278:	lea    rcx,[rdx+0x8]
  c1027c:	mov    rbx,QWORD PTR [rcx]
  c1027f:	movzx  edx,bpl
  c10283:	mov    rcx,QWORD PTR [rsp+0x20]
  c10288:	mov    r14,QWORD PTR [rbx+rcx*1+0x30]
  c1028d:	add    rbx,rcx
  c10290:	mov    rcx,rdx
  c10293:	sub    rcx,r14
  c10296:	jae    c10c72 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1352>
  c1029c:	mov    rcx,QWORD PTR [rbx+0x28]
  c102a0:	shl    edx,0x4
  c102a3:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c102a7:	jmp    c10c76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1356>
  c102ac:	mov    rdx,QWORD PTR [rsp+0x18]
  c102b1:	lea    rcx,[rdx+0x10]
  c102b5:	mov    rsi,QWORD PTR [rcx]
  c102b8:	cmp    QWORD PTR [rsp+0x8],rsi
  c102bd:	jae    c19abf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa19f>
  c102c3:	lea    rcx,[rdx+0x8]
  c102c7:	mov    rbx,QWORD PTR [rcx]
  c102ca:	movzx  edx,bpl
  c102ce:	mov    rcx,QWORD PTR [rsp+0x20]
  c102d3:	mov    r14,QWORD PTR [rbx+rcx*1+0x30]
  c102d8:	add    rbx,rcx
  c102db:	mov    rcx,rdx
  c102de:	sub    rcx,r14
  c102e1:	jae    c10cf6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13d6>
  c102e7:	mov    rcx,QWORD PTR [rbx+0x28]
  c102eb:	shl    edx,0x4
  c102ee:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c102f2:	jmp    c10cfa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13da>
  c102f7:	mov    rdx,QWORD PTR [rsp+0x18]
  c102fc:	lea    rcx,[rdx+0x10]
  c10300:	mov    rsi,QWORD PTR [rcx]
  c10303:	cmp    QWORD PTR [rsp+0x8],rsi
  c10308:	jae    c19bdf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2bf>
  c1030e:	lea    r14,[rdx+0x8]
  c10312:	mov    rsi,QWORD PTR [r14]
  c10315:	mov    rdi,QWORD PTR [rsp+0x20]
  c1031a:	lea    rdx,[rsi+rdi*1]
  c1031e:	mov    rcx,r12
  c10321:	sub    rcx,QWORD PTR [rsi+rdi*1+0x30]
  c10326:	jae    c10d7a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x145a>
  c1032c:	mov    rcx,QWORD PTR [rdx+0x28]
  c10330:	shl    r12d,0x4
  c10334:	mov    rcx,QWORD PTR [rcx+r12*1]
  c10338:	jmp    c10d7e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x145e>
  c1033d:	mov    rcx,QWORD PTR [rsp+0x18]
  c10342:	lea    rax,[rcx+0x10]
  c10346:	mov    rsi,QWORD PTR [rax]
  c10349:	cmp    QWORD PTR [rsp+0x8],rsi
  c1034e:	jae    c19ae3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1c3>
  c10354:	lea    rax,[rcx+0x8]
  c10358:	mov    rdx,QWORD PTR [rax]
  c1035b:	mov    rsi,QWORD PTR [rsp+0x20]
  c10360:	lea    rcx,[rdx+rsi*1]
  c10364:	mov    rax,r12
  c10367:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c1036c:	jae    c10dd2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14b2>
  c10372:	mov    rax,QWORD PTR [rcx+0x28]
  c10376:	shl    r12d,0x4
  c1037a:	mov    rax,QWORD PTR [rax+r12*1]
  c1037e:	jmp    c10dd6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x14b6>
  c10383:	mov    rcx,QWORD PTR [rsp+0x18]
  c10388:	lea    r14,[rcx+0x8]
  c1038c:	mov    rsi,QWORD PTR [r14]
  c1038f:	lea    rbx,[rcx+0x10]
  c10393:	mov    rdx,QWORD PTR [rbx]
  c10396:	mov    rdi,QWORD PTR [rsp+0x28]
  c1039b:	mov    rcx,QWORD PTR [rdi+0x8]
  c1039f:	mov    r8,QWORD PTR [rdi+0x10]
  c103a3:	sub    rsp,0x8
  c103a7:	movzx  eax,al
  c103aa:	movzx  r10d,bpl
  c103ae:	lea    rdi,[rsp+0x118]
  c103b6:	mov    r9,QWORD PTR [rsp+0x10]
  c103bb:	push   rax
  c103bc:	push   r10
  c103be:	push   r12
  c103c0:	call   c08c60 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3subEB2_>
  c103c5:	add    rsp,0x20
  c103c9:	cmp    BYTE PTR [rsp+0x110],0xff
  c103d1:	jne    c197bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9d>
  c103d7:	mov    rsi,QWORD PTR [rbx]
  c103da:	cmp    QWORD PTR [rsp+0x8],rsi
  c103df:	mov    r12,QWORD PTR [rsp+0x10]
  c103e4:	jb     c14128 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4808>
  c103ea:	jmp    c19c1f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2ff>
  c103ef:	cmp    QWORD PTR [r10+0x28],rbp
  c103f3:	jbe    c176ca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7daa>
  c103f9:	mov    rcx,QWORD PTR [r10+0x20]
  c103fd:	lea    rdx,[rbp*2+0x0]
  c10405:	add    rdx,rbp
  c10408:	mov    eax,DWORD PTR [rcx+rdx*8]
  c1040b:	mov    esi,eax
  c1040d:	sub    esi,0x2
  c10410:	mov    edi,0x3
  c10415:	cmovae edi,esi
  c10418:	lea    rcx,[rcx+rdx*8]
  c1041c:	lea    rdx,[rip+0xffffffffff6b58b1]        # 2c5cd4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1313>
  c10423:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c10427:	add    rsi,rdx
  c1042a:	jmp    rsi
  c1042c:	mov    rax,QWORD PTR [rcx+0x10]
  c10430:	mov    QWORD PTR [rsp+0x90],rax
  c10438:	movdqu xmm0,XMMWORD PTR [rcx]
  c1043c:	movdqa XMMWORD PTR [rsp+0x80],xmm0
  c10445:	mov    rax,QWORD PTR [rsp+0x18]
  c1044a:	lea    rdi,[rax+0x8]
  c1044e:	mov    r8,QWORD PTR [rsp+0x28]
  c10453:	lea    r9,[rax+0x10]
  c10457:	mov    rbp,QWORD PTR [rsp+0x30]
  c1045c:	jmp    c15eff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x65df>
  c10461:	mov    rcx,QWORD PTR [rsp+0x18]
  c10466:	lea    rax,[rcx+0x10]
  c1046a:	mov    rsi,QWORD PTR [rax]
  c1046d:	cmp    QWORD PTR [rsp+0x8],rsi
  c10472:	jae    c19bcd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2ad>
  c10478:	lea    rax,[rcx+0x8]
  c1047c:	mov    rdx,QWORD PTR [rax]
  c1047f:	mov    rsi,QWORD PTR [rsp+0x20]
  c10484:	lea    rcx,[rdx+rsi*1]
  c10488:	mov    rax,r12
  c1048b:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c10490:	mov    rbp,QWORD PTR [rsp+0x30]
  c10495:	jae    c10e6f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x154f>
  c1049b:	mov    rax,QWORD PTR [rcx+0x28]
  c1049f:	shl    r12d,0x4
  c104a3:	mov    rax,QWORD PTR [rax+r12*1]
  c104a7:	jmp    c10e73 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1553>
  c104ac:	cmp    QWORD PTR [rsp+0x4e0],rbp
  c104b4:	jbe    c1750e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7bee>
  c104ba:	mov    rcx,QWORD PTR [rsp+0x18]
  c104bf:	lea    rax,[rcx+0x10]
  c104c3:	mov    rsi,QWORD PTR [rax]
  c104c6:	cmp    QWORD PTR [rsp+0x8],rsi
  c104cb:	jae    c19cf9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3d9>
  c104d1:	lea    rax,[rcx+0x8]
  c104d5:	mov    rdx,QWORD PTR [rax]
  c104d8:	mov    rsi,QWORD PTR [rsp+0x20]
  c104dd:	lea    rcx,[rdx+rsi*1]
  c104e1:	mov    rax,r12
  c104e4:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c104e9:	mov    rdx,QWORD PTR [rsp+0x28]
  c104ee:	mov    r9,QWORD PTR [rsp+0x550]
  c104f6:	jae    c11612 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1cf2>
  c104fc:	mov    rax,QWORD PTR [rcx+0x28]
  c10500:	shl    r12d,0x4
  c10504:	mov    rax,QWORD PTR [rax+r12*1]
  c10508:	jmp    c11616 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1cf6>
  c1050d:	mov    rdx,QWORD PTR [rsp+0x18]
  c10512:	lea    rcx,[rdx+0x10]
  c10516:	mov    rsi,QWORD PTR [rcx]
  c10519:	cmp    QWORD PTR [rsp+0x8],rsi
  c1051e:	jae    c19ad1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1b1>
  c10524:	lea    rcx,[rdx+0x8]
  c10528:	mov    rbx,QWORD PTR [rcx]
  c1052b:	movzx  edx,bpl
  c1052f:	mov    rcx,QWORD PTR [rsp+0x20]
  c10534:	mov    rbp,QWORD PTR [rbx+rcx*1+0x30]
  c10539:	add    rbx,rcx
  c1053c:	mov    rcx,rdx
  c1053f:	sub    rcx,rbp
  c10542:	jae    c10efb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15db>
  c10548:	mov    rcx,QWORD PTR [rbx+0x28]
  c1054c:	shl    edx,0x4
  c1054f:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c10553:	jmp    c10eff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15df>
  c10558:	mov    rcx,QWORD PTR [rsp+0x18]
  c1055d:	lea    rax,[rcx+0x10]
  c10561:	mov    rsi,QWORD PTR [rax]
  c10564:	cmp    QWORD PTR [rsp+0x8],rsi
  c10569:	jae    c19b73 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa253>
  c1056f:	lea    rax,[rcx+0x8]
  c10573:	mov    rdx,QWORD PTR [rax]
  c10576:	mov    rsi,QWORD PTR [rsp+0x20]
  c1057b:	lea    rcx,[rdx+rsi*1]
  c1057f:	mov    rax,r12
  c10582:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c10587:	mov    rbp,QWORD PTR [rsp+0x30]
  c1058c:	jae    c10f74 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1654>
  c10592:	mov    rax,QWORD PTR [rcx+0x28]
  c10596:	shl    r12d,0x4
  c1059a:	mov    rax,QWORD PTR [rax+r12*1]
  c1059e:	jmp    c10f78 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1658>
  c105a3:	mov    rcx,QWORD PTR [rsp+0x18]
  c105a8:	lea    rax,[rcx+0x10]
  c105ac:	mov    rsi,QWORD PTR [rax]
  c105af:	cmp    QWORD PTR [rsp+0x8],rsi
  c105b4:	jae    c19a77 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa157>
  c105ba:	lea    r14,[rcx+0x8]
  c105be:	mov    rdx,QWORD PTR [r14]
  c105c1:	mov    rsi,QWORD PTR [rsp+0x20]
  c105c6:	lea    rcx,[rdx+rsi*1]
  c105ca:	mov    rax,r12
  c105cd:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c105d2:	mov    r8,QWORD PTR [rsp+0x4b8]
  c105da:	jae    c11000 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16e0>
  c105e0:	mov    rax,QWORD PTR [rcx+0x28]
  c105e4:	shl    r12d,0x4
  c105e8:	mov    rax,QWORD PTR [rax+r12*1]
  c105ec:	jmp    c11004 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16e4>
  c105f1:	mov    rax,QWORD PTR [rsp+0x18]
  c105f6:	lea    r10,[rax+0x10]
  c105fa:	mov    rsi,QWORD PTR [r10]
  c105fd:	cmp    QWORD PTR [rsp+0x8],rsi
  c10602:	jae    c19a89 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa169>
  c10608:	lea    r8,[rax+0x8]
  c1060c:	mov    rsi,QWORD PTR [r8]
  c1060f:	mov    rdi,QWORD PTR [rsp+0x20]
  c10614:	lea    rdx,[rsi+rdi*1]
  c10618:	movzx  ecx,bpl
  c1061c:	mov    rax,rcx
  c1061f:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c10624:	jae    c11056 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1736>
  c1062a:	mov    rax,QWORD PTR [rdx+0x28]
  c1062e:	shl    ecx,0x4
  c10631:	mov    rax,QWORD PTR [rax+rcx*1]
  c10635:	jmp    c1105a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x173a>
  c1063a:	cmp    QWORD PTR [rsp+0x4e0],rbp
  c10642:	jbe    c1750e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7bee>
  c10648:	mov    rax,QWORD PTR [rsp+0x1c8]
  c10650:	cmp    QWORD PTR [rax+0x10],rbp
  c10654:	jbe    c179dc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80bc>
  c1065a:	mov    rax,QWORD PTR [rax+0x8]
  c1065e:	lea    rdx,[rbp*2+0x0]
  c10666:	add    rdx,rbp
  c10669:	mov    ecx,DWORD PTR [rax+rdx*8]
  c1066c:	lea    esi,[rcx-0x2]
  c1066f:	cmp    rcx,0x2
  c10673:	mov    edi,0x3
  c10678:	cmovae edi,esi
  c1067b:	lea    rax,[rax+rdx*8]
  c1067f:	lea    rdx,[rip+0xffffffffff6b569e]        # 2c5d24 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1363>
  c10686:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c1068a:	add    rsi,rdx
  c1068d:	jmp    rsi
  c1068f:	mov    rbx,QWORD PTR [rax]
  c10692:	mov    r8,QWORD PTR [rax+0x8]
  c10696:	mov    rcx,QWORD PTR [rax+0x10]
  c1069a:	mov    rax,QWORD PTR [rsp+0x18]
  c1069f:	lea    rdx,[rax+0x8]
  c106a3:	mov    rdi,QWORD PTR [rsp+0x28]
  c106a8:	lea    rsi,[rax+0x10]
  c106ac:	mov    rbp,QWORD PTR [rsp+0x30]
  c106b1:	jmp    c142b8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4998>
  c106b6:	mov    rcx,QWORD PTR [rsp+0x18]
  c106bb:	lea    r14,[rcx+0x8]
  c106bf:	mov    rsi,QWORD PTR [r14]
  c106c2:	lea    rbx,[rcx+0x10]
  c106c6:	mov    rdx,QWORD PTR [rbx]
  c106c9:	mov    rdi,QWORD PTR [rsp+0x28]
  c106ce:	mov    rcx,QWORD PTR [rdi+0x8]
  c106d2:	mov    r8,QWORD PTR [rdi+0x10]
  c106d6:	sub    rsp,0x8
  c106da:	movzx  eax,al
  c106dd:	movzx  r10d,bpl
  c106e1:	lea    rdi,[rsp+0x118]
  c106e9:	mov    r9,QWORD PTR [rsp+0x10]
  c106ee:	push   rax
  c106ef:	push   r10
  c106f1:	push   r12
  c106f3:	call   c078e0 <_RINvCsbxgXiyEKxkX_6bsl_vm5binopNvMNtCs54fMbAdz0qV_6bsl_rt5valueNtBw_8BslValue3mulEB2_>
  c106f8:	add    rsp,0x20
  c106fc:	cmp    BYTE PTR [rsp+0x110],0xff
  c10704:	jne    c197bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9d>
  c1070a:	mov    rsi,QWORD PTR [rbx]
  c1070d:	cmp    QWORD PTR [rsp+0x8],rsi
  c10712:	mov    r12,QWORD PTR [rsp+0x10]
  c10717:	jb     c14128 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4808>
  c1071d:	jmp    c19c31 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa311>
  c10722:	mov    rcx,QWORD PTR [rsp+0x18]
  c10727:	lea    rax,[rcx+0x10]
  c1072b:	mov    rsi,QWORD PTR [rax]
  c1072e:	cmp    QWORD PTR [rsp+0x8],rsi
  c10733:	jae    c19b97 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa277>
  c10739:	lea    r14,[rcx+0x8]
  c1073d:	mov    r9,QWORD PTR [r14]
  c10740:	mov    rcx,QWORD PTR [rsp+0x20]
  c10745:	mov    rax,QWORD PTR [r9+rcx*1+0x30]
  c1074a:	add    r9,rcx
  c1074d:	mov    rcx,r12
  c10750:	sub    rcx,rax
  c10753:	jae    c110ac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x178c>
  c10759:	mov    rcx,QWORD PTR [r9+0x28]
  c1075d:	shl    r12d,0x4
  c10761:	mov    rcx,QWORD PTR [rcx+r12*1]
  c10765:	jmp    c110b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1790>
  c1076a:	mov    rcx,QWORD PTR [rsp+0x18]
  c1076f:	lea    r11,[rcx+0x10]
  c10773:	mov    rsi,QWORD PTR [r11]
  c10776:	cmp    QWORD PTR [rsp+0x8],rsi
  c1077b:	jae    c19b2b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa20b>
  c10781:	lea    r9,[rcx+0x8]
  c10785:	mov    rdi,QWORD PTR [r9]
  c10788:	mov    r8,QWORD PTR [rsp+0x20]
  c1078d:	lea    rsi,[rdi+r8*1]
  c10791:	movzx  edx,bpl
  c10795:	mov    rcx,rdx
  c10798:	sub    rcx,QWORD PTR [rdi+r8*1+0x30]
  c1079d:	jae    c11111 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x17f1>
  c107a3:	mov    rcx,QWORD PTR [rsi+0x28]
  c107a7:	shl    edx,0x4
  c107aa:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c107ae:	jmp    c11115 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x17f5>
  c107b3:	mov    rcx,QWORD PTR [rsp+0x18]
  c107b8:	lea    rax,[rcx+0x10]
  c107bc:	mov    rsi,QWORD PTR [rax]
  c107bf:	cmp    QWORD PTR [rsp+0x8],rsi
  c107c4:	jae    c19a41 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa121>
  c107ca:	lea    r14,[rcx+0x8]
  c107ce:	mov    rdx,QWORD PTR [r14]
  c107d1:	mov    rsi,QWORD PTR [rsp+0x20]
  c107d6:	lea    rcx,[rdx+rsi*1]
  c107da:	mov    rax,r12
  c107dd:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c107e2:	jae    c11164 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1844>
  c107e8:	mov    rax,QWORD PTR [rcx+0x28]
  c107ec:	shl    r12d,0x4
  c107f0:	mov    rax,QWORD PTR [rax+r12*1]
  c107f4:	jmp    c11168 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1848>
  c107f9:	mov    rdx,QWORD PTR [rsp+0x18]
  c107fe:	lea    rcx,[rdx+0x10]
  c10802:	mov    rsi,QWORD PTR [rcx]
  c10805:	cmp    QWORD PTR [rsp+0x8],rsi
  c1080a:	jae    c19b19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa1f9>
  c10810:	lea    rbx,[rdx+0x8]
  c10814:	mov    rdi,QWORD PTR [rbx]
  c10817:	mov    r8,QWORD PTR [rsp+0x20]
  c1081c:	lea    rsi,[rdi+r8*1]
  c10820:	movzx  edx,bpl
  c10824:	mov    rcx,rdx
  c10827:	sub    rcx,QWORD PTR [rdi+r8*1+0x30]
  c1082c:	jae    c111ba <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x189a>
  c10832:	mov    rcx,QWORD PTR [rsi+0x28]
  c10836:	shl    edx,0x4
  c10839:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c1083d:	jmp    c111be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x189e>
  c10842:	mov    rcx,QWORD PTR [rsp+0x18]
  c10847:	lea    rax,[rcx+0x10]
  c1084b:	mov    rsi,QWORD PTR [rax]
  c1084e:	cmp    QWORD PTR [rsp+0x8],rsi
  c10853:	jae    c19a65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa145>
  c10859:	lea    rbx,[rcx+0x8]
  c1085d:	mov    rsi,QWORD PTR [rbx]
  c10860:	mov    rdi,QWORD PTR [rsp+0x20]
  c10865:	lea    rdx,[rsi+rdi*1]
  c10869:	movzx  ecx,bpl
  c1086d:	mov    rax,rcx
  c10870:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c10875:	jae    c11212 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x18f2>
  c1087b:	mov    rax,QWORD PTR [rdx+0x28]
  c1087f:	shl    ecx,0x4
  c10882:	mov    rax,QWORD PTR [rax+rcx*1]
  c10886:	jmp    c11216 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x18f6>
  c1088b:	mov    rcx,QWORD PTR [rsp+0x18]
  c10890:	lea    rax,[rcx+0x10]
  c10894:	mov    rsi,QWORD PTR [rax]
  c10897:	cmp    QWORD PTR [rsp+0x8],rsi
  c1089c:	jae    c19bbb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa29b>
  c108a2:	lea    r14,[rcx+0x8]
  c108a6:	mov    rdx,QWORD PTR [r14]
  c108a9:	mov    rcx,QWORD PTR [rsp+0x20]
  c108ae:	mov    rax,QWORD PTR [rdx+rcx*1+0x50]
  c108b3:	cmp    rax,QWORD PTR [rsp+0x3b0]
  c108bb:	jae    c17548 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7c28>
  c108c1:	add    rdx,rcx
  c108c4:	mov    rcx,r12
  c108c7:	sub    rcx,QWORD PTR [rdx+0x30]
  c108cb:	jae    c11715 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1df5>
  c108d1:	mov    rcx,QWORD PTR [rdx+0x28]
  c108d5:	shl    r12d,0x4
  c108d9:	mov    rcx,QWORD PTR [rcx+r12*1]
  c108dd:	jmp    c11719 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1df9>
  c108e2:	mov    rcx,QWORD PTR [rsp+0x18]
  c108e7:	lea    rax,[rcx+0x10]
  c108eb:	mov    rsi,QWORD PTR [rax]
  c108ee:	cmp    QWORD PTR [rsp+0x8],rsi
  c108f3:	jae    c19a53 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa133>
  c108f9:	lea    rbx,[rcx+0x8]
  c108fd:	mov    rsi,QWORD PTR [rbx]
  c10900:	mov    rdi,QWORD PTR [rsp+0x20]
  c10905:	lea    rdx,[rsi+rdi*1]
  c10909:	movzx  ecx,bpl
  c1090d:	mov    rax,rcx
  c10910:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c10915:	jae    c11268 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1948>
  c1091b:	mov    rax,QWORD PTR [rdx+0x28]
  c1091f:	shl    ecx,0x4
  c10922:	mov    rax,QWORD PTR [rax+rcx*1]
  c10926:	jmp    c1126c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x194c>
  c1092b:	mov    DWORD PTR [rsp+0x3c],r15d
  c10930:	mov    QWORD PTR [rsp+0x1a8],r13
  c10938:	mov    rax,QWORD PTR [rsp+0x18]
  c1093d:	lea    r14,[rax+0x8]
  c10941:	mov    rdx,QWORD PTR [r14]
  c10944:	mov    r15,QWORD PTR [rsp+0x8]
  c10949:	lea    r13,[rax+0x10]
  c1094d:	mov    rcx,QWORD PTR [r13+0x0]
  c10951:	mov    rax,QWORD PTR [rsp+0x28]
  c10956:	mov    r8,QWORD PTR [rax+0x8]
  c1095a:	mov    r9,QWORD PTR [rax+0x10]
  c1095e:	movzx  eax,bpl
  c10962:	lea    rdi,[rsp+0x110]
  c1096a:	mov    rsi,QWORD PTR [rsp+0x1c0]
  c10972:	push   rbx
  c10973:	push   rax
  c10974:	push   r12
  c10976:	push   r15
  c10978:	call   c0c820 <_RNvCsbxgXiyEKxkX_6bsl_vm12add_const_op>
  c1097d:	add    rsp,0x20
  c10981:	cmp    BYTE PTR [rsp+0x110],0xff
  c10989:	jne    c197bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e9d>
  c1098f:	mov    rsi,QWORD PTR [r13+0x0]
  c10993:	cmp    r15,rsi
  c10996:	mov    r12,QWORD PTR [rsp+0x10]
  c1099b:	jae    c19d39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa419>
  c109a1:	mov    rax,QWORD PTR [r14]
  c109a4:	mov    rcx,QWORD PTR [rsp+0x20]
  c109a9:	inc    QWORD PTR [rax+rcx*1+0x58]
  c109ae:	mov    rbp,QWORD PTR [rsp+0x30]
  c109b3:	mov    r13,QWORD PTR [rsp+0x1a8]
  c109bb:	mov    r15d,DWORD PTR [rsp+0x3c]
  c109c0:	test   r15b,r15b
  c109c3:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c109c9:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c109ce:	mov    rcx,QWORD PTR [rsp+0x18]
  c109d3:	lea    rax,[rcx+0x10]
  c109d7:	mov    rsi,QWORD PTR [rax]
  c109da:	cmp    QWORD PTR [rsp+0x8],rsi
  c109df:	jae    c19a0b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0eb>
  c109e5:	lea    rbx,[rcx+0x8]
  c109e9:	mov    rsi,QWORD PTR [rbx]
  c109ec:	mov    rdi,QWORD PTR [rsp+0x20]
  c109f1:	lea    rdx,[rsi+rdi*1]
  c109f5:	movzx  ecx,bpl
  c109f9:	mov    rax,rcx
  c109fc:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c10a01:	jae    c112be <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x199e>
  c10a07:	mov    rax,QWORD PTR [rdx+0x28]
  c10a0b:	shl    ecx,0x4
  c10a0e:	mov    rax,QWORD PTR [rax+rcx*1]
  c10a12:	jmp    c112c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19a2>
  c10a17:	mov    rcx,QWORD PTR [rsp+0x18]
  c10a1c:	lea    r11,[rcx+0x10]
  c10a20:	mov    rsi,QWORD PTR [r11]
  c10a23:	cmp    QWORD PTR [rsp+0x8],rsi
  c10a28:	jae    c19a1d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0fd>
  c10a2e:	lea    r9,[rcx+0x8]
  c10a32:	mov    rdi,QWORD PTR [r9]
  c10a35:	mov    r8,QWORD PTR [rsp+0x20]
  c10a3a:	lea    rsi,[rdi+r8*1]
  c10a3e:	movzx  edx,bpl
  c10a42:	mov    rcx,rdx
  c10a45:	sub    rcx,QWORD PTR [rdi+r8*1+0x30]
  c10a4a:	jae    c11314 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19f4>
  c10a50:	mov    rcx,QWORD PTR [rsi+0x28]
  c10a54:	shl    edx,0x4
  c10a57:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c10a5b:	jmp    c11318 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x19f8>
  c10a60:	mov    DWORD PTR [rsp+0x3c],r15d
  c10a65:	mov    rcx,QWORD PTR [rsp+0x18]
  c10a6a:	lea    rax,[rcx+0x10]
  c10a6e:	mov    rsi,QWORD PTR [rax]
  c10a71:	cmp    QWORD PTR [rsp+0x8],rsi
  c10a76:	jae    c19b61 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa241>
  c10a7c:	lea    r14,[rcx+0x8]
  c10a80:	mov    rax,QWORD PTR [r14]
  c10a83:	mov    rdx,QWORD PTR [rsp+0x20]
  c10a88:	mov    rcx,QWORD PTR [rax+rdx*1+0x30]
  c10a8d:	add    rax,rdx
  c10a90:	mov    r15,r12
  c10a93:	sub    r15,rcx
  c10a96:	jae    c11367 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a47>
  c10a9c:	mov    rdx,QWORD PTR [rax+0x28]
  c10aa0:	shl    r12d,0x4
  c10aa4:	mov    r15,QWORD PTR [rdx+r12*1]
  c10aa8:	jmp    c1136b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a4b>
  c10aad:	mov    rcx,QWORD PTR [rsp+0x18]
  c10ab2:	lea    rax,[rcx+0x10]
  c10ab6:	mov    rsi,QWORD PTR [rax]
  c10ab9:	cmp    QWORD PTR [rsp+0x8],rsi
  c10abe:	jae    c19b3d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa21d>
  c10ac4:	lea    r14,[rcx+0x8]
  c10ac8:	mov    rdx,QWORD PTR [r14]
  c10acb:	mov    rsi,QWORD PTR [rsp+0x20]
  c10ad0:	lea    rcx,[rdx+rsi*1]
  c10ad4:	mov    rax,r12
  c10ad7:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c10adc:	jae    c114ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1bce>
  c10ae2:	mov    rax,QWORD PTR [rcx+0x28]
  c10ae6:	shl    r12d,0x4
  c10aea:	mov    rax,QWORD PTR [rax+r12*1]
  c10aee:	jmp    c114f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1bd2>
  c10af3:	mov    rcx,QWORD PTR [rsp+0x18]
  c10af8:	lea    rax,[rcx+0x10]
  c10afc:	mov    rsi,QWORD PTR [rax]
  c10aff:	cmp    QWORD PTR [rsp+0x8],rsi
  c10b04:	jae    c19a9b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa17b>
  c10b0a:	lea    r14,[rcx+0x8]
  c10b0e:	mov    rdx,QWORD PTR [r14]
  c10b11:	mov    rcx,QWORD PTR [rsp+0x20]
  c10b16:	mov    rax,QWORD PTR [rdx+rcx*1+0x50]
  c10b1b:	cmp    rax,QWORD PTR [rsp+0x3b0]
  c10b23:	jae    c17548 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7c28>
  c10b29:	add    rdx,rcx
  c10b2c:	mov    rcx,r12
  c10b2f:	sub    rcx,QWORD PTR [rdx+0x30]
  c10b33:	jae    c1176d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e4d>
  c10b39:	mov    rcx,QWORD PTR [rdx+0x28]
  c10b3d:	shl    r12d,0x4
  c10b41:	mov    rcx,QWORD PTR [rcx+r12*1]
  c10b45:	jmp    c11771 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1e51>
  c10b4a:	add    rax,QWORD PTR [rdx+0x60]
  c10b4e:	mov    rbp,QWORD PTR [rsp+0x30]
  c10b53:	mov    rcx,QWORD PTR [rsp+0x28]
  c10b58:	cmp    rax,QWORD PTR [rcx+0x10]
  c10b5c:	jae    c17707 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7de7>
  c10b62:	mov    rdx,QWORD PTR [rcx+0x8]
  c10b66:	lea    rax,[rax+rax*2]
  c10b6a:	mov    ecx,DWORD PTR [rdx+rax*8]
  c10b6d:	lea    esi,[rcx-0x2]
  c10b70:	cmp    rcx,0x2
  c10b74:	mov    edi,0x3
  c10b79:	cmovae edi,esi
  c10b7c:	lea    rax,[rdx+rax*8]
  c10b80:	lea    rdx,[rip+0xffffffffff6b4d3d]        # 2c58c4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf03>
  c10b87:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c10b8b:	add    rsi,rdx
  c10b8e:	jmp    rsi
  c10b90:	mov    rdx,QWORD PTR [rax]
  c10b93:	mov    rsi,QWORD PTR [rax+0x8]
  c10b97:	mov    rcx,QWORD PTR [rax+0x10]
  c10b9b:	mov    rax,QWORD PTR [rsp+0x1a0]
  c10ba3:	jmp    c11d1c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x23fc>
  c10ba8:	add    rcx,QWORD PTR [rsi+0x60]
  c10bac:	mov    rdx,QWORD PTR [rsp+0x28]
  c10bb1:	cmp    rcx,QWORD PTR [rdx+0x10]
  c10bb5:	jae    c176db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7dbb>
  c10bbb:	mov    rsi,QWORD PTR [rdx+0x8]
  c10bbf:	lea    rcx,[rcx+rcx*2]
  c10bc3:	mov    edx,DWORD PTR [rsi+rcx*8]
  c10bc6:	lea    edi,[rdx-0x2]
  c10bc9:	cmp    rdx,0x2
  c10bcd:	mov    r8d,0x3
  c10bd3:	cmovae r8d,edi
  c10bd7:	lea    rcx,[rsi+rcx*8]
  c10bdb:	lea    rsi,[rip+0xffffffffff6b4c0a]        # 2c57ec <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe2b>
  c10be2:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c10be6:	add    rdi,rsi
  c10be9:	jmp    rdi
  c10beb:	mov    rsi,QWORD PTR [rcx]
  c10bee:	mov    rdi,QWORD PTR [rcx+0x8]
  c10bf2:	mov    rcx,QWORD PTR [rcx+0x10]
  c10bf6:	jmp    c12211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28f1>
  c10bfb:	add    rcx,QWORD PTR [rbx+0x60]
  c10bff:	mov    rdx,QWORD PTR [rsp+0x28]
  c10c04:	mov    r13,QWORD PTR [rdx+0x10]
  c10c08:	cmp    rcx,r13
  c10c0b:	jae    c1775f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e3f>
  c10c11:	mov    r14,QWORD PTR [rdx+0x8]
  c10c15:	lea    rcx,[rcx+rcx*2]
  c10c19:	mov    esi,DWORD PTR [r14+rcx*8]
  c10c1d:	lea    edx,[rsi-0x2]
  c10c20:	cmp    rsi,0x2
  c10c24:	mov    edi,0x3
  c10c29:	cmovae edi,edx
  c10c2c:	lea    rdx,[r14+rcx*8]
  c10c30:	lea    rcx,[rip+0xffffffffff6b4e6d]        # 2c5aa4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x10e3>
  c10c37:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10c3b:	add    rdi,rcx
  c10c3e:	jmp    rdi
  c10c40:	mov    rcx,QWORD PTR [rdx]
  c10c43:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10c48:	mov    QWORD PTR [rsp+0x40],rcx
  c10c4d:	movdqu XMMWORD PTR [rsp+0x48],xmm0
  c10c53:	movzx  ecx,ax
  c10c56:	mov    rax,rcx
  c10c59:	sub    rax,r9
  c10c5c:	jae    c117c5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ea5>
  c10c62:	mov    rax,QWORD PTR [rbx+0x28]
  c10c66:	shl    ecx,0x4
  c10c69:	mov    rax,QWORD PTR [rax+rcx*1]
  c10c6d:	jmp    c117c9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1ea9>
  c10c72:	add    rcx,QWORD PTR [rbx+0x60]
  c10c76:	mov    rdx,QWORD PTR [rsp+0x28]
  c10c7b:	mov    rbp,QWORD PTR [rdx+0x10]
  c10c7f:	cmp    rcx,rbp
  c10c82:	jae    c1752e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7c0e>
  c10c88:	mov    DWORD PTR [rsp+0x3c],r15d
  c10c8d:	mov    QWORD PTR [rsp+0x1a8],r13
  c10c95:	mov    r15,QWORD PTR [rdx+0x8]
  c10c99:	lea    rcx,[rcx+rcx*2]
  c10c9d:	mov    esi,DWORD PTR [r15+rcx*8]
  c10ca1:	lea    edx,[rsi-0x2]
  c10ca4:	cmp    rsi,0x2
  c10ca8:	mov    edi,0x3
  c10cad:	cmovae edi,edx
  c10cb0:	lea    rdx,[r15+rcx*8]
  c10cb4:	lea    rcx,[rip+0xffffffffff6b4e89]        # 2c5b44 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1183>
  c10cbb:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10cbf:	add    rdi,rcx
  c10cc2:	jmp    rdi
  c10cc4:	mov    rcx,QWORD PTR [rdx]
  c10cc7:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10ccc:	mov    QWORD PTR [rsp+0x40],rcx
  c10cd1:	movdqu XMMWORD PTR [rsp+0x48],xmm0
  c10cd7:	movzx  ecx,ax
  c10cda:	mov    rax,rcx
  c10cdd:	sub    rax,r14
  c10ce0:	jae    c1180a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1eea>
  c10ce6:	mov    rax,QWORD PTR [rbx+0x28]
  c10cea:	shl    ecx,0x4
  c10ced:	mov    rax,QWORD PTR [rax+rcx*1]
  c10cf1:	jmp    c1180e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1eee>
  c10cf6:	add    rcx,QWORD PTR [rbx+0x60]
  c10cfa:	mov    rdx,QWORD PTR [rsp+0x28]
  c10cff:	mov    rbp,QWORD PTR [rdx+0x10]
  c10d03:	cmp    rcx,rbp
  c10d06:	jae    c1752e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7c0e>
  c10d0c:	mov    DWORD PTR [rsp+0x3c],r15d
  c10d11:	mov    QWORD PTR [rsp+0x1a8],r13
  c10d19:	mov    r15,QWORD PTR [rdx+0x8]
  c10d1d:	lea    rcx,[rcx+rcx*2]
  c10d21:	mov    esi,DWORD PTR [r15+rcx*8]
  c10d25:	lea    edx,[rsi-0x2]
  c10d28:	cmp    rsi,0x2
  c10d2c:	mov    edi,0x3
  c10d31:	cmovae edi,edx
  c10d34:	lea    rdx,[r15+rcx*8]
  c10d38:	lea    rcx,[rip+0xffffffffff6b4db5]        # 2c5af4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1133>
  c10d3f:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10d43:	add    rdi,rcx
  c10d46:	jmp    rdi
  c10d48:	mov    rcx,QWORD PTR [rdx]
  c10d4b:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10d50:	mov    QWORD PTR [rsp+0x40],rcx
  c10d55:	movdqu XMMWORD PTR [rsp+0x48],xmm0
  c10d5b:	movzx  ecx,ax
  c10d5e:	mov    rax,rcx
  c10d61:	sub    rax,r14
  c10d64:	jae    c1184f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f2f>
  c10d6a:	mov    rax,QWORD PTR [rbx+0x28]
  c10d6e:	shl    ecx,0x4
  c10d71:	mov    rax,QWORD PTR [rax+rcx*1]
  c10d75:	jmp    c11853 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f33>
  c10d7a:	add    rcx,QWORD PTR [rdx+0x60]
  c10d7e:	mov    r12,QWORD PTR [rsp+0x10]
  c10d83:	mov    rdx,QWORD PTR [rsp+0x28]
  c10d88:	cmp    rcx,QWORD PTR [rdx+0x10]
  c10d8c:	jae    c17733 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e13>
  c10d92:	mov    rsi,QWORD PTR [rdx+0x8]
  c10d96:	lea    rcx,[rcx+rcx*2]
  c10d9a:	mov    edx,DWORD PTR [rsi+rcx*8]
  c10d9d:	lea    edi,[rdx-0x2]
  c10da0:	cmp    rdx,0x2
  c10da4:	mov    r8d,0x3
  c10daa:	cmovae r8d,edi
  c10dae:	lea    rcx,[rsi+rcx*8]
  c10db2:	lea    rsi,[rip+0xffffffffff6b4b33]        # 2c58ec <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf2b>
  c10db9:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c10dbd:	add    rdi,rsi
  c10dc0:	jmp    rdi
  c10dc2:	mov    r8,QWORD PTR [rcx]
  c10dc5:	mov    rsi,QWORD PTR [rcx+0x8]
  c10dc9:	mov    rcx,QWORD PTR [rcx+0x10]
  c10dcd:	jmp    c129bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x309d>
  c10dd2:	add    rax,QWORD PTR [rcx+0x60]
  c10dd6:	mov    r12,QWORD PTR [rsp+0x10]
  c10ddb:	mov    rdx,QWORD PTR [rsp+0x28]
  c10de0:	mov    rcx,QWORD PTR [rdx+0x8]
  c10de4:	and    bpl,0x1
  c10de8:	mov    BYTE PTR [rsp+0x114],bpl
  c10df0:	mov    DWORD PTR [rsp+0x110],0x4
  c10dfb:	cmp    rax,QWORD PTR [rdx+0x10]
  c10dff:	jae    c17986 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8066>
  c10e05:	lea    rax,[rax+rax*2]
  c10e09:	lea    r14,[rcx+rax*8]
  c10e0d:	mov    eax,DWORD PTR [rcx+rax*8]
  c10e10:	mov    edx,eax
  c10e12:	sub    edx,0x2
  c10e15:	mov    ecx,0x3
  c10e1a:	cmovae ecx,edx
  c10e1d:	cmp    ecx,0x8
  c10e20:	ja     c13c9e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x437e>
  c10e26:	mov    edx,0x1e7
  c10e2b:	bt     edx,ecx
  c10e2e:	mov    rbp,QWORD PTR [rsp+0x30]
  c10e33:	jae    c11a27 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2107>
  c10e39:	mov    rax,QWORD PTR [rsp+0x120]
  c10e41:	mov    QWORD PTR [r14+0x10],rax
  c10e45:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c10e4e:	movdqu XMMWORD PTR [r14],xmm0
  c10e53:	mov    rcx,QWORD PTR [rsp+0x18]
  c10e58:	lea    rax,[rcx+0x10]
  c10e5c:	mov    rsi,QWORD PTR [rax]
  c10e5f:	cmp    QWORD PTR [rsp+0x8],rsi
  c10e64:	jb     c15fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66aa>
  c10e6a:	jmp    c19ce7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3c7>
  c10e6f:	add    rax,QWORD PTR [rcx+0x60]
  c10e73:	mov    r12,QWORD PTR [rsp+0x10]
  c10e78:	mov    rdx,QWORD PTR [rsp+0x28]
  c10e7d:	mov    rcx,QWORD PTR [rdx+0x8]
  c10e81:	mov    DWORD PTR [rsp+0x110],0x2
  c10e8c:	cmp    rax,QWORD PTR [rdx+0x10]
  c10e90:	jae    c179bc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x809c>
  c10e96:	lea    rax,[rax+rax*2]
  c10e9a:	lea    r14,[rcx+rax*8]
  c10e9e:	mov    eax,DWORD PTR [rcx+rax*8]
  c10ea1:	mov    edx,eax
  c10ea3:	sub    edx,0x2
  c10ea6:	mov    ecx,0x3
  c10eab:	cmovae ecx,edx
  c10eae:	cmp    ecx,0x8
  c10eb1:	ja     c14004 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x46e4>
  c10eb7:	mov    edx,0x1e7
  c10ebc:	bt     edx,ecx
  c10ebf:	jae    c11a54 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2134>
  c10ec5:	mov    rax,QWORD PTR [rsp+0x120]
  c10ecd:	mov    QWORD PTR [r14+0x10],rax
  c10ed1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c10eda:	movdqu XMMWORD PTR [r14],xmm0
  c10edf:	mov    rcx,QWORD PTR [rsp+0x18]
  c10ee4:	lea    rax,[rcx+0x10]
  c10ee8:	mov    rsi,QWORD PTR [rax]
  c10eeb:	cmp    QWORD PTR [rsp+0x8],rsi
  c10ef0:	jb     c15fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66aa>
  c10ef6:	jmp    c19c88 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa368>
  c10efb:	add    rcx,QWORD PTR [rbx+0x60]
  c10eff:	mov    rdx,QWORD PTR [rsp+0x28]
  c10f04:	mov    r14,QWORD PTR [rdx+0x10]
  c10f08:	cmp    rcx,r14
  c10f0b:	jae    c1788c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f6c>
  c10f11:	mov    DWORD PTR [rsp+0x3c],r15d
  c10f16:	mov    r15,QWORD PTR [rdx+0x8]
  c10f1a:	lea    rcx,[rcx+rcx*2]
  c10f1e:	mov    esi,DWORD PTR [r15+rcx*8]
  c10f22:	lea    edx,[rsi-0x2]
  c10f25:	cmp    rsi,0x2
  c10f29:	mov    edi,0x3
  c10f2e:	cmovae edi,edx
  c10f31:	lea    rdx,[r15+rcx*8]
  c10f35:	lea    rcx,[rip+0xffffffffff6b4c58]        # 2c5b94 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x11d3>
  c10f3c:	movsxd rdi,DWORD PTR [rcx+rdi*4]
  c10f40:	add    rdi,rcx
  c10f43:	jmp    rdi
  c10f45:	mov    rcx,QWORD PTR [rdx]
  c10f48:	movdqu xmm0,XMMWORD PTR [rdx+0x8]
  c10f4d:	mov    QWORD PTR [rsp+0x40],rcx
  c10f52:	movdqu XMMWORD PTR [rsp+0x48],xmm0
  c10f58:	mov    rcx,rax
  c10f5b:	sub    rcx,rbp
  c10f5e:	jae    c11894 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f74>
  c10f64:	mov    rcx,QWORD PTR [rbx+0x28]
  c10f68:	shl    eax,0x4
  c10f6b:	mov    rcx,QWORD PTR [rcx+rax*1]
  c10f6f:	jmp    c11898 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1f78>
  c10f74:	add    rax,QWORD PTR [rcx+0x60]
  c10f78:	mov    r12,QWORD PTR [rsp+0x10]
  c10f7d:	mov    rdx,QWORD PTR [rsp+0x28]
  c10f82:	mov    rcx,QWORD PTR [rdx+0x8]
  c10f86:	mov    DWORD PTR [rsp+0x110],0x3
  c10f91:	cmp    rax,QWORD PTR [rdx+0x10]
  c10f95:	jae    c17829 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f09>
  c10f9b:	lea    rax,[rax+rax*2]
  c10f9f:	lea    r14,[rcx+rax*8]
  c10fa3:	mov    eax,DWORD PTR [rcx+rax*8]
  c10fa6:	mov    edx,eax
  c10fa8:	sub    edx,0x2
  c10fab:	mov    ecx,0x3
  c10fb0:	cmovae ecx,edx
  c10fb3:	cmp    ecx,0x8
  c10fb6:	ja     c1403d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x471d>
  c10fbc:	mov    edx,0x1e7
  c10fc1:	bt     edx,ecx
  c10fc4:	jae    c11a81 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2161>
  c10fca:	mov    rax,QWORD PTR [rsp+0x120]
  c10fd2:	mov    QWORD PTR [r14+0x10],rax
  c10fd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c10fdf:	movdqu XMMWORD PTR [r14],xmm0
  c10fe4:	mov    rcx,QWORD PTR [rsp+0x18]
  c10fe9:	lea    rax,[rcx+0x10]
  c10fed:	mov    rsi,QWORD PTR [rax]
  c10ff0:	cmp    QWORD PTR [rsp+0x8],rsi
  c10ff5:	jb     c15fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66aa>
  c10ffb:	jmp    c19cb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa391>
  c11000:	add    rax,QWORD PTR [rcx+0x60]
  c11004:	mov    r12,QWORD PTR [rsp+0x10]
  c11009:	mov    rcx,QWORD PTR [rsp+0x28]
  c1100e:	cmp    rax,QWORD PTR [rcx+0x10]
  c11012:	jae    c1792a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x800a>
  c11018:	mov    rdx,QWORD PTR [rcx+0x8]
  c1101c:	lea    rax,[rax+rax*2]
  c11020:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11023:	lea    esi,[rcx-0x2]
  c11026:	cmp    rcx,0x2
  c1102a:	mov    edi,0x3
  c1102f:	cmovae edi,esi
  c11032:	lea    rax,[rdx+rax*8]
  c11036:	lea    rdx,[rip+0xffffffffff6b480f]        # 2c584c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe8b>
  c1103d:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c11041:	add    rsi,rdx
  c11044:	jmp    rsi
  c11046:	mov    rdi,QWORD PTR [rax]
  c11049:	mov    rdx,QWORD PTR [rax+0x8]
  c1104d:	mov    rax,QWORD PTR [rax+0x10]
  c11051:	jmp    c12c4b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x332b>
  c11056:	add    rax,QWORD PTR [rdx+0x60]
  c1105a:	mov    r9,QWORD PTR [rsp+0x28]
  c1105f:	mov    rbp,QWORD PTR [rsp+0x30]
  c11064:	cmp    rax,QWORD PTR [r9+0x10]
  c11068:	jae    c1798b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x806b>
  c1106e:	mov    rdx,QWORD PTR [r9+0x8]
  c11072:	lea    rax,[rax+rax*2]
  c11076:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11079:	lea    esi,[rcx-0x2]
  c1107c:	cmp    rcx,0x2
  c11080:	mov    edi,0x3
  c11085:	cmovae edi,esi
  c11088:	lea    rax,[rdx+rax*8]
  c1108c:	lea    rdx,[rip+0xffffffffff6b4cb9]        # 2c5d4c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x138b>
  c11093:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c11097:	add    rsi,rdx
  c1109a:	jmp    rsi
  c1109c:	mov    rsi,QWORD PTR [rax]
  c1109f:	mov    rdx,QWORD PTR [rax+0x8]
  c110a3:	mov    rax,QWORD PTR [rax+0x10]
  c110a7:	jmp    c13123 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3803>
  c110ac:	add    rcx,QWORD PTR [r9+0x60]
  c110b0:	mov    r12,QWORD PTR [rsp+0x10]
  c110b5:	movzx  edx,bpl
  c110b9:	mov    r8,rdx
  c110bc:	sub    r8,rax
  c110bf:	jae    c110ce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x17ae>
  c110c1:	mov    rax,QWORD PTR [r9+0x28]
  c110c5:	shl    edx,0x4
  c110c8:	mov    r8,QWORD PTR [rax+rdx*1]
  c110cc:	jmp    c110d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x17b2>
  c110ce:	add    r8,QWORD PTR [r9+0x60]
  c110d2:	mov    rbp,QWORD PTR [rsp+0x30]
  c110d7:	mov    rax,QWORD PTR [rsp+0x28]
  c110dc:	mov    rsi,QWORD PTR [rax+0x8]
  c110e0:	mov    rdx,QWORD PTR [rax+0x10]
  c110e4:	add    r9,0x58
  c110e8:	sub    rsp,0x8
  c110ec:	lea    rdi,[rsp+0x118]
  c110f4:	push   rbx
  c110f5:	call   c0f6a0 <_RNvCsbxgXiyEKxkX_6bsl_vm24numeric_for_next_regular>
  c110fa:	add    rsp,0x10
  c110fe:	cmp    BYTE PTR [rsp+0x110],0xff
  c11106:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c1110c:	jmp    c1782e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f0e>
  c11111:	add    rcx,QWORD PTR [rsi+0x60]
  c11115:	mov    r10,QWORD PTR [rsp+0x28]
  c1111a:	cmp    rcx,QWORD PTR [r10+0x10]
  c1111e:	jae    c178a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f86>
  c11124:	mov    rsi,QWORD PTR [r10+0x8]
  c11128:	lea    rcx,[rcx+rcx*2]
  c1112c:	mov    edx,DWORD PTR [rsi+rcx*8]
  c1112f:	lea    edi,[rdx-0x2]
  c11132:	cmp    rdx,0x2
  c11136:	mov    r8d,0x3
  c1113c:	cmovae r8d,edi
  c11140:	lea    rcx,[rsi+rcx*8]
  c11144:	lea    rsi,[rip+0xffffffffff6b4a99]        # 2c5be4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1223>
  c1114b:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c1114f:	add    rdi,rsi
  c11152:	jmp    rdi
  c11154:	mov    r8,QWORD PTR [rcx]
  c11157:	mov    rdi,QWORD PTR [rcx+0x8]
  c1115b:	mov    rsi,QWORD PTR [rcx+0x10]
  c1115f:	jmp    c132e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39c6>
  c11164:	add    rax,QWORD PTR [rcx+0x60]
  c11168:	mov    r12,QWORD PTR [rsp+0x10]
  c1116d:	mov    rcx,QWORD PTR [rsp+0x28]
  c11172:	cmp    rax,QWORD PTR [rcx+0x10]
  c11176:	jae    c177a5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e85>
  c1117c:	mov    rdx,QWORD PTR [rcx+0x8]
  c11180:	lea    rax,[rax+rax*2]
  c11184:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11187:	lea    esi,[rcx-0x2]
  c1118a:	cmp    rcx,0x2
  c1118e:	mov    edi,0x3
  c11193:	cmovae edi,esi
  c11196:	lea    rax,[rdx+rax*8]
  c1119a:	lea    rdx,[rip+0xffffffffff6b48b3]        # 2c5a54 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1093>
  c111a1:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c111a5:	add    rsi,rdx
  c111a8:	jmp    rsi
  c111aa:	mov    rdx,QWORD PTR [rax]
  c111ad:	mov    rsi,QWORD PTR [rax+0x8]
  c111b1:	mov    rax,QWORD PTR [rax+0x10]
  c111b5:	jmp    c13520 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c00>
  c111ba:	add    rcx,QWORD PTR [rsi+0x60]
  c111be:	mov    r14,QWORD PTR [rsp+0x28]
  c111c3:	mov    rbp,QWORD PTR [rsp+0x30]
  c111c8:	cmp    rcx,QWORD PTR [r14+0x10]
  c111cc:	jae    c177d1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7eb1>
  c111d2:	mov    rsi,QWORD PTR [r14+0x8]
  c111d6:	lea    rcx,[rcx+rcx*2]
  c111da:	mov    edx,DWORD PTR [rsi+rcx*8]
  c111dd:	lea    edi,[rdx-0x2]
  c111e0:	cmp    rdx,0x2
  c111e4:	mov    r8d,0x3
  c111ea:	cmovae r8d,edi
  c111ee:	lea    rcx,[rsi+rcx*8]
  c111f2:	lea    rsi,[rip+0xffffffffff6b476b]        # 2c5964 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xfa3>
  c111f9:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c111fd:	add    rdi,rsi
  c11200:	jmp    rdi
  c11202:	mov    r8,QWORD PTR [rcx]
  c11205:	mov    rdi,QWORD PTR [rcx+0x8]
  c11209:	mov    rsi,QWORD PTR [rcx+0x10]
  c1120d:	jmp    c1362e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d0e>
  c11212:	add    rax,QWORD PTR [rdx+0x60]
  c11216:	mov    r14,QWORD PTR [rsp+0x28]
  c1121b:	mov    rbp,QWORD PTR [rsp+0x30]
  c11220:	cmp    rax,QWORD PTR [r14+0x10]
  c11224:	jae    c17860 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7f40>
  c1122a:	mov    rdx,QWORD PTR [r14+0x8]
  c1122e:	lea    rax,[rax+rax*2]
  c11232:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11235:	lea    esi,[rcx-0x2]
  c11238:	cmp    rcx,0x2
  c1123c:	mov    edi,0x3
  c11241:	cmovae edi,esi
  c11244:	lea    rax,[rdx+rax*8]
  c11248:	lea    rdx,[rip+0xffffffffff6b45d5]        # 2c5824 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe63>
  c1124f:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c11253:	add    rsi,rdx
  c11256:	jmp    rsi
  c11258:	mov    rdx,QWORD PTR [rax]
  c1125b:	mov    rsi,QWORD PTR [rax+0x8]
  c1125f:	mov    rax,QWORD PTR [rax+0x10]
  c11263:	jmp    c1378c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e6c>
  c11268:	add    rax,QWORD PTR [rdx+0x60]
  c1126c:	mov    r14,QWORD PTR [rsp+0x28]
  c11271:	mov    rbp,QWORD PTR [rsp+0x30]
  c11276:	cmp    rax,QWORD PTR [r14+0x10]
  c1127a:	jae    c177fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7edd>
  c11280:	mov    rdx,QWORD PTR [r14+0x8]
  c11284:	lea    rax,[rax+rax*2]
  c11288:	mov    ecx,DWORD PTR [rdx+rax*8]
  c1128b:	lea    esi,[rcx-0x2]
  c1128e:	cmp    rcx,0x2
  c11292:	mov    edi,0x3
  c11297:	cmovae edi,esi
  c1129a:	lea    rax,[rdx+rax*8]
  c1129e:	lea    rdx,[rip+0xffffffffff6b49df]        # 2c5c84 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x12c3>
  c112a5:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c112a9:	add    rsi,rdx
  c112ac:	jmp    rsi
  c112ae:	mov    rdx,QWORD PTR [rax]
  c112b1:	mov    rsi,QWORD PTR [rax+0x8]
  c112b5:	mov    rax,QWORD PTR [rax+0x10]
  c112b9:	jmp    c13aca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41aa>
  c112be:	add    rax,QWORD PTR [rdx+0x60]
  c112c2:	mov    r14,QWORD PTR [rsp+0x28]
  c112c7:	mov    rbp,QWORD PTR [rsp+0x30]
  c112cc:	cmp    rax,QWORD PTR [r14+0x10]
  c112d0:	jae    c178d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7fb2>
  c112d6:	mov    rdx,QWORD PTR [r14+0x8]
  c112da:	lea    rax,[rax+rax*2]
  c112de:	mov    ecx,DWORD PTR [rdx+rax*8]
  c112e1:	lea    esi,[rcx-0x2]
  c112e4:	cmp    rcx,0x2
  c112e8:	mov    edi,0x3
  c112ed:	cmovae edi,esi
  c112f0:	lea    rax,[rdx+rax*8]
  c112f4:	lea    rdx,[rip+0xffffffffff6b49b1]        # 2c5cac <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x12eb>
  c112fb:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c112ff:	add    rsi,rdx
  c11302:	jmp    rsi
  c11304:	mov    rdx,QWORD PTR [rax]
  c11307:	mov    rsi,QWORD PTR [rax+0x8]
  c1130b:	mov    rax,QWORD PTR [rax+0x10]
  c1130f:	jmp    c13d64 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4444>
  c11314:	add    rcx,QWORD PTR [rsi+0x60]
  c11318:	mov    r10,QWORD PTR [rsp+0x28]
  c1131d:	cmp    rcx,QWORD PTR [r10+0x10]
  c11321:	jae    c178fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7fde>
  c11327:	mov    rsi,QWORD PTR [r10+0x8]
  c1132b:	lea    rcx,[rcx+rcx*2]
  c1132f:	mov    edx,DWORD PTR [rsi+rcx*8]
  c11332:	lea    edi,[rdx-0x2]
  c11335:	cmp    rdx,0x2
  c11339:	mov    r8d,0x3
  c1133f:	cmovae r8d,edi
  c11343:	lea    rcx,[rsi+rcx*8]
  c11347:	lea    rsi,[rip+0xffffffffff6b48e6]        # 2c5c34 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1273>
  c1134e:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c11352:	add    rdi,rsi
  c11355:	jmp    rdi
  c11357:	mov    r8,QWORD PTR [rcx]
  c1135a:	mov    rdi,QWORD PTR [rcx+0x8]
  c1135e:	mov    rsi,QWORD PTR [rcx+0x10]
  c11362:	jmp    c13f65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4645>
  c11367:	add    r15,QWORD PTR [rax+0x60]
  c1136b:	mov    r12,QWORD PTR [rsp+0x10]
  c11370:	movzx  edx,bpl
  c11374:	mov    rbp,rdx
  c11377:	sub    rbp,rcx
  c1137a:	jae    c11389 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a69>
  c1137c:	mov    rcx,QWORD PTR [rax+0x28]
  c11380:	shl    edx,0x4
  c11383:	mov    rbp,QWORD PTR [rcx+rdx*1]
  c11387:	jmp    c1138d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a6d>
  c11389:	add    rbp,QWORD PTR [rax+0x60]
  c1138d:	mov    rsi,QWORD PTR [rax]
  c11390:	mov    rdx,QWORD PTR [rax+0x8]
  c11394:	mov    r9,QWORD PTR [rax+0x10]
  c11398:	mov    rcx,QWORD PTR [rax+0x18]
  c1139c:	mov    QWORD PTR [rax],0x0
  c113a3:	cmp    rsi,0x1
  c113a7:	jne    c113ba <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1a9a>
  c113a9:	mov    rax,r13
  c113ac:	cmp    rdx,r13
  c113af:	je     c1143d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1b1d>
  c113b5:	jmp    c18a04 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x90e4>
  c113ba:	mov    rax,QWORD PTR [rsp+0x18]
  c113bf:	add    rax,0x10
  c113c3:	mov    rsi,QWORD PTR [rax]
  c113c6:	cmp    QWORD PTR [rsp+0x8],rsi
  c113cb:	jae    c19fcf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6af>
  c113d1:	mov    rax,QWORD PTR [r14]
  c113d4:	mov    rcx,QWORD PTR [rsp+0x28]
  c113d9:	mov    rsi,QWORD PTR [rcx+0x8]
  c113dd:	mov    rdx,QWORD PTR [rcx+0x10]
  c113e1:	mov    rcx,QWORD PTR [rsp+0x20]
  c113e6:	lea    rax,[rax+rcx*1+0x58]
  c113eb:	lea    rdi,[rsp+0x110]
  c113f3:	mov    rcx,r15
  c113f6:	mov    r8,rbp
  c113f9:	mov    r9,r13
  c113fc:	push   rbx
  c113fd:	push   rax
  c113fe:	call   c0e560 <_RNvCsbxgXiyEKxkX_6bsl_vm21numeric_for_i64_start>
  c11403:	add    rsp,0x10
  c11407:	movzx  eax,BYTE PTR [rsp+0x110]
  c1140f:	cmp    al,0xff
  c11411:	jne    c18a23 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9103>
  c11417:	test   BYTE PTR [rsp+0x118],0x1
  c1141f:	je     c17445 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b25>
  c11425:	mov    rax,QWORD PTR [rsp+0x120]
  c1142d:	mov    r9,QWORD PTR [rsp+0x128]
  c11435:	mov    rcx,QWORD PTR [rsp+0x130]
  c1143d:	mov    rdx,r9
  c11440:	inc    rdx
  c11443:	jo     c1975e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9e3e>
  c11449:	cmp    rdx,rcx
  c1144c:	jle    c118d9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1fb9>
  c11452:	mov    rsi,QWORD PTR [rsp+0x28]
  c11457:	mov    rax,QWORD PTR [rsi+0x8]
  c1145b:	mov    rcx,rdx
  c1145e:	sar    rcx,0x3f
  c11462:	mov    QWORD PTR [rsp+0x110],0x0
  c1146e:	mov    QWORD PTR [rsp+0x118],rdx
  c11476:	mov    QWORD PTR [rsp+0x120],rcx
  c1147e:	cmp    r15,QWORD PTR [rsi+0x10]
  c11482:	mov    rbp,QWORD PTR [rsp+0x30]
  c11487:	jae    c18a71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9151>
  c1148d:	lea    rcx,[r15+r15*2]
  c11491:	lea    r15,[rax+rcx*8]
  c11495:	mov    rdi,r15
  c11498:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1149d:	mov    rax,QWORD PTR [rsp+0x120]
  c114a5:	mov    QWORD PTR [r15+0x10],rax
  c114a9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c114b2:	movdqu XMMWORD PTR [r15],xmm0
  c114b7:	mov    rax,QWORD PTR [rsp+0x18]
  c114bc:	add    rax,0x10
  c114c0:	mov    rsi,QWORD PTR [rax]
  c114c3:	cmp    QWORD PTR [rsp+0x8],rsi
  c114c8:	jae    c1a04d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa72d>
  c114ce:	mov    rax,QWORD PTR [r14]
  c114d1:	mov    rcx,QWORD PTR [rsp+0x20]
  c114d6:	inc    QWORD PTR [rax+rcx*1+0x58]
  c114db:	mov    r15d,DWORD PTR [rsp+0x3c]
  c114e0:	test   r15b,r15b
  c114e3:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c114e9:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c114ee:	add    rax,QWORD PTR [rcx+0x60]
  c114f2:	mov    r12,QWORD PTR [rsp+0x10]
  c114f7:	mov    rcx,QWORD PTR [rsp+0x28]
  c114fc:	cmp    rax,QWORD PTR [rcx+0x10]
  c11500:	jae    c17779 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7e59>
  c11506:	mov    rdx,QWORD PTR [rcx+0x8]
  c1150a:	lea    rax,[rax+rax*2]
  c1150e:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11511:	lea    esi,[rcx-0x2]
  c11514:	cmp    rcx,0x2
  c11518:	mov    edi,0x3
  c1151d:	cmovae edi,esi
  c11520:	lea    rax,[rdx+rax*8]
  c11524:	lea    rdx,[rip+0xffffffffff6b4551]        # 2c5a7c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x10bb>
  c1152b:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c1152f:	add    rsi,rdx
  c11532:	jmp    rsi
  c11534:	mov    rdx,QWORD PTR [rax]
  c11537:	mov    rsi,QWORD PTR [rax+0x8]
  c1153b:	mov    rax,QWORD PTR [rax+0x10]
  c1153f:	jmp    c14087 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4767>
  c11544:	lea    rdi,[rsp+0x80]
  c1154c:	call   c25080 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs8as_slice>
  c11551:	mov    rbp,QWORD PTR [rsp+0x30]
  c11556:	mov    r8,rdx
  c11559:	mov    ecx,ebx
  c1155b:	shr    ebx,0x8
  c1155e:	sub    rsp,0x8
  c11562:	movzx  esi,cl
  c11565:	movzx  edx,bl
  c11568:	lea    rdi,[rsp+0x118]
  c11570:	mov    rcx,rax
  c11573:	mov    r9,QWORD PTR [rsp+0x648]
  c1157b:	push   QWORD PTR [rsp+0x658]
  c11582:	call   c0eb80 <_RNvCsbxgXiyEKxkX_6bsl_vm24call_builtin_with_format>
  c11587:	add    rsp,0x10
  c1158b:	movzx  eax,BYTE PTR [rsp+0x110]
  c11593:	cmp    al,0xff
  c11595:	jne    c17a89 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8169>
  c1159b:	lea    rcx,[rsp+0x114]
  c115a3:	mov    rax,QWORD PTR [rcx+0x14]
  c115a7:	lea    rdx,[rsp+0x47]
  c115ac:	mov    QWORD PTR [rdx+0x10],rax
  c115b0:	movups xmm0,XMMWORD PTR [rcx+0x4]
  c115b4:	movups XMMWORD PTR [rdx],xmm0
  c115b7:	movdqu xmm0,XMMWORD PTR [rdx]
  c115bb:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c115c4:	mov    rax,QWORD PTR [rdx+0x10]
  c115c8:	mov    QWORD PTR [rsp+0xe0],rax
  c115d0:	mov    rax,QWORD PTR [rsp+0x18]
  c115d5:	add    rax,0x10
  c115d9:	mov    rsi,QWORD PTR [rax]
  c115dc:	cmp    QWORD PTR [rsp+0x8],rsi
  c115e1:	jae    c19dcd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4ad>
  c115e7:	mov    rdx,QWORD PTR [r14]
  c115ea:	mov    rsi,QWORD PTR [rsp+0x20]
  c115ef:	lea    rcx,[rdx+rsi*1]
  c115f3:	mov    rax,r12
  c115f6:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c115fb:	jae    c11941 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2021>
  c11601:	mov    rax,QWORD PTR [rcx+0x28]
  c11605:	shl    r12d,0x4
  c11609:	mov    rax,QWORD PTR [rax+r12*1]
  c1160d:	jmp    c11945 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2025>
  c11612:	add    rax,QWORD PTR [rcx+0x60]
  c11616:	mov    r12,QWORD PTR [rsp+0x10]
  c1161b:	mov    r8,QWORD PTR [rsp+0x1c8]
  c11623:	cmp    rax,QWORD PTR [rdx+0x10]
  c11627:	jae    c17a39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8119>
  c1162d:	mov    rdx,QWORD PTR [rdx+0x8]
  c11631:	lea    rax,[rax+rax*2]
  c11635:	mov    ecx,DWORD PTR [rdx+rax*8]
  c11638:	lea    esi,[rcx-0x2]
  c1163b:	cmp    rcx,0x2
  c1163f:	mov    edi,0x3
  c11644:	cmovae edi,esi
  c11647:	lea    rax,[rdx+rax*8]
  c1164b:	lea    rdx,[rip+0xffffffffff6b46aa]        # 2c5cfc <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x133b>
  c11652:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c11656:	add    rsi,rdx
  c11659:	jmp    rsi
  c1165b:	mov    rdx,QWORD PTR [rax]
  c1165e:	mov    rcx,QWORD PTR [rax+0x8]
  c11662:	mov    r9,QWORD PTR [rax+0x10]
  c11666:	mov    QWORD PTR [rsp+0x500],rdx
  c1166e:	mov    QWORD PTR [rsp+0x508],rcx
  c11676:	mov    QWORD PTR [rsp+0x510],r9
  c1167e:	cmp    QWORD PTR [r8+0x10],rbp
  c11682:	jbe    c18011 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x86f1>
  c11688:	mov    QWORD PTR [rsp+0x550],r9
  c11690:	mov    QWORD PTR [rsp+0x420],rcx
  c11698:	mov    QWORD PTR [rsp+0x2a8],rdx
  c116a0:	mov    rax,QWORD PTR [r8+0x8]
  c116a4:	lea    rcx,[rbp*2+0x0]
  c116ac:	add    rcx,rbp
  c116af:	lea    r14,[rax+rcx*8]
  c116b3:	mov    eax,DWORD PTR [rax+rcx*8]
  c116b6:	mov    edx,eax
  c116b8:	sub    edx,0x2
  c116bb:	mov    ecx,0x3
  c116c0:	cmovae ecx,edx
  c116c3:	cmp    ecx,0x8
  c116c6:	ja     c156af <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d8f>
  c116cc:	mov    edx,0x1e7
  c116d1:	bt     edx,ecx
  c116d4:	mov    rbp,QWORD PTR [rsp+0x30]
  c116d9:	jae    c11adb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x21bb>
  c116df:	mov    rax,QWORD PTR [rsp+0x510]
  c116e7:	mov    QWORD PTR [r14+0x10],rax
  c116eb:	movdqu xmm0,XMMWORD PTR [rsp+0x500]
  c116f4:	movdqu XMMWORD PTR [r14],xmm0
  c116f9:	mov    rcx,QWORD PTR [rsp+0x18]
  c116fe:	lea    rax,[rcx+0x10]
  c11702:	mov    rsi,QWORD PTR [rax]
  c11705:	cmp    QWORD PTR [rsp+0x8],rsi
  c1170a:	jb     c15fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66aa>
  c11710:	jmp    c19e76 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa556>
  c11715:	add    rcx,QWORD PTR [rdx+0x60]
  c11719:	mov    rdx,QWORD PTR [rsp+0x28]
  c1171e:	cmp    rcx,QWORD PTR [rdx+0x10]
  c11722:	mov    r12,QWORD PTR [rsp+0x10]
  c11727:	jae    c17a5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x813d>
  c1172d:	mov    rsi,QWORD PTR [rdx+0x8]
  c11731:	lea    rcx,[rcx+rcx*2]
  c11735:	mov    edx,DWORD PTR [rsi+rcx*8]
  c11738:	lea    edi,[rdx-0x2]
  c1173b:	cmp    rdx,0x2
  c1173f:	mov    r8d,0x3
  c11745:	cmovae r8d,edi
  c11749:	lea    rcx,[rsi+rcx*8]
  c1174d:	lea    rsi,[rip+0xffffffffff6b42d8]        # 2c5a2c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x106b>
  c11754:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c11758:	add    rdi,rsi
  c1175b:	jmp    rdi
  c1175d:	mov    rsi,QWORD PTR [rcx]
  c11760:	mov    rdi,QWORD PTR [rcx+0x8]
  c11764:	mov    rcx,QWORD PTR [rcx+0x10]
  c11768:	jmp    c14554 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c34>
  c1176d:	add    rcx,QWORD PTR [rdx+0x60]
  c11771:	mov    rdx,QWORD PTR [rsp+0x28]
  c11776:	cmp    rcx,QWORD PTR [rdx+0x10]
  c1177a:	mov    r12,QWORD PTR [rsp+0x10]
  c1177f:	jae    c17a0d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x80ed>
  c11785:	mov    rsi,QWORD PTR [rdx+0x8]
  c11789:	lea    rcx,[rcx+rcx*2]
  c1178d:	mov    edx,DWORD PTR [rsi+rcx*8]
  c11790:	lea    edi,[rdx-0x2]
  c11793:	cmp    rdx,0x2
  c11797:	mov    r8d,0x3
  c1179d:	cmovae r8d,edi
  c117a1:	lea    rcx,[rsi+rcx*8]
  c117a5:	lea    rsi,[rip+0xffffffffff6b4258]        # 2c5a04 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1043>
  c117ac:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c117b0:	add    rdi,rsi
  c117b3:	jmp    rdi
  c117b5:	mov    rsi,QWORD PTR [rcx]
  c117b8:	mov    rdi,QWORD PTR [rcx+0x8]
  c117bc:	mov    rcx,QWORD PTR [rcx+0x10]
  c117c0:	jmp    c1472d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4e0d>
  c117c5:	add    rax,QWORD PTR [rbx+0x60]
  c117c9:	cmp    rax,r13
  c117cc:	jae    c17b3d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x821d>
  c117d2:	lea    rax,[rax+rax*2]
  c117d6:	mov    edx,DWORD PTR [r14+rax*8]
  c117da:	lea    ecx,[rdx-0x2]
  c117dd:	cmp    rdx,0x2
  c117e1:	mov    esi,0x3
  c117e6:	cmovae esi,ecx
  c117e9:	lea    rcx,[r14+rax*8]
  c117ed:	lea    rax,[rip+0xffffffffff6b42d8]        # 2c5acc <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x110b>
  c117f4:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c117f8:	add    rsi,rax
  c117fb:	jmp    rsi
  c117fd:	mov    rax,QWORD PTR [rcx]
  c11800:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c11805:	jmp    c162fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69dc>
  c1180a:	add    rax,QWORD PTR [rbx+0x60]
  c1180e:	cmp    rax,rbp
  c11811:	jae    c17ad1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x81b1>
  c11817:	lea    rax,[rax+rax*2]
  c1181b:	mov    edx,DWORD PTR [r15+rax*8]
  c1181f:	lea    ecx,[rdx-0x2]
  c11822:	cmp    rdx,0x2
  c11826:	mov    esi,0x3
  c1182b:	cmovae esi,ecx
  c1182e:	lea    rcx,[r15+rax*8]
  c11832:	lea    rax,[rip+0xffffffffff6b4333]        # 2c5b6c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x11ab>
  c11839:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c1183d:	add    rsi,rax
  c11840:	jmp    rsi
  c11842:	mov    rax,QWORD PTR [rcx]
  c11845:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c1184a:	jmp    c165c1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ca1>
  c1184f:	add    rax,QWORD PTR [rbx+0x60]
  c11853:	cmp    rax,rbp
  c11856:	jae    c17b23 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8203>
  c1185c:	lea    rax,[rax+rax*2]
  c11860:	mov    edx,DWORD PTR [r15+rax*8]
  c11864:	lea    ecx,[rdx-0x2]
  c11867:	cmp    rdx,0x2
  c1186b:	mov    esi,0x3
  c11870:	cmovae esi,ecx
  c11873:	lea    rcx,[r15+rax*8]
  c11877:	lea    rax,[rip+0xffffffffff6b429e]        # 2c5b1c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x115b>
  c1187e:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c11882:	add    rsi,rax
  c11885:	jmp    rsi
  c11887:	mov    rax,QWORD PTR [rcx]
  c1188a:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c1188f:	jmp    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c11894:	add    rcx,QWORD PTR [rbx+0x60]
  c11898:	cmp    rcx,r14
  c1189b:	jae    c17b09 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x81e9>
  c118a1:	lea    rax,[rcx+rcx*2]
  c118a5:	mov    edx,DWORD PTR [r15+rax*8]
  c118a9:	lea    ecx,[rdx-0x2]
  c118ac:	cmp    rdx,0x2
  c118b0:	mov    esi,0x3
  c118b5:	cmovae esi,ecx
  c118b8:	lea    rcx,[r15+rax*8]
  c118bc:	lea    rax,[rip+0xffffffffff6b42f9]        # 2c5bbc <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x11fb>
  c118c3:	movsxd rsi,DWORD PTR [rax+rsi*4]
  c118c7:	add    rsi,rax
  c118ca:	jmp    rsi
  c118cc:	mov    rax,QWORD PTR [rcx]
  c118cf:	movdqu xmm0,XMMWORD PTR [rcx+0x8]
  c118d4:	jmp    c16b61 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7241>
  c118d9:	mov    rsi,QWORD PTR [rsp+0x18]
  c118de:	lea    rdi,[rsi+0x10]
  c118e2:	mov    rsi,QWORD PTR [rdi]
  c118e5:	cmp    QWORD PTR [rsp+0x8],rsi
  c118ea:	mov    rbp,QWORD PTR [rsp+0x30]
  c118ef:	jae    c19ff3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6d3>
  c118f5:	mov    rsi,QWORD PTR [r14]
  c118f8:	mov    r8,QWORD PTR [rsp+0x20]
  c118fd:	mov    QWORD PTR [rsi+r8*1],0x1
  c11905:	mov    QWORD PTR [rsi+r8*1+0x8],rax
  c1190a:	mov    QWORD PTR [rsi+r8*1+0x10],rdx
  c1190f:	mov    QWORD PTR [rsi+r8*1+0x18],rcx
  c11914:	mov    rsi,QWORD PTR [rdi]
  c11917:	cmp    QWORD PTR [rsp+0x8],rsi
  c1191c:	mov    r15d,DWORD PTR [rsp+0x3c]
  c11921:	jae    c19fe1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6c1>
  c11927:	mov    rax,QWORD PTR [r14]
  c1192a:	movsx  rcx,bx
  c1192e:	mov    QWORD PTR [rax+r8*1+0x58],rcx
  c11933:	test   r15b,r15b
  c11936:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c1193c:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c11941:	add    rax,QWORD PTR [rcx+0x60]
  c11945:	mov    rsi,QWORD PTR [rsp+0x28]
  c1194a:	mov    rcx,QWORD PTR [rsi+0x8]
  c1194e:	mov    rdx,QWORD PTR [rsp+0xe0]
  c11956:	mov    QWORD PTR [rsp+0x120],rdx
  c1195e:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c11967:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c11970:	cmp    rax,QWORD PTR [rsi+0x10]
  c11974:	jae    c17f8c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x866c>
  c1197a:	lea    rax,[rax+rax*2]
  c1197e:	lea    r14,[rcx+rax*8]
  c11982:	mov    eax,DWORD PTR [rcx+rax*8]
  c11985:	mov    edx,eax
  c11987:	sub    edx,0x2
  c1198a:	mov    ecx,0x3
  c1198f:	cmovae ecx,edx
  c11992:	cmp    ecx,0x8
  c11995:	ja     c15656 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d36>
  c1199b:	mov    edx,0x1e7
  c119a0:	bt     edx,ecx
  c119a3:	mov    r12,QWORD PTR [rsp+0x10]
  c119a8:	jae    c11aae <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x218e>
  c119ae:	mov    rax,QWORD PTR [rsp+0xe0]
  c119b6:	mov    QWORD PTR [r14+0x10],rax
  c119ba:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c119c3:	movdqu XMMWORD PTR [r14],xmm0
  c119c8:	mov    rcx,QWORD PTR [rsp+0x18]
  c119cd:	lea    rax,[rcx+0x10]
  c119d1:	mov    rsi,QWORD PTR [rax]
  c119d4:	cmp    QWORD PTR [rsp+0x8],rsi
  c119d9:	jae    c19e0d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4ed>
  c119df:	lea    r14,[rcx+0x8]
  c119e3:	mov    rax,QWORD PTR [r14]
  c119e6:	mov    rcx,QWORD PTR [rsp+0x20]
  c119eb:	inc    QWORD PTR [rax+rcx*1+0x58]
  c119f0:	lea    rdi,[rsp+0x80]
  c119f8:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c119fd:	test   r15b,r15b
  c11a00:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c11a06:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c11a0b:	inc    QWORD PTR [rax+0x58]
  c11a0f:	mov    r12,QWORD PTR [rsp+0x10]
  c11a14:	mov    rbp,QWORD PTR [rsp+0x30]
  c11a19:	test   r15b,r15b
  c11a1c:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c11a22:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c11a27:	cmp    ecx,0x3
  c11a2a:	jne    c128e0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2fc0>
  c11a30:	test   eax,eax
  c11a32:	je     c10e39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1519>
  c11a38:	mov    rax,QWORD PTR [r14+0x8]
  c11a3c:	dec    QWORD PTR [rax]
  c11a3f:	jne    c10e39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1519>
  c11a45:	lea    rdi,[r14+0x8]
  c11a49:	call   QWORD PTR [rip+0x23bfb9]        # e4da08 <_DYNAMIC+0x248>
  c11a4f:	jmp    c10e39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1519>
  c11a54:	cmp    ecx,0x3
  c11a57:	jne    c12b3d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x321d>
  c11a5d:	test   eax,eax
  c11a5f:	je     c10ec5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a5>
  c11a65:	mov    rax,QWORD PTR [r14+0x8]
  c11a69:	dec    QWORD PTR [rax]
  c11a6c:	jne    c10ec5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a5>
  c11a72:	lea    rdi,[r14+0x8]
  c11a76:	call   QWORD PTR [rip+0x23bf8c]        # e4da08 <_DYNAMIC+0x248>
  c11a7c:	jmp    c10ec5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a5>
  c11a81:	cmp    ecx,0x3
  c11a84:	jne    c12b7a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x325a>
  c11a8a:	test   eax,eax
  c11a8c:	je     c10fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16aa>
  c11a92:	mov    rax,QWORD PTR [r14+0x8]
  c11a96:	dec    QWORD PTR [rax]
  c11a99:	jne    c10fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16aa>
  c11a9f:	lea    rdi,[r14+0x8]
  c11aa3:	call   QWORD PTR [rip+0x23bf5f]        # e4da08 <_DYNAMIC+0x248>
  c11aa9:	jmp    c10fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16aa>
  c11aae:	cmp    ecx,0x3
  c11ab1:	jne    c1563a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d1a>
  c11ab7:	test   eax,eax
  c11ab9:	je     c119ae <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x208e>
  c11abf:	mov    rax,QWORD PTR [r14+0x8]
  c11ac3:	dec    QWORD PTR [rax]
  c11ac6:	jne    c119ae <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x208e>
  c11acc:	lea    rdi,[r14+0x8]
  c11ad0:	call   QWORD PTR [rip+0x23bf32]        # e4da08 <_DYNAMIC+0x248>
  c11ad6:	jmp    c119ae <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x208e>
  c11adb:	cmp    ecx,0x3
  c11ade:	jne    c15677 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d57>
  c11ae4:	test   eax,eax
  c11ae6:	je     c116df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1dbf>
  c11aec:	mov    rax,QWORD PTR [r14+0x8]
  c11af0:	dec    QWORD PTR [rax]
  c11af3:	jne    c116df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1dbf>
  c11af9:	lea    rdi,[r14+0x8]
  c11afd:	call   QWORD PTR [rip+0x23bf05]        # e4da08 <_DYNAMIC+0x248>
  c11b03:	jmp    c116df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1dbf>
  c11b08:	mov    eax,0x8
  c11b0d:	xor    ecx,ecx
  c11b0f:	mov    QWORD PTR [rsp+0x40],rcx
  c11b14:	mov    QWORD PTR [rsp+0x48],rax
  c11b19:	mov    QWORD PTR [rsp+0x50],0x0
  c11b22:	mov    QWORD PTR [rsp+0x80],0x0
  c11b2e:	mov    QWORD PTR [rsp+0x88],0x8
  c11b3a:	mov    QWORD PTR [rsp+0x90],0x0
  c11b46:	test   r15,r15
  c11b49:	mov    QWORD PTR [rsp+0x548],rax
  c11b51:	je     c11b83 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2263>
  c11b53:	mov    r8,QWORD PTR [rbx+0x8]
  c11b57:	shl    r15,0x2
  c11b5b:	mov    QWORD PTR [rsp+0x560],r15
  c11b63:	xor    r11d,r11d
  c11b66:	movzx  eax,BYTE PTR [r8+r11*1]
  c11b6b:	lea    rcx,[rip+0xffffffffff6b3e42]        # 2c59b4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xff3>
  c11b72:	movsxd rax,DWORD PTR [rcx+rax*4]
  c11b76:	add    rax,rcx
  c11b79:	mov    QWORD PTR [rsp+0x558],r8
  c11b81:	jmp    rax
  c11b83:	mov    r15d,edx
  c11b86:	jmp    c16eb9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7599>
  c11b8b:	mov    rax,QWORD PTR [rcx+0x8]
  c11b8f:	inc    QWORD PTR [rax]
  c11b92:	mov    rcx,QWORD PTR [rsp+0x18]
  c11b97:	lea    r9,[rcx+0x10]
  c11b9b:	mov    rbp,QWORD PTR [rsp+0x30]
  c11ba0:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c11ba6:	mov    QWORD PTR [rsp+0x88],rax
  c11bae:	mov    DWORD PTR [rsp+0x80],0xb
  c11bb9:	jmp    c11c42 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2322>
  c11bbe:	mov    DWORD PTR [rsp+0x80],0x2
  c11bc9:	jmp    c10445 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xb25>
  c11bce:	mov    DWORD PTR [rsp+0x80],0x3
  c11bd9:	jmp    c10445 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xb25>
  c11bde:	test   al,0x1
  c11be0:	mov    rdi,QWORD PTR [rsp+0x18]
  c11be5:	lea    r9,[rdi+0x10]
  c11be9:	mov    rbp,QWORD PTR [rsp+0x30]
  c11bee:	je     c15ecd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x65ad>
  c11bf4:	mov    rdx,QWORD PTR [rcx+0x8]
  c11bf8:	inc    QWORD PTR [rdx]
  c11bfb:	lea    rdi,[rdi+0x8]
  c11bff:	mov    r8,QWORD PTR [rsp+0x28]
  c11c04:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c11c0a:	mov    eax,0x1
  c11c0f:	jmp    c15ee1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x65c1>
  c11c14:	mov    rax,QWORD PTR [rcx+0x8]
  c11c18:	inc    QWORD PTR [rax]
  c11c1b:	mov    rcx,QWORD PTR [rsp+0x18]
  c11c20:	lea    r9,[rcx+0x10]
  c11c24:	mov    rbp,QWORD PTR [rsp+0x30]
  c11c29:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c11c2f:	mov    QWORD PTR [rsp+0x88],rax
  c11c37:	mov    DWORD PTR [rsp+0x80],0x6
  c11c42:	lea    rdi,[rcx+0x8]
  c11c46:	mov    r8,QWORD PTR [rsp+0x28]
  c11c4b:	jmp    c15eff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x65df>
  c11c50:	mov    rsi,QWORD PTR [rax+0x8]
  c11c54:	inc    QWORD PTR [rsi]
  c11c57:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c11c5d:	movabs rax,0xffffffff00000000
  c11c67:	mov    rdx,QWORD PTR [rsp+0x318]
  c11c6f:	and    rdx,rax
  c11c72:	or     rdx,0xb
  c11c76:	jmp    c11d0c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x23ec>
  c11c7b:	movabs rax,0xffffffff00000000
  c11c85:	mov    rdx,QWORD PTR [rsp+0x318]
  c11c8d:	and    rdx,rax
  c11c90:	or     rdx,0x2
  c11c94:	jmp    c11caf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x238f>
  c11c96:	movabs rax,0xffffffff00000000
  c11ca0:	mov    rdx,QWORD PTR [rsp+0x318]
  c11ca8:	and    rdx,rax
  c11cab:	or     rdx,0x3
  c11caf:	mov    rax,QWORD PTR [rsp+0x1a0]
  c11cb7:	mov    rsi,QWORD PTR [rsp+0x478]
  c11cbf:	jmp    c11d14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x23f4>
  c11cc1:	test   cl,0x1
  c11cc4:	je     c1608b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x676b>
  c11cca:	mov    rsi,QWORD PTR [rax+0x8]
  c11cce:	inc    QWORD PTR [rsi]
  c11cd1:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c11cd7:	mov    edx,0x1
  c11cdc:	mov    rax,QWORD PTR [rsp+0x1a0]
  c11ce4:	jmp    c11d1c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x23fc>
  c11ce6:	mov    rsi,QWORD PTR [rax+0x8]
  c11cea:	inc    QWORD PTR [rsi]
  c11ced:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c11cf3:	movabs rax,0xffffffff00000000
  c11cfd:	mov    rdx,QWORD PTR [rsp+0x318]
  c11d05:	and    rdx,rax
  c11d08:	or     rdx,0x6
  c11d0c:	mov    rax,QWORD PTR [rsp+0x1a0]
  c11d14:	mov    rcx,QWORD PTR [rsp+0x240]
  c11d1c:	mov    QWORD PTR [rsp+0xf0],rdx
  c11d24:	mov    QWORD PTR [rsp+0xf8],rsi
  c11d2c:	mov    QWORD PTR [rsp+0x240],rcx
  c11d34:	mov    QWORD PTR [rsp+0x100],rcx
  c11d3c:	cmp    edx,0xb
  c11d3f:	mov    QWORD PTR [rsp+0x318],rdx
  c11d47:	mov    QWORD PTR [rsp+0x478],rsi
  c11d4f:	jne    c11ed6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x25b6>
  c11d55:	cmp    BYTE PTR [rsi+0x10],0xf
  c11d59:	jne    c11ed6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x25b6>
  c11d5f:	add    rsi,0x18
  c11d63:	mov    rax,QWORD PTR [rsp+0x378]
  c11d6b:	mov    rcx,QWORD PTR [rax]
  c11d6e:	test   rcx,rcx
  c11d71:	cmovne rcx,rax
  c11d75:	mov    rdx,QWORD PTR [rsp+0x370]
  c11d7d:	mov    rax,QWORD PTR [rdx]
  c11d80:	test   rax,rax
  c11d83:	cmovne rax,rdx
  c11d87:	mov    rdx,QWORD PTR [rsp+0x398]
  c11d8f:	movq   xmm0,QWORD PTR [rdx]
  c11d93:	mov    rdx,QWORD PTR [rsp+0x3a0]
  c11d9b:	movq   xmm1,QWORD PTR [rdx]
  c11d9f:	punpcklqdq xmm1,xmm0
  c11da3:	mov    rdx,QWORD PTR [rsp+0x640]
  c11dab:	mov    QWORD PTR [rsp+0x110],rdx
  c11db3:	mov    rdx,QWORD PTR [rip+0x23bd26]        # e4dae0 <_DYNAMIC+0x320>
  c11dba:	mov    QWORD PTR [rsp+0x118],rdx
  c11dc2:	mov    BYTE PTR [rsp+0x198],0x0
  c11dca:	mov    rdx,QWORD PTR [rsp+0x650]
  c11dd2:	movups xmm0,XMMWORD PTR [rdx]
  c11dd5:	movups XMMWORD PTR [rsp+0x120],xmm0
  c11ddd:	movdqu xmm0,XMMWORD PTR [rdx+0x10]
  c11de2:	movdqu XMMWORD PTR [rsp+0x130],xmm0
  c11deb:	mov    rdx,QWORD PTR [rsp+0x388]
  c11df3:	mov    QWORD PTR [rsp+0x140],rdx
  c11dfb:	mov    rdx,QWORD PTR [rsp+0x390]
  c11e03:	mov    QWORD PTR [rsp+0x148],rdx
  c11e0b:	mov    rdx,QWORD PTR [rsp+0x380]
  c11e13:	mov    QWORD PTR [rsp+0x150],rdx
  c11e1b:	mov    QWORD PTR [rsp+0x158],rcx
  c11e23:	mov    QWORD PTR [rsp+0x160],0x0
  c11e2f:	mov    QWORD PTR [rsp+0x170],0x0
  c11e3b:	pxor   xmm0,xmm0
  c11e3f:	pcmpeqd xmm0,xmm1
  c11e43:	pshufd xmm1,xmm0,0xb1
  c11e48:	pand   xmm1,xmm0
  c11e4c:	pandn  xmm1,XMMWORD PTR [rsp+0x530]
  c11e55:	movdqu XMMWORD PTR [rsp+0x180],xmm1
  c11e5e:	mov    QWORD PTR [rsp+0x190],rax
  c11e66:	lea    rdi,[rsp+0x80]
  c11e6e:	lea    r9,[rsp+0x110]
  c11e76:	mov    rdx,QWORD PTR [rsp+0x4c0]
  c11e7e:	mov    ecx,ebx
  c11e80:	mov    r8,QWORD PTR [rsp+0x1c0]
  c11e88:	call   c37e00 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7linking18component_prop_get>
  c11e8d:	movzx  eax,BYTE PTR [rsp+0x80]
  c11e95:	cmp    al,0xff
  c11e97:	jne    c18f53 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9633>
  c11e9d:	lea    rdx,[rsp+0x88]
  c11ea5:	mov    rax,QWORD PTR [rdx+0x10]
  c11ea9:	lea    rcx,[rsp+0x47]
  c11eae:	mov    QWORD PTR [rcx+0x10],rax
  c11eb2:	movups xmm0,XMMWORD PTR [rdx]
  c11eb5:	movups XMMWORD PTR [rcx],xmm0
  c11eb8:	movdqu xmm0,XMMWORD PTR [rcx]
  c11ebc:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c11ec5:	mov    rax,QWORD PTR [rcx+0x10]
  c11ec9:	mov    QWORD PTR [rsp+0xe0],rax
  c11ed1:	jmp    c11fec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x26cc>
  c11ed6:	mov    rcx,QWORD PTR [rsp+0x4d8]
  c11ede:	cmp    QWORD PTR [rsp+0x3b8],rcx
  c11ee6:	jae    c18733 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e13>
  c11eec:	cmp    r13,QWORD PTR [rax+0x10]
  c11ef0:	jae    c18741 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e21>
  c11ef6:	lea    rcx,[r13*2+0x0]
  c11efe:	add    rcx,r13
  c11f01:	shl    rcx,0x3
  c11f05:	add    rcx,QWORD PTR [rax+0x8]
  c11f09:	lea    rdi,[rsp+0x80]
  c11f11:	lea    rsi,[rsp+0xf0]
  c11f19:	mov    edx,ebx
  c11f1b:	call   QWORD PTR [rip+0x24109f]        # e52fc0 <_DYNAMIC+0x5800>
  c11f21:	movzx  eax,BYTE PTR [rsp+0x80]
  c11f29:	cmp    eax,0xff
  c11f2e:	je     c11fcb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x26ab>
  c11f34:	cmp    eax,0x5
  c11f37:	jne    c18bbd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x929d>
  c11f3d:	cmp    QWORD PTR [rsp+0x4d0],rbx
  c11f45:	jbe    c18bed <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92cd>
  c11f4b:	lea    rax,[rbx+rbx*2]
  c11f4f:	mov    rcx,QWORD PTR [rsp+0x4c8]
  c11f57:	mov    rdx,QWORD PTR [rcx+rax*8+0x8]
  c11f5c:	mov    rcx,QWORD PTR [rcx+rax*8+0x10]
  c11f61:	lea    rdi,[rsp+0x110]
  c11f69:	lea    rsi,[rsp+0xf0]
  c11f71:	call   QWORD PTR [rip+0x241051]        # e52fc8 <_DYNAMIC+0x5808>
  c11f77:	movzx  eax,BYTE PTR [rsp+0x110]
  c11f7f:	cmp    al,0xff
  c11f81:	jne    c18c0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x92ea>
  c11f87:	lea    rcx,[rsp+0x114]
  c11f8f:	mov    rax,QWORD PTR [rcx+0x14]
  c11f93:	lea    rdx,[rsp+0x47]
  c11f98:	mov    QWORD PTR [rdx+0x10],rax
  c11f9c:	movups xmm0,XMMWORD PTR [rcx+0x4]
  c11fa0:	movups XMMWORD PTR [rdx],xmm0
  c11fa3:	movdqu xmm0,XMMWORD PTR [rdx]
  c11fa7:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c11fb0:	mov    rax,QWORD PTR [rdx+0x10]
  c11fb4:	mov    QWORD PTR [rsp+0xe0],rax
  c11fbc:	lea    rdi,[rsp+0x80]
  c11fc4:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c11fc9:	jmp    c11fec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x26cc>
  c11fcb:	lea    rcx,[rsp+0x88]
  c11fd3:	mov    rax,QWORD PTR [rcx+0x10]
  c11fd7:	mov    QWORD PTR [rsp+0xe0],rax
  c11fdf:	movdqu xmm0,XMMWORD PTR [rcx]
  c11fe3:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c11fec:	mov    rax,QWORD PTR [rsp+0x18]
  c11ff1:	add    rax,0x10
  c11ff5:	mov    rsi,QWORD PTR [rax]
  c11ff8:	cmp    QWORD PTR [rsp+0x8],rsi
  c11ffd:	jae    c19edf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5bf>
  c12003:	mov    rdx,QWORD PTR [r14]
  c12006:	mov    rsi,QWORD PTR [rsp+0x20]
  c1200b:	lea    rcx,[rdx+rsi*1]
  c1200f:	mov    rax,r12
  c12012:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c12017:	jae    c12027 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2707>
  c12019:	mov    rax,QWORD PTR [rcx+0x28]
  c1201d:	shl    r12d,0x4
  c12021:	mov    rax,QWORD PTR [rax+r12*1]
  c12025:	jmp    c1202b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x270b>
  c12027:	add    rax,QWORD PTR [rcx+0x60]
  c1202b:	mov    rsi,QWORD PTR [rsp+0x28]
  c12030:	mov    rcx,QWORD PTR [rsi+0x8]
  c12034:	mov    rdx,QWORD PTR [rsp+0xe0]
  c1203c:	mov    QWORD PTR [rsp+0x120],rdx
  c12044:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1204d:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c12056:	cmp    rax,QWORD PTR [rsi+0x10]
  c1205a:	jae    c18695 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d75>
  c12060:	lea    rax,[rax+rax*2]
  c12064:	lea    r14,[rcx+rax*8]
  c12068:	mov    eax,DWORD PTR [rcx+rax*8]
  c1206b:	mov    edx,eax
  c1206d:	sub    edx,0x2
  c12070:	mov    ecx,0x3
  c12075:	cmovae ecx,edx
  c12078:	cmp    ecx,0x8
  c1207b:	ja     c15d95 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6475>
  c12081:	mov    edx,0x1e7
  c12086:	bt     edx,ecx
  c12089:	mov    r12,QWORD PTR [rsp+0x10]
  c1208e:	jae    c12128 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2808>
  c12094:	mov    rax,QWORD PTR [rsp+0xe0]
  c1209c:	mov    QWORD PTR [r14+0x10],rax
  c120a0:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c120a9:	movdqu XMMWORD PTR [r14],xmm0
  c120ae:	mov    rcx,QWORD PTR [rsp+0x18]
  c120b3:	lea    rax,[rcx+0x10]
  c120b7:	mov    rsi,QWORD PTR [rax]
  c120ba:	cmp    QWORD PTR [rsp+0x8],rsi
  c120bf:	jae    c19f95 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa675>
  c120c5:	lea    r14,[rcx+0x8]
  c120c9:	mov    rax,QWORD PTR [r14]
  c120cc:	mov    rcx,QWORD PTR [rsp+0x20]
  c120d1:	inc    QWORD PTR [rax+rcx*1+0x58]
  c120d6:	mov    eax,DWORD PTR [rsp+0xf0]
  c120dd:	mov    edx,eax
  c120df:	sub    edx,0x2
  c120e2:	mov    ecx,0x3
  c120e7:	cmovae ecx,edx
  c120ea:	cmp    ecx,0x8
  c120ed:	ja     c15dc9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64a9>
  c120f3:	mov    edx,0x1e7
  c120f8:	bt     edx,ecx
  c120fb:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c12101:	cmp    ecx,0x3
  c12104:	jne    c15db6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6496>
  c1210a:	test   eax,eax
  c1210c:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c12112:	mov    rax,QWORD PTR [rsp+0xf8]
  c1211a:	dec    QWORD PTR [rax]
  c1211d:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c12123:	jmp    c15202 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58e2>
  c12128:	cmp    ecx,0x3
  c1212b:	jne    c15d79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6459>
  c12131:	test   eax,eax
  c12133:	je     c12094 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2774>
  c12139:	mov    rax,QWORD PTR [r14+0x8]
  c1213d:	dec    QWORD PTR [rax]
  c12140:	jne    c12094 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2774>
  c12146:	lea    rdi,[r14+0x8]
  c1214a:	call   QWORD PTR [rip+0x23b8b8]        # e4da08 <_DYNAMIC+0x248>
  c12150:	jmp    c12094 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2774>
  c12155:	mov    rdi,QWORD PTR [rcx+0x8]
  c12159:	inc    QWORD PTR [rdi]
  c1215c:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12162:	movabs rcx,0xffffffff00000000
  c1216c:	mov    rsi,QWORD PTR [rsp+0x308]
  c12174:	and    rsi,rcx
  c12177:	or     rsi,0xb
  c1217b:	jmp    c12209 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28e9>
  c12180:	movabs rcx,0xffffffff00000000
  c1218a:	mov    rsi,QWORD PTR [rsp+0x308]
  c12192:	and    rsi,rcx
  c12195:	or     rsi,0x2
  c12199:	mov    rdi,QWORD PTR [rsp+0x460]
  c121a1:	jmp    c12209 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28e9>
  c121a3:	movabs rcx,0xffffffff00000000
  c121ad:	mov    rsi,QWORD PTR [rsp+0x308]
  c121b5:	and    rsi,rcx
  c121b8:	or     rsi,0x3
  c121bc:	mov    rdi,QWORD PTR [rsp+0x460]
  c121c4:	jmp    c12209 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28e9>
  c121c6:	test   dl,0x1
  c121c9:	je     c160ad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x678d>
  c121cf:	mov    rdi,QWORD PTR [rcx+0x8]
  c121d3:	inc    QWORD PTR [rdi]
  c121d6:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c121dc:	mov    esi,0x1
  c121e1:	jmp    c12211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28f1>
  c121e3:	mov    rdi,QWORD PTR [rcx+0x8]
  c121e7:	inc    QWORD PTR [rdi]
  c121ea:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c121f0:	movabs rcx,0xffffffff00000000
  c121fa:	mov    rsi,QWORD PTR [rsp+0x308]
  c12202:	and    rsi,rcx
  c12205:	or     rsi,0x6
  c12209:	mov    rcx,QWORD PTR [rsp+0x228]
  c12211:	mov    QWORD PTR [rsp+0x308],rsi
  c12219:	mov    QWORD PTR [rsp+0x358],rsi
  c12221:	mov    QWORD PTR [rsp+0x460],rdi
  c12229:	mov    QWORD PTR [rsp+0x360],rdi
  c12231:	mov    QWORD PTR [rsp+0x228],rcx
  c12239:	mov    QWORD PTR [rsp+0x368],rcx
  c12241:	mov    rcx,QWORD PTR [rsp+0x18]
  c12246:	add    rcx,0x10
  c1224a:	mov    rsi,QWORD PTR [rcx]
  c1224d:	cmp    QWORD PTR [rsp+0x8],rsi
  c12252:	jae    c19c43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa323>
  c12258:	mov    rcx,QWORD PTR [rsp+0x28]
  c1225d:	mov    rsi,QWORD PTR [rcx+0x8]
  c12261:	mov    rdx,QWORD PTR [rcx+0x10]
  c12265:	mov    rcx,QWORD PTR [r14]
  c12268:	add    rcx,QWORD PTR [rsp+0x20]
  c1226d:	movzx  r8d,al
  c12271:	movzx  r9d,bl
  c12275:	lea    rdi,[rsp+0x110]
  c1227d:	call   c247e0 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs4load>
  c12282:	mov    eax,DWORD PTR [rsp+0x110]
  c12289:	cmp    eax,0xffffffff
  c1228c:	je     c17c85 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8365>
  c12292:	shr    ebx,0x8
  c12295:	lea    rsi,[rsp+0x114]
  c1229d:	mov    ecx,DWORD PTR [rsi+0x30]
  c122a0:	mov    DWORD PTR [rsp+0x70],ecx
  c122a4:	movups xmm0,XMMWORD PTR [rsi]
  c122a7:	movups xmm1,XMMWORD PTR [rsi+0x10]
  c122ab:	movups xmm2,XMMWORD PTR [rsi+0x20]
  c122af:	movaps XMMWORD PTR [rsp+0x60],xmm2
  c122b4:	movaps XMMWORD PTR [rsp+0x50],xmm1
  c122b9:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c122be:	mov    rcx,QWORD PTR [rsi+0x44]
  c122c2:	lea    rdx,[rsp+0x84]
  c122ca:	mov    QWORD PTR [rdx+0x44],rcx
  c122ce:	movups xmm0,XMMWORD PTR [rsi+0x34]
  c122d2:	movups XMMWORD PTR [rdx+0x34],xmm0
  c122d6:	mov    ecx,DWORD PTR [rsp+0x70]
  c122da:	mov    DWORD PTR [rdx+0x30],ecx
  c122dd:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c122e3:	movdqa xmm1,XMMWORD PTR [rsp+0x50]
  c122e9:	movaps xmm2,XMMWORD PTR [rsp+0x60]
  c122ee:	movups XMMWORD PTR [rdx+0x20],xmm2
  c122f2:	movdqu XMMWORD PTR [rdx+0x10],xmm1
  c122f7:	movdqu XMMWORD PTR [rdx],xmm0
  c122fb:	mov    DWORD PTR [rsp+0x80],eax
  c12302:	cmp    DWORD PTR [rsp+0x358],0xb
  c1230a:	mov    DWORD PTR [rsp+0x3c],r15d
  c1230f:	jne    c124b3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2b93>
  c12315:	mov    rbp,QWORD PTR [rsp+0x360]
  c1231d:	cmp    BYTE PTR [rbp+0x10],0xf
  c12321:	jne    c124b3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2b93>
  c12327:	mov    rax,QWORD PTR [rsp+0x378]
  c1232f:	mov    rcx,QWORD PTR [rax]
  c12332:	test   rcx,rcx
  c12335:	cmovne rcx,rax
  c12339:	mov    rdx,QWORD PTR [rsp+0x370]
  c12341:	mov    rax,QWORD PTR [rdx]
  c12344:	test   rax,rax
  c12347:	cmovne rax,rdx
  c1234b:	mov    rdx,QWORD PTR [rsp+0x398]
  c12353:	movq   xmm0,QWORD PTR [rdx]
  c12357:	mov    rdx,QWORD PTR [rsp+0x3a0]
  c1235f:	movq   xmm1,QWORD PTR [rdx]
  c12363:	punpcklqdq xmm1,xmm0
  c12367:	mov    rdx,QWORD PTR [rsp+0x640]
  c1236f:	mov    QWORD PTR [rsp+0x110],rdx
  c12377:	mov    rdx,QWORD PTR [rip+0x23b762]        # e4dae0 <_DYNAMIC+0x320>
  c1237e:	mov    QWORD PTR [rsp+0x118],rdx
  c12386:	mov    BYTE PTR [rsp+0x198],0x0
  c1238e:	mov    rdx,QWORD PTR [rsp+0x650]
  c12396:	movups xmm0,XMMWORD PTR [rdx]
  c12399:	movups XMMWORD PTR [rsp+0x120],xmm0
  c123a1:	movdqu xmm0,XMMWORD PTR [rdx+0x10]
  c123a6:	movdqu XMMWORD PTR [rsp+0x130],xmm0
  c123af:	mov    rdx,QWORD PTR [rsp+0x388]
  c123b7:	mov    QWORD PTR [rsp+0x140],rdx
  c123bf:	mov    rdx,QWORD PTR [rsp+0x390]
  c123c7:	mov    QWORD PTR [rsp+0x148],rdx
  c123cf:	mov    rdx,QWORD PTR [rsp+0x380]
  c123d7:	mov    QWORD PTR [rsp+0x150],rdx
  c123df:	mov    QWORD PTR [rsp+0x158],rcx
  c123e7:	mov    rcx,QWORD PTR [rsp+0x660]
  c123ef:	mov    QWORD PTR [rsp+0x160],rcx
  c123f7:	lea    rcx,[rip+0x2241f2]        # e365f0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x9f0>
  c123fe:	mov    QWORD PTR [rsp+0x168],rcx
  c12406:	mov    QWORD PTR [rsp+0x170],0x0
  c12412:	pxor   xmm0,xmm0
  c12416:	pcmpeqd xmm0,xmm1
  c1241a:	pshufd xmm1,xmm0,0xb1
  c1241f:	pand   xmm1,xmm0
  c12423:	pandn  xmm1,XMMWORD PTR [rsp+0x530]
  c1242c:	movdqu XMMWORD PTR [rsp+0x180],xmm1
  c12435:	mov    QWORD PTR [rsp+0x190],rax
  c1243d:	movzx  edi,bl
  c12440:	call   QWORD PTR [rip+0x240b8a]        # e52fd0 <_DYNAMIC+0x5810>
  c12446:	mov    rbx,rax
  c12449:	mov    r15,rdx
  c1244c:	lea    rdi,[rsp+0x80]
  c12454:	call   c25080 <_RNvMs_CsbxgXiyEKxkX_6bsl_vmNtB4_8CallArgs8as_slice>
  c12459:	mov    r9,rdx
  c1245c:	add    rbp,0x18
  c12460:	sub    rsp,0x8
  c12464:	lea    rdi,[rsp+0x48]
  c12469:	mov    rsi,rbp
  c1246c:	mov    rdx,rbx
  c1246f:	mov    rcx,r15
  c12472:	mov    r8,rax
  c12475:	lea    rax,[rsp+0x118]
  c1247d:	push   rax
  c1247e:	call   QWORD PTR [rip+0x240b54]        # e52fd8 <_DYNAMIC+0x5818>
  c12484:	add    rsp,0x10
  c12488:	movzx  eax,BYTE PTR [rsp+0x40]
  c1248d:	cmp    al,0xff
  c1248f:	jne    c1901d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x96fd>
  c12495:	lea    rcx,[rsp+0x47]
  c1249a:	mov    rax,QWORD PTR [rcx+0x11]
  c1249e:	lea    rdx,[rsp+0xd7]
  c124a6:	mov    QWORD PTR [rdx+0x10],rax
  c124aa:	movups xmm0,XMMWORD PTR [rcx+0x1]
  c124ae:	jmp    c12586 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2c66>
  c124b3:	sub    eax,0xc
  c124b6:	mov    r8d,0x2
  c124bc:	cmovae r8d,eax
  c124c0:	lea    rax,[rip+0xffffffffff6b334d]        # 2c5814 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xe53>
  c124c7:	movsxd rcx,DWORD PTR [rax+r8*4]
  c124cb:	add    rcx,rax
  c124ce:	jmp    rcx
  c124d0:	mov    ecx,0x8
  c124d5:	jmp    c12513 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2bf3>
  c124d7:	mov    r8,QWORD PTR [rsp+0xc8]
  c124df:	cmp    r8,0x4
  c124e3:	jae    c1995e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa03e>
  c124e9:	lea    rcx,[rsp+0x80]
  c124f1:	jmp    c12513 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2bf3>
  c124f3:	mov    rcx,QWORD PTR [rsp+0x90]
  c124fb:	mov    r8,QWORD PTR [rsp+0x98]
  c12503:	jmp    c12513 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2bf3>
  c12505:	mov    r8d,0x1
  c1250b:	lea    rcx,[rsp+0x88]
  c12513:	mov    rdx,QWORD PTR [rsp+0x648]
  c1251b:	mov    rax,QWORD PTR [rdx+0x58]
  c1251f:	mov    r10,QWORD PTR [rdx+0x60]
  c12523:	mov    rdx,QWORD PTR [r10+0x10]
  c12527:	dec    rdx
  c1252a:	and    rdx,0xfffffffffffffff0
  c1252e:	add    rax,rdx
  c12531:	add    rax,0x10
  c12535:	movzx  esi,bl
  c12538:	lea    rdi,[rsp+0x110]
  c12540:	lea    rdx,[rsp+0x358]
  c12548:	mov    r9,QWORD PTR [rsp+0x640]
  c12550:	push   r10
  c12552:	push   rax
  c12553:	call   QWORD PTR [rip+0x240a87]        # e52fe0 <_DYNAMIC+0x5820>
  c12559:	add    rsp,0x10
  c1255d:	movzx  eax,BYTE PTR [rsp+0x110]
  c12565:	cmp    al,0xff
  c12567:	jne    c1877e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e5e>
  c1256d:	lea    rcx,[rsp+0x114]
  c12575:	mov    rax,QWORD PTR [rcx+0x14]
  c12579:	lea    rdx,[rsp+0x47]
  c1257e:	mov    QWORD PTR [rdx+0x10],rax
  c12582:	movups xmm0,XMMWORD PTR [rcx+0x4]
  c12586:	movups XMMWORD PTR [rdx],xmm0
  c12589:	movdqu xmm0,XMMWORD PTR [rdx]
  c1258d:	movdqa XMMWORD PTR [rsp+0xf0],xmm0
  c12596:	mov    rax,QWORD PTR [rdx+0x10]
  c1259a:	mov    QWORD PTR [rsp+0x100],rax
  c125a2:	mov    rax,QWORD PTR [rsp+0x18]
  c125a7:	add    rax,0x10
  c125ab:	mov    rsi,QWORD PTR [rax]
  c125ae:	cmp    QWORD PTR [rsp+0x8],rsi
  c125b3:	mov    rbp,QWORD PTR [rsp+0x30]
  c125b8:	mov    r15d,DWORD PTR [rsp+0x3c]
  c125bd:	jae    c19e88 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa568>
  c125c3:	mov    rdx,QWORD PTR [r14]
  c125c6:	mov    rsi,QWORD PTR [rsp+0x20]
  c125cb:	lea    rcx,[rdx+rsi*1]
  c125cf:	mov    rax,r12
  c125d2:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c125d7:	jae    c125e7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2cc7>
  c125d9:	mov    rax,QWORD PTR [rcx+0x28]
  c125dd:	shl    r12d,0x4
  c125e1:	mov    rax,QWORD PTR [rax+r12*1]
  c125e5:	jmp    c125eb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2ccb>
  c125e7:	add    rax,QWORD PTR [rcx+0x60]
  c125eb:	mov    rsi,QWORD PTR [rsp+0x28]
  c125f0:	mov    rcx,QWORD PTR [rsi+0x8]
  c125f4:	mov    rdx,QWORD PTR [rsp+0x100]
  c125fc:	mov    QWORD PTR [rsp+0x120],rdx
  c12604:	movdqa xmm0,XMMWORD PTR [rsp+0xf0]
  c1260d:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c12616:	cmp    rax,QWORD PTR [rsi+0x10]
  c1261a:	jae    c1861f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8cff>
  c12620:	lea    rax,[rax+rax*2]
  c12624:	lea    r14,[rcx+rax*8]
  c12628:	mov    eax,DWORD PTR [rcx+rax*8]
  c1262b:	mov    edx,eax
  c1262d:	sub    edx,0x2
  c12630:	mov    ecx,0x3
  c12635:	cmovae ecx,edx
  c12638:	cmp    ecx,0x8
  c1263b:	ja     c15c86 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6366>
  c12641:	mov    edx,0x1e7
  c12646:	bt     edx,ecx
  c12649:	jae    c1270c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2dec>
  c1264f:	mov    rax,QWORD PTR [rsp+0x100]
  c12657:	mov    QWORD PTR [r14+0x10],rax
  c1265b:	movdqa xmm0,XMMWORD PTR [rsp+0xf0]
  c12664:	movdqu XMMWORD PTR [r14],xmm0
  c12669:	mov    rcx,QWORD PTR [rsp+0x18]
  c1266e:	lea    rax,[rcx+0x10]
  c12672:	mov    rsi,QWORD PTR [rax]
  c12675:	cmp    QWORD PTR [rsp+0x8],rsi
  c1267a:	jae    c19f67 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa647>
  c12680:	lea    r14,[rcx+0x8]
  c12684:	mov    rax,QWORD PTR [r14]
  c12687:	mov    rcx,QWORD PTR [rsp+0x20]
  c1268c:	inc    QWORD PTR [rax+rcx*1+0x58]
  c12691:	lea    rdi,[rsp+0x80]
  c12699:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1269e:	mov    eax,DWORD PTR [rsp+0x358]
  c126a5:	mov    edx,eax
  c126a7:	sub    edx,0x2
  c126aa:	mov    ecx,0x3
  c126af:	cmovae ecx,edx
  c126b2:	cmp    ecx,0x8
  c126b5:	ja     c15cc0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63a0>
  c126bb:	mov    edx,0x1e7
  c126c0:	bt     edx,ecx
  c126c3:	mov    r12,QWORD PTR [rsp+0x10]
  c126c8:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c126ce:	cmp    ecx,0x3
  c126d1:	jne    c15ca2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6382>
  c126d7:	test   eax,eax
  c126d9:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c126df:	mov    rax,QWORD PTR [rsp+0x360]
  c126e7:	dec    QWORD PTR [rax]
  c126ea:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c126f0:	lea    rdi,[rsp+0x360]
  c126f8:	call   QWORD PTR [rip+0x23b30a]        # e4da08 <_DYNAMIC+0x248>
  c126fe:	test   r15b,r15b
  c12701:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c12707:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c1270c:	cmp    ecx,0x3
  c1270f:	jne    c15c6a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x634a>
  c12715:	test   eax,eax
  c12717:	je     c1264f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d2f>
  c1271d:	mov    rax,QWORD PTR [r14+0x8]
  c12721:	dec    QWORD PTR [rax]
  c12724:	jne    c1264f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d2f>
  c1272a:	lea    rdi,[r14+0x8]
  c1272e:	call   QWORD PTR [rip+0x23b2d4]        # e4da08 <_DYNAMIC+0x248>
  c12734:	jmp    c1264f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d2f>
  c12739:	mov    rcx,QWORD PTR [rdx+0x8]
  c1273d:	inc    QWORD PTR [rcx]
  c12740:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12746:	movq   xmm0,rcx
  c1274b:	mov    ecx,0xb
  c12750:	jmp    c10c48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1328>
  c12755:	mov    ecx,0x2
  c1275a:	jmp    c10c48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1328>
  c1275f:	mov    ecx,0x3
  c12764:	jmp    c10c48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1328>
  c12769:	mov    rcx,QWORD PTR [rdx+0x8]
  c1276d:	inc    QWORD PTR [rcx]
  c12770:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12776:	movq   xmm0,rcx
  c1277b:	mov    ecx,0xb
  c12780:	jmp    c10ccc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13ac>
  c12785:	mov    ecx,0x2
  c1278a:	jmp    c10ccc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13ac>
  c1278f:	mov    ecx,0x3
  c12794:	jmp    c10ccc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13ac>
  c12799:	mov    rcx,QWORD PTR [rdx+0x8]
  c1279d:	inc    QWORD PTR [rcx]
  c127a0:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c127a6:	movq   xmm0,rcx
  c127ab:	mov    ecx,0xb
  c127b0:	jmp    c10d50 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1430>
  c127b5:	mov    ecx,0x2
  c127ba:	jmp    c10d50 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1430>
  c127bf:	mov    ecx,0x3
  c127c4:	jmp    c10d50 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1430>
  c127c9:	mov    rsi,QWORD PTR [rcx+0x8]
  c127cd:	inc    QWORD PTR [rsi]
  c127d0:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c127d6:	movabs rcx,0xffffffff00000000
  c127e0:	mov    r8,QWORD PTR [rsp+0x2f0]
  c127e8:	and    r8,rcx
  c127eb:	or     r8,0xb
  c127ef:	jmp    c129b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3095>
  c127f4:	test   sil,0x1
  c127f8:	je     c160c7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67a7>
  c127fe:	mov    rdi,QWORD PTR [rdx+0x8]
  c12802:	inc    QWORD PTR [rdi]
  c12805:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1280b:	mov    ecx,0x1
  c12810:	jmp    c160d9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67b9>
  c12815:	movabs rcx,0xffffffff00000000
  c1281f:	mov    r8,QWORD PTR [rsp+0x2f0]
  c12827:	and    r8,rcx
  c1282a:	or     r8,0x2
  c1282e:	mov    rsi,QWORD PTR [rsp+0x480]
  c12836:	jmp    c129b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3095>
  c1283b:	movabs rcx,0xffffffff00000000
  c12845:	mov    r8,QWORD PTR [rsp+0x2f0]
  c1284d:	and    r8,rcx
  c12850:	or     r8,0x3
  c12854:	mov    rsi,QWORD PTR [rsp+0x480]
  c1285c:	jmp    c129b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3095>
  c12861:	test   sil,0x1
  c12865:	je     c160ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67cc>
  c1286b:	mov    rdi,QWORD PTR [rdx+0x8]
  c1286f:	inc    QWORD PTR [rdi]
  c12872:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12878:	mov    ecx,0x1
  c1287d:	jmp    c160fe <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67de>
  c12882:	test   sil,0x1
  c12886:	je     c16111 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x67f1>
  c1288c:	mov    rdi,QWORD PTR [rdx+0x8]
  c12890:	inc    QWORD PTR [rdi]
  c12893:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12899:	mov    ecx,0x1
  c1289e:	jmp    c16123 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6803>
  c128a3:	test   dl,0x1
  c128a6:	je     c16136 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6816>
  c128ac:	mov    rsi,QWORD PTR [rcx+0x8]
  c128b0:	inc    QWORD PTR [rsi]
  c128b3:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c128b9:	mov    r8d,0x1
  c128bf:	jmp    c129bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x309d>
  c128c4:	mov    rcx,QWORD PTR [rdx+0x8]
  c128c8:	inc    QWORD PTR [rcx]
  c128cb:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c128d1:	movq   xmm0,rcx
  c128d6:	mov    ecx,0x6
  c128db:	jmp    c10c48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1328>
  c128e0:	mov    rax,QWORD PTR [r14+0x8]
  c128e4:	dec    QWORD PTR [rax]
  c128e7:	jne    c10e39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1519>
  c128ed:	lea    rdi,[r14+0x8]
  c128f1:	call   QWORD PTR [rip+0x23b119]        # e4da10 <_DYNAMIC+0x250>
  c128f7:	jmp    c10e39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1519>
  c128fc:	mov    rcx,QWORD PTR [rdx+0x8]
  c12900:	inc    QWORD PTR [rcx]
  c12903:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12909:	movq   xmm0,rcx
  c1290e:	mov    ecx,0x6
  c12913:	jmp    c10ccc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13ac>
  c12918:	mov    rcx,QWORD PTR [rdx+0x8]
  c1291c:	inc    QWORD PTR [rcx]
  c1291f:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12925:	movq   xmm0,rcx
  c1292a:	mov    ecx,0xb
  c1292f:	jmp    c10f4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162d>
  c12934:	mov    rcx,QWORD PTR [rdx+0x8]
  c12938:	inc    QWORD PTR [rcx]
  c1293b:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12941:	movq   xmm0,rcx
  c12946:	mov    ecx,0x6
  c1294b:	jmp    c10d50 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1430>
  c12950:	mov    rdx,QWORD PTR [rax+0x8]
  c12954:	inc    QWORD PTR [rdx]
  c12957:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1295d:	movabs rax,0xffffffff00000000
  c12967:	mov    rdi,QWORD PTR [rsp+0x2e8]
  c1296f:	and    rdi,rax
  c12972:	or     rdi,0xb
  c12976:	jmp    c12c43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3323>
  c1297b:	mov    ecx,0x2
  c12980:	jmp    c10f4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162d>
  c12985:	mov    ecx,0x3
  c1298a:	jmp    c10f4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162d>
  c1298f:	mov    rsi,QWORD PTR [rcx+0x8]
  c12993:	inc    QWORD PTR [rsi]
  c12996:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1299c:	movabs rcx,0xffffffff00000000
  c129a6:	mov    r8,QWORD PTR [rsp+0x2f0]
  c129ae:	and    r8,rcx
  c129b1:	or     r8,0x6
  c129b5:	mov    rcx,QWORD PTR [rsp+0x248]
  c129bd:	mov    QWORD PTR [rsp+0x40],r8
  c129c2:	mov    QWORD PTR [rsp+0x480],rsi
  c129ca:	mov    QWORD PTR [rsp+0x48],rsi
  c129cf:	mov    QWORD PTR [rsp+0x248],rcx
  c129d7:	mov    QWORD PTR [rsp+0x50],rcx
  c129dc:	mov    rcx,QWORD PTR [rsp+0x18]
  c129e1:	add    rcx,0x10
  c129e5:	mov    rsi,QWORD PTR [rcx]
  c129e8:	cmp    QWORD PTR [rsp+0x8],rsi
  c129ed:	jae    c19d0b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa3eb>
  c129f3:	mov    rdi,QWORD PTR [r14]
  c129f6:	mov    r9,QWORD PTR [rsp+0x20]
  c129fb:	lea    rsi,[rdi+r9*1]
  c129ff:	movzx  edx,bpl
  c12a03:	mov    rcx,rdx
  c12a06:	sub    rcx,QWORD PTR [rdi+r9*1+0x30]
  c12a0b:	jae    c12a1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x30fa>
  c12a0d:	mov    rcx,QWORD PTR [rsi+0x28]
  c12a11:	shl    edx,0x4
  c12a14:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c12a18:	jmp    c12a1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x30fe>
  c12a1a:	add    rcx,QWORD PTR [rsi+0x60]
  c12a1e:	mov    rbp,QWORD PTR [rsp+0x30]
  c12a23:	mov    rdx,QWORD PTR [rsp+0x28]
  c12a28:	cmp    rcx,QWORD PTR [rdx+0x10]
  c12a2c:	jae    c17bd8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x82b8>
  c12a32:	mov    QWORD PTR [rsp+0x2f0],r8
  c12a3a:	mov    rsi,QWORD PTR [rdx+0x8]
  c12a3e:	lea    rcx,[rcx+rcx*2]
  c12a42:	mov    edx,DWORD PTR [rsi+rcx*8]
  c12a45:	lea    edi,[rdx-0x2]
  c12a48:	cmp    rdx,0x2
  c12a4c:	mov    r8d,0x3
  c12a52:	cmovae r8d,edi
  c12a56:	lea    rcx,[rsi+rcx*8]
  c12a5a:	lea    rsi,[rip+0xffffffffff6b2eb3]        # 2c5914 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf53>
  c12a61:	movsxd rdi,DWORD PTR [rsi+r8*4]
  c12a65:	add    rdi,rsi
  c12a68:	jmp    rdi
  c12a6a:	mov    r8,QWORD PTR [rcx]
  c12a6d:	mov    rdi,QWORD PTR [rcx+0x8]
  c12a71:	mov    rsi,QWORD PTR [rcx+0x10]
  c12a75:	jmp    c14b07 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51e7>
  c12a7a:	movabs rax,0xffffffff00000000
  c12a84:	mov    rdi,QWORD PTR [rsp+0x2e8]
  c12a8c:	and    rdi,rax
  c12a8f:	or     rdi,0x2
  c12a93:	mov    rdx,QWORD PTR [rsp+0x470]
  c12a9b:	jmp    c12c43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3323>
  c12aa0:	movabs rax,0xffffffff00000000
  c12aaa:	mov    rdi,QWORD PTR [rsp+0x2e8]
  c12ab2:	and    rdi,rax
  c12ab5:	or     rdi,0x3
  c12ab9:	mov    rdx,QWORD PTR [rsp+0x470]
  c12ac1:	jmp    c12c43 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3323>
  c12ac6:	mov    rdx,QWORD PTR [rax+0x8]
  c12aca:	inc    QWORD PTR [rdx]
  c12acd:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12ad3:	movabs rax,0xffffffff00000000
  c12add:	mov    rsi,QWORD PTR [rsp+0x300]
  c12ae5:	and    rsi,rax
  c12ae8:	or     rsi,0xb
  c12aec:	jmp    c1311b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x37fb>
  c12af1:	movabs rax,0xffffffff00000000
  c12afb:	mov    rsi,QWORD PTR [rsp+0x300]
  c12b03:	and    rsi,rax
  c12b06:	or     rsi,0x2
  c12b0a:	mov    rdx,QWORD PTR [rsp+0x4a8]
  c12b12:	jmp    c1311b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x37fb>
  c12b17:	movabs rax,0xffffffff00000000
  c12b21:	mov    rsi,QWORD PTR [rsp+0x300]
  c12b29:	and    rsi,rax
  c12b2c:	or     rsi,0x3
  c12b30:	mov    rdx,QWORD PTR [rsp+0x4a8]
  c12b38:	jmp    c1311b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x37fb>
  c12b3d:	mov    rax,QWORD PTR [r14+0x8]
  c12b41:	dec    QWORD PTR [rax]
  c12b44:	jne    c10ec5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a5>
  c12b4a:	lea    rdi,[r14+0x8]
  c12b4e:	call   QWORD PTR [rip+0x23aebc]        # e4da10 <_DYNAMIC+0x250>
  c12b54:	jmp    c10ec5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a5>
  c12b59:	test   sil,0x1
  c12b5d:	je     c16151 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6831>
  c12b63:	mov    rdi,QWORD PTR [rdx+0x8]
  c12b67:	inc    QWORD PTR [rdi]
  c12b6a:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12b70:	mov    ecx,0x1
  c12b75:	jmp    c16163 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6843>
  c12b7a:	mov    rax,QWORD PTR [r14+0x8]
  c12b7e:	dec    QWORD PTR [rax]
  c12b81:	jne    c10fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16aa>
  c12b87:	lea    rdi,[r14+0x8]
  c12b8b:	call   QWORD PTR [rip+0x23ae7f]        # e4da10 <_DYNAMIC+0x250>
  c12b91:	jmp    c10fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16aa>
  c12b96:	test   cl,0x1
  c12b99:	je     c16176 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6856>
  c12b9f:	mov    rdx,QWORD PTR [rax+0x8]
  c12ba3:	inc    QWORD PTR [rdx]
  c12ba6:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12bac:	mov    edi,0x1
  c12bb1:	jmp    c12c4b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x332b>
  c12bb6:	test   cl,0x1
  c12bb9:	je     c16190 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6870>
  c12bbf:	mov    rdx,QWORD PTR [rax+0x8]
  c12bc3:	inc    QWORD PTR [rdx]
  c12bc6:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12bcc:	mov    esi,0x1
  c12bd1:	jmp    c13123 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3803>
  c12bd6:	mov    rcx,QWORD PTR [rdx+0x8]
  c12bda:	inc    QWORD PTR [rcx]
  c12bdd:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12be3:	movq   xmm0,rcx
  c12be8:	mov    ecx,0x6
  c12bed:	jmp    c10f4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162d>
  c12bf2:	mov    rdi,QWORD PTR [rcx+0x8]
  c12bf6:	inc    QWORD PTR [rdi]
  c12bf9:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12bff:	movabs rcx,0xffffffff00000000
  c12c09:	mov    r8,QWORD PTR [rsp+0x2d8]
  c12c11:	and    r8,rcx
  c12c14:	or     r8,0xb
  c12c18:	jmp    c132de <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39be>
  c12c1d:	mov    rdx,QWORD PTR [rax+0x8]
  c12c21:	inc    QWORD PTR [rdx]
  c12c24:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c12c2a:	movabs rax,0xffffffff00000000
  c12c34:	mov    rdi,QWORD PTR [rsp+0x2e8]
  c12c3c:	and    rdi,rax
  c12c3f:	or     rdi,0x6
  c12c43:	mov    rax,QWORD PTR [rsp+0x238]
  c12c4b:	mov    QWORD PTR [rsp+0xf0],rdi
  c12c53:	mov    QWORD PTR [rsp+0x470],rdx
  c12c5b:	mov    QWORD PTR [rsp+0xf8],rdx
  c12c63:	mov    QWORD PTR [rsp+0x238],rax
  c12c6b:	mov    QWORD PTR [rsp+0x100],rax
  c12c73:	mov    rax,QWORD PTR [rsp+0x18]
  c12c78:	add    rax,0x10
  c12c7c:	mov    rsi,QWORD PTR [rax]
  c12c7f:	cmp    QWORD PTR [rsp+0x8],rsi
  c12c84:	jae    c19bf1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2d1>
  c12c8a:	mov    rsi,QWORD PTR [r14]
  c12c8d:	mov    r9,QWORD PTR [rsp+0x20]
  c12c92:	lea    rdx,[rsi+r9*1]
  c12c96:	movzx  ecx,bpl
  c12c9a:	mov    rax,rcx
  c12c9d:	sub    rax,QWORD PTR [rsi+r9*1+0x30]
  c12ca2:	jae    c12cb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3391>
  c12ca4:	mov    rax,QWORD PTR [rdx+0x28]
  c12ca8:	shl    ecx,0x4
  c12cab:	mov    rax,QWORD PTR [rax+rcx*1]
  c12caf:	jmp    c12cb5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3395>
  c12cb1:	add    rax,QWORD PTR [rdx+0x60]
  c12cb5:	mov    rcx,QWORD PTR [rsp+0x28]
  c12cba:	cmp    rax,QWORD PTR [rcx+0x10]
  c12cbe:	jae    c17b57 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8237>
  c12cc4:	mov    QWORD PTR [rsp+0x2e8],rdi
  c12ccc:	mov    rdx,QWORD PTR [rcx+0x8]
  c12cd0:	lea    rax,[rax+rax*2]
  c12cd4:	mov    ecx,DWORD PTR [rdx+rax*8]
  c12cd7:	lea    esi,[rcx-0x2]
  c12cda:	cmp    rcx,0x2
  c12cde:	mov    edi,0x3
  c12ce3:	cmovae edi,esi
  c12ce6:	lea    rax,[rdx+rax*8]
  c12cea:	lea    rdx,[rip+0xffffffffff6b2b83]        # 2c5874 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xeb3>
  c12cf1:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c12cf5:	add    rsi,rdx
  c12cf8:	jmp    rsi
  c12cfa:	mov    rdi,QWORD PTR [rax]
  c12cfd:	mov    rcx,QWORD PTR [rax+0x8]
  c12d01:	mov    r8,QWORD PTR [rax+0x10]
  c12d05:	mov    QWORD PTR [rsp+0x1d0],rcx
  c12d0d:	mov    QWORD PTR [rsp+0xd0],rdi
  c12d15:	mov    QWORD PTR [rsp+0xd8],rcx
  c12d1d:	mov    QWORD PTR [rsp+0xe0],r8
  c12d25:	cmp    DWORD PTR [rsp+0xf0],0xb
  c12d2d:	mov    QWORD PTR [rsp+0x2d0],rdi
  c12d35:	jne    c12ec2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x35a2>
  c12d3b:	mov    rsi,QWORD PTR [rsp+0xf8]
  c12d43:	cmp    BYTE PTR [rsi+0x10],0xf
  c12d47:	jne    c12ec2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x35a2>
  c12d4d:	mov    QWORD PTR [rsp+0x4b8],r8
  c12d55:	add    rsi,0x18
  c12d59:	mov    rax,QWORD PTR [rsp+0x378]
  c12d61:	mov    rcx,QWORD PTR [rax]
  c12d64:	test   rcx,rcx
  c12d67:	cmovne rcx,rax
  c12d6b:	mov    rdx,QWORD PTR [rsp+0x370]
  c12d73:	mov    rax,QWORD PTR [rdx]
  c12d76:	test   rax,rax
  c12d79:	cmovne rax,rdx
  c12d7d:	mov    rdx,QWORD PTR [rsp+0x398]
  c12d85:	movq   xmm0,QWORD PTR [rdx]
  c12d89:	mov    rdx,QWORD PTR [rsp+0x3a0]
  c12d91:	movq   xmm1,QWORD PTR [rdx]
  c12d95:	punpcklqdq xmm1,xmm0
  c12d99:	mov    rdx,QWORD PTR [rsp+0x640]
  c12da1:	mov    QWORD PTR [rsp+0x110],rdx
  c12da9:	mov    rdx,QWORD PTR [rip+0x23ad30]        # e4dae0 <_DYNAMIC+0x320>
  c12db0:	mov    QWORD PTR [rsp+0x118],rdx
  c12db8:	mov    BYTE PTR [rsp+0x198],0x0
  c12dc0:	mov    rdx,QWORD PTR [rsp+0x650]
  c12dc8:	movups xmm0,XMMWORD PTR [rdx]
  c12dcb:	movups XMMWORD PTR [rsp+0x120],xmm0
  c12dd3:	movdqu xmm0,XMMWORD PTR [rdx+0x10]
  c12dd8:	movdqu XMMWORD PTR [rsp+0x130],xmm0
  c12de1:	mov    rdx,QWORD PTR [rsp+0x388]
  c12de9:	mov    QWORD PTR [rsp+0x140],rdx
  c12df1:	mov    rdx,QWORD PTR [rsp+0x390]
  c12df9:	mov    QWORD PTR [rsp+0x148],rdx
  c12e01:	mov    rdx,QWORD PTR [rsp+0x380]
  c12e09:	mov    QWORD PTR [rsp+0x150],rdx
  c12e11:	mov    QWORD PTR [rsp+0x158],rcx
  c12e19:	mov    QWORD PTR [rsp+0x160],0x0
  c12e25:	mov    QWORD PTR [rsp+0x170],0x0
  c12e31:	pxor   xmm0,xmm0
  c12e35:	pcmpeqd xmm0,xmm1
  c12e39:	pshufd xmm1,xmm0,0xb1
  c12e3e:	pand   xmm1,xmm0
  c12e42:	pandn  xmm1,XMMWORD PTR [rsp+0x530]
  c12e4b:	movdqu XMMWORD PTR [rsp+0x180],xmm1
  c12e54:	mov    QWORD PTR [rsp+0x190],rax
  c12e5c:	mov    rax,QWORD PTR [rsp+0xe0]
  c12e64:	mov    QWORD PTR [rsp+0x50],rax
  c12e69:	movdqu xmm0,XMMWORD PTR [rsp+0xd0]
  c12e72:	movdqa XMMWORD PTR [rsp+0x40],xmm0
  c12e78:	sub    rsp,0x8
  c12e7c:	lea    rax,[rsp+0x118]
  c12e84:	lea    rdi,[rsp+0x88]
  c12e8c:	lea    r8,[rsp+0x48]
  c12e91:	mov    rdx,QWORD PTR [rsp+0x4c8]
  c12e99:	mov    ecx,ebx
  c12e9b:	mov    r9,QWORD PTR [rsp+0x1c8]
  c12ea3:	push   rax
  c12ea4:	call   c37f20 <_RNvNtCsbxgXiyEKxkX_6bsl_vm7linking18component_prop_set>
  c12ea9:	add    rsp,0x10
  c12ead:	cmp    BYTE PTR [rsp+0x80],0xff
  c12eb5:	jne    c19082 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9762>
  c12ebb:	xor    ebp,ebp
  c12ebd:	jmp    c1301c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36fc>
  c12ec2:	cmp    QWORD PTR [rsp+0x4d0],rbx
  c12eca:	jbe    c18762 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e42>
  c12ed0:	mov    DWORD PTR [rsp+0x3c],r15d
  c12ed5:	lea    rax,[rbx+rbx*2]
  c12ed9:	mov    rsi,QWORD PTR [rsp+0x4c8]
  c12ee1:	mov    r12,QWORD PTR [rsi+rax*8+0x8]
  c12ee6:	mov    ecx,edi
  c12ee8:	sub    ecx,0x2
  c12eeb:	mov    edx,0x3
  c12ef0:	cmovae edx,ecx
  c12ef3:	mov    r15,QWORD PTR [rsi+rax*8+0x10]
  c12ef8:	lea    rax,[rip+0xffffffffff6b299d]        # 2c589c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xedb>
  c12eff:	movsxd rcx,DWORD PTR [rax+rdx*4]
  c12f03:	add    rcx,rax
  c12f06:	jmp    rcx
  c12f08:	mov    rax,QWORD PTR [rsp+0xe0]
  c12f10:	mov    QWORD PTR [rsp+0x120],rax
  c12f18:	movdqu xmm0,XMMWORD PTR [rsp+0xd0]
  c12f21:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c12f2a:	mov    rax,QWORD PTR [rsp+0x1a0]
  c12f32:	mov    rcx,QWORD PTR [rsp+0x4d8]
  c12f3a:	cmp    QWORD PTR [rsp+0x3b8],rcx
  c12f42:	jae    c187bf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e9f>
  c12f48:	cmp    r13,QWORD PTR [rax+0x10]
  c12f4c:	jae    c187cd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ead>
  c12f52:	mov    QWORD PTR [rsp+0x4b8],r8
  c12f5a:	lea    r8,[r13*2+0x0]
  c12f62:	add    r8,r13
  c12f65:	shl    r8,0x3
  c12f69:	add    r8,QWORD PTR [rax+0x8]
  c12f6d:	lea    rdi,[rsp+0x80]
  c12f75:	lea    rsi,[rsp+0xf0]
  c12f7d:	lea    rcx,[rsp+0x110]
  c12f85:	mov    edx,ebx
  c12f87:	call   QWORD PTR [rip+0x24005b]        # e52fe8 <_DYNAMIC+0x5828>
  c12f8d:	movzx  eax,BYTE PTR [rsp+0x80]
  c12f95:	cmp    al,0x5
  c12f97:	setne  bpl
  c12f9b:	je     c12fb0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3690>
  c12f9d:	cmp    al,0xff
  c12f9f:	mov    r12,QWORD PTR [rsp+0x10]
  c12fa4:	mov    r15d,DWORD PTR [rsp+0x3c]
  c12fa9:	je     c1301c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36fc>
  c12fab:	jmp    c18c5f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x933f>
  c12fb0:	mov    rax,QWORD PTR [rsp+0xe0]
  c12fb8:	mov    QWORD PTR [rsp+0x50],rax
  c12fbd:	movdqu xmm0,XMMWORD PTR [rsp+0xd0]
  c12fc6:	movdqa XMMWORD PTR [rsp+0x40],xmm0
  c12fcc:	lea    rdi,[rsp+0x110]
  c12fd4:	lea    rsi,[rsp+0xf0]
  c12fdc:	lea    r8,[rsp+0x40]
  c12fe1:	mov    rdx,r12
  c12fe4:	mov    rcx,r15
  c12fe7:	call   QWORD PTR [rip+0x240003]        # e52ff0 <_DYNAMIC+0x5830>
  c12fed:	cmp    BYTE PTR [rsp+0x110],0xff
  c12ff5:	mov    r12,QWORD PTR [rsp+0x10]
  c12ffa:	mov    r15d,DWORD PTR [rsp+0x3c]
  c12fff:	jne    c18c92 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9372>
  c13005:	cmp    BYTE PTR [rsp+0x80],0xff
  c1300d:	je     c1301c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x36fc>
  c1300f:	lea    rdi,[rsp+0x80]
  c13017:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1301c:	mov    rax,QWORD PTR [rsp+0x18]
  c13021:	add    rax,0x10
  c13025:	mov    rsi,QWORD PTR [rax]
  c13028:	cmp    QWORD PTR [rsp+0x8],rsi
  c1302d:	jae    c19fac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa68c>
  c13033:	mov    rax,QWORD PTR [r14]
  c13036:	mov    rcx,QWORD PTR [rsp+0x20]
  c1303b:	inc    QWORD PTR [rax+rcx*1+0x58]
  c13040:	test   bpl,bpl
  c13043:	je     c13052 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3732>
  c13045:	lea    rdi,[rsp+0xd0]
  c1304d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c13052:	mov    eax,DWORD PTR [rsp+0xf0]
  c13059:	mov    edx,eax
  c1305b:	sub    edx,0x2
  c1305e:	mov    ecx,0x3
  c13063:	cmovae ecx,edx
  c13066:	cmp    ecx,0x8
  c13069:	mov    rbp,QWORD PTR [rsp+0x30]
  c1306e:	ja     c15e09 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64e9>
  c13074:	mov    edx,0x1e7
  c13079:	bt     edx,ecx
  c1307c:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c13082:	cmp    ecx,0x3
  c13085:	jne    c15ddc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64bc>
  c1308b:	test   eax,eax
  c1308d:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c13093:	mov    rax,QWORD PTR [rsp+0xf8]
  c1309b:	dec    QWORD PTR [rax]
  c1309e:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c130a4:	jmp    c15202 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58e2>
  c130a9:	movabs rcx,0xffffffff00000000
  c130b3:	mov    r8,QWORD PTR [rsp+0x2d8]
  c130bb:	and    r8,rcx
  c130be:	or     r8,0x2
  c130c2:	mov    rdi,QWORD PTR [rsp+0x450]
  c130ca:	jmp    c132de <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39be>
  c130cf:	movabs rcx,0xffffffff00000000
  c130d9:	mov    r8,QWORD PTR [rsp+0x2d8]
  c130e1:	and    r8,rcx
  c130e4:	or     r8,0x3
  c130e8:	mov    rdi,QWORD PTR [rsp+0x450]
  c130f0:	jmp    c132de <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39be>
  c130f5:	mov    rdx,QWORD PTR [rax+0x8]
  c130f9:	inc    QWORD PTR [rdx]
  c130fc:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c13102:	movabs rax,0xffffffff00000000
  c1310c:	mov    rsi,QWORD PTR [rsp+0x300]
  c13114:	and    rsi,rax
  c13117:	or     rsi,0x6
  c1311b:	mov    rax,QWORD PTR [rsp+0x220]
  c13123:	mov    QWORD PTR [rsp+0x300],rsi
  c1312b:	mov    QWORD PTR [rsp+0x80],rsi
  c13133:	mov    QWORD PTR [rsp+0x4a8],rdx
  c1313b:	mov    QWORD PTR [rsp+0x88],rdx
  c13143:	mov    QWORD PTR [rsp+0x220],rax
  c1314b:	mov    QWORD PTR [rsp+0x90],rax
  c13153:	mov    rsi,QWORD PTR [r10]
  c13156:	cmp    QWORD PTR [rsp+0x8],rsi
  c1315b:	jae    c19c5a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa33a>
  c13161:	mov    rdx,QWORD PTR [r8]
  c13164:	mov    rsi,QWORD PTR [rsp+0x20]
  c13169:	lea    rcx,[rdx+rsi*1]
  c1316d:	mov    rax,r12
  c13170:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c13175:	jae    c13185 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3865>
  c13177:	mov    rax,QWORD PTR [rcx+0x28]
  c1317b:	shl    r12d,0x4
  c1317f:	mov    rax,QWORD PTR [rax+r12*1]
  c13183:	jmp    c13189 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3869>
  c13185:	add    rax,QWORD PTR [rcx+0x60]
  c13189:	mov    r12,QWORD PTR [rsp+0x10]
  c1318e:	mov    rcx,QWORD PTR [r9+0x8]
  c13192:	mov    rdx,QWORD PTR [rsp+0x90]
  c1319a:	mov    QWORD PTR [rsp+0x120],rdx
  c131a2:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c131ab:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c131b4:	cmp    rax,QWORD PTR [r9+0x10]
  c131b8:	jae    c17bd3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x82b3>
  c131be:	lea    rax,[rax+rax*2]
  c131c2:	lea    r14,[rcx+rax*8]
  c131c6:	mov    eax,DWORD PTR [rcx+rax*8]
  c131c9:	mov    edx,eax
  c131cb:	sub    edx,0x2
  c131ce:	mov    ecx,0x3
  c131d3:	cmovae ecx,edx
  c131d6:	cmp    ecx,0x8
  c131d9:	ja     c1559a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c7a>
  c131df:	mov    edx,0x1e7
  c131e4:	bt     edx,ecx
  c131e7:	jae    c1321f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38ff>
  c131e9:	mov    rax,QWORD PTR [rsp+0x90]
  c131f1:	mov    QWORD PTR [r14+0x10],rax
  c131f5:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c131fe:	movdqu XMMWORD PTR [r14],xmm0
  c13203:	mov    rcx,QWORD PTR [rsp+0x18]
  c13208:	lea    rax,[rcx+0x10]
  c1320c:	mov    rsi,QWORD PTR [rax]
  c1320f:	cmp    QWORD PTR [rsp+0x8],rsi
  c13214:	jb     c15fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66aa>
  c1321a:	jmp    c19de4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4c4>
  c1321f:	cmp    ecx,0x3
  c13222:	jne    c14c31 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5311>
  c13228:	test   eax,eax
  c1322a:	je     c131e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38c9>
  c1322c:	mov    rax,QWORD PTR [r14+0x8]
  c13230:	dec    QWORD PTR [rax]
  c13233:	jne    c131e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38c9>
  c13235:	lea    rdi,[r14+0x8]
  c13239:	call   QWORD PTR [rip+0x23a7c9]        # e4da08 <_DYNAMIC+0x248>
  c1323f:	jmp    c131e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38c9>
  c13241:	test   dl,0x1
  c13244:	je     c161aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x688a>
  c1324a:	mov    rdi,QWORD PTR [rcx+0x8]
  c1324e:	inc    QWORD PTR [rdi]
  c13251:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c13257:	mov    r8d,0x1
  c1325d:	jmp    c132e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39c6>
  c13262:	mov    rsi,QWORD PTR [rax+0x8]
  c13266:	inc    QWORD PTR [rsi]
  c13269:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1326f:	movabs rax,0xffffffff00000000
  c13279:	mov    rdx,QWORD PTR [rsp+0x320]
  c13281:	and    rdx,rax
  c13284:	or     rdx,0xb
  c13288:	jmp    c13518 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3bf8>
  c1328d:	mov    rdi,QWORD PTR [rcx+0x8]
  c13291:	inc    QWORD PTR [rdi]
  c13294:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1329a:	movabs rcx,0xffffffff00000000
  c132a4:	mov    r8,QWORD PTR [rsp+0x2f8]
  c132ac:	and    r8,rcx
  c132af:	or     r8,0xb
  c132b3:	jmp    c13626 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d06>
  c132b8:	mov    rdi,QWORD PTR [rcx+0x8]
  c132bc:	inc    QWORD PTR [rdi]
  c132bf:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c132c5:	movabs rcx,0xffffffff00000000
  c132cf:	mov    r8,QWORD PTR [rsp+0x2d8]
  c132d7:	and    r8,rcx
  c132da:	or     r8,0x6
  c132de:	mov    rsi,QWORD PTR [rsp+0x268]
  c132e6:	mov    QWORD PTR [rsp+0x40],r8
  c132eb:	mov    QWORD PTR [rsp+0x48],rdi
  c132f0:	mov    QWORD PTR [rsp+0x268],rsi
  c132f8:	mov    QWORD PTR [rsp+0x50],rsi
  c132fd:	mov    rsi,QWORD PTR [r11]
  c13300:	cmp    QWORD PTR [rsp+0x8],rsi
  c13305:	jae    c19c9a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa37a>
  c1330b:	mov    rsi,QWORD PTR [r9]
  c1330e:	mov    rbx,QWORD PTR [rsp+0x20]
  c13313:	lea    rdx,[rsi+rbx*1]
  c13317:	movzx  ecx,ax
  c1331a:	mov    rax,rcx
  c1331d:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c13322:	jae    c13331 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3a11>
  c13324:	mov    rax,QWORD PTR [rdx+0x28]
  c13328:	shl    ecx,0x4
  c1332b:	mov    rax,QWORD PTR [rax+rcx*1]
  c1332f:	jmp    c13335 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3a15>
  c13331:	add    rax,QWORD PTR [rdx+0x60]
  c13335:	cmp    rax,QWORD PTR [r10+0x10]
  c13339:	jae    c17ba7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8287>
  c1333f:	mov    QWORD PTR [rsp+0x450],rdi
  c13347:	mov    rdx,QWORD PTR [r10+0x8]
  c1334b:	lea    rax,[rax+rax*2]
  c1334f:	mov    ecx,DWORD PTR [rdx+rax*8]
  c13352:	lea    esi,[rcx-0x2]
  c13355:	cmp    rcx,0x2
  c13359:	mov    edi,0x3
  c1335e:	cmovae edi,esi
  c13361:	lea    rax,[rdx+rax*8]
  c13365:	lea    rdx,[rip+0xffffffffff6b28a0]        # 2c5c0c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x124b>
  c1336c:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c13370:	add    rsi,rdx
  c13373:	jmp    rsi
  c13375:	mov    rdx,QWORD PTR [rax]
  c13378:	mov    rdi,QWORD PTR [rax+0x8]
  c1337c:	mov    rax,QWORD PTR [rax+0x10]
  c13380:	jmp    c14d62 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5442>
  c13385:	movabs rax,0xffffffff00000000
  c1338f:	mov    rdx,QWORD PTR [rsp+0x320]
  c13397:	and    rdx,rax
  c1339a:	or     rdx,0x2
  c1339e:	mov    rsi,QWORD PTR [rsp+0x488]
  c133a6:	jmp    c13518 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3bf8>
  c133ab:	movabs rax,0xffffffff00000000
  c133b5:	mov    rdx,QWORD PTR [rsp+0x320]
  c133bd:	and    rdx,rax
  c133c0:	or     rdx,0x3
  c133c4:	mov    rsi,QWORD PTR [rsp+0x488]
  c133cc:	jmp    c13518 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3bf8>
  c133d1:	movabs rcx,0xffffffff00000000
  c133db:	mov    r8,QWORD PTR [rsp+0x2f8]
  c133e3:	and    r8,rcx
  c133e6:	or     r8,0x2
  c133ea:	mov    rdi,QWORD PTR [rsp+0x448]
  c133f2:	jmp    c13626 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d06>
  c133f7:	movabs rcx,0xffffffff00000000
  c13401:	mov    r8,QWORD PTR [rsp+0x2f8]
  c13409:	and    r8,rcx
  c1340c:	or     r8,0x3
  c13410:	mov    rdi,QWORD PTR [rsp+0x448]
  c13418:	jmp    c13626 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d06>
  c1341d:	mov    rsi,QWORD PTR [rax+0x8]
  c13421:	inc    QWORD PTR [rsi]
  c13424:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1342a:	movabs rax,0xffffffff00000000
  c13434:	mov    rdx,QWORD PTR [rsp+0x310]
  c1343c:	and    rdx,rax
  c1343f:	or     rdx,0xb
  c13443:	jmp    c13784 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e64>
  c13448:	movabs rax,0xffffffff00000000
  c13452:	mov    rdx,QWORD PTR [rsp+0x310]
  c1345a:	and    rdx,rax
  c1345d:	or     rdx,0x2
  c13461:	mov    rsi,QWORD PTR [rsp+0x468]
  c13469:	jmp    c13784 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e64>
  c1346e:	movabs rax,0xffffffff00000000
  c13478:	mov    rdx,QWORD PTR [rsp+0x310]
  c13480:	and    rdx,rax
  c13483:	or     rdx,0x3
  c13487:	mov    rsi,QWORD PTR [rsp+0x468]
  c1348f:	jmp    c13784 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e64>
  c13494:	test   cl,0x1
  c13497:	je     c161c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68a2>
  c1349d:	mov    rsi,QWORD PTR [rax+0x8]
  c134a1:	inc    QWORD PTR [rsi]
  c134a4:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c134aa:	mov    edx,0x1
  c134af:	jmp    c13520 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c00>
  c134b1:	test   dl,0x1
  c134b4:	je     c161dc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68bc>
  c134ba:	mov    rdi,QWORD PTR [rcx+0x8]
  c134be:	inc    QWORD PTR [rdi]
  c134c1:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c134c7:	mov    r8d,0x1
  c134cd:	jmp    c1362e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d0e>
  c134d2:	test   cl,0x1
  c134d5:	je     c161f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68d4>
  c134db:	mov    rsi,QWORD PTR [rax+0x8]
  c134df:	inc    QWORD PTR [rsi]
  c134e2:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c134e8:	mov    edx,0x1
  c134ed:	jmp    c1378c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e6c>
  c134f2:	mov    rsi,QWORD PTR [rax+0x8]
  c134f6:	inc    QWORD PTR [rsi]
  c134f9:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c134ff:	movabs rax,0xffffffff00000000
  c13509:	mov    rdx,QWORD PTR [rsp+0x320]
  c13511:	and    rdx,rax
  c13514:	or     rdx,0x6
  c13518:	mov    rax,QWORD PTR [rsp+0x258]
  c13520:	mov    QWORD PTR [rsp+0x320],rdx
  c13528:	mov    QWORD PTR [rsp+0x80],rdx
  c13530:	mov    QWORD PTR [rsp+0x488],rsi
  c13538:	mov    QWORD PTR [rsp+0x88],rsi
  c13540:	mov    QWORD PTR [rsp+0x258],rax
  c13548:	mov    QWORD PTR [rsp+0x90],rax
  c13550:	lea    rdi,[rsp+0x110]
  c13558:	lea    rsi,[rsp+0x80]
  c13560:	call   QWORD PTR [rip+0x23eaf2]        # e52058 <_DYNAMIC+0x4898>
  c13566:	movzx  eax,BYTE PTR [rsp+0x110]
  c1356e:	movzx  ebx,BYTE PTR [rsp+0x111]
  c13576:	cmp    al,0xff
  c13578:	jne    c17568 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7c48>
  c1357e:	mov    eax,DWORD PTR [rsp+0x80]
  c13585:	mov    edx,eax
  c13587:	sub    edx,0x2
  c1358a:	mov    ecx,0x3
  c1358f:	cmovae ecx,edx
  c13592:	cmp    ecx,0x8
  c13595:	ja     c155b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c96>
  c1359b:	mov    edx,0x1e7
  c135a0:	bt     edx,ecx
  c135a3:	jae    c135d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3cb6>
  c135a5:	mov    rax,QWORD PTR [rsp+0x18]
  c135aa:	add    rax,0x10
  c135ae:	mov    rsi,QWORD PTR [rax]
  c135b1:	test   bl,0x1
  c135b4:	je     c135c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3ca6>
  c135b6:	cmp    QWORD PTR [rsp+0x8],rsi
  c135bb:	jb     c14153 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4833>
  c135c1:	jmp    c1a029 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa709>
  c135c6:	cmp    QWORD PTR [rsp+0x8],rsi
  c135cb:	jb     c14128 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4808>
  c135d1:	jmp    c1a03b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa71b>
  c135d6:	cmp    ecx,0x3
  c135d9:	jne    c14fc5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56a5>
  c135df:	test   eax,eax
  c135e1:	je     c135a5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c85>
  c135e3:	mov    rax,QWORD PTR [rsp+0x88]
  c135eb:	dec    QWORD PTR [rax]
  c135ee:	jne    c135a5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c85>
  c135f0:	lea    rdi,[rsp+0x88]
  c135f8:	call   QWORD PTR [rip+0x23a40a]        # e4da08 <_DYNAMIC+0x248>
  c135fe:	jmp    c135a5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c85>
  c13600:	mov    rdi,QWORD PTR [rcx+0x8]
  c13604:	inc    QWORD PTR [rdi]
  c13607:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1360d:	movabs rcx,0xffffffff00000000
  c13617:	mov    r8,QWORD PTR [rsp+0x2f8]
  c1361f:	and    r8,rcx
  c13622:	or     r8,0x6
  c13626:	mov    rsi,QWORD PTR [rsp+0x250]
  c1362e:	mov    QWORD PTR [rsp+0xf0],r8
  c13636:	mov    QWORD PTR [rsp+0xf8],rdi
  c1363e:	mov    QWORD PTR [rsp+0x250],rsi
  c13646:	mov    QWORD PTR [rsp+0x100],rsi
  c1364e:	mov    rcx,QWORD PTR [rsp+0x18]
  c13653:	add    rcx,0x10
  c13657:	mov    rsi,QWORD PTR [rcx]
  c1365a:	cmp    QWORD PTR [rsp+0x8],rsi
  c1365f:	jae    c19d22 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa402>
  c13665:	mov    rsi,QWORD PTR [rbx]
  c13668:	mov    r9,QWORD PTR [rsp+0x20]
  c1366d:	lea    rdx,[rsi+r9*1]
  c13671:	movzx  ecx,ax
  c13674:	mov    rax,rcx
  c13677:	sub    rax,QWORD PTR [rsi+r9*1+0x30]
  c1367c:	jae    c1368b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d6b>
  c1367e:	mov    rax,QWORD PTR [rdx+0x28]
  c13682:	shl    ecx,0x4
  c13685:	mov    rax,QWORD PTR [rax+rcx*1]
  c13689:	jmp    c1368f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d6f>
  c1368b:	add    rax,QWORD PTR [rdx+0x60]
  c1368f:	cmp    rax,QWORD PTR [r14+0x10]
  c13693:	jae    c17b7b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x825b>
  c13699:	mov    QWORD PTR [rsp+0x448],rdi
  c136a1:	mov    rdx,QWORD PTR [r14+0x8]
  c136a5:	lea    rax,[rax+rax*2]
  c136a9:	mov    ecx,DWORD PTR [rdx+rax*8]
  c136ac:	lea    esi,[rcx-0x2]
  c136af:	cmp    rcx,0x2
  c136b3:	mov    edi,0x3
  c136b8:	cmovae edi,esi
  c136bb:	lea    rax,[rdx+rax*8]
  c136bf:	lea    rdx,[rip+0xffffffffff6b22c6]        # 2c598c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xfcb>
  c136c6:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c136ca:	add    rsi,rdx
  c136cd:	mov    QWORD PTR [rsp+0x2f8],r8
  c136d5:	jmp    rsi
  c136d7:	mov    rdx,QWORD PTR [rax]
  c136da:	mov    rsi,QWORD PTR [rax+0x8]
  c136de:	mov    rdi,QWORD PTR [rax+0x10]
  c136e2:	jmp    c15017 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56f7>
  c136e7:	mov    rsi,QWORD PTR [rax+0x8]
  c136eb:	inc    QWORD PTR [rsi]
  c136ee:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c136f4:	movabs rax,0xffffffff00000000
  c136fe:	mov    rdx,QWORD PTR [rsp+0x330]
  c13706:	and    rdx,rax
  c13709:	or     rdx,0xb
  c1370d:	jmp    c13ac2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a2>
  c13712:	movabs rax,0xffffffff00000000
  c1371c:	mov    rdx,QWORD PTR [rsp+0x330]
  c13724:	and    rdx,rax
  c13727:	or     rdx,0x2
  c1372b:	mov    rsi,QWORD PTR [rsp+0x498]
  c13733:	jmp    c13ac2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a2>
  c13738:	movabs rax,0xffffffff00000000
  c13742:	mov    rdx,QWORD PTR [rsp+0x330]
  c1374a:	and    rdx,rax
  c1374d:	or     rdx,0x3
  c13751:	mov    rsi,QWORD PTR [rsp+0x498]
  c13759:	jmp    c13ac2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41a2>
  c1375e:	mov    rsi,QWORD PTR [rax+0x8]
  c13762:	inc    QWORD PTR [rsi]
  c13765:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1376b:	movabs rax,0xffffffff00000000
  c13775:	mov    rdx,QWORD PTR [rsp+0x310]
  c1377d:	and    rdx,rax
  c13780:	or     rdx,0x6
  c13784:	mov    rax,QWORD PTR [rsp+0x230]
  c1378c:	mov    QWORD PTR [rsp+0x310],rdx
  c13794:	mov    QWORD PTR [rsp+0x80],rdx
  c1379c:	mov    QWORD PTR [rsp+0x468],rsi
  c137a4:	mov    QWORD PTR [rsp+0x88],rsi
  c137ac:	mov    QWORD PTR [rsp+0x230],rax
  c137b4:	mov    QWORD PTR [rsp+0x90],rax
  c137bc:	lea    rdi,[rsp+0x110]
  c137c4:	lea    rsi,[rsp+0x80]
  c137cc:	call   QWORD PTR [rip+0x23e786]        # e51f58 <_DYNAMIC+0x4798>
  c137d2:	movzx  ecx,BYTE PTR [rsp+0x110]
  c137da:	cmp    cl,0xff
  c137dd:	jne    c17c30 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8310>
  c137e3:	mov    rax,QWORD PTR [rsp+0x18]
  c137e8:	add    rax,0x10
  c137ec:	mov    rsi,QWORD PTR [rax]
  c137ef:	cmp    QWORD PTR [rsp+0x8],rsi
  c137f4:	jae    c19d5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa43d>
  c137fa:	mov    rdx,QWORD PTR [rbx]
  c137fd:	mov    rsi,QWORD PTR [rsp+0x20]
  c13802:	lea    rcx,[rdx+rsi*1]
  c13806:	mov    rax,r12
  c13809:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c1380e:	jae    c1381e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3efe>
  c13810:	mov    rax,QWORD PTR [rcx+0x28]
  c13814:	shl    r12d,0x4
  c13818:	mov    rax,QWORD PTR [rax+r12*1]
  c1381c:	jmp    c13822 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f02>
  c1381e:	add    rax,QWORD PTR [rcx+0x60]
  c13822:	mov    r12,QWORD PTR [rsp+0x10]
  c13827:	mov    rdx,QWORD PTR [rsp+0x118]
  c1382f:	mov    rcx,QWORD PTR [r14+0x8]
  c13833:	mov    QWORD PTR [rsp+0x110],0x0
  c1383f:	mov    QWORD PTR [rsp+0x118],rdx
  c13847:	sar    rdx,0x3f
  c1384b:	mov    QWORD PTR [rsp+0x120],rdx
  c13853:	cmp    rax,QWORD PTR [r14+0x10]
  c13857:	jae    c18059 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8739>
  c1385d:	lea    rax,[rax+rax*2]
  c13861:	lea    r14,[rcx+rax*8]
  c13865:	mov    eax,DWORD PTR [rcx+rax*8]
  c13868:	mov    edx,eax
  c1386a:	sub    edx,0x2
  c1386d:	mov    ecx,0x3
  c13872:	cmovae ecx,edx
  c13875:	cmp    ecx,0x8
  c13878:	ja     c15726 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e06>
  c1387e:	mov    edx,0x1e7
  c13883:	bt     edx,ecx
  c13886:	jae    c13920 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4000>
  c1388c:	mov    rax,QWORD PTR [rsp+0x120]
  c13894:	mov    QWORD PTR [r14+0x10],rax
  c13898:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c138a1:	movdqu XMMWORD PTR [r14],xmm0
  c138a6:	mov    rcx,QWORD PTR [rsp+0x18]
  c138ab:	lea    rax,[rcx+0x10]
  c138af:	mov    rsi,QWORD PTR [rax]
  c138b2:	cmp    QWORD PTR [rsp+0x8],rsi
  c138b7:	jae    c19eb6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa596>
  c138bd:	lea    r14,[rcx+0x8]
  c138c1:	mov    rax,QWORD PTR [r14]
  c138c4:	mov    rcx,QWORD PTR [rsp+0x20]
  c138c9:	inc    QWORD PTR [rax+rcx*1+0x58]
  c138ce:	mov    eax,DWORD PTR [rsp+0x80]
  c138d5:	mov    edx,eax
  c138d7:	sub    edx,0x2
  c138da:	mov    ecx,0x3
  c138df:	cmovae ecx,edx
  c138e2:	cmp    ecx,0x8
  c138e5:	ja     c157fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5edd>
  c138eb:	mov    edx,0x1e7
  c138f0:	bt     edx,ecx
  c138f3:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c138f9:	cmp    ecx,0x3
  c138fc:	jne    c157df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ebf>
  c13902:	test   eax,eax
  c13904:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c1390a:	mov    rax,QWORD PTR [rsp+0x88]
  c13912:	dec    QWORD PTR [rax]
  c13915:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c1391b:	jmp    c1485c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f3c>
  c13920:	cmp    ecx,0x3
  c13923:	jne    c156ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5dcc>
  c13929:	test   eax,eax
  c1392b:	je     c1388c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f6c>
  c13931:	mov    rax,QWORD PTR [r14+0x8]
  c13935:	dec    QWORD PTR [rax]
  c13938:	jne    c1388c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f6c>
  c1393e:	lea    rdi,[r14+0x8]
  c13942:	call   QWORD PTR [rip+0x23a0c0]        # e4da08 <_DYNAMIC+0x248>
  c13948:	jmp    c1388c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f6c>
  c1394d:	test   cl,0x1
  c13950:	je     c1620e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x68ee>
  c13956:	mov    rsi,QWORD PTR [rax+0x8]
  c1395a:	inc    QWORD PTR [rsi]
  c1395d:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c13963:	mov    edx,0x1
  c13968:	jmp    c13aca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41aa>
  c1396d:	mov    rsi,QWORD PTR [rax+0x8]
  c13971:	inc    QWORD PTR [rsi]
  c13974:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1397a:	movabs rax,0xffffffff00000000
  c13984:	mov    rdx,QWORD PTR [rsp+0x338]
  c1398c:	and    rdx,rax
  c1398f:	or     rdx,0xb
  c13993:	jmp    c13d5c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x443c>
  c13998:	mov    rdi,QWORD PTR [rcx+0x8]
  c1399c:	inc    QWORD PTR [rdi]
  c1399f:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c139a5:	movabs rcx,0xffffffff00000000
  c139af:	mov    r8,QWORD PTR [rsp+0x2e0]
  c139b7:	and    r8,rcx
  c139ba:	or     r8,0xb
  c139be:	jmp    c13f5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x463d>
  c139c3:	movabs rax,0xffffffff00000000
  c139cd:	mov    rdx,QWORD PTR [rsp+0x338]
  c139d5:	and    rdx,rax
  c139d8:	or     rdx,0x2
  c139dc:	mov    rsi,QWORD PTR [rsp+0x4a0]
  c139e4:	jmp    c13d5c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x443c>
  c139e9:	movabs rax,0xffffffff00000000
  c139f3:	mov    rdx,QWORD PTR [rsp+0x338]
  c139fb:	and    rdx,rax
  c139fe:	or     rdx,0x3
  c13a02:	mov    rsi,QWORD PTR [rsp+0x4a0]
  c13a0a:	jmp    c13d5c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x443c>
  c13a0f:	movabs rcx,0xffffffff00000000
  c13a19:	mov    r8,QWORD PTR [rsp+0x2e0]
  c13a21:	and    r8,rcx
  c13a24:	or     r8,0x2
  c13a28:	mov    rdi,QWORD PTR [rsp+0x458]
  c13a30:	jmp    c13f5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x463d>
  c13a35:	movabs rcx,0xffffffff00000000
  c13a3f:	mov    r8,QWORD PTR [rsp+0x2e0]
  c13a47:	and    r8,rcx
  c13a4a:	or     r8,0x3
  c13a4e:	mov    rdi,QWORD PTR [rsp+0x458]
  c13a56:	jmp    c13f5d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x463d>
  c13a5b:	test   cl,0x1
  c13a5e:	je     c16228 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6908>
  c13a64:	mov    rsi,QWORD PTR [rax+0x8]
  c13a68:	inc    QWORD PTR [rsi]
  c13a6b:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c13a71:	mov    edx,0x1
  c13a76:	jmp    c13d64 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4444>
  c13a7b:	test   dl,0x1
  c13a7e:	je     c16242 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6922>
  c13a84:	mov    rdi,QWORD PTR [rcx+0x8]
  c13a88:	inc    QWORD PTR [rdi]
  c13a8b:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c13a91:	mov    r8d,0x1
  c13a97:	jmp    c13f65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4645>
  c13a9c:	mov    rsi,QWORD PTR [rax+0x8]
  c13aa0:	inc    QWORD PTR [rsi]
  c13aa3:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c13aa9:	movabs rax,0xffffffff00000000
  c13ab3:	mov    rdx,QWORD PTR [rsp+0x330]
  c13abb:	and    rdx,rax
  c13abe:	or     rdx,0x6
  c13ac2:	mov    rax,QWORD PTR [rsp+0x278]
  c13aca:	mov    QWORD PTR [rsp+0x330],rdx
  c13ad2:	mov    QWORD PTR [rsp+0x40],rdx
  c13ad7:	mov    QWORD PTR [rsp+0x498],rsi
  c13adf:	mov    QWORD PTR [rsp+0x48],rsi
  c13ae4:	mov    QWORD PTR [rsp+0x278],rax
  c13aec:	mov    QWORD PTR [rsp+0x50],rax
  c13af1:	lea    rdi,[rsp+0x110]
  c13af9:	lea    rsi,[rsp+0x40]
  c13afe:	call   QWORD PTR [rip+0x23f4f4]        # e52ff8 <_DYNAMIC+0x5838>
  c13b04:	movzx  eax,BYTE PTR [rsp+0x110]
  c13b0c:	cmp    al,0xff
  c13b0e:	jne    c175a4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7c84>
  c13b14:	lea    rdx,[rsp+0x118]
  c13b1c:	mov    rax,QWORD PTR [rdx+0x10]
  c13b20:	lea    rcx,[rsp+0x84]
  c13b28:	mov    QWORD PTR [rcx+0x13],rax
  c13b2c:	movups xmm0,XMMWORD PTR [rdx]
  c13b2f:	movups XMMWORD PTR [rcx+0x3],xmm0
  c13b33:	movdqu xmm0,XMMWORD PTR [rcx+0x3]
  c13b38:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c13b41:	mov    rax,QWORD PTR [rcx+0x13]
  c13b45:	mov    QWORD PTR [rsp+0xe0],rax
  c13b4d:	mov    eax,DWORD PTR [rsp+0x40]
  c13b51:	mov    edx,eax
  c13b53:	sub    edx,0x2
  c13b56:	mov    ecx,0x3
  c13b5b:	cmovae ecx,edx
  c13b5e:	cmp    ecx,0x8
  c13b61:	ja     c155da <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5cba>
  c13b67:	mov    edx,0x1e7
  c13b6c:	bt     edx,ecx
  c13b6f:	jae    c13c4a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x432a>
  c13b75:	mov    rax,QWORD PTR [rsp+0x18]
  c13b7a:	add    rax,0x10
  c13b7e:	mov    rsi,QWORD PTR [rax]
  c13b81:	cmp    QWORD PTR [rsp+0x8],rsi
  c13b86:	jae    c19d75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa455>
  c13b8c:	mov    rdx,QWORD PTR [rbx]
  c13b8f:	mov    rsi,QWORD PTR [rsp+0x20]
  c13b94:	lea    rcx,[rdx+rsi*1]
  c13b98:	mov    rax,r12
  c13b9b:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c13ba0:	jae    c13bb0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4290>
  c13ba2:	mov    rax,QWORD PTR [rcx+0x28]
  c13ba6:	shl    r12d,0x4
  c13baa:	mov    rax,QWORD PTR [rax+r12*1]
  c13bae:	jmp    c13bb4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4294>
  c13bb0:	add    rax,QWORD PTR [rcx+0x60]
  c13bb4:	mov    r12,QWORD PTR [rsp+0x10]
  c13bb9:	mov    rcx,QWORD PTR [r14+0x8]
  c13bbd:	mov    rdx,QWORD PTR [rsp+0xe0]
  c13bc5:	mov    QWORD PTR [rsp+0x120],rdx
  c13bcd:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c13bd6:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c13bdf:	cmp    rax,QWORD PTR [r14+0x10]
  c13be3:	jae    c18054 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8734>
  c13be9:	lea    rax,[rax+rax*2]
  c13bed:	lea    r14,[rcx+rax*8]
  c13bf1:	mov    eax,DWORD PTR [rcx+rax*8]
  c13bf4:	mov    edx,eax
  c13bf6:	sub    edx,0x2
  c13bf9:	mov    ecx,0x3
  c13bfe:	cmovae ecx,edx
  c13c01:	cmp    ecx,0x8
  c13c04:	ja     c157a7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e87>
  c13c0a:	mov    edx,0x1e7
  c13c0f:	bt     edx,ecx
  c13c12:	jae    c13c79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4359>
  c13c14:	mov    rax,QWORD PTR [rsp+0xe0]
  c13c1c:	mov    QWORD PTR [r14+0x10],rax
  c13c20:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c13c29:	movdqu XMMWORD PTR [r14],xmm0
  c13c2e:	mov    rcx,QWORD PTR [rsp+0x18]
  c13c33:	lea    rax,[rcx+0x10]
  c13c37:	mov    rsi,QWORD PTR [rax]
  c13c3a:	cmp    QWORD PTR [rsp+0x8],rsi
  c13c3f:	jb     c15fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66aa>
  c13c45:	jmp    c19ecd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5ad>
  c13c4a:	cmp    ecx,0x3
  c13c4d:	jne    c15280 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5960>
  c13c53:	test   eax,eax
  c13c55:	je     c13b75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4255>
  c13c5b:	mov    rax,QWORD PTR [rsp+0x48]
  c13c60:	dec    QWORD PTR [rax]
  c13c63:	jne    c13b75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4255>
  c13c69:	lea    rdi,[rsp+0x48]
  c13c6e:	call   QWORD PTR [rip+0x239d94]        # e4da08 <_DYNAMIC+0x248>
  c13c74:	jmp    c13b75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4255>
  c13c79:	cmp    ecx,0x3
  c13c7c:	jne    c1576f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e4f>
  c13c82:	test   eax,eax
  c13c84:	je     c13c14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x42f4>
  c13c86:	mov    rax,QWORD PTR [r14+0x8]
  c13c8a:	dec    QWORD PTR [rax]
  c13c8d:	jne    c13c14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x42f4>
  c13c8f:	lea    rdi,[r14+0x8]
  c13c93:	call   QWORD PTR [rip+0x239d6f]        # e4da08 <_DYNAMIC+0x248>
  c13c99:	jmp    c13c14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x42f4>
  c13c9e:	mov    rax,QWORD PTR [r14+0x8]
  c13ca2:	dec    QWORD PTR [rax]
  c13ca5:	mov    rbp,QWORD PTR [rsp+0x30]
  c13caa:	jne    c10e39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1519>
  c13cb0:	lea    rdi,[r14+0x8]
  c13cb4:	call   QWORD PTR [rip+0x239d5e]        # e4da18 <_DYNAMIC+0x258>
  c13cba:	jmp    c10e39 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1519>
  c13cbf:	mov    rsi,QWORD PTR [rax+0x8]
  c13cc3:	inc    QWORD PTR [rsi]
  c13cc6:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c13ccc:	movabs rax,0xffffffff00000000
  c13cd6:	mov    rdx,QWORD PTR [rsp+0x328]
  c13cde:	and    rdx,rax
  c13ce1:	or     rdx,0xb
  c13ce5:	jmp    c1407f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x475f>
  c13cea:	movabs rax,0xffffffff00000000
  c13cf4:	mov    rdx,QWORD PTR [rsp+0x328]
  c13cfc:	and    rdx,rax
  c13cff:	or     rdx,0x2
  c13d03:	mov    rsi,QWORD PTR [rsp+0x490]
  c13d0b:	jmp    c1407f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x475f>
  c13d10:	movabs rax,0xffffffff00000000
  c13d1a:	mov    rdx,QWORD PTR [rsp+0x328]
  c13d22:	and    rdx,rax
  c13d25:	or     rdx,0x3
  c13d29:	mov    rsi,QWORD PTR [rsp+0x490]
  c13d31:	jmp    c1407f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x475f>
  c13d36:	mov    rsi,QWORD PTR [rax+0x8]
  c13d3a:	inc    QWORD PTR [rsi]
  c13d3d:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c13d43:	movabs rax,0xffffffff00000000
  c13d4d:	mov    rdx,QWORD PTR [rsp+0x338]
  c13d55:	and    rdx,rax
  c13d58:	or     rdx,0x6
  c13d5c:	mov    rax,QWORD PTR [rsp+0x280]
  c13d64:	mov    QWORD PTR [rsp+0x338],rdx
  c13d6c:	mov    QWORD PTR [rsp+0x40],rdx
  c13d71:	mov    QWORD PTR [rsp+0x4a0],rsi
  c13d79:	mov    QWORD PTR [rsp+0x48],rsi
  c13d7e:	mov    QWORD PTR [rsp+0x280],rax
  c13d86:	mov    QWORD PTR [rsp+0x50],rax
  c13d8b:	lea    rdi,[rsp+0x110]
  c13d93:	lea    rsi,[rsp+0x40]
  c13d98:	call   c1ad20 <_RNvCsbxgXiyEKxkX_6bsl_vm6neg_op>
  c13d9d:	movzx  eax,BYTE PTR [rsp+0x110]
  c13da5:	cmp    al,0xff
  c13da7:	jne    c175a4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7c84>
  c13dad:	lea    rdx,[rsp+0x118]
  c13db5:	mov    rax,QWORD PTR [rdx+0x10]
  c13db9:	lea    rcx,[rsp+0x84]
  c13dc1:	mov    QWORD PTR [rcx+0x13],rax
  c13dc5:	movups xmm0,XMMWORD PTR [rdx]
  c13dc8:	movups XMMWORD PTR [rcx+0x3],xmm0
  c13dcc:	movdqu xmm0,XMMWORD PTR [rcx+0x3]
  c13dd1:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c13dda:	mov    rax,QWORD PTR [rcx+0x13]
  c13dde:	mov    QWORD PTR [rsp+0xe0],rax
  c13de6:	mov    eax,DWORD PTR [rsp+0x40]
  c13dea:	mov    edx,eax
  c13dec:	sub    edx,0x2
  c13def:	mov    ecx,0x3
  c13df4:	cmovae ecx,edx
  c13df7:	cmp    ecx,0x8
  c13dfa:	ja     c155f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5cd8>
  c13e00:	mov    edx,0x1e7
  c13e05:	bt     edx,ecx
  c13e08:	jae    c13ee3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x45c3>
  c13e0e:	mov    rax,QWORD PTR [rsp+0x18]
  c13e13:	add    rax,0x10
  c13e17:	mov    rsi,QWORD PTR [rax]
  c13e1a:	cmp    QWORD PTR [rsp+0x8],rsi
  c13e1f:	jae    c19d8c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa46c>
  c13e25:	mov    rdx,QWORD PTR [rbx]
  c13e28:	mov    rsi,QWORD PTR [rsp+0x20]
  c13e2d:	lea    rcx,[rdx+rsi*1]
  c13e31:	mov    rax,r12
  c13e34:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c13e39:	jae    c13e49 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4529>
  c13e3b:	mov    rax,QWORD PTR [rcx+0x28]
  c13e3f:	shl    r12d,0x4
  c13e43:	mov    rax,QWORD PTR [rax+r12*1]
  c13e47:	jmp    c13e4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x452d>
  c13e49:	add    rax,QWORD PTR [rcx+0x60]
  c13e4d:	mov    r12,QWORD PTR [rsp+0x10]
  c13e52:	mov    rcx,QWORD PTR [r14+0x8]
  c13e56:	mov    rdx,QWORD PTR [rsp+0xe0]
  c13e5e:	mov    QWORD PTR [rsp+0x120],rdx
  c13e66:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c13e6f:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c13e78:	cmp    rax,QWORD PTR [r14+0x10]
  c13e7c:	jae    c1804f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x872f>
  c13e82:	lea    rax,[rax+rax*2]
  c13e86:	lea    r14,[rcx+rax*8]
  c13e8a:	mov    eax,DWORD PTR [rcx+rax*8]
  c13e8d:	mov    edx,eax
  c13e8f:	sub    edx,0x2
  c13e92:	mov    ecx,0x3
  c13e97:	cmovae ecx,edx
  c13e9a:	cmp    ecx,0x8
  c13e9d:	ja     c157c3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ea3>
  c13ea3:	mov    edx,0x1e7
  c13ea8:	bt     edx,ecx
  c13eab:	jae    c13f12 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x45f2>
  c13ead:	mov    rax,QWORD PTR [rsp+0xe0]
  c13eb5:	mov    QWORD PTR [r14+0x10],rax
  c13eb9:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c13ec2:	movdqu XMMWORD PTR [r14],xmm0
  c13ec7:	mov    rcx,QWORD PTR [rsp+0x18]
  c13ecc:	lea    rax,[rcx+0x10]
  c13ed0:	mov    rsi,QWORD PTR [rax]
  c13ed3:	cmp    QWORD PTR [rsp+0x8],rsi
  c13ed8:	jb     c15fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66aa>
  c13ede:	jmp    c19e24 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa504>
  c13ee3:	cmp    ecx,0x3
  c13ee6:	jne    c15312 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x59f2>
  c13eec:	test   eax,eax
  c13eee:	je     c13e0e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44ee>
  c13ef4:	mov    rax,QWORD PTR [rsp+0x48]
  c13ef9:	dec    QWORD PTR [rax]
  c13efc:	jne    c13e0e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44ee>
  c13f02:	lea    rdi,[rsp+0x48]
  c13f07:	call   QWORD PTR [rip+0x239afb]        # e4da08 <_DYNAMIC+0x248>
  c13f0d:	jmp    c13e0e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44ee>
  c13f12:	cmp    ecx,0x3
  c13f15:	jne    c1578b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e6b>
  c13f1b:	test   eax,eax
  c13f1d:	je     c13ead <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x458d>
  c13f1f:	mov    rax,QWORD PTR [r14+0x8]
  c13f23:	dec    QWORD PTR [rax]
  c13f26:	jne    c13ead <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x458d>
  c13f28:	lea    rdi,[r14+0x8]
  c13f2c:	call   QWORD PTR [rip+0x239ad6]        # e4da08 <_DYNAMIC+0x248>
  c13f32:	jmp    c13ead <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x458d>
  c13f37:	mov    rdi,QWORD PTR [rcx+0x8]
  c13f3b:	inc    QWORD PTR [rdi]
  c13f3e:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c13f44:	movabs rcx,0xffffffff00000000
  c13f4e:	mov    r8,QWORD PTR [rsp+0x2e0]
  c13f56:	and    r8,rcx
  c13f59:	or     r8,0x6
  c13f5d:	mov    rsi,QWORD PTR [rsp+0x270]
  c13f65:	mov    QWORD PTR [rsp+0x40],r8
  c13f6a:	mov    QWORD PTR [rsp+0x48],rdi
  c13f6f:	mov    QWORD PTR [rsp+0x270],rsi
  c13f77:	mov    QWORD PTR [rsp+0x50],rsi
  c13f7c:	mov    rsi,QWORD PTR [r11]
  c13f7f:	cmp    QWORD PTR [rsp+0x8],rsi
  c13f84:	jae    c19c71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa351>
  c13f8a:	mov    rsi,QWORD PTR [r9]
  c13f8d:	mov    rbx,QWORD PTR [rsp+0x20]
  c13f92:	lea    rdx,[rsi+rbx*1]
  c13f96:	movzx  ecx,ax
  c13f99:	mov    rax,rcx
  c13f9c:	sub    rax,QWORD PTR [rsi+rbx*1+0x30]
  c13fa1:	jae    c13fb0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4690>
  c13fa3:	mov    rax,QWORD PTR [rdx+0x28]
  c13fa7:	shl    ecx,0x4
  c13faa:	mov    rax,QWORD PTR [rax+rcx*1]
  c13fae:	jmp    c13fb4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4694>
  c13fb0:	add    rax,QWORD PTR [rdx+0x60]
  c13fb4:	cmp    rax,QWORD PTR [r10+0x10]
  c13fb8:	jae    c17c04 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x82e4>
  c13fbe:	mov    QWORD PTR [rsp+0x458],rdi
  c13fc6:	mov    rdx,QWORD PTR [r10+0x8]
  c13fca:	lea    rax,[rax+rax*2]
  c13fce:	mov    ecx,DWORD PTR [rdx+rax*8]
  c13fd1:	lea    esi,[rcx-0x2]
  c13fd4:	cmp    rcx,0x2
  c13fd8:	mov    edi,0x3
  c13fdd:	cmovae edi,esi
  c13fe0:	lea    rax,[rdx+rax*8]
  c13fe4:	lea    rdx,[rip+0xffffffffff6b1c71]        # 2c5c5c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x129b>
  c13feb:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c13fef:	add    rsi,rdx
  c13ff2:	jmp    rsi
  c13ff4:	mov    rdx,QWORD PTR [rax]
  c13ff7:	mov    rdi,QWORD PTR [rax+0x8]
  c13ffb:	mov    rax,QWORD PTR [rax+0x10]
  c13fff:	jmp    c1537b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a5b>
  c14004:	mov    rax,QWORD PTR [r14+0x8]
  c14008:	dec    QWORD PTR [rax]
  c1400b:	jne    c10ec5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a5>
  c14011:	lea    rdi,[r14+0x8]
  c14015:	call   QWORD PTR [rip+0x2399fd]        # e4da18 <_DYNAMIC+0x258>
  c1401b:	jmp    c10ec5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x15a5>
  c14020:	test   cl,0x1
  c14023:	je     c1625a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x693a>
  c14029:	mov    rsi,QWORD PTR [rax+0x8]
  c1402d:	inc    QWORD PTR [rsi]
  c14030:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14036:	mov    edx,0x1
  c1403b:	jmp    c14087 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4767>
  c1403d:	mov    rax,QWORD PTR [r14+0x8]
  c14041:	dec    QWORD PTR [rax]
  c14044:	jne    c10fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16aa>
  c1404a:	lea    rdi,[r14+0x8]
  c1404e:	call   QWORD PTR [rip+0x2399c4]        # e4da18 <_DYNAMIC+0x258>
  c14054:	jmp    c10fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x16aa>
  c14059:	mov    rsi,QWORD PTR [rax+0x8]
  c1405d:	inc    QWORD PTR [rsi]
  c14060:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14066:	movabs rax,0xffffffff00000000
  c14070:	mov    rdx,QWORD PTR [rsp+0x328]
  c14078:	and    rdx,rax
  c1407b:	or     rdx,0x6
  c1407f:	mov    rax,QWORD PTR [rsp+0x260]
  c14087:	mov    QWORD PTR [rsp+0x328],rdx
  c1408f:	mov    QWORD PTR [rsp+0x80],rdx
  c14097:	mov    QWORD PTR [rsp+0x490],rsi
  c1409f:	mov    QWORD PTR [rsp+0x88],rsi
  c140a7:	mov    QWORD PTR [rsp+0x260],rax
  c140af:	mov    QWORD PTR [rsp+0x90],rax
  c140b7:	lea    rdi,[rsp+0x110]
  c140bf:	lea    rsi,[rsp+0x80]
  c140c7:	call   QWORD PTR [rip+0x23df8b]        # e52058 <_DYNAMIC+0x4898>
  c140cd:	movzx  eax,BYTE PTR [rsp+0x110]
  c140d5:	movzx  ebx,BYTE PTR [rsp+0x111]
  c140dd:	cmp    al,0xff
  c140df:	jne    c17568 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7c48>
  c140e5:	mov    eax,DWORD PTR [rsp+0x80]
  c140ec:	mov    edx,eax
  c140ee:	sub    edx,0x2
  c140f1:	mov    ecx,0x3
  c140f6:	cmovae ecx,edx
  c140f9:	cmp    ecx,0x8
  c140fc:	ja     c15616 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5cf6>
  c14102:	mov    edx,0x1e7
  c14107:	bt     edx,ecx
  c1410a:	jae    c14177 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4857>
  c1410c:	mov    rax,QWORD PTR [rsp+0x18]
  c14111:	add    rax,0x10
  c14115:	mov    rsi,QWORD PTR [rax]
  c14118:	test   bl,0x1
  c1411b:	je     c14148 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4828>
  c1411d:	cmp    QWORD PTR [rsp+0x8],rsi
  c14122:	jae    c1a005 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6e5>
  c14128:	mov    rax,QWORD PTR [r14]
  c1412b:	mov    rcx,QWORD PTR [rsp+0x20]
  c14130:	inc    QWORD PTR [rax+rcx*1+0x58]
  c14135:	mov    rbp,QWORD PTR [rsp+0x30]
  c1413a:	test   r15b,r15b
  c1413d:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c14143:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c14148:	cmp    QWORD PTR [rsp+0x8],rsi
  c1414d:	jae    c1a017 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6f7>
  c14153:	mov    rax,QWORD PTR [r14]
  c14156:	movsx  rcx,bp
  c1415a:	mov    rdx,QWORD PTR [rsp+0x20]
  c1415f:	mov    QWORD PTR [rax+rdx*1+0x58],rcx
  c14164:	mov    rbp,QWORD PTR [rsp+0x30]
  c14169:	test   r15b,r15b
  c1416c:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c14172:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c14177:	cmp    ecx,0x3
  c1417a:	jne    c15576 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c56>
  c14180:	test   eax,eax
  c14182:	je     c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c14184:	mov    rax,QWORD PTR [rsp+0x88]
  c1418c:	dec    QWORD PTR [rax]
  c1418f:	jne    c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c14195:	lea    rdi,[rsp+0x88]
  c1419d:	call   QWORD PTR [rip+0x239865]        # e4da08 <_DYNAMIC+0x248>
  c141a3:	jmp    c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c141a8:	mov    r8,QWORD PTR [rax+0x8]
  c141ac:	inc    QWORD PTR [r8]
  c141af:	mov    rax,QWORD PTR [rsp+0x18]
  c141b4:	lea    rdx,[rax+0x8]
  c141b8:	mov    rdi,QWORD PTR [rsp+0x28]
  c141bd:	lea    rsi,[rax+0x10]
  c141c1:	mov    rbp,QWORD PTR [rsp+0x30]
  c141c6:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c141cc:	movabs rax,0xffffffff00000000
  c141d6:	mov    rbx,QWORD PTR [rsp+0x2b0]
  c141de:	and    rbx,rax
  c141e1:	or     rbx,0xb
  c141e5:	jmp    c142b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4990>
  c141ea:	movabs rax,0xffffffff00000000
  c141f4:	mov    rbx,QWORD PTR [rsp+0x2b0]
  c141fc:	and    rbx,rax
  c141ff:	or     rbx,0x2
  c14203:	jmp    c1421e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x48fe>
  c14205:	movabs rax,0xffffffff00000000
  c1420f:	mov    rbx,QWORD PTR [rsp+0x2b0]
  c14217:	and    rbx,rax
  c1421a:	or     rbx,0x3
  c1421e:	mov    rax,QWORD PTR [rsp+0x18]
  c14223:	lea    rdx,[rax+0x8]
  c14227:	mov    rdi,QWORD PTR [rsp+0x28]
  c1422c:	lea    rsi,[rax+0x10]
  c14230:	mov    rbp,QWORD PTR [rsp+0x30]
  c14235:	mov    r8,QWORD PTR [rsp+0x428]
  c1423d:	jmp    c142b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4990>
  c1423f:	test   cl,0x1
  c14242:	mov    rsi,QWORD PTR [rsp+0x18]
  c14247:	lea    rdx,[rsi+0x8]
  c1424b:	mov    rdi,QWORD PTR [rsp+0x28]
  c14250:	lea    rsi,[rsi+0x10]
  c14254:	mov    rbp,QWORD PTR [rsp+0x30]
  c14259:	je     c16274 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6954>
  c1425f:	mov    r8,QWORD PTR [rax+0x8]
  c14263:	inc    QWORD PTR [r8]
  c14266:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1426c:	mov    ebx,0x1
  c14271:	jmp    c142b8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4998>
  c14273:	mov    r8,QWORD PTR [rax+0x8]
  c14277:	inc    QWORD PTR [r8]
  c1427a:	mov    rax,QWORD PTR [rsp+0x18]
  c1427f:	lea    rdx,[rax+0x8]
  c14283:	mov    rdi,QWORD PTR [rsp+0x28]
  c14288:	lea    rsi,[rax+0x10]
  c1428c:	mov    rbp,QWORD PTR [rsp+0x30]
  c14291:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14297:	movabs rax,0xffffffff00000000
  c142a1:	mov    rbx,QWORD PTR [rsp+0x2b0]
  c142a9:	and    rbx,rax
  c142ac:	or     rbx,0x6
  c142b0:	mov    rcx,QWORD PTR [rsp+0x218]
  c142b8:	mov    QWORD PTR [rsp+0x80],rbx
  c142c0:	mov    QWORD PTR [rsp+0x88],r8
  c142c8:	mov    QWORD PTR [rsp+0x218],rcx
  c142d0:	mov    QWORD PTR [rsp+0x90],rcx
  c142d8:	mov    rsi,QWORD PTR [rsi]
  c142db:	cmp    QWORD PTR [rsp+0x8],rsi
  c142e0:	jae    c19df6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4d6>
  c142e6:	mov    rdx,QWORD PTR [rdx]
  c142e9:	mov    rsi,QWORD PTR [rsp+0x20]
  c142ee:	lea    rcx,[rdx+rsi*1]
  c142f2:	mov    rax,r12
  c142f5:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c142fa:	jae    c1430a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x49ea>
  c142fc:	mov    rax,QWORD PTR [rcx+0x28]
  c14300:	shl    r12d,0x4
  c14304:	mov    rax,QWORD PTR [rax+r12*1]
  c14308:	jmp    c1430e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x49ee>
  c1430a:	add    rax,QWORD PTR [rcx+0x60]
  c1430e:	mov    r12,QWORD PTR [rsp+0x10]
  c14313:	mov    rcx,QWORD PTR [rdi+0x8]
  c14317:	mov    rdx,QWORD PTR [rsp+0x90]
  c1431f:	mov    QWORD PTR [rsp+0x120],rdx
  c14327:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c14330:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c14339:	cmp    rax,QWORD PTR [rdi+0x10]
  c1433d:	jae    c1801e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x86fe>
  c14343:	mov    QWORD PTR [rsp+0x428],r8
  c1434b:	lea    rax,[rax+rax*2]
  c1434f:	lea    r14,[rcx+rax*8]
  c14353:	mov    eax,DWORD PTR [rcx+rax*8]
  c14356:	mov    edx,eax
  c14358:	sub    edx,0x2
  c1435b:	mov    ecx,0x3
  c14360:	cmovae ecx,edx
  c14363:	cmp    ecx,0x8
  c14366:	ja     c156d0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5db0>
  c1436c:	mov    edx,0x1e7
  c14371:	bt     edx,ecx
  c14374:	jae    c143b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a94>
  c14376:	mov    QWORD PTR [rsp+0x2b0],rbx
  c1437e:	mov    rax,QWORD PTR [rsp+0x90]
  c14386:	mov    QWORD PTR [r14+0x10],rax
  c1438a:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c14393:	movdqu XMMWORD PTR [r14],xmm0
  c14398:	mov    rcx,QWORD PTR [rsp+0x18]
  c1439d:	lea    rax,[rcx+0x10]
  c143a1:	mov    rsi,QWORD PTR [rax]
  c143a4:	cmp    QWORD PTR [rsp+0x8],rsi
  c143a9:	jb     c15fca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66aa>
  c143af:	jmp    c19e4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa52d>
  c143b4:	cmp    ecx,0x3
  c143b7:	jne    c15693 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5d73>
  c143bd:	test   eax,eax
  c143bf:	je     c14376 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a56>
  c143c1:	mov    rax,QWORD PTR [r14+0x8]
  c143c5:	dec    QWORD PTR [rax]
  c143c8:	jne    c14376 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a56>
  c143ca:	lea    rdi,[r14+0x8]
  c143ce:	call   QWORD PTR [rip+0x239634]        # e4da08 <_DYNAMIC+0x248>
  c143d4:	jmp    c14376 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a56>
  c143d6:	mov    rcx,QWORD PTR [rax+0x8]
  c143da:	inc    QWORD PTR [rcx]
  c143dd:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c143e3:	movabs rax,0xffffffff00000000
  c143ed:	mov    rdx,QWORD PTR [rsp+0x2a8]
  c143f5:	and    rdx,rax
  c143f8:	or     rdx,0xb
  c143fc:	jmp    c11666 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1d46>
  c14401:	movabs rax,0xffffffff00000000
  c1440b:	mov    rdx,QWORD PTR [rsp+0x2a8]
  c14413:	and    rdx,rax
  c14416:	or     rdx,0x2
  c1441a:	mov    rcx,QWORD PTR [rsp+0x420]
  c14422:	jmp    c11666 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1d46>
  c14427:	movabs rax,0xffffffff00000000
  c14431:	mov    rdx,QWORD PTR [rsp+0x2a8]
  c14439:	and    rdx,rax
  c1443c:	or     rdx,0x3
  c14440:	mov    rcx,QWORD PTR [rsp+0x420]
  c14448:	jmp    c11666 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1d46>
  c1444d:	test   cl,0x1
  c14450:	je     c1628e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x696e>
  c14456:	mov    rcx,QWORD PTR [rax+0x8]
  c1445a:	inc    QWORD PTR [rcx]
  c1445d:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14463:	mov    edx,0x1
  c14468:	jmp    c11666 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1d46>
  c1446d:	mov    rcx,QWORD PTR [rax+0x8]
  c14471:	inc    QWORD PTR [rcx]
  c14474:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1447a:	movabs rax,0xffffffff00000000
  c14484:	mov    rdx,QWORD PTR [rsp+0x2a8]
  c1448c:	and    rdx,rax
  c1448f:	or     rdx,0x6
  c14493:	jmp    c11666 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1d46>
  c14498:	mov    rdi,QWORD PTR [rcx+0x8]
  c1449c:	inc    QWORD PTR [rdi]
  c1449f:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c144a5:	movabs rcx,0xffffffff00000000
  c144af:	mov    rsi,QWORD PTR [rsp+0x2a0]
  c144b7:	and    rsi,rcx
  c144ba:	or     rsi,0xb
  c144be:	jmp    c1454c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c2c>
  c144c3:	movabs rcx,0xffffffff00000000
  c144cd:	mov    rsi,QWORD PTR [rsp+0x2a0]
  c144d5:	and    rsi,rcx
  c144d8:	or     rsi,0x2
  c144dc:	mov    rdi,QWORD PTR [rsp+0x418]
  c144e4:	jmp    c1454c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c2c>
  c144e6:	movabs rcx,0xffffffff00000000
  c144f0:	mov    rsi,QWORD PTR [rsp+0x2a0]
  c144f8:	and    rsi,rcx
  c144fb:	or     rsi,0x3
  c144ff:	mov    rdi,QWORD PTR [rsp+0x418]
  c14507:	jmp    c1454c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c2c>
  c14509:	test   dl,0x1
  c1450c:	je     c162a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6988>
  c14512:	mov    rdi,QWORD PTR [rcx+0x8]
  c14516:	inc    QWORD PTR [rdi]
  c14519:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1451f:	mov    esi,0x1
  c14524:	jmp    c14554 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c34>
  c14526:	mov    rdi,QWORD PTR [rcx+0x8]
  c1452a:	inc    QWORD PTR [rdi]
  c1452d:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14533:	movabs rcx,0xffffffff00000000
  c1453d:	mov    rsi,QWORD PTR [rsp+0x2a0]
  c14545:	and    rsi,rcx
  c14548:	or     rsi,0x6
  c1454c:	mov    rcx,QWORD PTR [rsp+0x1f0]
  c14554:	imul   rax,rax,0xc8
  c1455b:	add    rax,QWORD PTR [rsp+0x3a8]
  c14563:	mov    QWORD PTR [rsp+0x110],rsi
  c1456b:	mov    QWORD PTR [rsp+0x118],rdi
  c14573:	mov    QWORD PTR [rsp+0x120],rcx
  c1457b:	cmp    QWORD PTR [rax+0x28],rbp
  c1457f:	jbe    c17fe5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x86c5>
  c14585:	mov    QWORD PTR [rsp+0x1f0],rcx
  c1458d:	mov    QWORD PTR [rsp+0x418],rdi
  c14595:	mov    QWORD PTR [rsp+0x2a0],rsi
  c1459d:	lea    rsi,[rbp*2+0x0]
  c145a5:	add    rsi,rbp
  c145a8:	shl    esi,0x3
  c145ab:	add    rsi,QWORD PTR [rax+0x20]
  c145af:	lea    rdi,[rsp+0x110]
  c145b7:	call   QWORD PTR [rip+0x23ea43]        # e53000 <_DYNAMIC+0x5840>
  c145bd:	mov    rcx,QWORD PTR [rsp+0x18]
  c145c2:	add    rcx,0x10
  c145c6:	mov    rsi,QWORD PTR [rcx]
  c145c9:	test   al,al
  c145cb:	mov    rbp,QWORD PTR [rsp+0x30]
  c145d0:	je     c145ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ccc>
  c145d2:	cmp    QWORD PTR [rsp+0x8],rsi
  c145d7:	jae    c1a068 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa748>
  c145dd:	mov    rax,QWORD PTR [r14]
  c145e0:	mov    rcx,QWORD PTR [rsp+0x20]
  c145e5:	inc    QWORD PTR [rax+rcx*1+0x58]
  c145ea:	jmp    c14608 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ce8>
  c145ec:	cmp    QWORD PTR [rsp+0x8],rsi
  c145f1:	jae    c1a05f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa73f>
  c145f7:	mov    rax,QWORD PTR [r14]
  c145fa:	movsx  rcx,bx
  c145fe:	mov    rdx,QWORD PTR [rsp+0x20]
  c14603:	mov    QWORD PTR [rax+rdx*1+0x58],rcx
  c14608:	mov    eax,DWORD PTR [rsp+0x110]
  c1460f:	mov    edx,eax
  c14611:	sub    edx,0x2
  c14614:	mov    ecx,0x3
  c14619:	cmovae ecx,edx
  c1461c:	cmp    ecx,0x8
  c1461f:	ja     c15742 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5e22>
  c14625:	mov    edx,0x1e7
  c1462a:	bt     edx,ecx
  c1462d:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c14633:	cmp    ecx,0x3
  c14636:	jne    c15708 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5de8>
  c1463c:	test   eax,eax
  c1463e:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c14644:	mov    rax,QWORD PTR [rsp+0x118]
  c1464c:	dec    QWORD PTR [rax]
  c1464f:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c14655:	lea    rdi,[rsp+0x118]
  c1465d:	call   QWORD PTR [rip+0x2393a5]        # e4da08 <_DYNAMIC+0x248>
  c14663:	test   r15b,r15b
  c14666:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c1466c:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c14671:	mov    rdi,QWORD PTR [rcx+0x8]
  c14675:	inc    QWORD PTR [rdi]
  c14678:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1467e:	movabs rcx,0xffffffff00000000
  c14688:	mov    rsi,QWORD PTR [rsp+0x298]
  c14690:	and    rsi,rcx
  c14693:	or     rsi,0xb
  c14697:	jmp    c14725 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4e05>
  c1469c:	movabs rcx,0xffffffff00000000
  c146a6:	mov    rsi,QWORD PTR [rsp+0x298]
  c146ae:	and    rsi,rcx
  c146b1:	or     rsi,0x2
  c146b5:	mov    rdi,QWORD PTR [rsp+0x410]
  c146bd:	jmp    c14725 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4e05>
  c146bf:	movabs rcx,0xffffffff00000000
  c146c9:	mov    rsi,QWORD PTR [rsp+0x298]
  c146d1:	and    rsi,rcx
  c146d4:	or     rsi,0x3
  c146d8:	mov    rdi,QWORD PTR [rsp+0x410]
  c146e0:	jmp    c14725 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4e05>
  c146e2:	test   dl,0x1
  c146e5:	je     c162c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69a2>
  c146eb:	mov    rdi,QWORD PTR [rcx+0x8]
  c146ef:	inc    QWORD PTR [rdi]
  c146f2:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c146f8:	mov    esi,0x1
  c146fd:	jmp    c1472d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4e0d>
  c146ff:	mov    rdi,QWORD PTR [rcx+0x8]
  c14703:	inc    QWORD PTR [rdi]
  c14706:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1470c:	movabs rcx,0xffffffff00000000
  c14716:	mov    rsi,QWORD PTR [rsp+0x298]
  c1471e:	and    rsi,rcx
  c14721:	or     rsi,0x6
  c14725:	mov    rcx,QWORD PTR [rsp+0x1e8]
  c1472d:	imul   rax,rax,0xc8
  c14734:	add    rax,QWORD PTR [rsp+0x3a8]
  c1473c:	mov    QWORD PTR [rsp+0x80],rsi
  c14744:	mov    QWORD PTR [rsp+0x88],rdi
  c1474c:	mov    QWORD PTR [rsp+0x90],rcx
  c14754:	cmp    QWORD PTR [rax+0x28],rbp
  c14758:	jbe    c17fc6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x86a6>
  c1475e:	mov    QWORD PTR [rsp+0x1e8],rcx
  c14766:	mov    QWORD PTR [rsp+0x410],rdi
  c1476e:	mov    QWORD PTR [rsp+0x298],rsi
  c14776:	lea    rdx,[rbp*2+0x0]
  c1477e:	add    rdx,rbp
  c14781:	shl    edx,0x3
  c14784:	add    rdx,QWORD PTR [rax+0x20]
  c14788:	lea    rcx,[rip+0xffffffffff6b1f64]        # 2c66f3 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x370>
  c1478f:	lea    rdi,[rsp+0x110]
  c14797:	lea    rsi,[rsp+0x80]
  c1479f:	mov    r8d,0x1
  c147a5:	call   QWORD PTR [rip+0x23adb5]        # e4f560 <_DYNAMIC+0x1da0>
  c147ab:	movzx  ecx,BYTE PTR [rsp+0x110]
  c147b3:	movzx  eax,BYTE PTR [rsp+0x111]
  c147bb:	cmp    cl,0xff
  c147be:	mov    rbp,QWORD PTR [rsp+0x30]
  c147c3:	jne    c18301 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89e1>
  c147c9:	mov    rcx,QWORD PTR [rsp+0x18]
  c147ce:	add    rcx,0x10
  c147d2:	mov    rsi,QWORD PTR [rcx]
  c147d5:	test   al,al
  c147d7:	js     c147f7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4ed7>
  c147d9:	cmp    QWORD PTR [rsp+0x8],rsi
  c147de:	jae    c19fc3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa6a3>
  c147e4:	mov    rax,QWORD PTR [r14]
  c147e7:	movsx  rcx,bx
  c147eb:	mov    rdx,QWORD PTR [rsp+0x20]
  c147f0:	mov    QWORD PTR [rax+rdx*1+0x58],rcx
  c147f5:	jmp    c1480f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4eef>
  c147f7:	cmp    QWORD PTR [rsp+0x8],rsi
  c147fc:	jae    c1a07f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa75f>
  c14802:	mov    rax,QWORD PTR [r14]
  c14805:	mov    rcx,QWORD PTR [rsp+0x20]
  c1480a:	inc    QWORD PTR [rax+rcx*1+0x58]
  c1480f:	mov    eax,DWORD PTR [rsp+0x80]
  c14816:	mov    edx,eax
  c14818:	sub    edx,0x2
  c1481b:	mov    ecx,0x3
  c14820:	cmovae ecx,edx
  c14823:	cmp    ecx,0x8
  c14826:	ja     c15b8c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x626c>
  c1482c:	mov    edx,0x1e7
  c14831:	bt     edx,ecx
  c14834:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c1483a:	cmp    ecx,0x3
  c1483d:	jne    c15b6e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x624e>
  c14843:	test   eax,eax
  c14845:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c1484b:	mov    rax,QWORD PTR [rsp+0x88]
  c14853:	dec    QWORD PTR [rax]
  c14856:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c1485c:	lea    rdi,[rsp+0x88]
  c14864:	call   QWORD PTR [rip+0x23919e]        # e4da08 <_DYNAMIC+0x248>
  c1486a:	test   r15b,r15b
  c1486d:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c14873:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c14878:	mov    rax,QWORD PTR [rcx+0x8]
  c1487c:	inc    QWORD PTR [rax]
  c1487f:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14885:	movq   xmm0,rax
  c1488a:	mov    eax,0xb
  c1488f:	jmp    c162fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69dc>
  c14894:	mov    eax,0x2
  c14899:	jmp    c148a0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4f80>
  c1489b:	mov    eax,0x3
  c148a0:	jmp    c162fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69dc>
  c148a5:	mov    rax,QWORD PTR [rcx+0x8]
  c148a9:	inc    QWORD PTR [rax]
  c148ac:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c148b2:	movq   xmm0,rax
  c148b7:	mov    eax,0xb
  c148bc:	jmp    c165c1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ca1>
  c148c1:	mov    eax,0x2
  c148c6:	jmp    c148cd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4fad>
  c148c8:	mov    eax,0x3
  c148cd:	jmp    c165c1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ca1>
  c148d2:	mov    rax,QWORD PTR [rcx+0x8]
  c148d6:	inc    QWORD PTR [rax]
  c148d9:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c148df:	movq   xmm0,rax
  c148e4:	mov    eax,0xb
  c148e9:	jmp    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c148ee:	mov    eax,0x2
  c148f3:	jmp    c148fa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4fda>
  c148f5:	mov    eax,0x3
  c148fa:	jmp    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c148ff:	test   dl,0x1
  c14902:	je     c162dc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69bc>
  c14908:	mov    rsi,QWORD PTR [rcx+0x8]
  c1490c:	inc    QWORD PTR [rsi]
  c1490f:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14915:	mov    eax,0x1
  c1491a:	jmp    c162ee <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69ce>
  c1491f:	test   dl,0x1
  c14922:	je     c165a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c81>
  c14928:	mov    rsi,QWORD PTR [rcx+0x8]
  c1492c:	inc    QWORD PTR [rsi]
  c1492f:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14935:	mov    eax,0x1
  c1493a:	jmp    c165b3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c93>
  c1493f:	test   dl,0x1
  c14942:	je     c16871 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f51>
  c14948:	mov    rsi,QWORD PTR [rcx+0x8]
  c1494c:	inc    QWORD PTR [rsi]
  c1494f:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14955:	mov    eax,0x1
  c1495a:	jmp    c16883 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f63>
  c1495f:	mov    rax,QWORD PTR [rcx+0x8]
  c14963:	inc    QWORD PTR [rax]
  c14966:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1496c:	movq   xmm0,rax
  c14971:	mov    eax,0x6
  c14976:	jmp    c162fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x69dc>
  c1497b:	mov    rax,QWORD PTR [rcx+0x8]
  c1497f:	inc    QWORD PTR [rax]
  c14982:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14988:	movq   xmm0,rax
  c1498d:	mov    eax,0x6
  c14992:	jmp    c165c1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ca1>
  c14997:	mov    rax,QWORD PTR [rcx+0x8]
  c1499b:	inc    QWORD PTR [rax]
  c1499e:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c149a4:	movq   xmm0,rax
  c149a9:	mov    eax,0xb
  c149ae:	jmp    c16b61 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7241>
  c149b3:	mov    rax,QWORD PTR [rcx+0x8]
  c149b7:	inc    QWORD PTR [rax]
  c149ba:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c149c0:	movq   xmm0,rax
  c149c5:	mov    eax,0x6
  c149ca:	jmp    c16891 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f71>
  c149cf:	mov    eax,0x2
  c149d4:	jmp    c149db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x50bb>
  c149d6:	mov    eax,0x3
  c149db:	jmp    c16b61 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7241>
  c149e0:	test   dl,0x1
  c149e3:	je     c16b41 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7221>
  c149e9:	mov    rsi,QWORD PTR [rcx+0x8]
  c149ed:	inc    QWORD PTR [rsi]
  c149f0:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c149f6:	mov    eax,0x1
  c149fb:	jmp    c16b53 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7233>
  c14a00:	mov    rax,QWORD PTR [rcx+0x8]
  c14a04:	inc    QWORD PTR [rax]
  c14a07:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14a0d:	movq   xmm0,rax
  c14a12:	mov    eax,0x6
  c14a17:	jmp    c16b61 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7241>
  c14a1c:	mov    rdi,QWORD PTR [rcx+0x8]
  c14a20:	inc    QWORD PTR [rdi]
  c14a23:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14a29:	movabs rcx,0xffffffff00000000
  c14a33:	mov    r8,QWORD PTR [rsp+0x290]
  c14a3b:	and    r8,rcx
  c14a3e:	or     r8,0xb
  c14a42:	jmp    c14aff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51df>
  c14a47:	movabs rcx,0xffffffff00000000
  c14a51:	mov    r8,QWORD PTR [rsp+0x290]
  c14a59:	and    r8,rcx
  c14a5c:	or     r8,0x2
  c14a60:	mov    rdi,QWORD PTR [rsp+0x408]
  c14a68:	jmp    c14aff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51df>
  c14a6d:	movabs rcx,0xffffffff00000000
  c14a77:	mov    r8,QWORD PTR [rsp+0x290]
  c14a7f:	and    r8,rcx
  c14a82:	or     r8,0x3
  c14a86:	mov    rdi,QWORD PTR [rsp+0x408]
  c14a8e:	jmp    c14aff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51df>
  c14a90:	test   dl,0x1
  c14a93:	je     c16df1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74d1>
  c14a99:	mov    rdi,QWORD PTR [rcx+0x8]
  c14a9d:	inc    QWORD PTR [rdi]
  c14aa0:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14aa6:	mov    r8d,0x1
  c14aac:	jmp    c14b07 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51e7>
  c14aae:	mov    rcx,QWORD PTR [rax+0x8]
  c14ab2:	inc    QWORD PTR [rcx]
  c14ab5:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14abb:	movabs rax,0xffffffff00000000
  c14ac5:	mov    rdi,QWORD PTR [rsp+0x2d0]
  c14acd:	and    rdi,rax
  c14ad0:	or     rdi,0xb
  c14ad4:	jmp    c12d05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33e5>
  c14ad9:	mov    rdi,QWORD PTR [rcx+0x8]
  c14add:	inc    QWORD PTR [rdi]
  c14ae0:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14ae6:	movabs rcx,0xffffffff00000000
  c14af0:	mov    r8,QWORD PTR [rsp+0x290]
  c14af8:	and    r8,rcx
  c14afb:	or     r8,0x6
  c14aff:	mov    rsi,QWORD PTR [rsp+0x210]
  c14b07:	mov    QWORD PTR [rsp+0x80],r8
  c14b0f:	mov    QWORD PTR [rsp+0x88],rdi
  c14b17:	mov    QWORD PTR [rsp+0x210],rsi
  c14b1f:	mov    QWORD PTR [rsp+0x90],rsi
  c14b27:	mov    rcx,QWORD PTR [rsp+0x18]
  c14b2c:	add    rcx,0x10
  c14b30:	mov    rsi,QWORD PTR [rcx]
  c14b33:	cmp    QWORD PTR [rsp+0x8],rsi
  c14b38:	jae    c19db5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa495>
  c14b3e:	mov    rsi,QWORD PTR [r14]
  c14b41:	mov    r9,QWORD PTR [rsp+0x20]
  c14b46:	lea    rdx,[rsi+r9*1]
  c14b4a:	movzx  ecx,ax
  c14b4d:	mov    rax,rcx
  c14b50:	sub    rax,QWORD PTR [rsi+r9*1+0x30]
  c14b55:	jae    c14b64 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5244>
  c14b57:	mov    rax,QWORD PTR [rdx+0x28]
  c14b5b:	shl    ecx,0x4
  c14b5e:	mov    rax,QWORD PTR [rax+rcx*1]
  c14b62:	jmp    c14b68 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5248>
  c14b64:	add    rax,QWORD PTR [rdx+0x60]
  c14b68:	mov    rcx,QWORD PTR [rsp+0x28]
  c14b6d:	cmp    rax,QWORD PTR [rcx+0x10]
  c14b71:	jae    c181f4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x88d4>
  c14b77:	mov    QWORD PTR [rsp+0x408],rdi
  c14b7f:	mov    rdx,QWORD PTR [rcx+0x8]
  c14b83:	lea    rax,[rax+rax*2]
  c14b87:	mov    ecx,DWORD PTR [rdx+rax*8]
  c14b8a:	lea    esi,[rcx-0x2]
  c14b8d:	cmp    rcx,0x2
  c14b91:	mov    edi,0x3
  c14b96:	cmovae edi,esi
  c14b99:	lea    rax,[rdx+rax*8]
  c14b9d:	lea    rdx,[rip+0xffffffffff6b0d98]        # 2c593c <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xf7b>
  c14ba4:	movsxd rsi,DWORD PTR [rdx+rdi*4]
  c14ba8:	add    rsi,rdx
  c14bab:	mov    QWORD PTR [rsp+0x290],r8
  c14bb3:	jmp    rsi
  c14bb5:	mov    rdx,QWORD PTR [rax]
  c14bb8:	mov    rsi,QWORD PTR [rax+0x8]
  c14bbc:	mov    rdi,QWORD PTR [rax+0x10]
  c14bc0:	jmp    c158cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5faf>
  c14bc5:	movabs rax,0xffffffff00000000
  c14bcf:	mov    rdi,QWORD PTR [rsp+0x2d0]
  c14bd7:	and    rdi,rax
  c14bda:	or     rdi,0x2
  c14bde:	mov    rcx,QWORD PTR [rsp+0x1d0]
  c14be6:	jmp    c12d05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33e5>
  c14beb:	movabs rax,0xffffffff00000000
  c14bf5:	mov    rdi,QWORD PTR [rsp+0x2d0]
  c14bfd:	and    rdi,rax
  c14c00:	or     rdi,0x3
  c14c04:	mov    rcx,QWORD PTR [rsp+0x1d0]
  c14c0c:	jmp    c12d05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33e5>
  c14c11:	test   cl,0x1
  c14c14:	je     c16e09 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74e9>
  c14c1a:	mov    rcx,QWORD PTR [rax+0x8]
  c14c1e:	inc    QWORD PTR [rcx]
  c14c21:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14c27:	mov    edi,0x1
  c14c2c:	jmp    c12d05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33e5>
  c14c31:	mov    rax,QWORD PTR [r14+0x8]
  c14c35:	dec    QWORD PTR [rax]
  c14c38:	jne    c131e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38c9>
  c14c3e:	lea    rdi,[r14+0x8]
  c14c42:	call   QWORD PTR [rip+0x238dc8]        # e4da10 <_DYNAMIC+0x250>
  c14c48:	jmp    c131e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38c9>
  c14c4d:	mov    rdi,QWORD PTR [rax+0x8]
  c14c51:	inc    QWORD PTR [rdi]
  c14c54:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14c5a:	movabs rax,0xffffffff00000000
  c14c64:	mov    rdx,QWORD PTR [rsp+0x2b8]
  c14c6c:	and    rdx,rax
  c14c6f:	or     rdx,0xb
  c14c73:	jmp    c14d5a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x543a>
  c14c78:	mov    rcx,QWORD PTR [rax+0x8]
  c14c7c:	inc    QWORD PTR [rcx]
  c14c7f:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14c85:	movabs rax,0xffffffff00000000
  c14c8f:	mov    rdi,QWORD PTR [rsp+0x2d0]
  c14c97:	and    rdi,rax
  c14c9a:	or     rdi,0x6
  c14c9e:	jmp    c12d05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33e5>
  c14ca3:	movabs rax,0xffffffff00000000
  c14cad:	mov    rdx,QWORD PTR [rsp+0x2b8]
  c14cb5:	and    rdx,rax
  c14cb8:	or     rdx,0x2
  c14cbc:	mov    rdi,QWORD PTR [rsp+0x430]
  c14cc4:	jmp    c14d5a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x543a>
  c14cc9:	movabs rax,0xffffffff00000000
  c14cd3:	mov    rdx,QWORD PTR [rsp+0x2b8]
  c14cdb:	and    rdx,rax
  c14cde:	or     rdx,0x3
  c14ce2:	mov    rdi,QWORD PTR [rsp+0x430]
  c14cea:	jmp    c14d5a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x543a>
  c14cec:	test   cl,0x1
  c14cef:	je     c16e23 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7503>
  c14cf5:	mov    rdi,QWORD PTR [rax+0x8]
  c14cf9:	inc    QWORD PTR [rdi]
  c14cfc:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14d02:	mov    edx,0x1
  c14d07:	jmp    c14d62 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5442>
  c14d09:	mov    rsi,QWORD PTR [rax+0x8]
  c14d0d:	inc    QWORD PTR [rsi]
  c14d10:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14d16:	movabs rax,0xffffffff00000000
  c14d20:	mov    rdx,QWORD PTR [rsp+0x2c8]
  c14d28:	and    rdx,rax
  c14d2b:	or     rdx,0xb
  c14d2f:	jmp    c1500f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56ef>
  c14d34:	mov    rdi,QWORD PTR [rax+0x8]
  c14d38:	inc    QWORD PTR [rdi]
  c14d3b:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14d41:	movabs rax,0xffffffff00000000
  c14d4b:	mov    rdx,QWORD PTR [rsp+0x2b8]
  c14d53:	and    rdx,rax
  c14d56:	or     rdx,0x6
  c14d5a:	mov    rax,QWORD PTR [rsp+0x200]
  c14d62:	mov    QWORD PTR [rsp+0x80],rdx
  c14d6a:	mov    QWORD PTR [rsp+0x88],rdi
  c14d72:	mov    QWORD PTR [rsp+0x200],rax
  c14d7a:	mov    QWORD PTR [rsp+0x90],rax
  c14d82:	mov    rsi,QWORD PTR [r11]
  c14d85:	cmp    QWORD PTR [rsp+0x8],rsi
  c14d8a:	jae    c19dc1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa4a1>
  c14d90:	mov    rcx,QWORD PTR [r9]
  c14d93:	mov    rsi,QWORD PTR [rsp+0x20]
  c14d98:	lea    rax,[rcx+rsi*1]
  c14d9c:	mov    rbx,r12
  c14d9f:	sub    rbx,QWORD PTR [rcx+rsi*1+0x30]
  c14da4:	mov    QWORD PTR [rsp+0x2d8],r8
  c14dac:	mov    QWORD PTR [rsp+0x2b8],rdx
  c14db4:	mov    QWORD PTR [rsp+0x430],rdi
  c14dbc:	mov    ebp,r15d
  c14dbf:	jae    c14dcf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54af>
  c14dc1:	mov    rax,QWORD PTR [rax+0x28]
  c14dc5:	shl    r12d,0x4
  c14dc9:	mov    rbx,QWORD PTR [rax+r12*1]
  c14dcd:	jmp    c14dd3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x54b3>
  c14dcf:	add    rbx,QWORD PTR [rax+0x60]
  c14dd3:	mov    r12,QWORD PTR [rsp+0x10]
  c14dd8:	mov    r15,QWORD PTR [r10+0x8]
  c14ddc:	mov    r14,QWORD PTR [r10+0x10]
  c14de0:	lea    rdi,[rsp+0x40]
  c14de5:	lea    rsi,[rsp+0x80]
  c14ded:	call   QWORD PTR [rip+0x23e20d]        # e53000 <_DYNAMIC+0x5840>
  c14df3:	xor    al,0x1
  c14df5:	mov    BYTE PTR [rsp+0x114],al
  c14dfc:	mov    DWORD PTR [rsp+0x110],0x4
  c14e07:	cmp    rbx,r14
  c14e0a:	jae    c182ad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x898d>
  c14e10:	lea    rax,[rbx+rbx*2]
  c14e14:	lea    r14,[r15+rax*8]
  c14e18:	mov    eax,DWORD PTR [r15+rax*8]
  c14e1c:	mov    edx,eax
  c14e1e:	sub    edx,0x2
  c14e21:	mov    ecx,0x3
  c14e26:	cmovae ecx,edx
  c14e29:	cmp    ecx,0x8
  c14e2c:	ja     c15a40 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6120>
  c14e32:	mov    edx,0x1e7
  c14e37:	bt     edx,ecx
  c14e3a:	mov    r15d,ebp
  c14e3d:	mov    rbp,QWORD PTR [rsp+0x30]
  c14e42:	jae    c14efd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x55dd>
  c14e48:	mov    rax,QWORD PTR [rsp+0x120]
  c14e50:	mov    QWORD PTR [r14+0x10],rax
  c14e54:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c14e5d:	movdqu XMMWORD PTR [r14],xmm0
  c14e62:	mov    rcx,QWORD PTR [rsp+0x18]
  c14e67:	lea    rax,[rcx+0x10]
  c14e6b:	mov    rsi,QWORD PTR [rax]
  c14e6e:	cmp    QWORD PTR [rsp+0x8],rsi
  c14e73:	jae    c19e5f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa53f>
  c14e79:	lea    r14,[rcx+0x8]
  c14e7d:	mov    rax,QWORD PTR [r14]
  c14e80:	mov    rcx,QWORD PTR [rsp+0x20]
  c14e85:	inc    QWORD PTR [rax+rcx*1+0x58]
  c14e8a:	mov    eax,DWORD PTR [rsp+0x80]
  c14e91:	mov    edx,eax
  c14e93:	sub    edx,0x2
  c14e96:	mov    ecx,0x3
  c14e9b:	cmovae ecx,edx
  c14e9e:	cmp    ecx,0x8
  c14ea1:	ja     c15ad0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x61b0>
  c14ea7:	mov    edx,0x1e7
  c14eac:	bt     edx,ecx
  c14eaf:	jae    c14f2a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x560a>
  c14eb1:	mov    eax,DWORD PTR [rsp+0x40]
  c14eb5:	mov    edx,eax
  c14eb7:	sub    edx,0x2
  c14eba:	mov    ecx,0x3
  c14ebf:	cmovae ecx,edx
  c14ec2:	cmp    ecx,0x8
  c14ec5:	ja     c15b48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6228>
  c14ecb:	mov    edx,0x1e7
  c14ed0:	bt     edx,ecx
  c14ed3:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c14ed9:	cmp    ecx,0x3
  c14edc:	jne    c15b18 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x61f8>
  c14ee2:	test   eax,eax
  c14ee4:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c14eea:	mov    rax,QWORD PTR [rsp+0x48]
  c14eef:	dec    QWORD PTR [rax]
  c14ef2:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c14ef8:	jmp    c159c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60a2>
  c14efd:	cmp    ecx,0x3
  c14f00:	jne    c15a08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60e8>
  c14f06:	test   eax,eax
  c14f08:	je     c14e48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5528>
  c14f0e:	mov    rax,QWORD PTR [r14+0x8]
  c14f12:	dec    QWORD PTR [rax]
  c14f15:	jne    c14e48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5528>
  c14f1b:	lea    rdi,[r14+0x8]
  c14f1f:	call   QWORD PTR [rip+0x238ae3]        # e4da08 <_DYNAMIC+0x248>
  c14f25:	jmp    c14e48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5528>
  c14f2a:	cmp    ecx,0x3
  c14f2d:	jne    c15a88 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6168>
  c14f33:	test   eax,eax
  c14f35:	je     c14eb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5591>
  c14f3b:	mov    rax,QWORD PTR [rsp+0x88]
  c14f43:	dec    QWORD PTR [rax]
  c14f46:	jne    c14eb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5591>
  c14f4c:	lea    rdi,[rsp+0x88]
  c14f54:	call   QWORD PTR [rip+0x238aae]        # e4da08 <_DYNAMIC+0x248>
  c14f5a:	jmp    c14eb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5591>
  c14f5f:	movabs rax,0xffffffff00000000
  c14f69:	mov    rdx,QWORD PTR [rsp+0x2c8]
  c14f71:	and    rdx,rax
  c14f74:	or     rdx,0x2
  c14f78:	mov    rsi,QWORD PTR [rsp+0x440]
  c14f80:	jmp    c1500f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56ef>
  c14f85:	movabs rax,0xffffffff00000000
  c14f8f:	mov    rdx,QWORD PTR [rsp+0x2c8]
  c14f97:	and    rdx,rax
  c14f9a:	or     rdx,0x3
  c14f9e:	mov    rsi,QWORD PTR [rsp+0x440]
  c14fa6:	jmp    c1500f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56ef>
  c14fa8:	test   cl,0x1
  c14fab:	je     c16e3d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x751d>
  c14fb1:	mov    rsi,QWORD PTR [rax+0x8]
  c14fb5:	inc    QWORD PTR [rsi]
  c14fb8:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14fbe:	mov    edx,0x1
  c14fc3:	jmp    c15017 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56f7>
  c14fc5:	mov    rax,QWORD PTR [rsp+0x88]
  c14fcd:	dec    QWORD PTR [rax]
  c14fd0:	jne    c135a5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c85>
  c14fd6:	lea    rdi,[rsp+0x88]
  c14fde:	call   QWORD PTR [rip+0x238a2c]        # e4da10 <_DYNAMIC+0x250>
  c14fe4:	jmp    c135a5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c85>
  c14fe9:	mov    rsi,QWORD PTR [rax+0x8]
  c14fed:	inc    QWORD PTR [rsi]
  c14ff0:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c14ff6:	movabs rax,0xffffffff00000000
  c15000:	mov    rdx,QWORD PTR [rsp+0x2c8]
  c15008:	and    rdx,rax
  c1500b:	or     rdx,0x6
  c1500f:	mov    rdi,QWORD PTR [rsp+0x1f8]
  c15017:	mov    QWORD PTR [rsp+0x2c8],rdx
  c1501f:	mov    QWORD PTR [rsp+0xd0],rdx
  c15027:	mov    QWORD PTR [rsp+0x440],rsi
  c1502f:	mov    QWORD PTR [rsp+0xd8],rsi
  c15037:	mov    QWORD PTR [rsp+0x1f8],rdi
  c1503f:	mov    QWORD PTR [rsp+0xe0],rdi
  c15047:	lea    rdi,[rsp+0x110]
  c1504f:	lea    rsi,[rsp+0xf0]
  c15057:	lea    rdx,[rsp+0xd0]
  c1505f:	mov    rcx,QWORD PTR [rsp+0x640]
  c15067:	call   QWORD PTR [rip+0x23cef3]        # e51f60 <_DYNAMIC+0x47a0>
  c1506d:	movzx  eax,BYTE PTR [rsp+0x110]
  c15075:	cmp    al,0xff
  c15077:	jne    c18220 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8900>
  c1507d:	lea    rdx,[rsp+0x114]
  c15085:	mov    rax,QWORD PTR [rdx+0x14]
  c15089:	lea    rcx,[rsp+0x84]
  c15091:	mov    QWORD PTR [rcx+0x13],rax
  c15095:	movups xmm0,XMMWORD PTR [rdx+0x4]
  c15099:	movups XMMWORD PTR [rcx+0x3],xmm0
  c1509d:	movdqu xmm0,XMMWORD PTR [rcx+0x3]
  c150a2:	movdqa XMMWORD PTR [rsp+0x40],xmm0
  c150a8:	mov    rax,QWORD PTR [rcx+0x13]
  c150ac:	mov    QWORD PTR [rsp+0x50],rax
  c150b1:	mov    rax,QWORD PTR [rsp+0x18]
  c150b6:	add    rax,0x10
  c150ba:	mov    rsi,QWORD PTR [rax]
  c150bd:	cmp    QWORD PTR [rsp+0x8],rsi
  c150c2:	jae    c19e36 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa516>
  c150c8:	mov    rdx,QWORD PTR [rbx]
  c150cb:	mov    rsi,QWORD PTR [rsp+0x20]
  c150d0:	lea    rcx,[rdx+rsi*1]
  c150d4:	mov    rax,r12
  c150d7:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c150dc:	jae    c150ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x57cc>
  c150de:	mov    rax,QWORD PTR [rcx+0x28]
  c150e2:	shl    r12d,0x4
  c150e6:	mov    rax,QWORD PTR [rax+r12*1]
  c150ea:	jmp    c150f0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x57d0>
  c150ec:	add    rax,QWORD PTR [rcx+0x60]
  c150f0:	mov    rcx,QWORD PTR [r14+0x8]
  c150f4:	mov    rdx,QWORD PTR [rsp+0x50]
  c150f9:	mov    QWORD PTR [rsp+0x120],rdx
  c15101:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c15107:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c15110:	cmp    rax,QWORD PTR [r14+0x10]
  c15114:	jae    c185e5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8cc5>
  c1511a:	lea    rax,[rax+rax*2]
  c1511e:	lea    r14,[rcx+rax*8]
  c15122:	mov    eax,DWORD PTR [rcx+rax*8]
  c15125:	mov    edx,eax
  c15127:	sub    edx,0x2
  c1512a:	mov    ecx,0x3
  c1512f:	cmovae ecx,edx
  c15132:	cmp    ecx,0x8
  c15135:	ja     c15bd5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62b5>
  c1513b:	mov    edx,0x1e7
  c15140:	bt     edx,ecx
  c15143:	mov    r12,QWORD PTR [rsp+0x10]
  c15148:	jae    c1521e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x58fe>
  c1514e:	mov    rax,QWORD PTR [rsp+0x50]
  c15153:	mov    QWORD PTR [r14+0x10],rax
  c15157:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c1515d:	movdqu XMMWORD PTR [r14],xmm0
  c15162:	mov    rcx,QWORD PTR [rsp+0x18]
  c15167:	lea    rax,[rcx+0x10]
  c1516b:	mov    rsi,QWORD PTR [rax]
  c1516e:	cmp    QWORD PTR [rsp+0x8],rsi
  c15173:	jae    c19f2c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa60c>
  c15179:	lea    r14,[rcx+0x8]
  c1517d:	mov    rax,QWORD PTR [r14]
  c15180:	mov    rcx,QWORD PTR [rsp+0x20]
  c15185:	inc    QWORD PTR [rax+rcx*1+0x58]
  c1518a:	mov    eax,DWORD PTR [rsp+0xd0]
  c15191:	mov    edx,eax
  c15193:	sub    edx,0x2
  c15196:	mov    ecx,0x3
  c1519b:	cmovae ecx,edx
  c1519e:	cmp    ecx,0x8
  c151a1:	ja     c15c1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62fa>
  c151a7:	mov    edx,0x1e7
  c151ac:	bt     edx,ecx
  c151af:	jae    c1524b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x592b>
  c151b5:	mov    eax,DWORD PTR [rsp+0xf0]
  c151bc:	mov    edx,eax
  c151be:	sub    edx,0x2
  c151c1:	mov    ecx,0x3
  c151c6:	cmovae ecx,edx
  c151c9:	cmp    ecx,0x8
  c151cc:	ja     c15c54 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6334>
  c151d2:	mov    edx,0x1e7
  c151d7:	bt     edx,ecx
  c151da:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c151e0:	cmp    ecx,0x3
  c151e3:	jne    c15c3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x631e>
  c151e9:	test   eax,eax
  c151eb:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c151f1:	mov    rax,QWORD PTR [rsp+0xf8]
  c151f9:	dec    QWORD PTR [rax]
  c151fc:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15202:	lea    rdi,[rsp+0xf8]
  c1520a:	call   QWORD PTR [rip+0x2387f8]        # e4da08 <_DYNAMIC+0x248>
  c15210:	test   r15b,r15b
  c15213:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c15219:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c1521e:	cmp    ecx,0x3
  c15221:	jne    c15bb9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6299>
  c15227:	test   eax,eax
  c15229:	je     c1514e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x582e>
  c1522f:	mov    rax,QWORD PTR [r14+0x8]
  c15233:	dec    QWORD PTR [rax]
  c15236:	jne    c1514e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x582e>
  c1523c:	lea    rdi,[r14+0x8]
  c15240:	call   QWORD PTR [rip+0x2387c2]        # e4da08 <_DYNAMIC+0x248>
  c15246:	jmp    c1514e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x582e>
  c1524b:	cmp    ecx,0x3
  c1524e:	jne    c15bf6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x62d6>
  c15254:	test   eax,eax
  c15256:	je     c151b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5895>
  c1525c:	mov    rax,QWORD PTR [rsp+0xd8]
  c15264:	dec    QWORD PTR [rax]
  c15267:	jne    c151b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5895>
  c1526d:	lea    rdi,[rsp+0xd8]
  c15275:	call   QWORD PTR [rip+0x23878d]        # e4da08 <_DYNAMIC+0x248>
  c1527b:	jmp    c151b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5895>
  c15280:	mov    rax,QWORD PTR [rsp+0x48]
  c15285:	dec    QWORD PTR [rax]
  c15288:	jne    c13b75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4255>
  c1528e:	lea    rdi,[rsp+0x48]
  c15293:	call   QWORD PTR [rip+0x238777]        # e4da10 <_DYNAMIC+0x250>
  c15299:	jmp    c13b75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4255>
  c1529e:	mov    rdi,QWORD PTR [rax+0x8]
  c152a2:	inc    QWORD PTR [rdi]
  c152a5:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c152ab:	movabs rax,0xffffffff00000000
  c152b5:	mov    rdx,QWORD PTR [rsp+0x2c0]
  c152bd:	and    rdx,rax
  c152c0:	or     rdx,0xb
  c152c4:	jmp    c15373 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a53>
  c152c9:	movabs rax,0xffffffff00000000
  c152d3:	mov    rdx,QWORD PTR [rsp+0x2c0]
  c152db:	and    rdx,rax
  c152de:	or     rdx,0x2
  c152e2:	mov    rdi,QWORD PTR [rsp+0x438]
  c152ea:	jmp    c15373 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a53>
  c152ef:	movabs rax,0xffffffff00000000
  c152f9:	mov    rdx,QWORD PTR [rsp+0x2c0]
  c15301:	and    rdx,rax
  c15304:	or     rdx,0x3
  c15308:	mov    rdi,QWORD PTR [rsp+0x438]
  c15310:	jmp    c15373 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a53>
  c15312:	mov    rax,QWORD PTR [rsp+0x48]
  c15317:	dec    QWORD PTR [rax]
  c1531a:	jne    c13e0e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44ee>
  c15320:	lea    rdi,[rsp+0x48]
  c15325:	call   QWORD PTR [rip+0x2386e5]        # e4da10 <_DYNAMIC+0x250>
  c1532b:	jmp    c13e0e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44ee>
  c15330:	test   cl,0x1
  c15333:	je     c16e54 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7534>
  c15339:	mov    rdi,QWORD PTR [rax+0x8]
  c1533d:	inc    QWORD PTR [rdi]
  c15340:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c15346:	mov    edx,0x1
  c1534b:	jmp    c1537b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a5b>
  c1534d:	mov    rdi,QWORD PTR [rax+0x8]
  c15351:	inc    QWORD PTR [rdi]
  c15354:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1535a:	movabs rax,0xffffffff00000000
  c15364:	mov    rdx,QWORD PTR [rsp+0x2c0]
  c1536c:	and    rdx,rax
  c1536f:	or     rdx,0x6
  c15373:	mov    rax,QWORD PTR [rsp+0x208]
  c1537b:	mov    QWORD PTR [rsp+0x80],rdx
  c15383:	mov    QWORD PTR [rsp+0x88],rdi
  c1538b:	mov    QWORD PTR [rsp+0x208],rax
  c15393:	mov    QWORD PTR [rsp+0x90],rax
  c1539b:	mov    rsi,QWORD PTR [r11]
  c1539e:	cmp    QWORD PTR [rsp+0x8],rsi
  c153a3:	jae    c19d69 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa449>
  c153a9:	mov    rcx,QWORD PTR [r9]
  c153ac:	mov    rsi,QWORD PTR [rsp+0x20]
  c153b1:	lea    rax,[rcx+rsi*1]
  c153b5:	mov    rbx,r12
  c153b8:	sub    rbx,QWORD PTR [rcx+rsi*1+0x30]
  c153bd:	mov    QWORD PTR [rsp+0x2e0],r8
  c153c5:	mov    QWORD PTR [rsp+0x2c0],rdx
  c153cd:	mov    QWORD PTR [rsp+0x438],rdi
  c153d5:	mov    ebp,r15d
  c153d8:	jae    c153e8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ac8>
  c153da:	mov    rax,QWORD PTR [rax+0x28]
  c153de:	shl    r12d,0x4
  c153e2:	mov    rbx,QWORD PTR [rax+r12*1]
  c153e6:	jmp    c153ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5acc>
  c153e8:	add    rbx,QWORD PTR [rax+0x60]
  c153ec:	mov    r12,QWORD PTR [rsp+0x10]
  c153f1:	mov    r15,QWORD PTR [r10+0x8]
  c153f5:	mov    r14,QWORD PTR [r10+0x10]
  c153f9:	lea    rdi,[rsp+0x40]
  c153fe:	lea    rsi,[rsp+0x80]
  c15406:	call   QWORD PTR [rip+0x23dbf4]        # e53000 <_DYNAMIC+0x5840>
  c1540c:	mov    BYTE PTR [rsp+0x114],al
  c15413:	mov    DWORD PTR [rsp+0x110],0x4
  c1541e:	cmp    rbx,r14
  c15421:	jae    c18274 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8954>
  c15427:	lea    rax,[rbx+rbx*2]
  c1542b:	lea    r14,[r15+rax*8]
  c1542f:	mov    eax,DWORD PTR [r15+rax*8]
  c15433:	mov    edx,eax
  c15435:	sub    edx,0x2
  c15438:	mov    ecx,0x3
  c1543d:	cmovae ecx,edx
  c15440:	cmp    ecx,0x8
  c15443:	ja     c15a64 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6144>
  c15449:	mov    edx,0x1e7
  c1544e:	bt     edx,ecx
  c15451:	mov    r15d,ebp
  c15454:	mov    rbp,QWORD PTR [rsp+0x30]
  c15459:	jae    c15514 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5bf4>
  c1545f:	mov    rax,QWORD PTR [rsp+0x120]
  c15467:	mov    QWORD PTR [r14+0x10],rax
  c1546b:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c15474:	movdqu XMMWORD PTR [r14],xmm0
  c15479:	mov    rcx,QWORD PTR [rsp+0x18]
  c1547e:	lea    rax,[rcx+0x10]
  c15482:	mov    rsi,QWORD PTR [rax]
  c15485:	cmp    QWORD PTR [rsp+0x8],rsi
  c1548a:	jae    c19e9f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa57f>
  c15490:	lea    r14,[rcx+0x8]
  c15494:	mov    rax,QWORD PTR [r14]
  c15497:	mov    rcx,QWORD PTR [rsp+0x20]
  c1549c:	inc    QWORD PTR [rax+rcx*1+0x58]
  c154a1:	mov    eax,DWORD PTR [rsp+0x80]
  c154a8:	mov    edx,eax
  c154aa:	sub    edx,0x2
  c154ad:	mov    ecx,0x3
  c154b2:	cmovae ecx,edx
  c154b5:	cmp    ecx,0x8
  c154b8:	ja     c15af4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x61d4>
  c154be:	mov    edx,0x1e7
  c154c3:	bt     edx,ecx
  c154c6:	jae    c15541 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5c21>
  c154c8:	mov    eax,DWORD PTR [rsp+0x40]
  c154cc:	mov    edx,eax
  c154ce:	sub    edx,0x2
  c154d1:	mov    ecx,0x3
  c154d6:	cmovae ecx,edx
  c154d9:	cmp    ecx,0x8
  c154dc:	ja     c15b5b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x623b>
  c154e2:	mov    edx,0x1e7
  c154e7:	bt     edx,ecx
  c154ea:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c154f0:	cmp    ecx,0x3
  c154f3:	jne    c15b30 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6210>
  c154f9:	test   eax,eax
  c154fb:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15501:	mov    rax,QWORD PTR [rsp+0x48]
  c15506:	dec    QWORD PTR [rax]
  c15509:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c1550f:	jmp    c159c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60a2>
  c15514:	cmp    ecx,0x3
  c15517:	jne    c15a24 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6104>
  c1551d:	test   eax,eax
  c1551f:	je     c1545f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b3f>
  c15525:	mov    rax,QWORD PTR [r14+0x8]
  c15529:	dec    QWORD PTR [rax]
  c1552c:	jne    c1545f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b3f>
  c15532:	lea    rdi,[r14+0x8]
  c15536:	call   QWORD PTR [rip+0x2384cc]        # e4da08 <_DYNAMIC+0x248>
  c1553c:	jmp    c1545f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b3f>
  c15541:	cmp    ecx,0x3
  c15544:	jne    c15aac <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x618c>
  c1554a:	test   eax,eax
  c1554c:	je     c154c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ba8>
  c15552:	mov    rax,QWORD PTR [rsp+0x88]
  c1555a:	dec    QWORD PTR [rax]
  c1555d:	jne    c154c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ba8>
  c15563:	lea    rdi,[rsp+0x88]
  c1556b:	call   QWORD PTR [rip+0x238497]        # e4da08 <_DYNAMIC+0x248>
  c15571:	jmp    c154c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ba8>
  c15576:	mov    rax,QWORD PTR [rsp+0x88]
  c1557e:	dec    QWORD PTR [rax]
  c15581:	jne    c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c15587:	lea    rdi,[rsp+0x88]
  c1558f:	call   QWORD PTR [rip+0x23847b]        # e4da10 <_DYNAMIC+0x250>
  c15595:	jmp    c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c1559a:	mov    rax,QWORD PTR [r14+0x8]
  c1559e:	dec    QWORD PTR [rax]
  c155a1:	jne    c131e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38c9>
  c155a7:	lea    rdi,[r14+0x8]
  c155ab:	call   QWORD PTR [rip+0x238467]        # e4da18 <_DYNAMIC+0x258>
  c155b1:	jmp    c131e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x38c9>
  c155b6:	mov    rax,QWORD PTR [rsp+0x88]
  c155be:	dec    QWORD PTR [rax]
  c155c1:	jne    c135a5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c85>
  c155c7:	lea    rdi,[rsp+0x88]
  c155cf:	call   QWORD PTR [rip+0x238443]        # e4da18 <_DYNAMIC+0x258>
  c155d5:	jmp    c135a5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c85>
  c155da:	mov    rax,QWORD PTR [rsp+0x48]
  c155df:	dec    QWORD PTR [rax]
  c155e2:	jne    c13b75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4255>
  c155e8:	lea    rdi,[rsp+0x48]
  c155ed:	call   QWORD PTR [rip+0x238425]        # e4da18 <_DYNAMIC+0x258>
  c155f3:	jmp    c13b75 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4255>
  c155f8:	mov    rax,QWORD PTR [rsp+0x48]
  c155fd:	dec    QWORD PTR [rax]
  c15600:	jne    c13e0e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44ee>
  c15606:	lea    rdi,[rsp+0x48]
  c1560b:	call   QWORD PTR [rip+0x238407]        # e4da18 <_DYNAMIC+0x258>
  c15611:	jmp    c13e0e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x44ee>
  c15616:	mov    rax,QWORD PTR [rsp+0x88]
  c1561e:	dec    QWORD PTR [rax]
  c15621:	jne    c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c15627:	lea    rdi,[rsp+0x88]
  c1562f:	call   QWORD PTR [rip+0x2383e3]        # e4da18 <_DYNAMIC+0x258>
  c15635:	jmp    c1410c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x47ec>
  c1563a:	mov    rax,QWORD PTR [r14+0x8]
  c1563e:	dec    QWORD PTR [rax]
  c15641:	jne    c119ae <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x208e>
  c15647:	lea    rdi,[r14+0x8]
  c1564b:	call   QWORD PTR [rip+0x2383bf]        # e4da10 <_DYNAMIC+0x250>
  c15651:	jmp    c119ae <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x208e>
  c15656:	mov    rax,QWORD PTR [r14+0x8]
  c1565a:	dec    QWORD PTR [rax]
  c1565d:	mov    r12,QWORD PTR [rsp+0x10]
  c15662:	jne    c119ae <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x208e>
  c15668:	lea    rdi,[r14+0x8]
  c1566c:	call   QWORD PTR [rip+0x2383a6]        # e4da18 <_DYNAMIC+0x258>
  c15672:	jmp    c119ae <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x208e>
  c15677:	mov    rax,QWORD PTR [r14+0x8]
  c1567b:	dec    QWORD PTR [rax]
  c1567e:	jne    c116df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1dbf>
  c15684:	lea    rdi,[r14+0x8]
  c15688:	call   QWORD PTR [rip+0x238382]        # e4da10 <_DYNAMIC+0x250>
  c1568e:	jmp    c116df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1dbf>
  c15693:	mov    rax,QWORD PTR [r14+0x8]
  c15697:	dec    QWORD PTR [rax]
  c1569a:	jne    c14376 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a56>
  c156a0:	lea    rdi,[r14+0x8]
  c156a4:	call   QWORD PTR [rip+0x238366]        # e4da10 <_DYNAMIC+0x250>
  c156aa:	jmp    c14376 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a56>
  c156af:	mov    rax,QWORD PTR [r14+0x8]
  c156b3:	dec    QWORD PTR [rax]
  c156b6:	mov    rbp,QWORD PTR [rsp+0x30]
  c156bb:	jne    c116df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1dbf>
  c156c1:	lea    rdi,[r14+0x8]
  c156c5:	call   QWORD PTR [rip+0x23834d]        # e4da18 <_DYNAMIC+0x258>
  c156cb:	jmp    c116df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1dbf>
  c156d0:	mov    rax,QWORD PTR [r14+0x8]
  c156d4:	dec    QWORD PTR [rax]
  c156d7:	jne    c14376 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a56>
  c156dd:	lea    rdi,[r14+0x8]
  c156e1:	call   QWORD PTR [rip+0x238331]        # e4da18 <_DYNAMIC+0x258>
  c156e7:	jmp    c14376 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4a56>
  c156ec:	mov    rax,QWORD PTR [r14+0x8]
  c156f0:	dec    QWORD PTR [rax]
  c156f3:	jne    c1388c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f6c>
  c156f9:	lea    rdi,[r14+0x8]
  c156fd:	call   QWORD PTR [rip+0x23830d]        # e4da10 <_DYNAMIC+0x250>
  c15703:	jmp    c1388c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f6c>
  c15708:	mov    rax,QWORD PTR [rsp+0x118]
  c15710:	dec    QWORD PTR [rax]
  c15713:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15719:	lea    rdi,[rsp+0x118]
  c15721:	jmp    c15df5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d5>
  c15726:	mov    rax,QWORD PTR [r14+0x8]
  c1572a:	dec    QWORD PTR [rax]
  c1572d:	jne    c1388c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f6c>
  c15733:	lea    rdi,[r14+0x8]
  c15737:	call   QWORD PTR [rip+0x2382db]        # e4da18 <_DYNAMIC+0x258>
  c1573d:	jmp    c1388c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f6c>
  c15742:	mov    rax,QWORD PTR [rsp+0x118]
  c1574a:	dec    QWORD PTR [rax]
  c1574d:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15753:	lea    rdi,[rsp+0x118]
  c1575b:	call   QWORD PTR [rip+0x2382b7]        # e4da18 <_DYNAMIC+0x258>
  c15761:	test   r15b,r15b
  c15764:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c1576a:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c1576f:	mov    rax,QWORD PTR [r14+0x8]
  c15773:	dec    QWORD PTR [rax]
  c15776:	jne    c13c14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x42f4>
  c1577c:	lea    rdi,[r14+0x8]
  c15780:	call   QWORD PTR [rip+0x23828a]        # e4da10 <_DYNAMIC+0x250>
  c15786:	jmp    c13c14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x42f4>
  c1578b:	mov    rax,QWORD PTR [r14+0x8]
  c1578f:	dec    QWORD PTR [rax]
  c15792:	jne    c13ead <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x458d>
  c15798:	lea    rdi,[r14+0x8]
  c1579c:	call   QWORD PTR [rip+0x23826e]        # e4da10 <_DYNAMIC+0x250>
  c157a2:	jmp    c13ead <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x458d>
  c157a7:	mov    rax,QWORD PTR [r14+0x8]
  c157ab:	dec    QWORD PTR [rax]
  c157ae:	jne    c13c14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x42f4>
  c157b4:	lea    rdi,[r14+0x8]
  c157b8:	call   QWORD PTR [rip+0x23825a]        # e4da18 <_DYNAMIC+0x258>
  c157be:	jmp    c13c14 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x42f4>
  c157c3:	mov    rax,QWORD PTR [r14+0x8]
  c157c7:	dec    QWORD PTR [rax]
  c157ca:	jne    c13ead <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x458d>
  c157d0:	lea    rdi,[r14+0x8]
  c157d4:	call   QWORD PTR [rip+0x23823e]        # e4da18 <_DYNAMIC+0x258>
  c157da:	jmp    c13ead <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x458d>
  c157df:	mov    rax,QWORD PTR [rsp+0x88]
  c157e7:	dec    QWORD PTR [rax]
  c157ea:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c157f0:	lea    rdi,[rsp+0x88]
  c157f8:	jmp    c15df5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d5>
  c157fd:	mov    rax,QWORD PTR [rsp+0x88]
  c15805:	dec    QWORD PTR [rax]
  c15808:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c1580e:	jmp    c15b9d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x627d>
  c15813:	mov    rsi,QWORD PTR [rax+0x8]
  c15817:	inc    QWORD PTR [rsi]
  c1581a:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c15820:	movabs rax,0xffffffff00000000
  c1582a:	mov    rdx,QWORD PTR [rsp+0x288]
  c15832:	and    rdx,rax
  c15835:	or     rdx,0xb
  c15839:	jmp    c158c7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5fa7>
  c1583e:	movabs rax,0xffffffff00000000
  c15848:	mov    rdx,QWORD PTR [rsp+0x288]
  c15850:	and    rdx,rax
  c15853:	or     rdx,0x2
  c15857:	mov    rsi,QWORD PTR [rsp+0x400]
  c1585f:	jmp    c158c7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5fa7>
  c15861:	movabs rax,0xffffffff00000000
  c1586b:	mov    rdx,QWORD PTR [rsp+0x288]
  c15873:	and    rdx,rax
  c15876:	or     rdx,0x3
  c1587a:	mov    rsi,QWORD PTR [rsp+0x400]
  c15882:	jmp    c158c7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5fa7>
  c15884:	test   cl,0x1
  c15887:	je     c16e6e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x754e>
  c1588d:	mov    rsi,QWORD PTR [rax+0x8]
  c15891:	inc    QWORD PTR [rsi]
  c15894:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1589a:	mov    edx,0x1
  c1589f:	jmp    c158cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5faf>
  c158a1:	mov    rsi,QWORD PTR [rax+0x8]
  c158a5:	inc    QWORD PTR [rsi]
  c158a8:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c158ae:	movabs rax,0xffffffff00000000
  c158b8:	mov    rdx,QWORD PTR [rsp+0x288]
  c158c0:	and    rdx,rax
  c158c3:	or     rdx,0x6
  c158c7:	mov    rdi,QWORD PTR [rsp+0x1e0]
  c158cf:	mov    QWORD PTR [rsp+0x288],rdx
  c158d7:	mov    QWORD PTR [rsp+0x5e0],rdx
  c158df:	mov    QWORD PTR [rsp+0x400],rsi
  c158e7:	mov    QWORD PTR [rsp+0x5e8],rsi
  c158ef:	mov    QWORD PTR [rsp+0x1e0],rdi
  c158f7:	mov    QWORD PTR [rsp+0x5f0],rdi
  c158ff:	lea    rdi,[rsp+0x110]
  c15907:	lea    rsi,[rsp+0x40]
  c1590c:	lea    rdx,[rsp+0x80]
  c15914:	lea    rcx,[rsp+0x5e0]
  c1591c:	call   QWORD PTR [rip+0x23d6e6]        # e53008 <_DYNAMIC+0x5848>
  c15922:	cmp    BYTE PTR [rsp+0x110],0xff
  c1592a:	jne    c1864c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d2c>
  c15930:	mov    rax,QWORD PTR [rsp+0x18]
  c15935:	add    rax,0x10
  c15939:	mov    rsi,QWORD PTR [rax]
  c1593c:	cmp    QWORD PTR [rsp+0x8],rsi
  c15941:	jae    c19f7e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa65e>
  c15947:	mov    rax,QWORD PTR [r14]
  c1594a:	mov    rcx,QWORD PTR [rsp+0x20]
  c1594f:	inc    QWORD PTR [rax+rcx*1+0x58]
  c15954:	mov    eax,DWORD PTR [rsp+0x80]
  c1595b:	mov    edx,eax
  c1595d:	sub    edx,0x2
  c15960:	mov    ecx,0x3
  c15965:	cmovae ecx,edx
  c15968:	cmp    ecx,0x8
  c1596b:	ja     c15d16 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63f6>
  c15971:	mov    edx,0x1e7
  c15976:	bt     edx,ecx
  c15979:	jae    c159db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x60bb>
  c1597b:	mov    eax,DWORD PTR [rsp+0x40]
  c1597f:	mov    edx,eax
  c15981:	sub    edx,0x2
  c15984:	mov    ecx,0x3
  c15989:	cmovae ecx,edx
  c1598c:	cmp    ecx,0x8
  c1598f:	ja     c15d52 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6432>
  c15995:	mov    edx,0x1e7
  c1599a:	bt     edx,ecx
  c1599d:	jb     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c159a3:	cmp    ecx,0x3
  c159a6:	jne    c15d3a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x641a>
  c159ac:	test   eax,eax
  c159ae:	je     c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c159b4:	mov    rax,QWORD PTR [rsp+0x48]
  c159b9:	dec    QWORD PTR [rax]
  c159bc:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c159c2:	lea    rdi,[rsp+0x48]
  c159c7:	call   QWORD PTR [rip+0x23803b]        # e4da08 <_DYNAMIC+0x248>
  c159cd:	test   r15b,r15b
  c159d0:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c159d6:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c159db:	cmp    ecx,0x3
  c159de:	jne    c15cf2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x63d2>
  c159e4:	test   eax,eax
  c159e6:	je     c1597b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x605b>
  c159e8:	mov    rax,QWORD PTR [rsp+0x88]
  c159f0:	dec    QWORD PTR [rax]
  c159f3:	jne    c1597b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x605b>
  c159f5:	lea    rdi,[rsp+0x88]
  c159fd:	call   QWORD PTR [rip+0x238005]        # e4da08 <_DYNAMIC+0x248>
  c15a03:	jmp    c1597b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x605b>
  c15a08:	mov    rax,QWORD PTR [r14+0x8]
  c15a0c:	dec    QWORD PTR [rax]
  c15a0f:	jne    c14e48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5528>
  c15a15:	lea    rdi,[r14+0x8]
  c15a19:	call   QWORD PTR [rip+0x237ff1]        # e4da10 <_DYNAMIC+0x250>
  c15a1f:	jmp    c14e48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5528>
  c15a24:	mov    rax,QWORD PTR [r14+0x8]
  c15a28:	dec    QWORD PTR [rax]
  c15a2b:	jne    c1545f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b3f>
  c15a31:	lea    rdi,[r14+0x8]
  c15a35:	call   QWORD PTR [rip+0x237fd5]        # e4da10 <_DYNAMIC+0x250>
  c15a3b:	jmp    c1545f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b3f>
  c15a40:	mov    rax,QWORD PTR [r14+0x8]
  c15a44:	dec    QWORD PTR [rax]
  c15a47:	mov    r15d,ebp
  c15a4a:	mov    rbp,QWORD PTR [rsp+0x30]
  c15a4f:	jne    c14e48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5528>
  c15a55:	lea    rdi,[r14+0x8]
  c15a59:	call   QWORD PTR [rip+0x237fb9]        # e4da18 <_DYNAMIC+0x258>
  c15a5f:	jmp    c14e48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5528>
  c15a64:	mov    rax,QWORD PTR [r14+0x8]
  c15a68:	dec    QWORD PTR [rax]
  c15a6b:	mov    r15d,ebp
  c15a6e:	mov    rbp,QWORD PTR [rsp+0x30]
  c15a73:	jne    c1545f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b3f>
  c15a79:	lea    rdi,[r14+0x8]
  c15a7d:	call   QWORD PTR [rip+0x237f95]        # e4da18 <_DYNAMIC+0x258>
  c15a83:	jmp    c1545f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5b3f>
  c15a88:	mov    rax,QWORD PTR [rsp+0x88]
  c15a90:	dec    QWORD PTR [rax]
  c15a93:	jne    c14eb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5591>
  c15a99:	lea    rdi,[rsp+0x88]
  c15aa1:	call   QWORD PTR [rip+0x237f69]        # e4da10 <_DYNAMIC+0x250>
  c15aa7:	jmp    c14eb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5591>
  c15aac:	mov    rax,QWORD PTR [rsp+0x88]
  c15ab4:	dec    QWORD PTR [rax]
  c15ab7:	jne    c154c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ba8>
  c15abd:	lea    rdi,[rsp+0x88]
  c15ac5:	call   QWORD PTR [rip+0x237f45]        # e4da10 <_DYNAMIC+0x250>
  c15acb:	jmp    c154c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ba8>
  c15ad0:	mov    rax,QWORD PTR [rsp+0x88]
  c15ad8:	dec    QWORD PTR [rax]
  c15adb:	jne    c14eb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5591>
  c15ae1:	lea    rdi,[rsp+0x88]
  c15ae9:	call   QWORD PTR [rip+0x237f29]        # e4da18 <_DYNAMIC+0x258>
  c15aef:	jmp    c14eb1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5591>
  c15af4:	mov    rax,QWORD PTR [rsp+0x88]
  c15afc:	dec    QWORD PTR [rax]
  c15aff:	jne    c154c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ba8>
  c15b05:	lea    rdi,[rsp+0x88]
  c15b0d:	call   QWORD PTR [rip+0x237f05]        # e4da18 <_DYNAMIC+0x258>
  c15b13:	jmp    c154c8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5ba8>
  c15b18:	mov    rax,QWORD PTR [rsp+0x48]
  c15b1d:	dec    QWORD PTR [rax]
  c15b20:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15b26:	lea    rdi,[rsp+0x48]
  c15b2b:	jmp    c15df5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d5>
  c15b30:	mov    rax,QWORD PTR [rsp+0x48]
  c15b35:	dec    QWORD PTR [rax]
  c15b38:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15b3e:	lea    rdi,[rsp+0x48]
  c15b43:	jmp    c15df5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d5>
  c15b48:	mov    rax,QWORD PTR [rsp+0x48]
  c15b4d:	dec    QWORD PTR [rax]
  c15b50:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15b56:	jmp    c15d60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6440>
  c15b5b:	mov    rax,QWORD PTR [rsp+0x48]
  c15b60:	dec    QWORD PTR [rax]
  c15b63:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15b69:	jmp    c15d60 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6440>
  c15b6e:	mov    rax,QWORD PTR [rsp+0x88]
  c15b76:	dec    QWORD PTR [rax]
  c15b79:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15b7f:	lea    rdi,[rsp+0x88]
  c15b87:	jmp    c15df5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d5>
  c15b8c:	mov    rax,QWORD PTR [rsp+0x88]
  c15b94:	dec    QWORD PTR [rax]
  c15b97:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15b9d:	lea    rdi,[rsp+0x88]
  c15ba5:	call   QWORD PTR [rip+0x237e6d]        # e4da18 <_DYNAMIC+0x258>
  c15bab:	test   r15b,r15b
  c15bae:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c15bb4:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c15bb9:	mov    rax,QWORD PTR [r14+0x8]
  c15bbd:	dec    QWORD PTR [rax]
  c15bc0:	jne    c1514e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x582e>
  c15bc6:	lea    rdi,[r14+0x8]
  c15bca:	call   QWORD PTR [rip+0x237e40]        # e4da10 <_DYNAMIC+0x250>
  c15bd0:	jmp    c1514e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x582e>
  c15bd5:	mov    rax,QWORD PTR [r14+0x8]
  c15bd9:	dec    QWORD PTR [rax]
  c15bdc:	mov    r12,QWORD PTR [rsp+0x10]
  c15be1:	jne    c1514e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x582e>
  c15be7:	lea    rdi,[r14+0x8]
  c15beb:	call   QWORD PTR [rip+0x237e27]        # e4da18 <_DYNAMIC+0x258>
  c15bf1:	jmp    c1514e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x582e>
  c15bf6:	mov    rax,QWORD PTR [rsp+0xd8]
  c15bfe:	dec    QWORD PTR [rax]
  c15c01:	jne    c151b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5895>
  c15c07:	lea    rdi,[rsp+0xd8]
  c15c0f:	call   QWORD PTR [rip+0x237dfb]        # e4da10 <_DYNAMIC+0x250>
  c15c15:	jmp    c151b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5895>
  c15c1a:	mov    rax,QWORD PTR [rsp+0xd8]
  c15c22:	dec    QWORD PTR [rax]
  c15c25:	jne    c151b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5895>
  c15c2b:	lea    rdi,[rsp+0xd8]
  c15c33:	call   QWORD PTR [rip+0x237ddf]        # e4da18 <_DYNAMIC+0x258>
  c15c39:	jmp    c151b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5895>
  c15c3e:	mov    rax,QWORD PTR [rsp+0xf8]
  c15c46:	dec    QWORD PTR [rax]
  c15c49:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15c4f:	jmp    c15ded <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64cd>
  c15c54:	mov    rax,QWORD PTR [rsp+0xf8]
  c15c5c:	dec    QWORD PTR [rax]
  c15c5f:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15c65:	jmp    c15e1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64fa>
  c15c6a:	mov    rax,QWORD PTR [r14+0x8]
  c15c6e:	dec    QWORD PTR [rax]
  c15c71:	jne    c1264f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d2f>
  c15c77:	lea    rdi,[r14+0x8]
  c15c7b:	call   QWORD PTR [rip+0x237d8f]        # e4da10 <_DYNAMIC+0x250>
  c15c81:	jmp    c1264f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d2f>
  c15c86:	mov    rax,QWORD PTR [r14+0x8]
  c15c8a:	dec    QWORD PTR [rax]
  c15c8d:	jne    c1264f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d2f>
  c15c93:	lea    rdi,[r14+0x8]
  c15c97:	call   QWORD PTR [rip+0x237d7b]        # e4da18 <_DYNAMIC+0x258>
  c15c9d:	jmp    c1264f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2d2f>
  c15ca2:	mov    rax,QWORD PTR [rsp+0x360]
  c15caa:	dec    QWORD PTR [rax]
  c15cad:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15cb3:	lea    rdi,[rsp+0x360]
  c15cbb:	jmp    c15df5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d5>
  c15cc0:	mov    rax,QWORD PTR [rsp+0x360]
  c15cc8:	dec    QWORD PTR [rax]
  c15ccb:	mov    r12,QWORD PTR [rsp+0x10]
  c15cd0:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15cd6:	lea    rdi,[rsp+0x360]
  c15cde:	call   QWORD PTR [rip+0x237d34]        # e4da18 <_DYNAMIC+0x258>
  c15ce4:	test   r15b,r15b
  c15ce7:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c15ced:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c15cf2:	mov    rax,QWORD PTR [rsp+0x88]
  c15cfa:	dec    QWORD PTR [rax]
  c15cfd:	jne    c1597b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x605b>
  c15d03:	lea    rdi,[rsp+0x88]
  c15d0b:	call   QWORD PTR [rip+0x237cff]        # e4da10 <_DYNAMIC+0x250>
  c15d11:	jmp    c1597b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x605b>
  c15d16:	mov    rax,QWORD PTR [rsp+0x88]
  c15d1e:	dec    QWORD PTR [rax]
  c15d21:	jne    c1597b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x605b>
  c15d27:	lea    rdi,[rsp+0x88]
  c15d2f:	call   QWORD PTR [rip+0x237ce3]        # e4da18 <_DYNAMIC+0x258>
  c15d35:	jmp    c1597b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x605b>
  c15d3a:	mov    rax,QWORD PTR [rsp+0x48]
  c15d3f:	dec    QWORD PTR [rax]
  c15d42:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15d48:	lea    rdi,[rsp+0x48]
  c15d4d:	jmp    c15df5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64d5>
  c15d52:	mov    rax,QWORD PTR [rsp+0x48]
  c15d57:	dec    QWORD PTR [rax]
  c15d5a:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15d60:	lea    rdi,[rsp+0x48]
  c15d65:	call   QWORD PTR [rip+0x237cad]        # e4da18 <_DYNAMIC+0x258>
  c15d6b:	test   r15b,r15b
  c15d6e:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c15d74:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c15d79:	mov    rax,QWORD PTR [r14+0x8]
  c15d7d:	dec    QWORD PTR [rax]
  c15d80:	jne    c12094 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2774>
  c15d86:	lea    rdi,[r14+0x8]
  c15d8a:	call   QWORD PTR [rip+0x237c80]        # e4da10 <_DYNAMIC+0x250>
  c15d90:	jmp    c12094 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2774>
  c15d95:	mov    rax,QWORD PTR [r14+0x8]
  c15d99:	dec    QWORD PTR [rax]
  c15d9c:	mov    r12,QWORD PTR [rsp+0x10]
  c15da1:	jne    c12094 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2774>
  c15da7:	lea    rdi,[r14+0x8]
  c15dab:	call   QWORD PTR [rip+0x237c67]        # e4da18 <_DYNAMIC+0x258>
  c15db1:	jmp    c12094 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x2774>
  c15db6:	mov    rax,QWORD PTR [rsp+0xf8]
  c15dbe:	dec    QWORD PTR [rax]
  c15dc1:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15dc7:	jmp    c15ded <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64cd>
  c15dc9:	mov    rax,QWORD PTR [rsp+0xf8]
  c15dd1:	dec    QWORD PTR [rax]
  c15dd4:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15dda:	jmp    c15e1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x64fa>
  c15ddc:	mov    rax,QWORD PTR [rsp+0xf8]
  c15de4:	dec    QWORD PTR [rax]
  c15de7:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15ded:	lea    rdi,[rsp+0xf8]
  c15df5:	call   QWORD PTR [rip+0x237c15]        # e4da10 <_DYNAMIC+0x250>
  c15dfb:	test   r15b,r15b
  c15dfe:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c15e04:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c15e09:	mov    rax,QWORD PTR [rsp+0xf8]
  c15e11:	dec    QWORD PTR [rax]
  c15e14:	jne    c15fdb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66bb>
  c15e1a:	lea    rdi,[rsp+0xf8]
  c15e22:	call   QWORD PTR [rip+0x237bf0]        # e4da18 <_DYNAMIC+0x258>
  c15e28:	test   r15b,r15b
  c15e2b:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c15e31:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c15e36:	mov    rax,QWORD PTR [rsp+0x1d0]
  c15e3e:	inc    QWORD PTR [rax]
  c15e41:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c15e47:	mov    QWORD PTR [rsp+0x118],rax
  c15e4f:	mov    DWORD PTR [rsp+0x110],0xb
  c15e5a:	jmp    c12f2a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x360a>
  c15e5f:	mov    DWORD PTR [rsp+0x110],0x2
  c15e6a:	jmp    c12f2a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x360a>
  c15e6f:	mov    DWORD PTR [rsp+0x110],0x3
  c15e7a:	jmp    c12f2a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x360a>
  c15e7f:	test   dil,0x1
  c15e83:	je     c16e85 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7565>
  c15e89:	mov    rax,QWORD PTR [rsp+0x1d0]
  c15e91:	inc    QWORD PTR [rax]
  c15e94:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c15e9a:	mov    ecx,0x1
  c15e9f:	jmp    c16e8e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x756e>
  c15ea4:	mov    rax,QWORD PTR [rsp+0x1d0]
  c15eac:	inc    QWORD PTR [rax]
  c15eaf:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c15eb5:	mov    QWORD PTR [rsp+0x118],rax
  c15ebd:	mov    DWORD PTR [rsp+0x110],0x6
  c15ec8:	jmp    c12f2a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x360a>
  c15ecd:	mov    esi,DWORD PTR [rcx+0x4]
  c15ed0:	mov    rdx,QWORD PTR [rcx+0x8]
  c15ed4:	mov    rcx,QWORD PTR [rcx+0x10]
  c15ed8:	add    rdi,0x8
  c15edc:	mov    r8,QWORD PTR [rsp+0x28]
  c15ee1:	mov    DWORD PTR [rsp+0x80],eax
  c15ee8:	mov    DWORD PTR [rsp+0x84],esi
  c15eef:	mov    QWORD PTR [rsp+0x88],rdx
  c15ef7:	mov    QWORD PTR [rsp+0x90],rcx
  c15eff:	mov    rsi,QWORD PTR [r9]
  c15f02:	cmp    QWORD PTR [rsp+0x8],rsi
  c15f07:	jae    c19c08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa2e8>
  c15f0d:	mov    rdx,QWORD PTR [rdi]
  c15f10:	mov    rsi,QWORD PTR [rsp+0x20]
  c15f15:	lea    rcx,[rdx+rsi*1]
  c15f19:	mov    rax,r12
  c15f1c:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c15f21:	jae    c15f31 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6611>
  c15f23:	mov    rax,QWORD PTR [rcx+0x28]
  c15f27:	shl    r12d,0x4
  c15f2b:	mov    rax,QWORD PTR [rax+r12*1]
  c15f2f:	jmp    c15f35 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6615>
  c15f31:	add    rax,QWORD PTR [rcx+0x60]
  c15f35:	mov    r12,QWORD PTR [rsp+0x10]
  c15f3a:	mov    rcx,QWORD PTR [r8+0x8]
  c15f3e:	mov    rdx,QWORD PTR [rsp+0x90]
  c15f46:	mov    QWORD PTR [rsp+0x120],rdx
  c15f4e:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c15f57:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c15f60:	cmp    rax,QWORD PTR [r8+0x10]
  c15f64:	jae    c17aeb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x81cb>
  c15f6a:	lea    rax,[rax+rax*2]
  c15f6e:	lea    r14,[rcx+rax*8]
  c15f72:	mov    eax,DWORD PTR [rcx+rax*8]
  c15f75:	mov    edx,eax
  c15f77:	sub    edx,0x2
  c15f7a:	mov    ecx,0x3
  c15f7f:	cmovae ecx,edx
  c15f82:	cmp    ecx,0x8
  c15f85:	ja     c1606f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x674f>
  c15f8b:	mov    edx,0x1e7
  c15f90:	bt     edx,ecx
  c15f93:	jae    c1602a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x670a>
  c15f99:	mov    rax,QWORD PTR [rsp+0x90]
  c15fa1:	mov    QWORD PTR [r14+0x10],rax
  c15fa5:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c15fae:	movdqu XMMWORD PTR [r14],xmm0
  c15fb3:	mov    rcx,QWORD PTR [rsp+0x18]
  c15fb8:	lea    rax,[rcx+0x10]
  c15fbc:	mov    rsi,QWORD PTR [rax]
  c15fbf:	cmp    QWORD PTR [rsp+0x8],rsi
  c15fc4:	jae    c19da3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa483>
  c15fca:	lea    r14,[rcx+0x8]
  c15fce:	mov    rax,QWORD PTR [r14]
  c15fd1:	mov    rcx,QWORD PTR [rsp+0x20]
  c15fd6:	inc    QWORD PTR [rax+rcx*1+0x58]
  c15fdb:	test   r15b,r15b
  c15fde:	je     c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c15fe4:	mov    rax,QWORD PTR [rsp+0x18]
  c15fe9:	add    rax,0x10
  c15fed:	mov    rsi,QWORD PTR [rax]
  c15ff0:	cmp    QWORD PTR [rsp+0x8],rsi
  c15ff5:	jae    c1998f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa06f>
  c15ffb:	mov    rax,QWORD PTR [r14]
  c15ffe:	mov    rcx,QWORD PTR [rsp+0x20]
  c16003:	mov    r13,QWORD PTR [rax+rcx*1+0x58]
  c16008:	cmp    r13,rbp
  c1600b:	jae    c17445 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b25>
  c16011:	dec    r15b
  c16014:	cmp    r13,rbp
  c16017:	mov    rbp,QWORD PTR [rsp+0x350]
  c1601f:	jb     c0fc40 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x320>
  c16025:	jmp    c1997a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa05a>
  c1602a:	cmp    ecx,0x3
  c1602d:	jne    c16053 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6733>
  c1602f:	test   eax,eax
  c16031:	je     c15f99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6679>
  c16037:	mov    rax,QWORD PTR [r14+0x8]
  c1603b:	dec    QWORD PTR [rax]
  c1603e:	jne    c15f99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6679>
  c16044:	lea    rdi,[r14+0x8]
  c16048:	call   QWORD PTR [rip+0x2379ba]        # e4da08 <_DYNAMIC+0x248>
  c1604e:	jmp    c15f99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6679>
  c16053:	mov    rax,QWORD PTR [r14+0x8]
  c16057:	dec    QWORD PTR [rax]
  c1605a:	jne    c15f99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6679>
  c16060:	lea    rdi,[r14+0x8]
  c16064:	call   QWORD PTR [rip+0x2379a6]        # e4da10 <_DYNAMIC+0x250>
  c1606a:	jmp    c15f99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6679>
  c1606f:	mov    rax,QWORD PTR [r14+0x8]
  c16073:	dec    QWORD PTR [rax]
  c16076:	jne    c15f99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6679>
  c1607c:	lea    rdi,[r14+0x8]
  c16080:	call   QWORD PTR [rip+0x237992]        # e4da18 <_DYNAMIC+0x258>
  c16086:	jmp    c15f99 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6679>
  c1608b:	mov    rsi,QWORD PTR [rax+0x8]
  c1608f:	mov    rdi,QWORD PTR [rax+0x10]
  c16093:	mov    edx,DWORD PTR [rax+0x4]
  c16096:	shl    rdx,0x20
  c1609a:	or     rdx,rcx
  c1609d:	mov    rcx,rdi
  c160a0:	mov    rax,QWORD PTR [rsp+0x1a0]
  c160a8:	jmp    c11d1c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x23fc>
  c160ad:	mov    rdi,QWORD PTR [rcx+0x8]
  c160b1:	mov    r8,QWORD PTR [rcx+0x10]
  c160b5:	mov    esi,DWORD PTR [rcx+0x4]
  c160b8:	mov    rcx,r8
  c160bb:	shl    rsi,0x20
  c160bf:	or     rsi,rdx
  c160c2:	jmp    c12211 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x28f1>
  c160c7:	mov    rdi,QWORD PTR [rdx+0x8]
  c160cb:	mov    r8,QWORD PTR [rdx+0x10]
  c160cf:	mov    ecx,DWORD PTR [rdx+0x4]
  c160d2:	shl    rcx,0x20
  c160d6:	or     rcx,rsi
  c160d9:	movq   xmm1,r8
  c160de:	movq   xmm0,rdi
  c160e3:	punpcklqdq xmm0,xmm1
  c160e7:	jmp    c10c48 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1328>
  c160ec:	mov    rdi,QWORD PTR [rdx+0x8]
  c160f0:	mov    r8,QWORD PTR [rdx+0x10]
  c160f4:	mov    ecx,DWORD PTR [rdx+0x4]
  c160f7:	shl    rcx,0x20
  c160fb:	or     rcx,rsi
  c160fe:	movq   xmm1,r8
  c16103:	movq   xmm0,rdi
  c16108:	punpcklqdq xmm0,xmm1
  c1610c:	jmp    c10ccc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x13ac>
  c16111:	mov    rdi,QWORD PTR [rdx+0x8]
  c16115:	mov    r8,QWORD PTR [rdx+0x10]
  c16119:	mov    ecx,DWORD PTR [rdx+0x4]
  c1611c:	shl    rcx,0x20
  c16120:	or     rcx,rsi
  c16123:	movq   xmm1,r8
  c16128:	movq   xmm0,rdi
  c1612d:	punpcklqdq xmm0,xmm1
  c16131:	jmp    c10d50 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1430>
  c16136:	mov    rsi,QWORD PTR [rcx+0x8]
  c1613a:	mov    rdi,QWORD PTR [rcx+0x10]
  c1613e:	mov    r8d,DWORD PTR [rcx+0x4]
  c16142:	mov    rcx,rdi
  c16145:	shl    r8,0x20
  c16149:	or     r8,rdx
  c1614c:	jmp    c129bd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x309d>
  c16151:	mov    rdi,QWORD PTR [rdx+0x8]
  c16155:	mov    r8,QWORD PTR [rdx+0x10]
  c16159:	mov    ecx,DWORD PTR [rdx+0x4]
  c1615c:	shl    rcx,0x20
  c16160:	or     rcx,rsi
  c16163:	movq   xmm1,r8
  c16168:	movq   xmm0,rdi
  c1616d:	punpcklqdq xmm0,xmm1
  c16171:	jmp    c10f4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x162d>
  c16176:	mov    rdx,QWORD PTR [rax+0x8]
  c1617a:	mov    rsi,QWORD PTR [rax+0x10]
  c1617e:	mov    edi,DWORD PTR [rax+0x4]
  c16181:	shl    rdi,0x20
  c16185:	or     rdi,rcx
  c16188:	mov    rax,rsi
  c1618b:	jmp    c12c4b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x332b>
  c16190:	mov    rdx,QWORD PTR [rax+0x8]
  c16194:	mov    rdi,QWORD PTR [rax+0x10]
  c16198:	mov    esi,DWORD PTR [rax+0x4]
  c1619b:	shl    rsi,0x20
  c1619f:	or     rsi,rcx
  c161a2:	mov    rax,rdi
  c161a5:	jmp    c13123 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3803>
  c161aa:	mov    rdi,QWORD PTR [rcx+0x8]
  c161ae:	mov    rsi,QWORD PTR [rcx+0x10]
  c161b2:	mov    r8d,DWORD PTR [rcx+0x4]
  c161b6:	shl    r8,0x20
  c161ba:	or     r8,rdx
  c161bd:	jmp    c132e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x39c6>
  c161c2:	mov    rsi,QWORD PTR [rax+0x8]
  c161c6:	mov    rdi,QWORD PTR [rax+0x10]
  c161ca:	mov    edx,DWORD PTR [rax+0x4]
  c161cd:	shl    rdx,0x20
  c161d1:	or     rdx,rcx
  c161d4:	mov    rax,rdi
  c161d7:	jmp    c13520 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3c00>
  c161dc:	mov    rdi,QWORD PTR [rcx+0x8]
  c161e0:	mov    rsi,QWORD PTR [rcx+0x10]
  c161e4:	mov    r8d,DWORD PTR [rcx+0x4]
  c161e8:	shl    r8,0x20
  c161ec:	or     r8,rdx
  c161ef:	jmp    c1362e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3d0e>
  c161f4:	mov    rsi,QWORD PTR [rax+0x8]
  c161f8:	mov    rdi,QWORD PTR [rax+0x10]
  c161fc:	mov    edx,DWORD PTR [rax+0x4]
  c161ff:	shl    rdx,0x20
  c16203:	or     rdx,rcx
  c16206:	mov    rax,rdi
  c16209:	jmp    c1378c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3e6c>
  c1620e:	mov    rsi,QWORD PTR [rax+0x8]
  c16212:	mov    rdi,QWORD PTR [rax+0x10]
  c16216:	mov    edx,DWORD PTR [rax+0x4]
  c16219:	shl    rdx,0x20
  c1621d:	or     rdx,rcx
  c16220:	mov    rax,rdi
  c16223:	jmp    c13aca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x41aa>
  c16228:	mov    rsi,QWORD PTR [rax+0x8]
  c1622c:	mov    rdi,QWORD PTR [rax+0x10]
  c16230:	mov    edx,DWORD PTR [rax+0x4]
  c16233:	shl    rdx,0x20
  c16237:	or     rdx,rcx
  c1623a:	mov    rax,rdi
  c1623d:	jmp    c13d64 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4444>
  c16242:	mov    rdi,QWORD PTR [rcx+0x8]
  c16246:	mov    rsi,QWORD PTR [rcx+0x10]
  c1624a:	mov    r8d,DWORD PTR [rcx+0x4]
  c1624e:	shl    r8,0x20
  c16252:	or     r8,rdx
  c16255:	jmp    c13f65 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4645>
  c1625a:	mov    rsi,QWORD PTR [rax+0x8]
  c1625e:	mov    rdi,QWORD PTR [rax+0x10]
  c16262:	mov    edx,DWORD PTR [rax+0x4]
  c16265:	shl    rdx,0x20
  c16269:	or     rdx,rcx
  c1626c:	mov    rax,rdi
  c1626f:	jmp    c14087 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4767>
  c16274:	mov    r8,QWORD PTR [rax+0x8]
  c16278:	mov    r9,QWORD PTR [rax+0x10]
  c1627c:	mov    ebx,DWORD PTR [rax+0x4]
  c1627f:	shl    rbx,0x20
  c16283:	or     rbx,rcx
  c16286:	mov    rcx,r9
  c16289:	jmp    c142b8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4998>
  c1628e:	mov    rsi,QWORD PTR [rax+0x8]
  c16292:	mov    r9,QWORD PTR [rax+0x10]
  c16296:	mov    edx,DWORD PTR [rax+0x4]
  c16299:	shl    rdx,0x20
  c1629d:	or     rdx,rcx
  c162a0:	mov    rcx,rsi
  c162a3:	jmp    c11666 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x1d46>
  c162a8:	mov    rdi,QWORD PTR [rcx+0x8]
  c162ac:	mov    r8,QWORD PTR [rcx+0x10]
  c162b0:	mov    esi,DWORD PTR [rcx+0x4]
  c162b3:	mov    rcx,r8
  c162b6:	shl    rsi,0x20
  c162ba:	or     rsi,rdx
  c162bd:	jmp    c14554 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4c34>
  c162c2:	mov    rdi,QWORD PTR [rcx+0x8]
  c162c6:	mov    r8,QWORD PTR [rcx+0x10]
  c162ca:	mov    esi,DWORD PTR [rcx+0x4]
  c162cd:	mov    rcx,r8
  c162d0:	shl    rsi,0x20
  c162d4:	or     rsi,rdx
  c162d7:	jmp    c1472d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x4e0d>
  c162dc:	mov    rsi,QWORD PTR [rcx+0x8]
  c162e0:	mov    rdi,QWORD PTR [rcx+0x10]
  c162e4:	mov    eax,DWORD PTR [rcx+0x4]
  c162e7:	shl    rax,0x20
  c162eb:	or     rax,rdx
  c162ee:	movq   xmm1,rdi
  c162f3:	movq   xmm0,rsi
  c162f8:	punpcklqdq xmm0,xmm1
  c162fc:	mov    r15,r9
  c162ff:	mov    QWORD PTR [rsp+0x80],rax
  c16307:	movdqu XMMWORD PTR [rsp+0x88],xmm0
  c16310:	lea    rcx,[rip+0xffffffffff6b03e0]        # 2c66f7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x374>
  c16317:	lea    rdi,[rsp+0x110]
  c1631f:	lea    rsi,[rsp+0x40]
  c16324:	lea    rdx,[rsp+0x80]
  c1632c:	mov    r8d,0x2
  c16332:	call   QWORD PTR [rip+0x239228]        # e4f560 <_DYNAMIC+0x1da0>
  c16338:	movzx  ecx,BYTE PTR [rsp+0x110]
  c16340:	movzx  ebp,BYTE PTR [rsp+0x111]
  c16348:	cmp    cl,0xff
  c1634b:	jne    c180e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x87c9>
  c16351:	mov    rax,r12
  c16354:	sub    rax,r15
  c16357:	jae    c16367 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a47>
  c16359:	mov    rax,QWORD PTR [rbx+0x28]
  c1635d:	shl    r12d,0x4
  c16361:	mov    rax,QWORD PTR [rax+r12*1]
  c16365:	jmp    c1636b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a4b>
  c16367:	add    rax,QWORD PTR [rbx+0x60]
  c1636b:	cmp    rax,r13
  c1636e:	mov    r12,QWORD PTR [rsp+0x10]
  c16373:	jae    c18489 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b69>
  c16379:	not    bpl
  c1637c:	shr    bpl,0x7
  c16380:	lea    rax,[rax+rax*2]
  c16384:	lea    r15,[r14+rax*8]
  c16388:	mov    eax,DWORD PTR [r14+rax*8]
  c1638c:	mov    edx,eax
  c1638e:	sub    edx,0x2
  c16391:	mov    ecx,0x3
  c16396:	cmovae ecx,edx
  c16399:	cmp    ecx,0x8
  c1639c:	ja     c164e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6bc6>
  c163a2:	mov    edx,0x1e7
  c163a7:	bt     edx,ecx
  c163aa:	mov    rdx,QWORD PTR [rsp+0x18]
  c163af:	lea    r14,[rdx+0x8]
  c163b3:	jae    c1643d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b1d>
  c163b9:	mov    DWORD PTR [r15],0x4
  c163c0:	mov    BYTE PTR [r15+0x4],bpl
  c163c4:	mov    eax,DWORD PTR [rsp+0x80]
  c163cb:	mov    edx,eax
  c163cd:	sub    edx,0x2
  c163d0:	mov    ecx,0x3
  c163d5:	cmovae ecx,edx
  c163d8:	cmp    ecx,0x8
  c163db:	ja     c1652f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c0f>
  c163e1:	mov    edx,0x1e7
  c163e6:	bt     edx,ecx
  c163e9:	mov    rbp,QWORD PTR [rsp+0x30]
  c163ee:	mov    r13,QWORD PTR [rsp+0x1a8]
  c163f6:	mov    r15d,DWORD PTR [rsp+0x3c]
  c163fb:	jae    c1646a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b4a>
  c163fd:	mov    eax,DWORD PTR [rsp+0x40]
  c16401:	mov    edx,eax
  c16403:	sub    edx,0x2
  c16406:	mov    ecx,0x3
  c1640b:	cmovae ecx,edx
  c1640e:	cmp    ecx,0x8
  c16411:	ja     c16583 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c63>
  c16417:	mov    edx,0x1e7
  c1641c:	bt     edx,ecx
  c1641f:	jae    c1649b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b7b>
  c16421:	mov    rax,QWORD PTR [rsp+0x18]
  c16426:	add    rax,0x10
  c1642a:	mov    rsi,QWORD PTR [rax]
  c1642d:	cmp    QWORD PTR [rsp+0x8],rsi
  c16432:	jb     c15fce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66ae>
  c16438:	jmp    c19f55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa635>
  c1643d:	cmp    ecx,0x3
  c16440:	jne    c164ca <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6baa>
  c16446:	test   eax,eax
  c16448:	je     c163b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a99>
  c1644e:	mov    rax,QWORD PTR [r15+0x8]
  c16452:	dec    QWORD PTR [rax]
  c16455:	jne    c163b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a99>
  c1645b:	lea    rdi,[r15+0x8]
  c1645f:	call   QWORD PTR [rip+0x2375a3]        # e4da08 <_DYNAMIC+0x248>
  c16465:	jmp    c163b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a99>
  c1646a:	cmp    ecx,0x3
  c1646d:	jne    c1650b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6beb>
  c16473:	test   eax,eax
  c16475:	je     c163fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6add>
  c16477:	mov    rax,QWORD PTR [rsp+0x88]
  c1647f:	dec    QWORD PTR [rax]
  c16482:	jne    c163fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6add>
  c16488:	lea    rdi,[rsp+0x88]
  c16490:	call   QWORD PTR [rip+0x237572]        # e4da08 <_DYNAMIC+0x248>
  c16496:	jmp    c163fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6add>
  c1649b:	cmp    ecx,0x3
  c1649e:	jne    c16565 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6c45>
  c164a4:	test   eax,eax
  c164a6:	je     c16421 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b01>
  c164ac:	mov    rax,QWORD PTR [rsp+0x48]
  c164b1:	dec    QWORD PTR [rax]
  c164b4:	jne    c16421 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b01>
  c164ba:	lea    rdi,[rsp+0x48]
  c164bf:	call   QWORD PTR [rip+0x237543]        # e4da08 <_DYNAMIC+0x248>
  c164c5:	jmp    c16421 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b01>
  c164ca:	mov    rax,QWORD PTR [r15+0x8]
  c164ce:	dec    QWORD PTR [rax]
  c164d1:	jne    c163b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a99>
  c164d7:	lea    rdi,[r15+0x8]
  c164db:	call   QWORD PTR [rip+0x23752f]        # e4da10 <_DYNAMIC+0x250>
  c164e1:	jmp    c163b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a99>
  c164e6:	mov    rax,QWORD PTR [r15+0x8]
  c164ea:	dec    QWORD PTR [rax]
  c164ed:	mov    rax,QWORD PTR [rsp+0x18]
  c164f2:	lea    r14,[rax+0x8]
  c164f6:	jne    c163b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a99>
  c164fc:	lea    rdi,[r15+0x8]
  c16500:	call   QWORD PTR [rip+0x237512]        # e4da18 <_DYNAMIC+0x258>
  c16506:	jmp    c163b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6a99>
  c1650b:	mov    rax,QWORD PTR [rsp+0x88]
  c16513:	dec    QWORD PTR [rax]
  c16516:	jne    c163fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6add>
  c1651c:	lea    rdi,[rsp+0x88]
  c16524:	call   QWORD PTR [rip+0x2374e6]        # e4da10 <_DYNAMIC+0x250>
  c1652a:	jmp    c163fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6add>
  c1652f:	mov    rax,QWORD PTR [rsp+0x88]
  c16537:	dec    QWORD PTR [rax]
  c1653a:	mov    rbp,QWORD PTR [rsp+0x30]
  c1653f:	mov    r13,QWORD PTR [rsp+0x1a8]
  c16547:	mov    r15d,DWORD PTR [rsp+0x3c]
  c1654c:	jne    c163fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6add>
  c16552:	lea    rdi,[rsp+0x88]
  c1655a:	call   QWORD PTR [rip+0x2374b8]        # e4da18 <_DYNAMIC+0x258>
  c16560:	jmp    c163fd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6add>
  c16565:	mov    rax,QWORD PTR [rsp+0x48]
  c1656a:	dec    QWORD PTR [rax]
  c1656d:	jne    c16421 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b01>
  c16573:	lea    rdi,[rsp+0x48]
  c16578:	call   QWORD PTR [rip+0x237492]        # e4da10 <_DYNAMIC+0x250>
  c1657e:	jmp    c16421 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b01>
  c16583:	mov    rax,QWORD PTR [rsp+0x48]
  c16588:	dec    QWORD PTR [rax]
  c1658b:	jne    c16421 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b01>
  c16591:	lea    rdi,[rsp+0x48]
  c16596:	call   QWORD PTR [rip+0x23747c]        # e4da18 <_DYNAMIC+0x258>
  c1659c:	jmp    c16421 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6b01>
  c165a1:	mov    rsi,QWORD PTR [rcx+0x8]
  c165a5:	mov    rdi,QWORD PTR [rcx+0x10]
  c165a9:	mov    eax,DWORD PTR [rcx+0x4]
  c165ac:	shl    rax,0x20
  c165b0:	or     rax,rdx
  c165b3:	movq   xmm1,rdi
  c165b8:	movq   xmm0,rsi
  c165bd:	punpcklqdq xmm0,xmm1
  c165c1:	mov    QWORD PTR [rsp+0x80],rax
  c165c9:	movdqu XMMWORD PTR [rsp+0x88],xmm0
  c165d2:	lea    rcx,[rip+0xffffffffff6b011b]        # 2c66f4 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x371>
  c165d9:	lea    rdi,[rsp+0x110]
  c165e1:	lea    rsi,[rsp+0x40]
  c165e6:	lea    rdx,[rsp+0x80]
  c165ee:	mov    r8d,0x1
  c165f4:	call   QWORD PTR [rip+0x238f66]        # e4f560 <_DYNAMIC+0x1da0>
  c165fa:	movzx  r13d,BYTE PTR [rsp+0x110]
  c16603:	movzx  ecx,BYTE PTR [rsp+0x111]
  c1660b:	cmp    r13b,0xff
  c1660f:	jne    c18146 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8826>
  c16615:	mov    rax,r12
  c16618:	sub    rax,r14
  c1661b:	jae    c1662b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d0b>
  c1661d:	mov    rax,QWORD PTR [rbx+0x28]
  c16621:	shl    r12d,0x4
  c16625:	mov    rax,QWORD PTR [rax+r12*1]
  c16629:	jmp    c1662f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d0f>
  c1662b:	add    rax,QWORD PTR [rbx+0x60]
  c1662f:	test   cl,cl
  c16631:	setg   r14b
  c16635:	cmp    rax,rbp
  c16638:	jae    c183d0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ab0>
  c1663e:	lea    rax,[rax+rax*2]
  c16642:	lea    r12,[r15+rax*8]
  c16646:	mov    eax,DWORD PTR [r15+rax*8]
  c1664a:	mov    edx,eax
  c1664c:	sub    edx,0x2
  c1664f:	mov    ecx,0x3
  c16654:	cmovae ecx,edx
  c16657:	cmp    ecx,0x8
  c1665a:	ja     c167af <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e8f>
  c16660:	mov    edx,0x1e7
  c16665:	bt     edx,ecx
  c16668:	mov    rbp,QWORD PTR [rsp+0x30]
  c1666d:	mov    r13,QWORD PTR [rsp+0x1a8]
  c16675:	mov    r15d,DWORD PTR [rsp+0x3c]
  c1667a:	jae    c16702 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6de2>
  c16680:	mov    DWORD PTR [r12],0x4
  c16688:	mov    BYTE PTR [r12+0x4],r14b
  c1668d:	mov    eax,DWORD PTR [rsp+0x80]
  c16694:	mov    edx,eax
  c16696:	sub    edx,0x2
  c16699:	mov    ecx,0x3
  c1669e:	cmovae ecx,edx
  c166a1:	cmp    ecx,0x8
  c166a4:	ja     c16803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ee3>
  c166aa:	mov    edx,0x1e7
  c166af:	bt     edx,ecx
  c166b2:	mov    r12,QWORD PTR [rsp+0x10]
  c166b7:	mov    rdx,QWORD PTR [rsp+0x18]
  c166bc:	lea    r14,[rdx+0x8]
  c166c0:	jae    c16731 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e11>
  c166c2:	mov    eax,DWORD PTR [rsp+0x40]
  c166c6:	mov    edx,eax
  c166c8:	sub    edx,0x2
  c166cb:	mov    ecx,0x3
  c166d0:	cmovae ecx,edx
  c166d3:	cmp    ecx,0x8
  c166d6:	ja     c16853 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f33>
  c166dc:	mov    edx,0x1e7
  c166e1:	bt     edx,ecx
  c166e4:	jae    c16762 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e42>
  c166e6:	mov    rax,QWORD PTR [rsp+0x18]
  c166eb:	add    rax,0x10
  c166ef:	mov    rsi,QWORD PTR [rax]
  c166f2:	cmp    QWORD PTR [rsp+0x8],rsi
  c166f7:	jb     c15fce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66ae>
  c166fd:	jmp    c19ef6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5d6>
  c16702:	cmp    ecx,0x3
  c16705:	jne    c16791 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6e71>
  c1670b:	test   eax,eax
  c1670d:	je     c16680 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d60>
  c16713:	mov    rax,QWORD PTR [r12+0x8]
  c16718:	dec    QWORD PTR [rax]
  c1671b:	jne    c16680 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d60>
  c16721:	lea    rdi,[r12+0x8]
  c16726:	call   QWORD PTR [rip+0x2372dc]        # e4da08 <_DYNAMIC+0x248>
  c1672c:	jmp    c16680 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d60>
  c16731:	cmp    ecx,0x3
  c16734:	jne    c167df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6ebf>
  c1673a:	test   eax,eax
  c1673c:	je     c166c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6da2>
  c1673e:	mov    rax,QWORD PTR [rsp+0x88]
  c16746:	dec    QWORD PTR [rax]
  c16749:	jne    c166c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6da2>
  c1674f:	lea    rdi,[rsp+0x88]
  c16757:	call   QWORD PTR [rip+0x2372ab]        # e4da08 <_DYNAMIC+0x248>
  c1675d:	jmp    c166c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6da2>
  c16762:	cmp    ecx,0x3
  c16765:	jne    c16835 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6f15>
  c1676b:	test   eax,eax
  c1676d:	je     c166e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dc6>
  c16773:	mov    rax,QWORD PTR [rsp+0x48]
  c16778:	dec    QWORD PTR [rax]
  c1677b:	jne    c166e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dc6>
  c16781:	lea    rdi,[rsp+0x48]
  c16786:	call   QWORD PTR [rip+0x23727c]        # e4da08 <_DYNAMIC+0x248>
  c1678c:	jmp    c166e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dc6>
  c16791:	mov    rax,QWORD PTR [r12+0x8]
  c16796:	dec    QWORD PTR [rax]
  c16799:	jne    c16680 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d60>
  c1679f:	lea    rdi,[r12+0x8]
  c167a4:	call   QWORD PTR [rip+0x237266]        # e4da10 <_DYNAMIC+0x250>
  c167aa:	jmp    c16680 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d60>
  c167af:	mov    rax,QWORD PTR [r12+0x8]
  c167b4:	dec    QWORD PTR [rax]
  c167b7:	mov    rbp,QWORD PTR [rsp+0x30]
  c167bc:	mov    r13,QWORD PTR [rsp+0x1a8]
  c167c4:	mov    r15d,DWORD PTR [rsp+0x3c]
  c167c9:	jne    c16680 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d60>
  c167cf:	lea    rdi,[r12+0x8]
  c167d4:	call   QWORD PTR [rip+0x23723e]        # e4da18 <_DYNAMIC+0x258>
  c167da:	jmp    c16680 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6d60>
  c167df:	mov    rax,QWORD PTR [rsp+0x88]
  c167e7:	dec    QWORD PTR [rax]
  c167ea:	jne    c166c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6da2>
  c167f0:	lea    rdi,[rsp+0x88]
  c167f8:	call   QWORD PTR [rip+0x237212]        # e4da10 <_DYNAMIC+0x250>
  c167fe:	jmp    c166c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6da2>
  c16803:	mov    rax,QWORD PTR [rsp+0x88]
  c1680b:	dec    QWORD PTR [rax]
  c1680e:	mov    r12,QWORD PTR [rsp+0x10]
  c16813:	mov    rax,QWORD PTR [rsp+0x18]
  c16818:	lea    r14,[rax+0x8]
  c1681c:	jne    c166c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6da2>
  c16822:	lea    rdi,[rsp+0x88]
  c1682a:	call   QWORD PTR [rip+0x2371e8]        # e4da18 <_DYNAMIC+0x258>
  c16830:	jmp    c166c2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6da2>
  c16835:	mov    rax,QWORD PTR [rsp+0x48]
  c1683a:	dec    QWORD PTR [rax]
  c1683d:	jne    c166e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dc6>
  c16843:	lea    rdi,[rsp+0x48]
  c16848:	call   QWORD PTR [rip+0x2371c2]        # e4da10 <_DYNAMIC+0x250>
  c1684e:	jmp    c166e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dc6>
  c16853:	mov    rax,QWORD PTR [rsp+0x48]
  c16858:	dec    QWORD PTR [rax]
  c1685b:	jne    c166e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dc6>
  c16861:	lea    rdi,[rsp+0x48]
  c16866:	call   QWORD PTR [rip+0x2371ac]        # e4da18 <_DYNAMIC+0x258>
  c1686c:	jmp    c166e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6dc6>
  c16871:	mov    rsi,QWORD PTR [rcx+0x8]
  c16875:	mov    rdi,QWORD PTR [rcx+0x10]
  c16879:	mov    eax,DWORD PTR [rcx+0x4]
  c1687c:	shl    rax,0x20
  c16880:	or     rax,rdx
  c16883:	movq   xmm1,rdi
  c16888:	movq   xmm0,rsi
  c1688d:	punpcklqdq xmm0,xmm1
  c16891:	mov    QWORD PTR [rsp+0x80],rax
  c16899:	movdqu XMMWORD PTR [rsp+0x88],xmm0
  c168a2:	lea    rcx,[rip+0xffffffffff6afe4c]        # 2c66f5 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x372>
  c168a9:	lea    rdi,[rsp+0x110]
  c168b1:	lea    rsi,[rsp+0x40]
  c168b6:	lea    rdx,[rsp+0x80]
  c168be:	mov    r8d,0x2
  c168c4:	call   QWORD PTR [rip+0x238c96]        # e4f560 <_DYNAMIC+0x1da0>
  c168ca:	movzx  r13d,BYTE PTR [rsp+0x110]
  c168d3:	movzx  ecx,BYTE PTR [rsp+0x111]
  c168db:	cmp    r13b,0xff
  c168df:	jne    c1819d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x887d>
  c168e5:	mov    rax,r12
  c168e8:	sub    rax,r14
  c168eb:	jae    c168fb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fdb>
  c168ed:	mov    rax,QWORD PTR [rbx+0x28]
  c168f1:	shl    r12d,0x4
  c168f5:	mov    rax,QWORD PTR [rax+r12*1]
  c168f9:	jmp    c168ff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x6fdf>
  c168fb:	add    rax,QWORD PTR [rbx+0x60]
  c168ff:	test   cl,cl
  c16901:	setle  r14b
  c16905:	cmp    rax,rbp
  c16908:	jae    c1834a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a2a>
  c1690e:	lea    rax,[rax+rax*2]
  c16912:	lea    r12,[r15+rax*8]
  c16916:	mov    eax,DWORD PTR [r15+rax*8]
  c1691a:	mov    edx,eax
  c1691c:	sub    edx,0x2
  c1691f:	mov    ecx,0x3
  c16924:	cmovae ecx,edx
  c16927:	cmp    ecx,0x8
  c1692a:	ja     c16a7f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x715f>
  c16930:	mov    edx,0x1e7
  c16935:	bt     edx,ecx
  c16938:	mov    rbp,QWORD PTR [rsp+0x30]
  c1693d:	mov    r13,QWORD PTR [rsp+0x1a8]
  c16945:	mov    r15d,DWORD PTR [rsp+0x3c]
  c1694a:	jae    c169d2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x70b2>
  c16950:	mov    DWORD PTR [r12],0x4
  c16958:	mov    BYTE PTR [r12+0x4],r14b
  c1695d:	mov    eax,DWORD PTR [rsp+0x80]
  c16964:	mov    edx,eax
  c16966:	sub    edx,0x2
  c16969:	mov    ecx,0x3
  c1696e:	cmovae ecx,edx
  c16971:	cmp    ecx,0x8
  c16974:	ja     c16ad3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71b3>
  c1697a:	mov    edx,0x1e7
  c1697f:	bt     edx,ecx
  c16982:	mov    r12,QWORD PTR [rsp+0x10]
  c16987:	mov    rdx,QWORD PTR [rsp+0x18]
  c1698c:	lea    r14,[rdx+0x8]
  c16990:	jae    c16a01 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x70e1>
  c16992:	mov    eax,DWORD PTR [rsp+0x40]
  c16996:	mov    edx,eax
  c16998:	sub    edx,0x2
  c1699b:	mov    ecx,0x3
  c169a0:	cmovae ecx,edx
  c169a3:	cmp    ecx,0x8
  c169a6:	ja     c16b23 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7203>
  c169ac:	mov    edx,0x1e7
  c169b1:	bt     edx,ecx
  c169b4:	jae    c16a32 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7112>
  c169b6:	mov    rax,QWORD PTR [rsp+0x18]
  c169bb:	add    rax,0x10
  c169bf:	mov    rsi,QWORD PTR [rax]
  c169c2:	cmp    QWORD PTR [rsp+0x8],rsi
  c169c7:	jb     c15fce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66ae>
  c169cd:	jmp    c19f1a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5fa>
  c169d2:	cmp    ecx,0x3
  c169d5:	jne    c16a61 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7141>
  c169db:	test   eax,eax
  c169dd:	je     c16950 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7030>
  c169e3:	mov    rax,QWORD PTR [r12+0x8]
  c169e8:	dec    QWORD PTR [rax]
  c169eb:	jne    c16950 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7030>
  c169f1:	lea    rdi,[r12+0x8]
  c169f6:	call   QWORD PTR [rip+0x23700c]        # e4da08 <_DYNAMIC+0x248>
  c169fc:	jmp    c16950 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7030>
  c16a01:	cmp    ecx,0x3
  c16a04:	jne    c16aaf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x718f>
  c16a0a:	test   eax,eax
  c16a0c:	je     c16992 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7072>
  c16a0e:	mov    rax,QWORD PTR [rsp+0x88]
  c16a16:	dec    QWORD PTR [rax]
  c16a19:	jne    c16992 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7072>
  c16a1f:	lea    rdi,[rsp+0x88]
  c16a27:	call   QWORD PTR [rip+0x236fdb]        # e4da08 <_DYNAMIC+0x248>
  c16a2d:	jmp    c16992 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7072>
  c16a32:	cmp    ecx,0x3
  c16a35:	jne    c16b05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x71e5>
  c16a3b:	test   eax,eax
  c16a3d:	je     c169b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7096>
  c16a43:	mov    rax,QWORD PTR [rsp+0x48]
  c16a48:	dec    QWORD PTR [rax]
  c16a4b:	jne    c169b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7096>
  c16a51:	lea    rdi,[rsp+0x48]
  c16a56:	call   QWORD PTR [rip+0x236fac]        # e4da08 <_DYNAMIC+0x248>
  c16a5c:	jmp    c169b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7096>
  c16a61:	mov    rax,QWORD PTR [r12+0x8]
  c16a66:	dec    QWORD PTR [rax]
  c16a69:	jne    c16950 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7030>
  c16a6f:	lea    rdi,[r12+0x8]
  c16a74:	call   QWORD PTR [rip+0x236f96]        # e4da10 <_DYNAMIC+0x250>
  c16a7a:	jmp    c16950 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7030>
  c16a7f:	mov    rax,QWORD PTR [r12+0x8]
  c16a84:	dec    QWORD PTR [rax]
  c16a87:	mov    rbp,QWORD PTR [rsp+0x30]
  c16a8c:	mov    r13,QWORD PTR [rsp+0x1a8]
  c16a94:	mov    r15d,DWORD PTR [rsp+0x3c]
  c16a99:	jne    c16950 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7030>
  c16a9f:	lea    rdi,[r12+0x8]
  c16aa4:	call   QWORD PTR [rip+0x236f6e]        # e4da18 <_DYNAMIC+0x258>
  c16aaa:	jmp    c16950 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7030>
  c16aaf:	mov    rax,QWORD PTR [rsp+0x88]
  c16ab7:	dec    QWORD PTR [rax]
  c16aba:	jne    c16992 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7072>
  c16ac0:	lea    rdi,[rsp+0x88]
  c16ac8:	call   QWORD PTR [rip+0x236f42]        # e4da10 <_DYNAMIC+0x250>
  c16ace:	jmp    c16992 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7072>
  c16ad3:	mov    rax,QWORD PTR [rsp+0x88]
  c16adb:	dec    QWORD PTR [rax]
  c16ade:	mov    r12,QWORD PTR [rsp+0x10]
  c16ae3:	mov    rax,QWORD PTR [rsp+0x18]
  c16ae8:	lea    r14,[rax+0x8]
  c16aec:	jne    c16992 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7072>
  c16af2:	lea    rdi,[rsp+0x88]
  c16afa:	call   QWORD PTR [rip+0x236f18]        # e4da18 <_DYNAMIC+0x258>
  c16b00:	jmp    c16992 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7072>
  c16b05:	mov    rax,QWORD PTR [rsp+0x48]
  c16b0a:	dec    QWORD PTR [rax]
  c16b0d:	jne    c169b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7096>
  c16b13:	lea    rdi,[rsp+0x48]
  c16b18:	call   QWORD PTR [rip+0x236ef2]        # e4da10 <_DYNAMIC+0x250>
  c16b1e:	jmp    c169b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7096>
  c16b23:	mov    rax,QWORD PTR [rsp+0x48]
  c16b28:	dec    QWORD PTR [rax]
  c16b2b:	jne    c169b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7096>
  c16b31:	lea    rdi,[rsp+0x48]
  c16b36:	call   QWORD PTR [rip+0x236edc]        # e4da18 <_DYNAMIC+0x258>
  c16b3c:	jmp    c169b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7096>
  c16b41:	mov    rsi,QWORD PTR [rcx+0x8]
  c16b45:	mov    rdi,QWORD PTR [rcx+0x10]
  c16b49:	mov    eax,DWORD PTR [rcx+0x4]
  c16b4c:	shl    rax,0x20
  c16b50:	or     rax,rdx
  c16b53:	movq   xmm1,rdi
  c16b58:	movq   xmm0,rsi
  c16b5d:	punpcklqdq xmm0,xmm1
  c16b61:	mov    QWORD PTR [rsp+0x80],rax
  c16b69:	movdqu XMMWORD PTR [rsp+0x88],xmm0
  c16b72:	lea    rcx,[rip+0xffffffffff6afb7a]        # 2c66f3 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x370>
  c16b79:	lea    rdi,[rsp+0x110]
  c16b81:	lea    rsi,[rsp+0x40]
  c16b86:	lea    rdx,[rsp+0x80]
  c16b8e:	mov    r8d,0x1
  c16b94:	call   QWORD PTR [rip+0x2389c6]        # e4f560 <_DYNAMIC+0x1da0>
  c16b9a:	movzx  edx,BYTE PTR [rsp+0x110]
  c16ba2:	movzx  ecx,BYTE PTR [rsp+0x111]
  c16baa:	cmp    dl,0xff
  c16bad:	jne    c1808a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x876a>
  c16bb3:	mov    rax,r12
  c16bb6:	sub    rax,rbp
  c16bb9:	jae    c16bc9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72a9>
  c16bbb:	mov    rax,QWORD PTR [rbx+0x28]
  c16bbf:	shl    r12d,0x4
  c16bc3:	mov    rax,QWORD PTR [rax+r12*1]
  c16bc7:	jmp    c16bcd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72ad>
  c16bc9:	add    rax,QWORD PTR [rbx+0x60]
  c16bcd:	cmp    rax,r14
  c16bd0:	mov    r12,QWORD PTR [rsp+0x10]
  c16bd5:	jae    c18531 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c11>
  c16bdb:	shr    cl,0x7
  c16bde:	mov    ebp,ecx
  c16be0:	lea    rax,[rax+rax*2]
  c16be4:	lea    r14,[r15+rax*8]
  c16be8:	mov    eax,DWORD PTR [r15+rax*8]
  c16bec:	mov    edx,eax
  c16bee:	sub    edx,0x2
  c16bf1:	mov    ecx,0x3
  c16bf6:	cmovae ecx,edx
  c16bf9:	cmp    ecx,0x8
  c16bfc:	ja     c16d3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x741e>
  c16c02:	mov    edx,0x1e7
  c16c07:	bt     edx,ecx
  c16c0a:	mov    r15d,DWORD PTR [rsp+0x3c]
  c16c0f:	jae    c16c95 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7375>
  c16c15:	mov    DWORD PTR [r14],0x4
  c16c1c:	mov    BYTE PTR [r14+0x4],bpl
  c16c20:	mov    eax,DWORD PTR [rsp+0x80]
  c16c27:	mov    edx,eax
  c16c29:	sub    edx,0x2
  c16c2c:	mov    ecx,0x3
  c16c31:	cmovae ecx,edx
  c16c34:	cmp    ecx,0x8
  c16c37:	ja     c16d83 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7463>
  c16c3d:	mov    edx,0x1e7
  c16c42:	bt     edx,ecx
  c16c45:	mov    rdx,QWORD PTR [rsp+0x18]
  c16c4a:	lea    r14,[rdx+0x8]
  c16c4e:	mov    rbp,QWORD PTR [rsp+0x30]
  c16c53:	jae    c16cc2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x73a2>
  c16c55:	mov    eax,DWORD PTR [rsp+0x40]
  c16c59:	mov    edx,eax
  c16c5b:	sub    edx,0x2
  c16c5e:	mov    ecx,0x3
  c16c63:	cmovae ecx,edx
  c16c66:	cmp    ecx,0x8
  c16c69:	ja     c16dd3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x74b3>
  c16c6f:	mov    edx,0x1e7
  c16c74:	bt     edx,ecx
  c16c77:	jae    c16cf3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x73d3>
  c16c79:	mov    rax,QWORD PTR [rsp+0x18]
  c16c7e:	add    rax,0x10
  c16c82:	mov    rsi,QWORD PTR [rax]
  c16c85:	cmp    QWORD PTR [rsp+0x8],rsi
  c16c8a:	jb     c15fce <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66ae>
  c16c90:	jmp    c19f08 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa5e8>
  c16c95:	cmp    ecx,0x3
  c16c98:	jne    c16d22 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7402>
  c16c9e:	test   eax,eax
  c16ca0:	je     c16c15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72f5>
  c16ca6:	mov    rax,QWORD PTR [r14+0x8]
  c16caa:	dec    QWORD PTR [rax]
  c16cad:	jne    c16c15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72f5>
  c16cb3:	lea    rdi,[r14+0x8]
  c16cb7:	call   QWORD PTR [rip+0x236d4b]        # e4da08 <_DYNAMIC+0x248>
  c16cbd:	jmp    c16c15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72f5>
  c16cc2:	cmp    ecx,0x3
  c16cc5:	jne    c16d5f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x743f>
  c16ccb:	test   eax,eax
  c16ccd:	je     c16c55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7335>
  c16ccf:	mov    rax,QWORD PTR [rsp+0x88]
  c16cd7:	dec    QWORD PTR [rax]
  c16cda:	jne    c16c55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7335>
  c16ce0:	lea    rdi,[rsp+0x88]
  c16ce8:	call   QWORD PTR [rip+0x236d1a]        # e4da08 <_DYNAMIC+0x248>
  c16cee:	jmp    c16c55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7335>
  c16cf3:	cmp    ecx,0x3
  c16cf6:	jne    c16db5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7495>
  c16cfc:	test   eax,eax
  c16cfe:	je     c16c79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7359>
  c16d04:	mov    rax,QWORD PTR [rsp+0x48]
  c16d09:	dec    QWORD PTR [rax]
  c16d0c:	jne    c16c79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7359>
  c16d12:	lea    rdi,[rsp+0x48]
  c16d17:	call   QWORD PTR [rip+0x236ceb]        # e4da08 <_DYNAMIC+0x248>
  c16d1d:	jmp    c16c79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7359>
  c16d22:	mov    rax,QWORD PTR [r14+0x8]
  c16d26:	dec    QWORD PTR [rax]
  c16d29:	jne    c16c15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72f5>
  c16d2f:	lea    rdi,[r14+0x8]
  c16d33:	call   QWORD PTR [rip+0x236cd7]        # e4da10 <_DYNAMIC+0x250>
  c16d39:	jmp    c16c15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72f5>
  c16d3e:	mov    rax,QWORD PTR [r14+0x8]
  c16d42:	dec    QWORD PTR [rax]
  c16d45:	mov    r15d,DWORD PTR [rsp+0x3c]
  c16d4a:	jne    c16c15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72f5>
  c16d50:	lea    rdi,[r14+0x8]
  c16d54:	call   QWORD PTR [rip+0x236cbe]        # e4da18 <_DYNAMIC+0x258>
  c16d5a:	jmp    c16c15 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x72f5>
  c16d5f:	mov    rax,QWORD PTR [rsp+0x88]
  c16d67:	dec    QWORD PTR [rax]
  c16d6a:	jne    c16c55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7335>
  c16d70:	lea    rdi,[rsp+0x88]
  c16d78:	call   QWORD PTR [rip+0x236c92]        # e4da10 <_DYNAMIC+0x250>
  c16d7e:	jmp    c16c55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7335>
  c16d83:	mov    rax,QWORD PTR [rsp+0x88]
  c16d8b:	dec    QWORD PTR [rax]
  c16d8e:	mov    rax,QWORD PTR [rsp+0x18]
  c16d93:	lea    r14,[rax+0x8]
  c16d97:	mov    rbp,QWORD PTR [rsp+0x30]
  c16d9c:	jne    c16c55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7335>
  c16da2:	lea    rdi,[rsp+0x88]
  c16daa:	call   QWORD PTR [rip+0x236c68]        # e4da18 <_DYNAMIC+0x258>
  c16db0:	jmp    c16c55 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7335>
  c16db5:	mov    rax,QWORD PTR [rsp+0x48]
  c16dba:	dec    QWORD PTR [rax]
  c16dbd:	jne    c16c79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7359>
  c16dc3:	lea    rdi,[rsp+0x48]
  c16dc8:	call   QWORD PTR [rip+0x236c42]        # e4da10 <_DYNAMIC+0x250>
  c16dce:	jmp    c16c79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7359>
  c16dd3:	mov    rax,QWORD PTR [rsp+0x48]
  c16dd8:	dec    QWORD PTR [rax]
  c16ddb:	jne    c16c79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7359>
  c16de1:	lea    rdi,[rsp+0x48]
  c16de6:	call   QWORD PTR [rip+0x236c2c]        # e4da18 <_DYNAMIC+0x258>
  c16dec:	jmp    c16c79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7359>
  c16df1:	mov    rdi,QWORD PTR [rcx+0x8]
  c16df5:	mov    rsi,QWORD PTR [rcx+0x10]
  c16df9:	mov    r8d,DWORD PTR [rcx+0x4]
  c16dfd:	shl    r8,0x20
  c16e01:	or     r8,rdx
  c16e04:	jmp    c14b07 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x51e7>
  c16e09:	mov    rdx,QWORD PTR [rax+0x8]
  c16e0d:	mov    r8,QWORD PTR [rax+0x10]
  c16e11:	mov    edi,DWORD PTR [rax+0x4]
  c16e14:	shl    rdi,0x20
  c16e18:	or     rdi,rcx
  c16e1b:	mov    rcx,rdx
  c16e1e:	jmp    c12d05 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x33e5>
  c16e23:	mov    rdi,QWORD PTR [rax+0x8]
  c16e27:	mov    rsi,QWORD PTR [rax+0x10]
  c16e2b:	mov    edx,DWORD PTR [rax+0x4]
  c16e2e:	shl    rdx,0x20
  c16e32:	or     rdx,rcx
  c16e35:	mov    rax,rsi
  c16e38:	jmp    c14d62 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5442>
  c16e3d:	mov    rsi,QWORD PTR [rax+0x8]
  c16e41:	mov    rdi,QWORD PTR [rax+0x10]
  c16e45:	mov    edx,DWORD PTR [rax+0x4]
  c16e48:	shl    rdx,0x20
  c16e4c:	or     rdx,rcx
  c16e4f:	jmp    c15017 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x56f7>
  c16e54:	mov    rdi,QWORD PTR [rax+0x8]
  c16e58:	mov    rsi,QWORD PTR [rax+0x10]
  c16e5c:	mov    edx,DWORD PTR [rax+0x4]
  c16e5f:	shl    rdx,0x20
  c16e63:	or     rdx,rcx
  c16e66:	mov    rax,rsi
  c16e69:	jmp    c1537b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5a5b>
  c16e6e:	mov    rsi,QWORD PTR [rax+0x8]
  c16e72:	mov    rdi,QWORD PTR [rax+0x10]
  c16e76:	mov    edx,DWORD PTR [rax+0x4]
  c16e79:	shl    rdx,0x20
  c16e7d:	or     rdx,rcx
  c16e80:	jmp    c158cf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x5faf>
  c16e85:	mov    rax,rdi
  c16e88:	shr    rax,0x20
  c16e8c:	mov    ecx,edi
  c16e8e:	mov    DWORD PTR [rsp+0x110],ecx
  c16e95:	mov    DWORD PTR [rsp+0x114],eax
  c16e9c:	mov    rax,QWORD PTR [rsp+0x1d0]
  c16ea4:	mov    QWORD PTR [rsp+0x118],rax
  c16eac:	mov    QWORD PTR [rsp+0x120],r8
  c16eb4:	jmp    c12f2a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x360a>
  c16eb9:	mov    rdx,QWORD PTR [rsp+0x1d8]
  c16ec1:	movzx  eax,BYTE PTR [rdx+0xc5]
  c16ec8:	xor    ecx,ecx
  c16eca:	sub    al,BYTE PTR [rdx+0xc3]
  c16ed0:	movzx  eax,al
  c16ed3:	cmovb  eax,ecx
  c16ed6:	mov    rdi,QWORD PTR [rsp+0x28]
  c16edb:	mov    rbx,QWORD PTR [rdi+0x10]
  c16edf:	movzx  esi,al
  c16ee2:	add    rsi,rbx
  c16ee5:	mov    DWORD PTR [rsp+0x110],0x2
  c16ef0:	lea    rdx,[rsp+0x110]
  c16ef8:	call   c335c0 <_RNvMs1_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueE6resizeCsbxgXiyEKxkX_6bsl_vm>
  c16efd:	mov    rdi,QWORD PTR [rsp+0x18]
  c16f02:	lea    r14,[rdi+0x8]
  c16f06:	lea    rax,[rdi+0x10]
  c16f0a:	mov    r12,QWORD PTR [rax]
  c16f0d:	cmp    QWORD PTR [rsp+0x8],r12
  c16f12:	jae    c1a096 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa776>
  c16f18:	mov    rax,QWORD PTR [rdi+0x8]
  c16f1c:	mov    rcx,QWORD PTR [rsp+0x20]
  c16f21:	mov    ecx,DWORD PTR [rax+rcx*1+0x70]
  c16f25:	mov    rdx,QWORD PTR [rsp+0x50]
  c16f2a:	lea    rsi,[rsp+0x114]
  c16f32:	mov    QWORD PTR [rsi+0x2c],rdx
  c16f36:	movups xmm0,XMMWORD PTR [rsp+0x40]
  c16f3b:	movups XMMWORD PTR [rsi+0x1c],xmm0
  c16f3f:	mov    rdx,QWORD PTR [rsp+0x90]
  c16f47:	mov    QWORD PTR [rsi+0x44],rdx
  c16f4b:	movups xmm0,XMMWORD PTR [rsp+0x80]
  c16f53:	movups XMMWORD PTR [rsi+0x34],xmm0
  c16f57:	mov    DWORD PTR [rsp+0x180],ecx
  c16f5e:	mov    rcx,QWORD PTR [rsp+0x4b0]
  c16f66:	mov    QWORD PTR [rsp+0x160],rcx
  c16f6e:	mov    QWORD PTR [rsp+0x168],0x0
  c16f7a:	mov    QWORD PTR [rsp+0x170],rbx
  c16f82:	mov    QWORD PTR [rsp+0x178],rbx
  c16f8a:	mov    BYTE PTR [rsp+0x184],bpl
  c16f92:	mov    QWORD PTR [rsp+0x110],0x0
  c16f9e:	cmp    r12,QWORD PTR [rdi]
  c16fa1:	mov    rbp,QWORD PTR [rsp+0x30]
  c16fa6:	jne    c16fb6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7696>
  c16fa8:	call   QWORD PTR [rip+0x23c062]        # e53010 <_DYNAMIC+0x5850>
  c16fae:	mov    rax,QWORD PTR [r14]
  c16fb1:	mov    rdi,QWORD PTR [rsp+0x18]
  c16fb6:	imul   rcx,r12,0x78
  c16fba:	mov    rdx,QWORD PTR [rsp+0x180]
  c16fc2:	mov    QWORD PTR [rax+rcx*1+0x70],rdx
  c16fc7:	movups xmm0,XMMWORD PTR [rsp+0x170]
  c16fcf:	movups XMMWORD PTR [rax+rcx*1+0x60],xmm0
  c16fd4:	movups xmm0,XMMWORD PTR [rsp+0x160]
  c16fdc:	movups XMMWORD PTR [rax+rcx*1+0x50],xmm0
  c16fe1:	movups xmm0,XMMWORD PTR [rsp+0x150]
  c16fe9:	movups XMMWORD PTR [rax+rcx*1+0x40],xmm0
  c16fee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c16ff7:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c17000:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c17008:	movups xmm3,XMMWORD PTR [rsp+0x140]
  c17010:	movups XMMWORD PTR [rax+rcx*1+0x30],xmm3
  c17015:	movups XMMWORD PTR [rax+rcx*1+0x20],xmm2
  c1701a:	movdqu XMMWORD PTR [rax+rcx*1+0x10],xmm1
  c17020:	movdqu XMMWORD PTR [rax+rcx*1],xmm0
  c17025:	inc    r12
  c17028:	lea    rax,[rdi+0x10]
  c1702c:	mov    QWORD PTR [rax],r12
  c1702f:	mov    r12,QWORD PTR [rsp+0x10]
  c17034:	test   r15b,r15b
  c17037:	jne    c15fe4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x66c4>
  c1703d:	jmp    c0fd19 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x3f9>
  c17042:	inc    r14b
  c17045:	mov    r8,QWORD PTR [rsp+0x558]
  c1704d:	movzx  eax,BYTE PTR [r8+r11*1]
  c17052:	lea    rcx,[rip+0xffffffffff6ae95b]        # 2c59b4 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0xff3>
  c17059:	movsxd rax,DWORD PTR [rcx+rax*4]
  c1705d:	add    rax,rcx
  c17060:	jmp    rax
  c17062:	mov    QWORD PTR [rsp+0x340],r11
  c1706a:	mov    rcx,QWORD PTR [rsp+0x18]
  c1706f:	lea    rax,[rcx+0x10]
  c17073:	mov    r12,QWORD PTR [rax]
  c17076:	cmp    QWORD PTR [rsp+0x8],r12
  c1707b:	lea    rax,[rcx+0x8]
  c1707f:	mov    rsi,QWORD PTR [rsp+0x20]
  c17084:	jae    c199d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0b6>
  c1708a:	mov    rdx,QWORD PTR [rax]
  c1708d:	lea    rcx,[rdx+rsi*1]
  c17091:	movzx  eax,r14b
  c17095:	mov    rbx,rax
  c17098:	sub    rbx,QWORD PTR [rdx+rsi*1+0x30]
  c1709d:	jb     c171b6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7896>
  c170a3:	add    rbx,QWORD PTR [rcx+0x60]
  c170a7:	mov    r15b,0x1
  c170aa:	mov    r12,QWORD PTR [rsp+0x50]
  c170af:	cmp    r12,QWORD PTR [rsp+0x40]
  c170b4:	jne    c173c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7aa4>
  c170ba:	jmp    c173b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a99>
  c170bf:	mov    QWORD PTR [rsp+0x340],r11
  c170c7:	mov    rcx,QWORD PTR [rsp+0x18]
  c170cc:	lea    rax,[rcx+0x10]
  c170d0:	mov    r12,QWORD PTR [rax]
  c170d3:	cmp    QWORD PTR [rsp+0x8],r12
  c170d8:	lea    rax,[rcx+0x8]
  c170dc:	mov    rsi,QWORD PTR [rsp+0x20]
  c170e1:	jae    c199df <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0bf>
  c170e7:	mov    rdx,QWORD PTR [rax]
  c170ea:	lea    rcx,[rdx+rsi*1]
  c170ee:	movzx  eax,r14b
  c170f2:	mov    rbx,rax
  c170f5:	sub    rbx,QWORD PTR [rdx+rsi*1+0x30]
  c170fa:	jae    c17109 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x77e9>
  c170fc:	mov    rcx,QWORD PTR [rcx+0x28]
  c17100:	shl    eax,0x4
  c17103:	mov    rbx,QWORD PTR [rcx+rax*1]
  c17107:	jmp    c1710d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x77ed>
  c17109:	add    rbx,QWORD PTR [rcx+0x60]
  c1710d:	mov    rcx,QWORD PTR [rsp+0x10]
  c17112:	mov    rax,QWORD PTR [rsp+0x28]
  c17117:	cmp    rbx,QWORD PTR [rax+0x10]
  c1711b:	jae    c174f5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7bd5>
  c17121:	mov    rax,QWORD PTR [rax+0x8]
  c17125:	lea    rcx,[rbx+rbx*2]
  c17129:	lea    r15,[rax+rcx*8]
  c1712d:	mov    eax,DWORD PTR [rax+rcx*8]
  c17130:	mov    edx,eax
  c17132:	sub    edx,0x2
  c17135:	mov    ecx,0x3
  c1713a:	cmovae ecx,edx
  c1713d:	cmp    ecx,0x8
  c17140:	ja     c17429 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b09>
  c17146:	mov    edx,0x1e7
  c1714b:	bt     edx,ecx
  c1714e:	jae    c17252 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7932>
  c17154:	mov    DWORD PTR [r15],0x2
  c1715b:	xor    r15d,r15d
  c1715e:	mov    r12,QWORD PTR [rsp+0x50]
  c17163:	cmp    r12,QWORD PTR [rsp+0x40]
  c17168:	je     c173b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a99>
  c1716e:	jmp    c173c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7aa4>
  c17173:	mov    rcx,QWORD PTR [rsp+0x18]
  c17178:	lea    rax,[rcx+0x10]
  c1717c:	mov    r12,QWORD PTR [rax]
  c1717f:	cmp    QWORD PTR [rsp+0x8],r12
  c17184:	lea    rax,[rcx+0x8]
  c17188:	mov    rsi,QWORD PTR [rsp+0x20]
  c1718d:	mov    QWORD PTR [rsp+0x340],r11
  c17195:	jae    c199e8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0c8>
  c1719b:	mov    rdx,QWORD PTR [rax]
  c1719e:	lea    rcx,[rdx+rsi*1]
  c171a2:	movzx  eax,BYTE PTR [r8+r11*1+0x1]
  c171a8:	mov    rbx,rax
  c171ab:	sub    rbx,QWORD PTR [rdx+rsi*1+0x30]
  c171b0:	jae    c170a3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7783>
  c171b6:	mov    rcx,QWORD PTR [rcx+0x28]
  c171ba:	shl    eax,0x4
  c171bd:	mov    rbx,QWORD PTR [rcx+rax*1]
  c171c1:	mov    r15b,0x1
  c171c4:	mov    r12,QWORD PTR [rsp+0x50]
  c171c9:	cmp    r12,QWORD PTR [rsp+0x40]
  c171ce:	jne    c173c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7aa4>
  c171d4:	jmp    c173b9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a99>
  c171d9:	movzx  r15d,WORD PTR [r8+r11*1+0x2]
  c171df:	mov    rax,QWORD PTR [rsp+0x1c8]
  c171e7:	cmp    QWORD PTR [rax+0x10],r15
  c171eb:	mov    rcx,QWORD PTR [rsp+0x10]
  c171f0:	mov    r8,QWORD PTR [rsp+0x570]
  c171f8:	mov    r9,QWORD PTR [rsp+0x4e8]
  c17200:	mov    r10,QWORD PTR [rsp+0x568]
  c17208:	mov    QWORD PTR [rsp+0x340],r11
  c17210:	jbe    c174d5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7bb5>
  c17216:	mov    rdx,QWORD PTR [rax+0x8]
  c1721a:	lea    rsi,[r15+r15*2]
  c1721e:	mov    ecx,DWORD PTR [rdx+rsi*8]
  c17221:	mov    edi,ecx
  c17223:	sub    edi,0x2
  c17226:	mov    eax,0x3
  c1722b:	cmovb  edi,eax
  c1722e:	lea    rdx,[rdx+rsi*8]
  c17232:	lea    rsi,[rip+0xffffffffff6ae78f]        # 2c59c8 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1007>
  c17239:	movsxd rdi,DWORD PTR [rsi+rdi*4]
  c1723d:	add    rdi,rsi
  c17240:	jmp    rdi
  c17242:	mov    r9d,DWORD PTR [rdx+0x4]
  c17246:	mov    r10,QWORD PTR [rdx+0x8]
  c1724a:	mov    r8,QWORD PTR [rdx+0x10]
  c1724e:	mov    eax,ecx
  c17250:	jmp    c172bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x799b>
  c17252:	cmp    ecx,0x3
  c17255:	jne    c1740d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7aed>
  c1725b:	test   eax,eax
  c1725d:	je     c17154 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7834>
  c17263:	mov    rax,QWORD PTR [r15+0x8]
  c17267:	dec    QWORD PTR [rax]
  c1726a:	jne    c17154 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7834>
  c17270:	lea    rdi,[r15+0x8]
  c17274:	call   QWORD PTR [rip+0x23678e]        # e4da08 <_DYNAMIC+0x248>
  c1727a:	jmp    c17154 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7834>
  c1727f:	mov    r10,QWORD PTR [rdx+0x8]
  c17283:	mov    eax,0xb
  c17288:	jmp    c172b2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7992>
  c1728a:	mov    eax,0x2
  c1728f:	jmp    c172bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x799b>
  c17291:	test   cl,0x1
  c17294:	je     c17242 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7922>
  c17296:	mov    r10,QWORD PTR [rdx+0x8]
  c1729a:	mov    eax,0x1
  c1729f:	inc    QWORD PTR [r10]
  c172a2:	jne    c172bb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x799b>
  c172a4:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c172a9:	mov    r10,QWORD PTR [rdx+0x8]
  c172ad:	mov    eax,0x6
  c172b2:	inc    QWORD PTR [r10]
  c172b5:	je     c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c172bb:	mov    eax,eax
  c172bd:	mov    QWORD PTR [rsp+0x4e8],r9
  c172c5:	mov    rcx,r9
  c172c8:	shl    rcx,0x20
  c172cc:	or     rcx,rax
  c172cf:	mov    QWORD PTR [rsp+0x598],rcx
  c172d7:	mov    QWORD PTR [rsp+0x568],r10
  c172df:	mov    QWORD PTR [rsp+0x5a0],r10
  c172e7:	mov    QWORD PTR [rsp+0x570],r8
  c172ef:	mov    QWORD PTR [rsp+0x5a8],r8
  c172f7:	mov    r12,QWORD PTR [rsp+0x28]
  c172fc:	mov    rbx,QWORD PTR [r12+0x10]
  c17301:	cmp    rbx,QWORD PTR [r12]
  c17305:	jne    c17310 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x79f0>
  c17307:	mov    rdi,r12
  c1730a:	call   QWORD PTR [rip+0x2382b8]        # e4f5c8 <_DYNAMIC+0x1e08>
  c17310:	mov    rax,QWORD PTR [r12+0x8]
  c17315:	lea    rcx,[rbx+rbx*2]
  c17319:	mov    rdx,QWORD PTR [rsp+0x5a8]
  c17321:	mov    QWORD PTR [rax+rcx*8+0x10],rdx
  c17326:	movdqu xmm0,XMMWORD PTR [rsp+0x598]
  c1732f:	movdqu XMMWORD PTR [rax+rcx*8],xmm0
  c17334:	lea    rax,[rbx+0x1]
  c17338:	mov    QWORD PTR [r12+0x10],rax
  c1733d:	mov    rcx,QWORD PTR [rsp+0x18]
  c17342:	lea    rax,[rcx+0x10]
  c17346:	mov    r12,QWORD PTR [rax]
  c17349:	cmp    QWORD PTR [rsp+0x8],r12
  c1734e:	jae    c199f1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0d1>
  c17354:	lea    rax,[rcx+0x8]
  c17358:	mov    rax,QWORD PTR [rax]
  c1735b:	mov    rcx,QWORD PTR [rsp+0x20]
  c17360:	mov    r13d,DWORD PTR [rax+rcx*1+0x70]
  c17365:	mov    r12,QWORD PTR [rsp+0x90]
  c1736d:	cmp    r12,QWORD PTR [rsp+0x80]
  c17375:	jne    c17385 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7a65>
  c17377:	lea    rdi,[rsp+0x80]
  c1737f:	call   QWORD PTR [rip+0x23bc93]        # e53018 <_DYNAMIC+0x5858>
  c17385:	mov    rax,QWORD PTR [rsp+0x88]
  c1738d:	lea    rcx,[r12+r12*2]
  c17391:	mov    QWORD PTR [rax+rcx*8],rbx
  c17395:	mov    DWORD PTR [rax+rcx*8+0x8],r13d
  c1739a:	mov    QWORD PTR [rax+rcx*8+0x10],r15
  c1739f:	inc    r12
  c173a2:	mov    QWORD PTR [rsp+0x90],r12
  c173aa:	mov    r15b,0x1
  c173ad:	mov    r12,QWORD PTR [rsp+0x50]
  c173b2:	cmp    r12,QWORD PTR [rsp+0x40]
  c173b7:	jne    c173c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7aa4>
  c173b9:	lea    rdi,[rsp+0x40]
  c173be:	call   QWORD PTR [rip+0x23bc5c]        # e53020 <_DYNAMIC+0x5860>
  c173c4:	mov    rax,QWORD PTR [rsp+0x48]
  c173c9:	mov    rcx,r12
  c173cc:	shl    rcx,0x4
  c173d0:	mov    QWORD PTR [rax+rcx*1],rbx
  c173d4:	mov    BYTE PTR [rax+rcx*1+0x8],r15b
  c173d9:	inc    r12
  c173dc:	mov    QWORD PTR [rsp+0x50],r12
  c173e1:	mov    r11,QWORD PTR [rsp+0x340]
  c173e9:	add    r11,0x4
  c173ed:	cmp    QWORD PTR [rsp+0x560],r11
  c173f5:	jne    c17042 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7722>
  c173fb:	mov    r13,QWORD PTR [rsp+0x1a8]
  c17403:	mov    r15d,DWORD PTR [rsp+0x3c]
  c17408:	jmp    c16eb9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7599>
  c1740d:	mov    rax,QWORD PTR [r15+0x8]
  c17411:	dec    QWORD PTR [rax]
  c17414:	jne    c17154 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7834>
  c1741a:	lea    rdi,[r15+0x8]
  c1741e:	call   QWORD PTR [rip+0x2365ec]        # e4da10 <_DYNAMIC+0x250>
  c17424:	jmp    c17154 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7834>
  c17429:	mov    rax,QWORD PTR [r15+0x8]
  c1742d:	dec    QWORD PTR [rax]
  c17430:	jne    c17154 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7834>
  c17436:	lea    rdi,[r15+0x8]
  c1743a:	call   QWORD PTR [rip+0x2365d8]        # e4da18 <_DYNAMIC+0x258>
  c17440:	jmp    c17154 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7834>
  c17445:	mov    DWORD PTR [r12+0x8],0xc
  c1744e:	mov    BYTE PTR [r12],0xff
  c17453:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17458:	mov    eax,DWORD PTR [rsp+0x118]
  c1745f:	movups xmm0,XMMWORD PTR [rsp+0x11c]
  c17467:	movaps XMMWORD PTR [rsp+0x3c0],xmm0
  c1746f:	mov    ecx,DWORD PTR [rsp+0x12c]
  c17476:	mov    DWORD PTR [rsp+0x3d0],ecx
  c1747d:	cmp    eax,0xffffffff
  c17480:	je     c1749c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b7c>
  c17482:	mov    ecx,DWORD PTR [rsp+0x3d0]
  c17489:	mov    DWORD PTR [rsp+0x50],ecx
  c1748d:	movaps xmm0,XMMWORD PTR [rsp+0x3c0]
  c17495:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c1749a:	jmp    c174a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b81>
  c1749c:	mov    eax,0xc
  c174a1:	mov    DWORD PTR [rbx+0x8],eax
  c174a4:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c174aa:	movdqu XMMWORD PTR [rbx+0xc],xmm0
  c174af:	mov    eax,DWORD PTR [rsp+0x50]
  c174b3:	mov    DWORD PTR [rbx+0x1c],eax
  c174b6:	mov    BYTE PTR [rbx],0xff
  c174b9:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c174be:	xor    r13d,r13d
  c174c1:	mov    r12,QWORD PTR [rsp+0x548]
  c174c9:	mov    rdi,r13
  c174cc:	mov    rsi,r12
  c174cf:	call   QWORD PTR [rip+0x2365d3]        # e4daa8 <_DYNAMIC+0x2e8>
  c174d5:	mov    BYTE PTR [rcx],0x1f
  c174d8:	lea    rax,[rip+0xffffffffff6aec39]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c174df:	mov    QWORD PTR [rcx+0x8],rax
  c174e3:	mov    QWORD PTR [rcx+0x10],0x4f
  c174eb:	mov    eax,0x18
  c174f0:	jmp    c186e0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dc0>
  c174f5:	mov    BYTE PTR [rcx],0x1f
  c174f8:	lea    rax,[rip+0xffffffffff6af40d]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c174ff:	mov    QWORD PTR [rcx+0x8],rax
  c17503:	mov    r8d,0x4f
  c17509:	jmp    c186db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dbb>
  c1750e:	mov    rcx,QWORD PTR [rsp+0x10]
  c17513:	mov    BYTE PTR [rcx],0x1f
  c17516:	lea    rax,[rip+0xffffffffff6af194]        # 2c66b1 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x32e>
  c1751d:	mov    QWORD PTR [rcx+0x8],rax
  c17521:	mov    QWORD PTR [rcx+0x10],0x42
  c17529:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1752e:	mov    r13b,0x1f
  c17531:	lea    rbx,[rip+0xffffffffff6aebe0]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17538:	mov    r15d,0x4f
  c1753e:	mov    r12,QWORD PTR [rsp+0x10]
  c17543:	jmp    c1843a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1a>
  c17548:	mov    rcx,QWORD PTR [rsp+0x10]
  c1754d:	mov    BYTE PTR [rcx],0x1f
  c17550:	lea    rax,[rip+0xffffffffff6aed3c]        # 2c6293 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x18d2>
  c17557:	mov    QWORD PTR [rcx+0x8],rax
  c1755b:	mov    QWORD PTR [rcx+0x10],0x3a
  c17563:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17568:	movdqu xmm0,XMMWORD PTR [rsp+0x112]
  c17571:	movdqu xmm1,XMMWORD PTR [rsp+0x122]
  c1757a:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c17582:	movups XMMWORD PTR [r12+0x20],xmm2
  c17588:	movdqu XMMWORD PTR [r12+0x12],xmm1
  c1758f:	movdqu XMMWORD PTR [r12+0x2],xmm0
  c17596:	mov    BYTE PTR [r12],al
  c1759a:	mov    BYTE PTR [r12+0x1],bl
  c1759f:	jmp    c18338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a18>
  c175a4:	movups xmm0,XMMWORD PTR [rsp+0x111]
  c175ac:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c175b5:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c175bd:	movdqu XMMWORD PTR [rsp+0x8f],xmm1
  c175c6:	movaps XMMWORD PTR [rsp+0x80],xmm0
  c175ce:	mov    rcx,QWORD PTR [rsp+0x10]
  c175d3:	movups XMMWORD PTR [rcx+0x20],xmm2
  c175d7:	movups xmm0,XMMWORD PTR [rsp+0x8f]
  c175df:	movups XMMWORD PTR [rcx+0x10],xmm0
  c175e3:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c175ec:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c175f1:	mov    BYTE PTR [rcx],al
  c175f3:	jmp    c18686 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d66>
  c175f8:	test   r14b,0x1
  c175fc:	je     c188a6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8f86>
  c17602:	mov    rcx,QWORD PTR [rsp+0x18]
  c17607:	lea    rax,[rcx+0x10]
  c1760b:	mov    rsi,QWORD PTR [rax]
  c1760e:	cmp    QWORD PTR [rsp+0x8],rsi
  c17613:	mov    rbx,QWORD PTR [rsp+0x10]
  c17618:	jae    c1a0db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa7bb>
  c1761e:	lea    rax,[rcx+0x8]
  c17622:	mov    rsi,QWORD PTR [rax]
  c17625:	mov    rdi,QWORD PTR [rsp+0x20]
  c1762a:	lea    rdx,[rsi+rdi*1]
  c1762e:	movzx  ecx,bpl
  c17632:	mov    rax,rcx
  c17635:	sub    rax,QWORD PTR [rsi+rdi*1+0x30]
  c1763a:	mov    r14,QWORD PTR [rsp+0x28]
  c1763f:	jae    c18db6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9496>
  c17645:	mov    rax,QWORD PTR [rdx+0x28]
  c17649:	shl    ecx,0x4
  c1764c:	mov    rax,QWORD PTR [rax+rcx*1]
  c17650:	jmp    c18dba <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x949a>
  c17655:	mov    rax,QWORD PTR [rsp+0x1b0]
  c1765d:	mov    rsi,QWORD PTR [rax]
  c17660:	cmp    QWORD PTR [rsp+0x8],rsi
  c17665:	jae    c1a0c9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa7a9>
  c1766b:	mov    rax,QWORD PTR [rsp+0x1b8]
  c17673:	mov    rdi,QWORD PTR [rax]
  c17676:	mov    r8,QWORD PTR [rsp+0x28]
  c1767b:	mov    rax,QWORD PTR [r8+0x10]
  c1767f:	mov    r9,QWORD PTR [rsp+0x20]
  c17684:	lea    rsi,[rdi+r9*1]
  c17688:	movzx  edx,bpl
  c1768c:	mov    rcx,rdx
  c1768f:	sub    rcx,QWORD PTR [rdi+r9*1+0x30]
  c17694:	jae    c188c0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8fa0>
  c1769a:	mov    rcx,QWORD PTR [rsi+0x28]
  c1769e:	shl    edx,0x4
  c176a1:	mov    rcx,QWORD PTR [rcx+rdx*1]
  c176a5:	jmp    c188c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8fa4>
  c176aa:	mov    rcx,QWORD PTR [rsp+0x10]
  c176af:	mov    BYTE PTR [rcx],0x1f
  c176b2:	lea    rax,[rip+0xffffffffff6af09e]        # 2c6757 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x3d4>
  c176b9:	mov    QWORD PTR [rcx+0x8],rax
  c176bd:	mov    QWORD PTR [rcx+0x10],0x5c
  c176c5:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c176ca:	lea    rax,[rip+0xffffffffff6aebfc]        # 2c62cd <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x190c>
  c176d1:	mov    r12,QWORD PTR [rsp+0x10]
  c176d6:	jmp    c17aff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x81df>
  c176db:	mov    rcx,QWORD PTR [rsp+0x10]
  c176e0:	mov    BYTE PTR [rcx],0x1f
  c176e3:	lea    rax,[rip+0xffffffffff6aea2e]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c176ea:	mov    QWORD PTR [rcx+0x8],rax
  c176ee:	mov    QWORD PTR [rcx+0x10],0x4f
  c176f6:	mov    rax,QWORD PTR [rsp+0x228]
  c176fe:	mov    QWORD PTR [rcx+0x18],rax
  c17702:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17707:	mov    rcx,QWORD PTR [rsp+0x10]
  c1770c:	mov    BYTE PTR [rcx],0x1f
  c1770f:	lea    rax,[rip+0xffffffffff6aea02]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17716:	mov    QWORD PTR [rcx+0x8],rax
  c1771a:	mov    QWORD PTR [rcx+0x10],0x4f
  c17722:	mov    rax,QWORD PTR [rsp+0x240]
  c1772a:	mov    QWORD PTR [rcx+0x18],rax
  c1772e:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17733:	mov    BYTE PTR [r12],0x1f
  c17738:	lea    rax,[rip+0xffffffffff6ae9d9]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1773f:	mov    QWORD PTR [r12+0x8],rax
  c17744:	mov    QWORD PTR [r12+0x10],0x4f
  c1774d:	mov    rax,QWORD PTR [rsp+0x248]
  c17755:	mov    QWORD PTR [r12+0x18],rax
  c1775a:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1775f:	mov    r15b,0x1f
  c17762:	lea    rbx,[rip+0xffffffffff6ae9af]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17769:	mov    r14d,0x4f
  c1776f:	mov    r12,QWORD PTR [rsp+0x10]
  c17774:	jmp    c184ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bcc>
  c17779:	mov    BYTE PTR [r12],0x1f
  c1777e:	lea    rax,[rip+0xffffffffff6ae993]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17785:	mov    QWORD PTR [r12+0x8],rax
  c1778a:	mov    QWORD PTR [r12+0x10],0x4f
  c17793:	mov    rax,QWORD PTR [rsp+0x260]
  c1779b:	mov    QWORD PTR [r12+0x18],rax
  c177a0:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c177a5:	mov    BYTE PTR [r12],0x1f
  c177aa:	lea    rax,[rip+0xffffffffff6ae967]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c177b1:	mov    QWORD PTR [r12+0x8],rax
  c177b6:	mov    QWORD PTR [r12+0x10],0x4f
  c177bf:	mov    rax,QWORD PTR [rsp+0x258]
  c177c7:	mov    QWORD PTR [r12+0x18],rax
  c177cc:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c177d1:	mov    rcx,QWORD PTR [rsp+0x10]
  c177d6:	mov    BYTE PTR [rcx],0x1f
  c177d9:	lea    rax,[rip+0xffffffffff6ae938]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c177e0:	mov    QWORD PTR [rcx+0x8],rax
  c177e4:	mov    QWORD PTR [rcx+0x10],0x4f
  c177ec:	mov    rax,QWORD PTR [rsp+0x250]
  c177f4:	mov    QWORD PTR [rcx+0x18],rax
  c177f8:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c177fd:	mov    rcx,QWORD PTR [rsp+0x10]
  c17802:	mov    BYTE PTR [rcx],0x1f
  c17805:	lea    rax,[rip+0xffffffffff6ae90c]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1780c:	mov    QWORD PTR [rcx+0x8],rax
  c17810:	mov    QWORD PTR [rcx+0x10],0x4f
  c17818:	mov    rax,QWORD PTR [rsp+0x278]
  c17820:	mov    QWORD PTR [rcx+0x18],rax
  c17824:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17829:	jmp    c18a71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9151>
  c1782e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c17837:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c17840:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c17848:	movups XMMWORD PTR [r12+0x20],xmm2
  c1784e:	movdqu XMMWORD PTR [r12+0x10],xmm1
  c17855:	movdqu XMMWORD PTR [r12],xmm0
  c1785b:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17860:	mov    rcx,QWORD PTR [rsp+0x10]
  c17865:	mov    BYTE PTR [rcx],0x1f
  c17868:	lea    rax,[rip+0xffffffffff6ae8a9]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1786f:	mov    QWORD PTR [rcx+0x8],rax
  c17873:	mov    QWORD PTR [rcx+0x10],0x4f
  c1787b:	mov    rax,QWORD PTR [rsp+0x230]
  c17883:	mov    QWORD PTR [rcx+0x18],rax
  c17887:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1788c:	mov    r15b,0x1f
  c1788f:	lea    rbx,[rip+0xffffffffff6ae882]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17896:	mov    r14d,0x4f
  c1789c:	mov    r12,QWORD PTR [rsp+0x10]
  c178a1:	jmp    c18596 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c76>
  c178a6:	mov    rcx,QWORD PTR [rsp+0x10]
  c178ab:	mov    BYTE PTR [rcx],0x1f
  c178ae:	lea    rax,[rip+0xffffffffff6ae863]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c178b5:	mov    QWORD PTR [rcx+0x8],rax
  c178b9:	mov    QWORD PTR [rcx+0x10],0x4f
  c178c1:	mov    rax,QWORD PTR [rsp+0x268]
  c178c9:	mov    QWORD PTR [rcx+0x18],rax
  c178cd:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c178d2:	mov    rcx,QWORD PTR [rsp+0x10]
  c178d7:	mov    BYTE PTR [rcx],0x1f
  c178da:	lea    rax,[rip+0xffffffffff6ae837]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c178e1:	mov    QWORD PTR [rcx+0x8],rax
  c178e5:	mov    QWORD PTR [rcx+0x10],0x4f
  c178ed:	mov    rax,QWORD PTR [rsp+0x280]
  c178f5:	mov    QWORD PTR [rcx+0x18],rax
  c178f9:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c178fe:	mov    rcx,QWORD PTR [rsp+0x10]
  c17903:	mov    BYTE PTR [rcx],0x1f
  c17906:	lea    rax,[rip+0xffffffffff6ae80b]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1790d:	mov    QWORD PTR [rcx+0x8],rax
  c17911:	mov    QWORD PTR [rcx+0x10],0x4f
  c17919:	mov    rax,QWORD PTR [rsp+0x270]
  c17921:	mov    QWORD PTR [rcx+0x18],rax
  c17925:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1792a:	mov    BYTE PTR [r12],0x1f
  c1792f:	lea    rax,[rip+0xffffffffff6ae7e2]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17936:	mov    QWORD PTR [r12+0x8],rax
  c1793b:	mov    QWORD PTR [r12+0x10],0x4f
  c17944:	mov    rax,QWORD PTR [rsp+0x238]
  c1794c:	mov    QWORD PTR [r12+0x18],rax
  c17951:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17956:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c1795f:	movdqu xmm1,XMMWORD PTR [rsp+0x128]
  c17968:	movups xmm2,XMMWORD PTR [rsp+0x138]
  c17970:	movups XMMWORD PTR [rsp+0x64],xmm2
  c17975:	movdqu XMMWORD PTR [rsp+0x54],xmm1
  c1797b:	movdqu XMMWORD PTR [rsp+0x44],xmm0
  c17981:	jmp    c197d7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9eb7>
  c17986:	jmp    c18a71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9151>
  c1798b:	mov    rcx,QWORD PTR [rsp+0x10]
  c17990:	mov    BYTE PTR [rcx],0x1f
  c17993:	lea    rax,[rip+0xffffffffff6ae77e]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1799a:	mov    QWORD PTR [rcx+0x8],rax
  c1799e:	mov    QWORD PTR [rcx+0x10],0x4f
  c179a6:	mov    eax,0x18
  c179ab:	mov    rdx,QWORD PTR [rsp+0x220]
  c179b3:	mov    QWORD PTR [rcx+rax*1],rdx
  c179b7:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c179bc:	jmp    c18a71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9151>
  c179c1:	mov    BYTE PTR [rcx],0x1f
  c179c4:	lea    rax,[rip+0xffffffffff6aede8]        # 2c67b3 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x430>
  c179cb:	mov    QWORD PTR [rcx+0x8],rax
  c179cf:	mov    QWORD PTR [rcx+0x10],0x51
  c179d7:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c179dc:	mov    rcx,QWORD PTR [rsp+0x10]
  c179e1:	mov    BYTE PTR [rcx],0x1f
  c179e4:	lea    rax,[rip+0xffffffffff6ae72d]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c179eb:	mov    QWORD PTR [rcx+0x8],rax
  c179ef:	mov    QWORD PTR [rcx+0x10],0x4f
  c179f7:	mov    eax,0x18
  c179fc:	mov    rdx,QWORD PTR [rsp+0x218]
  c17a04:	mov    QWORD PTR [rcx+rax*1],rdx
  c17a08:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17a0d:	mov    BYTE PTR [r12],0x1f
  c17a12:	lea    rax,[rip+0xffffffffff6ae6ff]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a19:	mov    QWORD PTR [r12+0x8],rax
  c17a1e:	mov    QWORD PTR [r12+0x10],0x4f
  c17a27:	mov    rax,QWORD PTR [rsp+0x1e8]
  c17a2f:	mov    QWORD PTR [r12+0x18],rax
  c17a34:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17a39:	mov    BYTE PTR [r12],0x1f
  c17a3e:	lea    rax,[rip+0xffffffffff6ae6d3]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a45:	mov    QWORD PTR [r12+0x8],rax
  c17a4a:	mov    QWORD PTR [r12+0x10],0x4f
  c17a53:	mov    QWORD PTR [r12+0x18],r9
  c17a58:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17a5d:	mov    BYTE PTR [r12],0x1f
  c17a62:	lea    rax,[rip+0xffffffffff6ae6af]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17a69:	mov    QWORD PTR [r12+0x8],rax
  c17a6e:	mov    QWORD PTR [r12+0x10],0x4f
  c17a77:	mov    rax,QWORD PTR [rsp+0x1f0]
  c17a7f:	mov    QWORD PTR [r12+0x18],rax
  c17a84:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17a89:	movups xmm0,XMMWORD PTR [rsp+0x111]
  c17a91:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c17a9a:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c17aa2:	movdqu XMMWORD PTR [rsp+0x4f],xmm1
  c17aa8:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c17aad:	mov    rcx,QWORD PTR [rsp+0x10]
  c17ab2:	movups XMMWORD PTR [rcx+0x20],xmm2
  c17ab6:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c17abb:	movups XMMWORD PTR [rcx+0x10],xmm0
  c17abf:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c17ac5:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c17aca:	mov    BYTE PTR [rcx],al
  c17acc:	jmp    c17fb4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8694>
  c17ad1:	mov    r13b,0x1f
  c17ad4:	lea    rbx,[rip+0xffffffffff6ae63d]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17adb:	mov    r15d,0x4f
  c17ae1:	mov    r12,QWORD PTR [rsp+0x10]
  c17ae6:	jmp    c18410 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af0>
  c17aeb:	lea    rdi,[rsp+0x110]
  c17af3:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17af8:	lea    rax,[rip+0xffffffffff6aee0d]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c17aff:	mov    BYTE PTR [r12],0x1f
  c17b04:	jmp    c18a8a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x916a>
  c17b09:	mov    r15b,0x1f
  c17b0c:	lea    rbx,[rip+0xffffffffff6ae605]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17b13:	mov    r14d,0x4f
  c17b19:	mov    r12,QWORD PTR [rsp+0x10]
  c17b1e:	jmp    c1856c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c4c>
  c17b23:	mov    r13b,0x1f
  c17b26:	lea    rbx,[rip+0xffffffffff6ae5eb]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17b2d:	mov    r15d,0x4f
  c17b33:	mov    r12,QWORD PTR [rsp+0x10]
  c17b38:	jmp    c1838a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a6a>
  c17b3d:	mov    r15b,0x1f
  c17b40:	lea    rbx,[rip+0xffffffffff6ae5d1]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17b47:	mov    r14d,0x4f
  c17b4d:	mov    r12,QWORD PTR [rsp+0x10]
  c17b52:	jmp    c184c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ba4>
  c17b57:	mov    BYTE PTR [r12],0x1f
  c17b5c:	lea    rax,[rip+0xffffffffff6ae5b5]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17b63:	mov    QWORD PTR [r12+0x8],rax
  c17b68:	mov    QWORD PTR [r12+0x10],0x4f
  c17b71:	mov    QWORD PTR [r12+0x18],r8
  c17b76:	jmp    c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c17b7b:	mov    rcx,QWORD PTR [rsp+0x10]
  c17b80:	mov    BYTE PTR [rcx],0x1f
  c17b83:	lea    rax,[rip+0xffffffffff6ae58e]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17b8a:	mov    QWORD PTR [rcx+0x8],rax
  c17b8e:	mov    QWORD PTR [rcx+0x10],0x4f
  c17b96:	mov    rax,QWORD PTR [rsp+0x1f8]
  c17b9e:	mov    QWORD PTR [rcx+0x18],rax
  c17ba2:	jmp    c1861a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8cfa>
  c17ba7:	mov    rcx,QWORD PTR [rsp+0x10]
  c17bac:	mov    BYTE PTR [rcx],0x1f
  c17baf:	lea    rax,[rip+0xffffffffff6ae562]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17bb6:	mov    QWORD PTR [rcx+0x8],rax
  c17bba:	mov    QWORD PTR [rcx+0x10],0x4f
  c17bc2:	mov    rax,QWORD PTR [rsp+0x200]
  c17bca:	mov    QWORD PTR [rcx+0x18],rax
  c17bce:	jmp    c182e1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x89c1>
  c17bd3:	jmp    c1801e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x86fe>
  c17bd8:	mov    BYTE PTR [r12],0x1f
  c17bdd:	lea    rax,[rip+0xffffffffff6ae534]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17be4:	mov    QWORD PTR [r12+0x8],rax
  c17be9:	mov    QWORD PTR [r12+0x10],0x4f
  c17bf2:	mov    rax,QWORD PTR [rsp+0x210]
  c17bfa:	mov    QWORD PTR [r12+0x18],rax
  c17bff:	jmp    c18686 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d66>
  c17c04:	mov    rcx,QWORD PTR [rsp+0x10]
  c17c09:	mov    BYTE PTR [rcx],0x1f
  c17c0c:	lea    rax,[rip+0xffffffffff6ae505]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c17c13:	mov    QWORD PTR [rcx+0x8],rax
  c17c17:	mov    QWORD PTR [rcx+0x10],0x4f
  c17c1f:	mov    rax,QWORD PTR [rsp+0x208]
  c17c27:	mov    QWORD PTR [rcx+0x18],rax
  c17c2b:	jmp    c182a8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8988>
  c17c30:	mov    eax,DWORD PTR [rsp+0x111]
  c17c37:	mov    edx,DWORD PTR [rsp+0x114]
  c17c3e:	mov    r12,QWORD PTR [rsp+0x10]
  c17c43:	mov    DWORD PTR [r12+0x4],edx
  c17c48:	mov    DWORD PTR [r12+0x1],eax
  c17c4d:	mov    rax,QWORD PTR [rsp+0x118]
  c17c55:	movups xmm0,XMMWORD PTR [rsp+0x130]
  c17c5d:	movups XMMWORD PTR [r12+0x20],xmm0
  c17c63:	movdqu xmm0,XMMWORD PTR [rsp+0x120]
  c17c6c:	movdqu XMMWORD PTR [r12+0x10],xmm0
  c17c73:	mov    BYTE PTR [r12],cl
  c17c77:	mov    ecx,0x8
  c17c7c:	mov    QWORD PTR [r12+rcx*1],rax
  c17c80:	jmp    c18338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a18>
  c17c85:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c17c8e:	movdqu xmm1,XMMWORD PTR [rsp+0x128]
  c17c97:	movups xmm2,XMMWORD PTR [rsp+0x138]
  c17c9f:	movups XMMWORD PTR [rsp+0x64],xmm2
  c17ca4:	movdqu XMMWORD PTR [rsp+0x54],xmm1
  c17caa:	movdqu XMMWORD PTR [rsp+0x44],xmm0
  c17cb0:	mov    rax,QWORD PTR [rsp+0x10]
  c17cb5:	movups XMMWORD PTR [rax+0x20],xmm2
  c17cb9:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c17cbe:	movdqu XMMWORD PTR [rax],xmm0
  c17cc2:	jmp    c19070 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9750>
  c17cc7:	mov    rax,QWORD PTR [rsp+0x1d8]
  c17ccf:	movzx  esi,BYTE PTR [rax+0xc5]
  c17cd6:	lea    rdi,[rsp+0x110]
  c17cde:	mov    ecx,0x8
  c17ce3:	mov    r8d,0x18
  c17ce9:	xor    edx,edx
  c17ceb:	call   c4f8a0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsbxgXiyEKxkX_6bsl_vm>
  c17cf0:	mov    rdi,QWORD PTR [rsp+0x118]
  c17cf8:	cmp    BYTE PTR [rsp+0x110],0x0
  c17d00:	jne    c199b5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa095>
  c17d06:	mov    rax,QWORD PTR [rsp+0x120]
  c17d0e:	mov    QWORD PTR [rsp+0xd0],rdi
  c17d16:	mov    QWORD PTR [rsp+0xd8],rax
  c17d1e:	mov    QWORD PTR [rsp+0xe0],0x0
  c17d2a:	mov    r15,QWORD PTR [rbx+0x10]
  c17d2e:	lea    rdi,[rsp+0x110]
  c17d36:	mov    ecx,0x8
  c17d3b:	mov    r8d,0x10
  c17d41:	mov    rsi,r15
  c17d44:	xor    edx,edx
  c17d46:	call   c4f8a0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsbxgXiyEKxkX_6bsl_vm>
  c17d4b:	mov    rdi,QWORD PTR [rsp+0x118]
  c17d53:	cmp    BYTE PTR [rsp+0x110],0x0
  c17d5b:	jne    c199c3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0a3>
  c17d61:	mov    rax,QWORD PTR [rsp+0x120]
  c17d69:	mov    QWORD PTR [rsp+0x40],rdi
  c17d6e:	mov    QWORD PTR [rsp+0x48],rax
  c17d73:	mov    QWORD PTR [rsp+0x50],0x0
  c17d7c:	mov    rbx,QWORD PTR [rbx+0x8]
  c17d80:	shl    r15,0x2
  c17d84:	mov    QWORD PTR [rsp+0x18],r15
  c17d89:	xor    r13d,r13d
  c17d8c:	lea    rax,[rip+0x21e5a5]        # e36338 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x738>
  c17d93:	mov    QWORD PTR [rsp+0x1c0],rax
  c17d9b:	cmp    QWORD PTR [rsp+0x18],r13
  c17da0:	mov    r15,QWORD PTR [rsp+0x20]
  c17da5:	je     c18a9d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x917d>
  c17dab:	movzx  eax,BYTE PTR [rbx+r13*1]
  c17db0:	lea    rcx,[rip+0xffffffffff6adc39]        # 2c59f0 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x102f>
  c17db7:	movsxd rax,DWORD PTR [rcx+rax*4]
  c17dbb:	add    rax,rcx
  c17dbe:	mov    rdi,QWORD PTR [rsp+0x10]
  c17dc3:	jmp    rax
  c17dc5:	mov    rax,QWORD PTR [rsp+0x1b0]
  c17dcd:	mov    rsi,QWORD PTR [rax]
  c17dd0:	cmp    QWORD PTR [rsp+0x8],rsi
  c17dd5:	jae    c1a0a2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa782>
  c17ddb:	mov    rax,QWORD PTR [rsp+0x1b8]
  c17de3:	mov    rsi,QWORD PTR [rax]
  c17de6:	lea    rdx,[rsi+r15*1]
  c17dea:	movzx  ecx,r14b
  c17dee:	mov    rax,rcx
  c17df1:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c17df6:	jae    c17eab <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x858b>
  c17dfc:	mov    rax,QWORD PTR [rdx+0x28]
  c17e00:	shl    ecx,0x4
  c17e03:	mov    rax,QWORD PTR [rax+rcx*1]
  c17e07:	jmp    c17eaf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x858f>
  c17e0c:	movzx  eax,WORD PTR [rbx+r13*1+0x2]
  c17e12:	mov    rcx,QWORD PTR [rsp+0x1c8]
  c17e1a:	cmp    QWORD PTR [rcx+0x10],rax
  c17e1e:	jbe    c19348 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9a28>
  c17e24:	lea    rsi,[rax+rax*2]
  c17e28:	shl    esi,0x3
  c17e2b:	add    rsi,QWORD PTR [rcx+0x8]
  c17e2f:	lea    rdi,[rsp+0x110]
  c17e37:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c17e3c:	mov    rax,QWORD PTR [rsp+0x110]
  c17e44:	mov    rcx,QWORD PTR [rsp+0x120]
  c17e4c:	mov    QWORD PTR [rsp+0x30],rcx
  c17e51:	jmp    c17f35 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8615>
  c17e56:	mov    DWORD PTR [rsp+0x518],0x2
  c17e61:	xor    r12d,r12d
  c17e64:	jmp    c17f52 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8632>
  c17e69:	mov    rax,QWORD PTR [rsp+0x1b0]
  c17e71:	mov    rsi,QWORD PTR [rax]
  c17e74:	cmp    QWORD PTR [rsp+0x8],rsi
  c17e79:	jae    c1a0b1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa791>
  c17e7f:	mov    rax,QWORD PTR [rsp+0x1b8]
  c17e87:	mov    rsi,QWORD PTR [rax]
  c17e8a:	lea    rdx,[rsi+r15*1]
  c17e8e:	movzx  ecx,BYTE PTR [rbx+r13*1+0x1]
  c17e94:	mov    rax,rcx
  c17e97:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c17e9c:	jae    c17ef1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85d1>
  c17e9e:	mov    rax,QWORD PTR [rdx+0x28]
  c17ea2:	shl    ecx,0x4
  c17ea5:	mov    rax,QWORD PTR [rax+rcx*1]
  c17ea9:	jmp    c17ef5 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x85d5>
  c17eab:	add    rax,QWORD PTR [rdx+0x60]
  c17eaf:	mov    rcx,QWORD PTR [rsp+0x28]
  c17eb4:	cmp    rax,QWORD PTR [rcx+0x10]
  c17eb8:	jae    c1936c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9a4c>
  c17ebe:	mov    rcx,QWORD PTR [rcx+0x8]
  c17ec2:	lea    rax,[rax+rax*2]
  c17ec6:	lea    rsi,[rcx+rax*8]
  c17eca:	lea    rdi,[rsp+0x110]
  c17ed2:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c17ed7:	mov    rax,QWORD PTR [rsp+0x110]
  c17edf:	mov    rcx,QWORD PTR [rsp+0x120]
  c17ee7:	mov    QWORD PTR [rsp+0x350],rcx
  c17eef:	jmp    c17f35 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8615>
  c17ef1:	add    rax,QWORD PTR [rdx+0x60]
  c17ef5:	mov    rcx,QWORD PTR [rsp+0x28]
  c17efa:	cmp    rax,QWORD PTR [rcx+0x10]
  c17efe:	jae    c19393 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9a73>
  c17f04:	mov    rcx,QWORD PTR [rcx+0x8]
  c17f08:	lea    rax,[rax+rax*2]
  c17f0c:	lea    rsi,[rcx+rax*8]
  c17f10:	lea    rdi,[rsp+0x110]
  c17f18:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c17f1d:	mov    rax,QWORD PTR [rsp+0x110]
  c17f25:	mov    rcx,QWORD PTR [rsp+0x120]
  c17f2d:	mov    QWORD PTR [rsp+0x348],rcx
  c17f35:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c17f3e:	mov    QWORD PTR [rsp+0x518],rax
  c17f46:	movdqu XMMWORD PTR [rsp+0x520],xmm0
  c17f4f:	mov    r12b,0x1
  c17f52:	mov    r15,QWORD PTR [rsp+0xe0]
  c17f5a:	lea    rdi,[rsp+0xd0]
  c17f62:	lea    rsi,[rsp+0x518]
  c17f6a:	call   c24780 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueE8push_mutCsbxgXiyEKxkX_6bsl_vm>
  c17f6f:	inc    r14b
  c17f72:	add    r13,0x4
  c17f76:	movzx  edx,r12b
  c17f7a:	lea    rdi,[rsp+0x40]
  c17f7f:	mov    rsi,r15
  c17f82:	call   c24720 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtCsbxgXiyEKxkX_6bsl_vm9ParamSlotE8push_mutBG_>
  c17f87:	jmp    c17d9b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x847b>
  c17f8c:	lea    rdi,[rsp+0x110]
  c17f94:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c17f99:	mov    rcx,QWORD PTR [rsp+0x10]
  c17f9e:	mov    BYTE PTR [rcx],0x1f
  c17fa1:	lea    rax,[rip+0xffffffffff6ae964]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c17fa8:	mov    QWORD PTR [rcx+0x8],rax
  c17fac:	mov    QWORD PTR [rcx+0x10],0x4f
  c17fb4:	lea    rdi,[rsp+0x80]
  c17fbc:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c17fc1:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c17fc6:	mov    BYTE PTR [r12],0x1f
  c17fcb:	lea    rax,[rip+0xffffffffff6ae2fb]        # 2c62cd <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x190c>
  c17fd2:	mov    QWORD PTR [r12+0x8],rax
  c17fd7:	mov    QWORD PTR [r12+0x10],0x4f
  c17fe0:	jmp    c18338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a18>
  c17fe5:	mov    BYTE PTR [r12],0x1f
  c17fea:	lea    rax,[rip+0xffffffffff6ae2dc]        # 2c62cd <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x190c>
  c17ff1:	mov    QWORD PTR [r12+0x8],rax
  c17ff6:	mov    QWORD PTR [r12+0x10],0x4f
  c17fff:	lea    rdi,[rsp+0x110]
  c18007:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1800c:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18011:	lea    rdi,[rsp+0x500]
  c18019:	jmp    c18a79 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9159>
  c1801e:	lea    rdi,[rsp+0x110]
  c18026:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1802b:	mov    BYTE PTR [r12],0x1f
  c18030:	lea    rax,[rip+0xffffffffff6ae8d5]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c18037:	mov    QWORD PTR [r12+0x8],rax
  c1803c:	mov    eax,0x4f
  c18041:	mov    ecx,0x10
  c18046:	mov    QWORD PTR [r12+rcx*1],rax
  c1804a:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1804f:	jmp    c18a71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9151>
  c18054:	jmp    c18a71 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9151>
  c18059:	lea    rdi,[rsp+0x110]
  c18061:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18066:	mov    BYTE PTR [r12],0x1f
  c1806b:	lea    rax,[rip+0xffffffffff6ae89a]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c18072:	mov    QWORD PTR [r12+0x8],rax
  c18077:	mov    eax,0x4f
  c1807c:	mov    ecx,0x10
  c18081:	mov    QWORD PTR [r12+rcx*1],rax
  c18085:	jmp    c18338 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a18>
  c1808a:	mov    ebp,ecx
  c1808c:	movzx  eax,WORD PTR [rsp+0x116]
  c18094:	mov    WORD PTR [rsp+0xf4],ax
  c1809c:	mov    eax,DWORD PTR [rsp+0x112]
  c180a3:	mov    DWORD PTR [rsp+0xf0],eax
  c180aa:	mov    rbx,QWORD PTR [rsp+0x118]
  c180b2:	mov    r14,QWORD PTR [rsp+0x120]
  c180ba:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c180c3:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c180cc:	mov    rax,QWORD PTR [rsp+0x138]
  c180d4:	mov    QWORD PTR [rsp+0xe0],rax
  c180dc:	mov    r12,QWORD PTR [rsp+0x10]
  c180e1:	mov    r15d,edx
  c180e4:	jmp    c18541 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c21>
  c180e9:	movzx  eax,WORD PTR [rsp+0x116]
  c180f1:	mov    WORD PTR [rsp+0xf4],ax
  c180f9:	mov    eax,DWORD PTR [rsp+0x112]
  c18100:	mov    DWORD PTR [rsp+0xf0],eax
  c18107:	mov    rbx,QWORD PTR [rsp+0x118]
  c1810f:	mov    r14,QWORD PTR [rsp+0x120]
  c18117:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c18120:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c18129:	mov    rax,QWORD PTR [rsp+0x138]
  c18131:	mov    QWORD PTR [rsp+0xe0],rax
  c18139:	mov    r12,QWORD PTR [rsp+0x10]
  c1813e:	mov    r15d,ecx
  c18141:	jmp    c18499 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b79>
  c18146:	mov    ebp,ecx
  c18148:	movzx  eax,WORD PTR [rsp+0x116]
  c18150:	mov    WORD PTR [rsp+0xf4],ax
  c18158:	mov    eax,DWORD PTR [rsp+0x112]
  c1815f:	mov    DWORD PTR [rsp+0xf0],eax
  c18166:	mov    rbx,QWORD PTR [rsp+0x118]
  c1816e:	mov    r15,QWORD PTR [rsp+0x120]
  c18176:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c1817f:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c18188:	mov    rax,QWORD PTR [rsp+0x138]
  c18190:	mov    QWORD PTR [rsp+0xe0],rax
  c18198:	jmp    c183e0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ac0>
  c1819d:	mov    ebp,ecx
  c1819f:	movzx  eax,WORD PTR [rsp+0x116]
  c181a7:	mov    WORD PTR [rsp+0xf4],ax
  c181af:	mov    eax,DWORD PTR [rsp+0x112]
  c181b6:	mov    DWORD PTR [rsp+0xf0],eax
  c181bd:	mov    rbx,QWORD PTR [rsp+0x118]
  c181c5:	mov    r15,QWORD PTR [rsp+0x120]
  c181cd:	movdqu xmm0,XMMWORD PTR [rsp+0x128]
  c181d6:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c181df:	mov    rax,QWORD PTR [rsp+0x138]
  c181e7:	mov    QWORD PTR [rsp+0xe0],rax
  c181ef:	jmp    c1835a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a3a>
  c181f4:	mov    BYTE PTR [r12],0x1f
  c181f9:	lea    rax,[rip+0xffffffffff6adf18]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c18200:	mov    QWORD PTR [r12+0x8],rax
  c18205:	mov    QWORD PTR [r12+0x10],0x4f
  c1820e:	mov    rax,QWORD PTR [rsp+0x1e0]
  c18216:	mov    QWORD PTR [r12+0x18],rax
  c1821b:	jmp    c18679 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d59>
  c18220:	movups xmm0,XMMWORD PTR [rsp+0x111]
  c18228:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c18231:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c18239:	movdqu XMMWORD PTR [rsp+0x8f],xmm1
  c18242:	movaps XMMWORD PTR [rsp+0x80],xmm0
  c1824a:	mov    rcx,QWORD PTR [rsp+0x10]
  c1824f:	movups XMMWORD PTR [rcx+0x20],xmm2
  c18253:	movups xmm0,XMMWORD PTR [rsp+0x8f]
  c1825b:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1825f:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c18268:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c1826d:	mov    BYTE PTR [rcx],al
  c1826f:	jmp    c1860d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ced>
  c18274:	lea    rdi,[rsp+0x110]
  c1827c:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18281:	mov    BYTE PTR [r12],0x1f
  c18286:	lea    rax,[rip+0xffffffffff6ae67f]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1828d:	mov    QWORD PTR [r12+0x8],rax
  c18292:	mov    QWORD PTR [r12+0x10],0x4f
  c1829b:	lea    rdi,[rsp+0x80]
  c182a3:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c182a8:	jmp    c18686 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d66>
  c182ad:	lea    rdi,[rsp+0x110]
  c182b5:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c182ba:	mov    BYTE PTR [r12],0x1f
  c182bf:	lea    rax,[rip+0xffffffffff6ae646]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c182c6:	mov    QWORD PTR [r12+0x8],rax
  c182cb:	mov    QWORD PTR [r12+0x10],0x4f
  c182d4:	lea    rdi,[rsp+0x80]
  c182dc:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c182e1:	jmp    c18686 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8d66>
  c182e6:	mov    BYTE PTR [rcx],0x23
  c182e9:	lea    rax,[rip+0xffffffffff6ae558]        # 2c6848 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x4c5>
  c182f0:	mov    QWORD PTR [rcx+0x8],rax
  c182f4:	mov    QWORD PTR [rcx+0x10],0x3f
  c182fc:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18301:	movdqu xmm0,XMMWORD PTR [rsp+0x112]
  c1830a:	movdqu xmm1,XMMWORD PTR [rsp+0x122]
  c18313:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c1831b:	movups XMMWORD PTR [r12+0x20],xmm2
  c18321:	movdqu XMMWORD PTR [r12+0x12],xmm1
  c18328:	movdqu XMMWORD PTR [r12+0x2],xmm0
  c1832f:	mov    BYTE PTR [r12],cl
  c18333:	mov    BYTE PTR [r12+0x1],al
  c18338:	lea    rdi,[rsp+0x80]
  c18340:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18345:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1834a:	mov    r13b,0x1f
  c1834d:	lea    rbx,[rip+0xffffffffff6ae5b8]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c18354:	mov    r15d,0x4f
  c1835a:	mov    eax,DWORD PTR [rsp+0x80]
  c18361:	mov    edx,eax
  c18363:	sub    edx,0x2
  c18366:	mov    ecx,0x3
  c1836b:	cmovae ecx,edx
  c1836e:	cmp    ecx,0x8
  c18371:	mov    r12,QWORD PTR [rsp+0x10]
  c18376:	ja     c19168 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9848>
  c1837c:	mov    edx,0x1e7
  c18381:	bt     edx,ecx
  c18384:	jae    c18b1e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x91fe>
  c1838a:	mov    eax,DWORD PTR [rsp+0x40]
  c1838e:	mov    edx,eax
  c18390:	sub    edx,0x2
  c18393:	mov    ecx,0x3
  c18398:	cmovae ecx,edx
  c1839b:	cmp    ecx,0x8
  c1839e:	ja     c18d7a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x945a>
  c183a4:	mov    edx,0x1e7
  c183a9:	bt     edx,ecx
  c183ac:	jb     c18438 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b18>
  c183b2:	cmp    ecx,0x3
  c183b5:	jne    c18d20 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9400>
  c183bb:	test   eax,eax
  c183bd:	mov    ecx,ebp
  c183bf:	je     c1843a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1a>
  c183c1:	mov    rax,QWORD PTR [rsp+0x48]
  c183c6:	dec    QWORD PTR [rax]
  c183c9:	jne    c1843a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1a>
  c183cb:	jmp    c18836 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8f16>
  c183d0:	mov    r13b,0x1f
  c183d3:	lea    rbx,[rip+0xffffffffff6ae532]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c183da:	mov    r15d,0x4f
  c183e0:	mov    eax,DWORD PTR [rsp+0x80]
  c183e7:	mov    edx,eax
  c183e9:	sub    edx,0x2
  c183ec:	mov    ecx,0x3
  c183f1:	cmovae ecx,edx
  c183f4:	cmp    ecx,0x8
  c183f7:	mov    r12,QWORD PTR [rsp+0x10]
  c183fc:	ja     c19120 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9800>
  c18402:	mov    edx,0x1e7
  c18407:	bt     edx,ecx
  c1840a:	jae    c18ae9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x91c9>
  c18410:	mov    eax,DWORD PTR [rsp+0x40]
  c18414:	mov    edx,eax
  c18416:	sub    edx,0x2
  c18419:	mov    ecx,0x3
  c1841e:	cmovae ecx,edx
  c18421:	cmp    ecx,0x8
  c18424:	ja     c18cef <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x93cf>
  c1842a:	mov    edx,0x1e7
  c1842f:	bt     edx,ecx
  c18432:	jae    c18815 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ef5>
  c18438:	mov    ecx,ebp
  c1843a:	movzx  eax,WORD PTR [rsp+0xf4]
  c18442:	mov    WORD PTR [r12+0x6],ax
  c18448:	mov    eax,DWORD PTR [rsp+0xf0]
  c1844f:	mov    DWORD PTR [r12+0x2],eax
  c18454:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1845d:	movdqu XMMWORD PTR [r12+0x18],xmm0
  c18464:	mov    rax,QWORD PTR [rsp+0xe0]
  c1846c:	mov    QWORD PTR [r12+0x28],rax
  c18471:	mov    BYTE PTR [r12],r13b
  c18475:	mov    BYTE PTR [r12+0x1],cl
  c1847a:	mov    QWORD PTR [r12+0x8],rbx
  c1847f:	mov    QWORD PTR [r12+0x10],r15
  c18484:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18489:	mov    r15b,0x1f
  c1848c:	lea    rbx,[rip+0xffffffffff6ae479]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c18493:	mov    r14d,0x4f
  c18499:	mov    eax,DWORD PTR [rsp+0x80]
  c184a0:	mov    edx,eax
  c184a2:	sub    edx,0x2
  c184a5:	mov    ecx,0x3
  c184aa:	cmovae ecx,edx
  c184ad:	cmp    ecx,0x8
  c184b0:	ja     c1918c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x986c>
  c184b6:	mov    edx,0x1e7
  c184bb:	bt     edx,ecx
  c184be:	jae    c18b53 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9233>
  c184c4:	mov    eax,DWORD PTR [rsp+0x40]
  c184c8:	mov    edx,eax
  c184ca:	sub    edx,0x2
  c184cd:	mov    ecx,0x3
  c184d2:	cmovae ecx,edx
  c184d5:	cmp    ecx,0x8
  c184d8:	ja     c18d98 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9478>
  c184de:	mov    edx,0x1e7
  c184e3:	bt     edx,ecx
  c184e6:	jae    c18877 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8f57>
  c184ec:	movzx  eax,WORD PTR [rsp+0xf4]
  c184f4:	mov    WORD PTR [r12+0x6],ax
  c184fa:	mov    eax,DWORD PTR [rsp+0xf0]
  c18501:	mov    DWORD PTR [r12+0x2],eax
  c18506:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1850f:	movdqu XMMWORD PTR [r12+0x18],xmm0
  c18516:	mov    rax,QWORD PTR [rsp+0xe0]
  c1851e:	mov    QWORD PTR [r12+0x28],rax
  c18523:	mov    BYTE PTR [r12],r15b
  c18527:	mov    BYTE PTR [r12+0x1],bpl
  c1852c:	jmp    c185d6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8cb6>
  c18531:	mov    r15b,0x1f
  c18534:	lea    rbx,[rip+0xffffffffff6ae3d1]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1853b:	mov    r14d,0x4f
  c18541:	mov    eax,DWORD PTR [rsp+0x80]
  c18548:	mov    edx,eax
  c1854a:	sub    edx,0x2
  c1854d:	mov    ecx,0x3
  c18552:	cmovae ecx,edx
  c18555:	cmp    ecx,0x8
  c18558:	ja     c191b0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9890>
  c1855e:	mov    edx,0x1e7
  c18563:	bt     edx,ecx
  c18566:	jae    c18b88 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9268>
  c1856c:	mov    eax,DWORD PTR [rsp+0x40]
  c18570:	mov    edx,eax
  c18572:	sub    edx,0x2
  c18575:	mov    ecx,0x3
  c1857a:	cmovae ecx,edx
  c1857d:	cmp    ecx,0x8
  c18580:	ja     c18d5c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x943c>
  c18586:	mov    edx,0x1e7
  c1858b:	bt     edx,ecx
  c1858e:	jae    c18846 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8f26>
  c18594:	mov    ecx,ebp
  c18596:	movzx  eax,WORD PTR [rsp+0xf4]
  c1859e:	mov    WORD PTR [r12+0x6],ax
  c185a4:	mov    eax,DWORD PTR [rsp+0xf0]
  c185ab:	mov    DWORD PTR [r12+0x2],eax
  c185b0:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c185b9:	movdqu XMMWORD PTR [r12+0x18],xmm0
  c185c0:	mov    rax,QWORD PTR [rsp+0xe0]
  c185c8:	mov    QWORD PTR [r12+0x28],rax
  c185cd:	mov    BYTE PTR [r12],r15b
  c185d1:	mov    BYTE PTR [r12+0x1],cl
  c185d6:	mov    QWORD PTR [r12+0x8],rbx
  c185db:	mov    QWORD PTR [r12+0x10],r14
  c185e0:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c185e5:	lea    rdi,[rsp+0x110]
  c185ed:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c185f2:	mov    rcx,QWORD PTR [rsp+0x10]
  c185f7:	mov    BYTE PTR [rcx],0x1f
  c185fa:	lea    rax,[rip+0xffffffffff6ae30b]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c18601:	mov    QWORD PTR [rcx+0x8],rax
  c18605:	mov    QWORD PTR [rcx+0x10],0x4f
  c1860d:	lea    rdi,[rsp+0xd0]
  c18615:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1861a:	jmp    c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c1861f:	lea    rdi,[rsp+0x110]
  c18627:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1862c:	mov    rcx,QWORD PTR [rsp+0x10]
  c18631:	mov    BYTE PTR [rcx],0x1f
  c18634:	lea    rax,[rip+0xffffffffff6ae2d1]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1863b:	mov    QWORD PTR [rcx+0x8],rax
  c1863f:	mov    QWORD PTR [rcx+0x10],0x4f
  c18647:	jmp    c19063 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9743>
  c1864c:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c18655:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c1865e:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c18666:	movups XMMWORD PTR [r12+0x20],xmm2
  c1866c:	movdqu XMMWORD PTR [r12+0x10],xmm1
  c18673:	movdqu XMMWORD PTR [r12],xmm0
  c18679:	lea    rdi,[rsp+0x80]
  c18681:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18686:	lea    rdi,[rsp+0x40]
  c1868b:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18690:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18695:	lea    rdi,[rsp+0x110]
  c1869d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c186a2:	mov    rcx,QWORD PTR [rsp+0x10]
  c186a7:	mov    BYTE PTR [rcx],0x1f
  c186aa:	lea    rax,[rip+0xffffffffff6ae25b]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c186b1:	mov    QWORD PTR [rcx+0x8],rax
  c186b5:	mov    QWORD PTR [rcx+0x10],0x4f
  c186bd:	jmp    c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c186c2:	mov    rcx,QWORD PTR [rsp+0x10]
  c186c7:	mov    BYTE PTR [rcx],0x1f
  c186ca:	lea    rax,[rip+0xffffffffff6ae133]        # 2c6804 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x481>
  c186d1:	mov    QWORD PTR [rcx+0x8],rax
  c186d5:	mov    r8d,0x44
  c186db:	mov    eax,0x10
  c186e0:	mov    QWORD PTR [rcx+rax*1],r8
  c186e4:	mov    rax,QWORD PTR [rsp+0x80]
  c186ec:	test   rax,rax
  c186ef:	je     c1870c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8dec>
  c186f1:	mov    rdi,QWORD PTR [rsp+0x88]
  c186f9:	shl    rax,0x3
  c186fd:	lea    rsi,[rax+rax*2]
  c18701:	mov    edx,0x8
  c18706:	call   QWORD PTR [rip+0x2352f4]        # e4da00 <_DYNAMIC+0x240>
  c1870c:	mov    rsi,QWORD PTR [rsp+0x40]
  c18711:	test   rsi,rsi
  c18714:	je     c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1871a:	mov    rdi,QWORD PTR [rsp+0x48]
  c1871f:	shl    rsi,0x4
  c18723:	mov    edx,0x8
  c18728:	call   QWORD PTR [rip+0x2352d2]        # e4da00 <_DYNAMIC+0x240>
  c1872e:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18733:	lea    rax,[rip+0xffffffffff6adad3]        # 2c620d <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x184c>
  c1873a:	mov    ecx,0x41
  c1873f:	jmp    c1874d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8e2d>
  c18741:	lea    rax,[rip+0xffffffffff6adb06]        # 2c624e <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x188d>
  c18748:	mov    ecx,0x45
  c1874d:	mov    rdx,QWORD PTR [rsp+0x10]
  c18752:	mov    BYTE PTR [rdx],0x1f
  c18755:	mov    QWORD PTR [rdx+0x8],rax
  c18759:	mov    QWORD PTR [rdx+0x10],rcx
  c1875d:	jmp    c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c18762:	mov    BYTE PTR [r12],0x1f
  c18767:	lea    rax,[rip+0xffffffffff6ada48]        # 2c61b6 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x17f5>
  c1876e:	mov    QWORD PTR [r12+0x8],rax
  c18773:	mov    QWORD PTR [r12+0x10],0x57
  c1877c:	jmp    c187f6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ed6>
  c1877e:	movups xmm0,XMMWORD PTR [rsp+0x111]
  c18786:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c1878f:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c18797:	movdqu XMMWORD PTR [rsp+0x4f],xmm1
  c1879d:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c187a2:	mov    rcx,QWORD PTR [rsp+0x10]
  c187a7:	movups XMMWORD PTR [rcx+0x20],xmm2
  c187ab:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c187b0:	movups XMMWORD PTR [rcx+0x10],xmm0
  c187b4:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c187ba:	jmp    c1905c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x973c>
  c187bf:	lea    rax,[rip+0xffffffffff6ada47]        # 2c620d <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x184c>
  c187c6:	mov    ecx,0x41
  c187cb:	jmp    c187d9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8eb9>
  c187cd:	lea    rax,[rip+0xffffffffff6ada7a]        # 2c624e <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x188d>
  c187d4:	mov    ecx,0x45
  c187d9:	mov    rdx,QWORD PTR [rsp+0x10]
  c187de:	mov    BYTE PTR [rdx],0x1f
  c187e1:	mov    QWORD PTR [rdx+0x8],rax
  c187e5:	mov    QWORD PTR [rdx+0x10],rcx
  c187e9:	lea    rdi,[rsp+0x110]
  c187f1:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c187f6:	lea    rdi,[rsp+0xd0]
  c187fe:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18803:	lea    rdi,[rsp+0xf0]
  c1880b:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18810:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18815:	cmp    ecx,0x3
  c18818:	jne    c18cdf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x93bf>
  c1881e:	test   eax,eax
  c18820:	mov    ecx,ebp
  c18822:	je     c1843a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1a>
  c18828:	mov    rax,QWORD PTR [rsp+0x48]
  c1882d:	dec    QWORD PTR [rax]
  c18830:	jne    c1843a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b1a>
  c18836:	lea    rdi,[rsp+0x48]
  c1883b:	call   QWORD PTR [rip+0x2351c7]        # e4da08 <_DYNAMIC+0x248>
  c18841:	jmp    c18438 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b18>
  c18846:	cmp    ecx,0x3
  c18849:	mov    ecx,ebp
  c1884b:	jne    c18d02 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x93e2>
  c18851:	test   eax,eax
  c18853:	je     c18596 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c76>
  c18859:	mov    rax,QWORD PTR [rsp+0x48]
  c1885e:	dec    QWORD PTR [rax]
  c18861:	jne    c18596 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c76>
  c18867:	lea    rdi,[rsp+0x48]
  c1886c:	call   QWORD PTR [rip+0x235196]        # e4da08 <_DYNAMIC+0x248>
  c18872:	jmp    c18594 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c74>
  c18877:	cmp    ecx,0x3
  c1887a:	jne    c18d3e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x941e>
  c18880:	test   eax,eax
  c18882:	je     c184ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bcc>
  c18888:	mov    rax,QWORD PTR [rsp+0x48]
  c1888d:	dec    QWORD PTR [rax]
  c18890:	jne    c184ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bcc>
  c18896:	lea    rdi,[rsp+0x48]
  c1889b:	call   QWORD PTR [rip+0x235167]        # e4da08 <_DYNAMIC+0x248>
  c188a1:	jmp    c184ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bcc>
  c188a6:	mov    DWORD PTR [rsp+0x5c8],0x2
  c188b1:	mov    rbx,QWORD PTR [rsp+0x10]
  c188b6:	mov    r14,QWORD PTR [rsp+0x28]
  c188bb:	jmp    c18dff <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x94df>
  c188c0:	add    rcx,QWORD PTR [rsi+0x60]
  c188c4:	cmp    rcx,rax
  c188c7:	jae    c189e4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x90c4>
  c188cd:	mov    rax,QWORD PTR [r8+0x8]
  c188d1:	lea    rcx,[rcx+rcx*2]
  c188d5:	lea    rsi,[rax+rcx*8]
  c188d9:	lea    rdi,[rsp+0x110]
  c188e1:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c188e6:	mov    rax,QWORD PTR [rsp+0x110]
  c188ee:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c188f7:	mov    QWORD PTR [rsp+0xf0],rax
  c188ff:	movdqu XMMWORD PTR [rsp+0xf8],xmm0
  c18908:	lea    rdi,[rsp+0x110]
  c18910:	lea    rsi,[rsp+0xf0]
  c18918:	call   QWORD PTR [rip+0x23a70a]        # e53028 <_DYNAMIC+0x5868>
  c1891e:	cmp    DWORD PTR [rsp+0x110],0x1
  c18926:	jne    c18f0a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x95ea>
  c1892c:	mov    rax,QWORD PTR [rsp+0x118]
  c18934:	mov    rdx,QWORD PTR [rsp+0x660]
  c1893c:	cmp    rax,QWORD PTR [rdx+0xa8]
  c18943:	jne    c191d4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x98b4>
  c18949:	mov    rcx,QWORD PTR [rsp+0x120]
  c18951:	lea    rax,[rip+0xffffffffff6adf2f]        # 2c6887 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x504>
  c18958:	cmp    rcx,QWORD PTR [rdx+0x88]
  c1895f:	jae    c1968d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d6d>
  c18965:	lea    rbx,[rcx+rcx*2]
  c18969:	shl    rbx,0x4
  c1896d:	add    rbx,QWORD PTR [rdx+0x80]
  c18974:	mov    QWORD PTR [rsp+0x118],rax
  c1897c:	mov    QWORD PTR [rsp+0x120],0x40
  c18988:	mov    BYTE PTR [rsp+0x110],0x1f
  c18990:	lea    rdi,[rsp+0x110]
  c18998:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1899d:	movzx  eax,BYTE PTR [rbx]
  c189a0:	cmp    al,0xfe
  c189a2:	jne    c196d8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9db8>
  c189a8:	add    rbx,0x8
  c189ac:	lea    rsi,[rsp+0x668]
  c189b4:	mov    rdi,rbx
  c189b7:	call   c3bb00 <_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequejE8containsCsbxgXiyEKxkX_6bsl_vm>
  c189bc:	test   al,al
  c189be:	jne    c189d0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x90b0>
  c189c0:	mov    rdi,rbx
  c189c3:	mov    rsi,QWORD PTR [rsp+0x4f0]
  c189cb:	call   c3b4c0 <_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequejE13push_back_mutCsbxgXiyEKxkX_6bsl_vm>
  c189d0:	mov    rax,QWORD PTR [rsp+0x10]
  c189d5:	mov    DWORD PTR [rax+0x8],0xf
  c189dc:	mov    BYTE PTR [rax],0xff
  c189df:	jmp    c19945 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa025>
  c189e4:	mov    rcx,QWORD PTR [rsp+0x10]
  c189e9:	mov    BYTE PTR [rcx],0x1f
  c189ec:	lea    rax,[rip+0xffffffffff6ad725]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c189f3:	mov    QWORD PTR [rcx+0x8],rax
  c189f7:	mov    QWORD PTR [rcx+0x10],0x4f
  c189ff:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18a04:	mov    BYTE PTR [r12],0x1f
  c18a09:	lea    rax,[rip+0xffffffffff6adce9]        # 2c66f9 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x376>
  c18a10:	mov    QWORD PTR [r12+0x8],rax
  c18a15:	mov    QWORD PTR [r12+0x10],0x5e
  c18a1e:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18a23:	mov    ecx,DWORD PTR [rsp+0x111]
  c18a2a:	mov    edx,DWORD PTR [rsp+0x114]
  c18a31:	mov    DWORD PTR [r12+0x4],edx
  c18a36:	mov    DWORD PTR [r12+0x1],ecx
  c18a3b:	mov    rcx,QWORD PTR [rsp+0x138]
  c18a43:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c18a4c:	movdqu xmm1,XMMWORD PTR [rsp+0x128]
  c18a55:	mov    BYTE PTR [r12],al
  c18a59:	movdqu XMMWORD PTR [r12+0x8],xmm0
  c18a60:	movdqu XMMWORD PTR [r12+0x18],xmm1
  c18a67:	mov    QWORD PTR [r12+0x28],rcx
  c18a6c:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18a71:	lea    rdi,[rsp+0x110]
  c18a79:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c18a7e:	mov    BYTE PTR [r12],0x1f
  c18a83:	lea    rax,[rip+0xffffffffff6ade82]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c18a8a:	mov    QWORD PTR [r12+0x8],rax
  c18a8f:	mov    QWORD PTR [r12+0x10],0x4f
  c18a98:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c18a9d:	lea    rdi,[rsp+0xd0]
  c18aa5:	mov    rsi,QWORD PTR [rsp+0x1d8]
  c18aad:	call   c0daa0 <_RNvCsbxgXiyEKxkX_6bsl_vm18push_own_registers>
  c18ab2:	mov    rbx,QWORD PTR [rsp+0x10]
  c18ab7:	mov    r12,QWORD PTR [rsp+0x8]
  c18abc:	mov    rsi,QWORD PTR [rsp+0x660]
  c18ac4:	mov    rax,QWORD PTR [rsp+0x1d8]
  c18acc:	cmp    BYTE PTR [rax+0xc0],0x0
  c18ad3:	je     c18f9b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x967b>
  c18ad9:	mov    eax,0x2
  c18ade:	mov    r14d,0x2
  c18ae4:	jmp    c19411 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9af1>
  c18ae9:	cmp    ecx,0x3
  c18aec:	jne    c190b4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9794>
  c18af2:	test   eax,eax
  c18af4:	je     c18410 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af0>
  c18afa:	mov    rax,QWORD PTR [rsp+0x88]
  c18b02:	dec    QWORD PTR [rax]
  c18b05:	jne    c18410 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af0>
  c18b0b:	lea    rdi,[rsp+0x88]
  c18b13:	call   QWORD PTR [rip+0x234eef]        # e4da08 <_DYNAMIC+0x248>
  c18b19:	jmp    c18410 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af0>
  c18b1e:	cmp    ecx,0x3
  c18b21:	jne    c190d8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x97b8>
  c18b27:	test   eax,eax
  c18b29:	je     c1838a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a6a>
  c18b2f:	mov    rax,QWORD PTR [rsp+0x88]
  c18b37:	dec    QWORD PTR [rax]
  c18b3a:	jne    c1838a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a6a>
  c18b40:	lea    rdi,[rsp+0x88]
  c18b48:	call   QWORD PTR [rip+0x234eba]        # e4da08 <_DYNAMIC+0x248>
  c18b4e:	jmp    c1838a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a6a>
  c18b53:	cmp    ecx,0x3
  c18b56:	jne    c190fc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x97dc>
  c18b5c:	test   eax,eax
  c18b5e:	je     c184c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ba4>
  c18b64:	mov    rax,QWORD PTR [rsp+0x88]
  c18b6c:	dec    QWORD PTR [rax]
  c18b6f:	jne    c184c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ba4>
  c18b75:	lea    rdi,[rsp+0x88]
  c18b7d:	call   QWORD PTR [rip+0x234e85]        # e4da08 <_DYNAMIC+0x248>
  c18b83:	jmp    c184c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ba4>
  c18b88:	cmp    ecx,0x3
  c18b8b:	jne    c19144 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9824>
  c18b91:	test   eax,eax
  c18b93:	je     c1856c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c4c>
  c18b99:	mov    rax,QWORD PTR [rsp+0x88]
  c18ba1:	dec    QWORD PTR [rax]
  c18ba4:	jne    c1856c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c4c>
  c18baa:	lea    rdi,[rsp+0x88]
  c18bb2:	call   QWORD PTR [rip+0x234e50]        # e4da08 <_DYNAMIC+0x248>
  c18bb8:	jmp    c1856c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c4c>
  c18bbd:	lea    rdx,[rsp+0x84]
  c18bc5:	movups xmm0,XMMWORD PTR [rdx+0x1c]
  c18bc9:	mov    rcx,QWORD PTR [rsp+0x10]
  c18bce:	movups XMMWORD PTR [rcx+0x20],xmm0
  c18bd2:	movdqu xmm0,XMMWORD PTR [rdx-0x3]
  c18bd7:	movdqu xmm1,XMMWORD PTR [rdx+0xc]
  c18bdc:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c18be1:	movdqu XMMWORD PTR [rcx+0x10],xmm1
  c18be6:	mov    BYTE PTR [rcx],al
  c18be8:	jmp    c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c18bed:	mov    rcx,QWORD PTR [rsp+0x10]
  c18bf2:	mov    BYTE PTR [rcx],0x1f
  c18bf5:	lea    rax,[rip+0xffffffffff6ad5ba]        # 2c61b6 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x17f5>
  c18bfc:	mov    QWORD PTR [rcx+0x8],rax
  c18c00:	mov    QWORD PTR [rcx+0x10],0x57
  c18c08:	jmp    c18c4d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x932d>
  c18c0a:	movups xmm0,XMMWORD PTR [rsp+0x111]
  c18c12:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c18c1b:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c18c23:	movdqu XMMWORD PTR [rsp+0x4f],xmm1
  c18c29:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c18c2e:	mov    rcx,QWORD PTR [rsp+0x10]
  c18c33:	movups XMMWORD PTR [rcx+0x20],xmm2
  c18c37:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c18c3c:	movups XMMWORD PTR [rcx+0x10],xmm0
  c18c40:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c18c46:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c18c4b:	mov    BYTE PTR [rcx],al
  c18c4d:	lea    rdi,[rsp+0x80]
  c18c55:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c18c5a:	jmp    c18f96 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9676>
  c18c5f:	lea    rcx,[rsp+0x84]
  c18c67:	movdqu xmm0,XMMWORD PTR [rcx-0x3]
  c18c6c:	movdqu xmm1,XMMWORD PTR [rcx+0xd]
  c18c71:	movups xmm2,XMMWORD PTR [rcx+0x1c]
  c18c75:	movups XMMWORD PTR [r12+0x20],xmm2
  c18c7b:	movdqu XMMWORD PTR [r12+0x11],xmm1
  c18c82:	movdqu XMMWORD PTR [r12+0x1],xmm0
  c18c89:	mov    BYTE PTR [r12],al
  c18c8d:	jmp    c187f6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ed6>
  c18c92:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c18c9b:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c18ca4:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c18cac:	movups XMMWORD PTR [r12+0x20],xmm2
  c18cb2:	movdqu XMMWORD PTR [r12+0x10],xmm1
  c18cb9:	movdqu XMMWORD PTR [r12],xmm0
  c18cbf:	cmp    BYTE PTR [rsp+0x80],0xff
  c18cc7:	je     c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c18ccd:	lea    rdi,[rsp+0x80]
  c18cd5:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c18cda:	jmp    c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c18cdf:	mov    rax,QWORD PTR [rsp+0x48]
  c18ce4:	dec    QWORD PTR [rax]
  c18ce7:	jne    c18438 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b18>
  c18ced:	jmp    c18d2e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x940e>
  c18cef:	mov    rax,QWORD PTR [rsp+0x48]
  c18cf4:	dec    QWORD PTR [rax]
  c18cf7:	jne    c18438 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b18>
  c18cfd:	jmp    c18d88 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9468>
  c18d02:	mov    rax,QWORD PTR [rsp+0x48]
  c18d07:	dec    QWORD PTR [rax]
  c18d0a:	jne    c18596 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c76>
  c18d10:	lea    rdi,[rsp+0x48]
  c18d15:	call   QWORD PTR [rip+0x234cf5]        # e4da10 <_DYNAMIC+0x250>
  c18d1b:	jmp    c18594 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c74>
  c18d20:	mov    rax,QWORD PTR [rsp+0x48]
  c18d25:	dec    QWORD PTR [rax]
  c18d28:	jne    c18438 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b18>
  c18d2e:	lea    rdi,[rsp+0x48]
  c18d33:	call   QWORD PTR [rip+0x234cd7]        # e4da10 <_DYNAMIC+0x250>
  c18d39:	jmp    c18438 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b18>
  c18d3e:	mov    rax,QWORD PTR [rsp+0x48]
  c18d43:	dec    QWORD PTR [rax]
  c18d46:	jne    c184ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bcc>
  c18d4c:	lea    rdi,[rsp+0x48]
  c18d51:	call   QWORD PTR [rip+0x234cb9]        # e4da10 <_DYNAMIC+0x250>
  c18d57:	jmp    c184ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bcc>
  c18d5c:	mov    rax,QWORD PTR [rsp+0x48]
  c18d61:	dec    QWORD PTR [rax]
  c18d64:	jne    c18594 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c74>
  c18d6a:	lea    rdi,[rsp+0x48]
  c18d6f:	call   QWORD PTR [rip+0x234ca3]        # e4da18 <_DYNAMIC+0x258>
  c18d75:	jmp    c18594 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c74>
  c18d7a:	mov    rax,QWORD PTR [rsp+0x48]
  c18d7f:	dec    QWORD PTR [rax]
  c18d82:	jne    c18438 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b18>
  c18d88:	lea    rdi,[rsp+0x48]
  c18d8d:	call   QWORD PTR [rip+0x234c85]        # e4da18 <_DYNAMIC+0x258>
  c18d93:	jmp    c18438 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8b18>
  c18d98:	mov    rax,QWORD PTR [rsp+0x48]
  c18d9d:	dec    QWORD PTR [rax]
  c18da0:	jne    c184ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bcc>
  c18da6:	lea    rdi,[rsp+0x48]
  c18dab:	call   QWORD PTR [rip+0x234c67]        # e4da18 <_DYNAMIC+0x258>
  c18db1:	jmp    c184ec <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8bcc>
  c18db6:	add    rax,QWORD PTR [rdx+0x60]
  c18dba:	cmp    rax,QWORD PTR [r14+0x10]
  c18dbe:	jae    c18efb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x95db>
  c18dc4:	lea    rsi,[rax+rax*2]
  c18dc8:	shl    rsi,0x3
  c18dcc:	add    rsi,QWORD PTR [r14+0x8]
  c18dd0:	lea    rdi,[rsp+0x110]
  c18dd8:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c18ddd:	mov    rax,QWORD PTR [rsp+0x110]
  c18de5:	movdqu xmm0,XMMWORD PTR [rsp+0x118]
  c18dee:	mov    QWORD PTR [rsp+0x5c8],rax
  c18df6:	movdqu XMMWORD PTR [rsp+0x5d0],xmm0
  c18dff:	mov    rax,QWORD PTR [rsp+0x630]
  c18e07:	mov    r9,QWORD PTR [rax+0x10]
  c18e0b:	sub    rsp,0x8
  c18e0f:	lea    rax,[rsp+0x5d0]
  c18e17:	lea    rdi,[rsp+0x118]
  c18e1f:	mov    rsi,QWORD PTR [rsp+0x20]
  c18e24:	mov    rdx,r14
  c18e27:	mov    rcx,QWORD PTR [rsp+0x1d0]
  c18e2f:	mov    r8,QWORD PTR [rsp+0x500]
  c18e37:	push   rax
  c18e38:	call   c0dae0 <_RNvCsbxgXiyEKxkX_6bsl_vm20do_return_with_value>
  c18e3d:	add    rsp,0x10
  c18e41:	movzx  eax,BYTE PTR [rsp+0x110]
  c18e49:	cmp    al,0xff
  c18e4b:	je     c18eaa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x958a>
  c18e4d:	mov    ecx,DWORD PTR [rsp+0x111]
  c18e54:	mov    edx,DWORD PTR [rsp+0x114]
  c18e5b:	mov    DWORD PTR [rbx+0x4],edx
  c18e5e:	mov    DWORD PTR [rbx+0x1],ecx
  c18e61:	mov    ecx,DWORD PTR [rsp+0x118]
  c18e68:	movups xmm0,XMMWORD PTR [rsp+0x11c]
  c18e70:	movaps XMMWORD PTR [rsp+0x3e0],xmm0
  c18e78:	mov    edx,DWORD PTR [rsp+0x12c]
  c18e7f:	mov    DWORD PTR [rsp+0x3f0],edx
  c18e86:	movups xmm0,XMMWORD PTR [rsp+0x130]
  c18e8e:	movups XMMWORD PTR [rbx+0x20],xmm0
  c18e92:	mov    edx,DWORD PTR [rsp+0x3f0]
  c18e99:	mov    DWORD PTR [rbx+0x1c],edx
  c18e9c:	movdqa xmm0,XMMWORD PTR [rsp+0x3e0]
  c18ea5:	jmp    c0faad <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x18d>
  c18eaa:	mov    eax,DWORD PTR [rsp+0x118]
  c18eb1:	movups xmm0,XMMWORD PTR [rsp+0x11c]
  c18eb9:	movaps XMMWORD PTR [rsp+0x3e0],xmm0
  c18ec1:	mov    ecx,DWORD PTR [rsp+0x12c]
  c18ec8:	mov    DWORD PTR [rsp+0x3f0],ecx
  c18ecf:	cmp    eax,0xffffffff
  c18ed2:	je     c193ba <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9a9a>
  c18ed8:	mov    ecx,DWORD PTR [rsp+0x3f0]
  c18edf:	mov    DWORD PTR [rsp+0x90],ecx
  c18ee6:	movaps xmm0,XMMWORD PTR [rsp+0x3e0]
  c18eee:	movaps XMMWORD PTR [rsp+0x80],xmm0
  c18ef6:	jmp    c193bf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9a9f>
  c18efb:	mov    BYTE PTR [rbx],0x1f
  c18efe:	lea    rax,[rip+0xffffffffff6ad213]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c18f05:	jmp    c1931c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x99fc>
  c18f0a:	mov    rax,QWORD PTR [rsp+0x1b0]
  c18f12:	mov    rsi,QWORD PTR [rax]
  c18f15:	cmp    QWORD PTR [rsp+0x8],rsi
  c18f1a:	mov    rdi,QWORD PTR [rsp+0x20]
  c18f1f:	mov    r14,QWORD PTR [rsp+0x1b8]
  c18f27:	jae    c1a102 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa7e2>
  c18f2d:	mov    rdx,QWORD PTR [r14]
  c18f30:	lea    rcx,[rdx+rdi*1]
  c18f34:	mov    rax,r12
  c18f37:	sub    rax,QWORD PTR [rdx+rdi*1+0x30]
  c18f3c:	jae    c1924f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x992f>
  c18f42:	mov    rax,QWORD PTR [rcx+0x28]
  c18f46:	shl    r12d,0x4
  c18f4a:	mov    rax,QWORD PTR [rax+r12*1]
  c18f4e:	jmp    c19253 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9933>
  c18f53:	movups xmm0,XMMWORD PTR [rsp+0x81]
  c18f5b:	movdqu xmm1,XMMWORD PTR [rsp+0x90]
  c18f64:	movups xmm2,XMMWORD PTR [rsp+0xa0]
  c18f6c:	movdqu XMMWORD PTR [rsp+0x4f],xmm1
  c18f72:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c18f77:	mov    rcx,QWORD PTR [rsp+0x10]
  c18f7c:	movups XMMWORD PTR [rcx+0x20],xmm2
  c18f80:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c18f85:	movups XMMWORD PTR [rcx+0x10],xmm0
  c18f89:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c18f8f:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c18f94:	mov    BYTE PTR [rcx],al
  c18f96:	jmp    c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c18f9b:	lea    rdi,[rsp+0x110]
  c18fa3:	call   c49460 <_RNvMs0_NtCsbxgXiyEKxkX_6bsl_vm9schedulerNtB5_10AsyncState11new_promise>
  c18fa8:	movzx  eax,BYTE PTR [rsp+0x110]
  c18fb0:	cmp    al,0xff
  c18fb2:	je     c193dc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9abc>
  c18fb8:	mov    ecx,DWORD PTR [rsp+0x111]
  c18fbf:	mov    edx,DWORD PTR [rsp+0x114]
  c18fc6:	mov    DWORD PTR [rbx+0x4],edx
  c18fc9:	mov    DWORD PTR [rbx+0x1],ecx
  c18fcc:	mov    rcx,QWORD PTR [rsp+0x118]
  c18fd4:	mov    edx,DWORD PTR [rsp+0x120]
  c18fdb:	movdqu xmm0,XMMWORD PTR [rsp+0x124]
  c18fe4:	movdqa XMMWORD PTR [rsp+0x80],xmm0
  c18fed:	mov    esi,DWORD PTR [rsp+0x134]
  c18ff4:	mov    DWORD PTR [rsp+0x90],esi
  c18ffb:	mov    rdi,QWORD PTR [rsp+0x138]
  c19003:	mov    DWORD PTR [rbx+0x24],esi
  c19006:	movdqu XMMWORD PTR [rbx+0x14],xmm0
  c1900b:	mov    BYTE PTR [rbx],al
  c1900d:	mov    QWORD PTR [rbx+0x8],rcx
  c19011:	mov    DWORD PTR [rbx+0x10],edx
  c19014:	mov    QWORD PTR [rbx+0x28],rdi
  c19018:	jmp    c1965d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d3d>
  c1901d:	movups xmm0,XMMWORD PTR [rsp+0x41]
  c19022:	movdqu xmm1,XMMWORD PTR [rsp+0x50]
  c19028:	movups xmm2,XMMWORD PTR [rsp+0x60]
  c1902d:	movdqu XMMWORD PTR [rsp+0xdf],xmm1
  c19036:	movaps XMMWORD PTR [rsp+0xd0],xmm0
  c1903e:	mov    rcx,QWORD PTR [rsp+0x10]
  c19043:	movups XMMWORD PTR [rcx+0x20],xmm2
  c19047:	movups xmm0,XMMWORD PTR [rsp+0xdf]
  c1904f:	movups XMMWORD PTR [rcx+0x10],xmm0
  c19053:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1905c:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c19061:	mov    BYTE PTR [rcx],al
  c19063:	lea    rdi,[rsp+0x80]
  c1906b:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c19070:	lea    rdi,[rsp+0x358]
  c19078:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1907d:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c19082:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c1908b:	movdqu xmm1,XMMWORD PTR [rsp+0x90]
  c19094:	movups xmm2,XMMWORD PTR [rsp+0xa0]
  c1909c:	movups XMMWORD PTR [r12+0x20],xmm2
  c190a2:	movdqu XMMWORD PTR [r12+0x10],xmm1
  c190a9:	movdqu XMMWORD PTR [r12],xmm0
  c190af:	jmp    c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c190b4:	mov    rax,QWORD PTR [rsp+0x88]
  c190bc:	dec    QWORD PTR [rax]
  c190bf:	jne    c18410 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af0>
  c190c5:	lea    rdi,[rsp+0x88]
  c190cd:	call   QWORD PTR [rip+0x23493d]        # e4da10 <_DYNAMIC+0x250>
  c190d3:	jmp    c18410 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af0>
  c190d8:	mov    rax,QWORD PTR [rsp+0x88]
  c190e0:	dec    QWORD PTR [rax]
  c190e3:	jne    c1838a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a6a>
  c190e9:	lea    rdi,[rsp+0x88]
  c190f1:	call   QWORD PTR [rip+0x234919]        # e4da10 <_DYNAMIC+0x250>
  c190f7:	jmp    c1838a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a6a>
  c190fc:	mov    rax,QWORD PTR [rsp+0x88]
  c19104:	dec    QWORD PTR [rax]
  c19107:	jne    c184c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ba4>
  c1910d:	lea    rdi,[rsp+0x88]
  c19115:	call   QWORD PTR [rip+0x2348f5]        # e4da10 <_DYNAMIC+0x250>
  c1911b:	jmp    c184c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ba4>
  c19120:	mov    rax,QWORD PTR [rsp+0x88]
  c19128:	dec    QWORD PTR [rax]
  c1912b:	jne    c18410 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af0>
  c19131:	lea    rdi,[rsp+0x88]
  c19139:	call   QWORD PTR [rip+0x2348d9]        # e4da18 <_DYNAMIC+0x258>
  c1913f:	jmp    c18410 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8af0>
  c19144:	mov    rax,QWORD PTR [rsp+0x88]
  c1914c:	dec    QWORD PTR [rax]
  c1914f:	jne    c1856c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c4c>
  c19155:	lea    rdi,[rsp+0x88]
  c1915d:	call   QWORD PTR [rip+0x2348ad]        # e4da10 <_DYNAMIC+0x250>
  c19163:	jmp    c1856c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c4c>
  c19168:	mov    rax,QWORD PTR [rsp+0x88]
  c19170:	dec    QWORD PTR [rax]
  c19173:	jne    c1838a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a6a>
  c19179:	lea    rdi,[rsp+0x88]
  c19181:	call   QWORD PTR [rip+0x234891]        # e4da18 <_DYNAMIC+0x258>
  c19187:	jmp    c1838a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8a6a>
  c1918c:	mov    rax,QWORD PTR [rsp+0x88]
  c19194:	dec    QWORD PTR [rax]
  c19197:	jne    c184c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ba4>
  c1919d:	lea    rdi,[rsp+0x88]
  c191a5:	call   QWORD PTR [rip+0x23486d]        # e4da18 <_DYNAMIC+0x258>
  c191ab:	jmp    c184c4 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ba4>
  c191b0:	mov    rax,QWORD PTR [rsp+0x88]
  c191b8:	dec    QWORD PTR [rax]
  c191bb:	jne    c1856c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c4c>
  c191c1:	lea    rdi,[rsp+0x88]
  c191c9:	call   QWORD PTR [rip+0x234849]        # e4da18 <_DYNAMIC+0x258>
  c191cf:	jmp    c1856c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8c4c>
  c191d4:	call   QWORD PTR [rip+0x2348e6]        # e4dac0 <_DYNAMIC+0x300>
  c191da:	mov    edi,0x45
  c191df:	mov    esi,0x1
  c191e4:	call   QWORD PTR [rip+0x2348de]        # e4dac8 <_DYNAMIC+0x308>
  c191ea:	test   rax,rax
  c191ed:	je     c1a13d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa81d>
  c191f3:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6ad6fd]        # 2c68f7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x574>
  c191fa:	movups XMMWORD PTR [rax+0x30],xmm0
  c191fe:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6ad6e2]        # 2c68e7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x564>
  c19205:	movups XMMWORD PTR [rax+0x20],xmm0
  c19209:	movups xmm0,XMMWORD PTR [rip+0xffffffffff6ad6c7]        # 2c68d7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x554>
  c19210:	movups XMMWORD PTR [rax+0x10],xmm0
  c19214:	movdqu xmm0,XMMWORD PTR [rip+0xffffffffff6ad6ab]        # 2c68c7 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x544>
  c1921c:	movdqu XMMWORD PTR [rax],xmm0
  c19220:	movabs rcx,0x83d1bad081d183d1
  c1922a:	mov    QWORD PTR [rax+0x3d],rcx
  c1922e:	mov    rcx,QWORD PTR [rsp+0x10]
  c19233:	mov    BYTE PTR [rcx],0x1e
  c19236:	mov    QWORD PTR [rcx+0x8],0x45
  c1923e:	mov    QWORD PTR [rcx+0x10],rax
  c19242:	mov    QWORD PTR [rcx+0x18],0x45
  c1924a:	jmp    c19945 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa025>
  c1924f:	add    rax,QWORD PTR [rcx+0x60]
  c19253:	mov    rbx,QWORD PTR [rsp+0x10]
  c19258:	mov    rsi,QWORD PTR [rsp+0x28]
  c1925d:	mov    rcx,QWORD PTR [rsi+0x8]
  c19261:	mov    rdx,QWORD PTR [rsp+0x100]
  c19269:	mov    QWORD PTR [rsp+0x90],rdx
  c19271:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
  c1927a:	movdqa XMMWORD PTR [rsp+0x80],xmm0
  c19283:	cmp    rax,QWORD PTR [rsi+0x10]
  c19287:	jae    c19305 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x99e5>
  c19289:	lea    rax,[rax+rax*2]
  c1928d:	lea    r15,[rcx+rax*8]
  c19291:	mov    rax,QWORD PTR [rsp+0x100]
  c19299:	mov    QWORD PTR [rsp+0x120],rax
  c192a1:	movups xmm0,XMMWORD PTR [rsp+0xf0]
  c192a9:	movaps XMMWORD PTR [rsp+0x110],xmm0
  c192b1:	mov    rdi,r15
  c192b4:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c192b9:	mov    rax,QWORD PTR [rsp+0x120]
  c192c1:	mov    QWORD PTR [r15+0x10],rax
  c192c5:	movdqa xmm0,XMMWORD PTR [rsp+0x110]
  c192ce:	movdqu XMMWORD PTR [r15],xmm0
  c192d3:	mov    rax,QWORD PTR [rsp+0x1b0]
  c192db:	mov    rsi,QWORD PTR [rax]
  c192de:	cmp    QWORD PTR [rsp+0x8],rsi
  c192e3:	jae    c1a14f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa82f>
  c192e9:	mov    rax,QWORD PTR [r14]
  c192ec:	mov    rcx,QWORD PTR [rsp+0x20]
  c192f1:	inc    QWORD PTR [rax+rcx*1+0x58]
  c192f6:	mov    DWORD PTR [rbx+0x8],0xd
  c192fd:	mov    BYTE PTR [rbx],0xff
  c19300:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c19305:	lea    rdi,[rsp+0x80]
  c1930d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c19312:	mov    BYTE PTR [rbx],0x1f
  c19315:	lea    rax,[rip+0xffffffffff6ad5f0]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c1931c:	mov    QWORD PTR [rbx+0x8],rax
  c19320:	mov    QWORD PTR [rbx+0x10],0x4f
  c19328:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1932d:	mov    BYTE PTR [rdi],0x1f
  c19330:	lea    rax,[rip+0xffffffffff6ad4cd]        # 2c6804 <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x481>
  c19337:	mov    QWORD PTR [rdi+0x8],rax
  c1933b:	mov    QWORD PTR [rdi+0x10],0x44
  c19343:	jmp    c1965d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d3d>
  c19348:	mov    BYTE PTR [rdi],0x1f
  c1934b:	lea    rax,[rip+0xffffffffff6acdc6]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c19352:	mov    QWORD PTR [rdi+0x8],rax
  c19356:	mov    QWORD PTR [rdi+0x10],0x4f
  c1935e:	mov    rax,QWORD PTR [rsp+0x30]
  c19363:	mov    QWORD PTR [rdi+0x18],rax
  c19367:	jmp    c1965d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d3d>
  c1936c:	mov    BYTE PTR [rdi],0x1f
  c1936f:	lea    rax,[rip+0xffffffffff6acda2]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c19376:	mov    QWORD PTR [rdi+0x8],rax
  c1937a:	mov    QWORD PTR [rdi+0x10],0x4f
  c19382:	mov    rax,QWORD PTR [rsp+0x350]
  c1938a:	mov    QWORD PTR [rdi+0x18],rax
  c1938e:	jmp    c1965d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d3d>
  c19393:	mov    BYTE PTR [rdi],0x1f
  c19396:	lea    rax,[rip+0xffffffffff6acd7b]        # 2c6118 <anon.72d569096cd19b34e7d31a7a1ed00097.40.llvm.9843623889729815062+0x1757>
  c1939d:	mov    QWORD PTR [rdi+0x8],rax
  c193a1:	mov    QWORD PTR [rdi+0x10],0x4f
  c193a9:	mov    rax,QWORD PTR [rsp+0x348]
  c193b1:	mov    QWORD PTR [rdi+0x18],rax
  c193b5:	jmp    c1965d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d3d>
  c193ba:	mov    eax,0xc
  c193bf:	mov    DWORD PTR [rbx+0x8],eax
  c193c2:	movdqa xmm0,XMMWORD PTR [rsp+0x80]
  c193cb:	movdqu XMMWORD PTR [rbx+0xc],xmm0
  c193d0:	mov    eax,DWORD PTR [rsp+0x90]
  c193d7:	jmp    c174b3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x7b93>
  c193dc:	mov    rbx,QWORD PTR [rsp+0x118]
  c193e4:	mov    eax,DWORD PTR [rsp+0x120]
  c193eb:	mov    ecx,DWORD PTR [rsp+0x134]
  c193f2:	movdqu xmm0,XMMWORD PTR [rsp+0x124]
  c193fb:	movdqa XMMWORD PTR [rsp+0x5b0],xmm0
  c19404:	mov    DWORD PTR [rsp+0x5c0],ecx
  c1940b:	mov    r14d,0x1
  c19411:	mov    DWORD PTR [rsp+0x80],eax
  c19418:	mov    eax,DWORD PTR [rsp+0x5c0]
  c1941f:	mov    DWORD PTR [rsp+0x94],eax
  c19426:	movdqa xmm0,XMMWORD PTR [rsp+0x5b0]
  c1942f:	movdqu XMMWORD PTR [rsp+0x84],xmm0
  c19438:	mov    rax,QWORD PTR [rsp+0x1b0]
  c19440:	mov    rsi,QWORD PTR [rax]
  c19443:	cmp    r12,rsi
  c19446:	jae    c1a0ed <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa7cd>
  c1944c:	mov    rax,QWORD PTR [rsp+0x1b8]
  c19454:	mov    rsi,QWORD PTR [rax]
  c19457:	lea    rdx,[rsi+r15*1]
  c1945b:	movzx  ecx,bpl
  c1945f:	mov    rax,rcx
  c19462:	sub    rax,QWORD PTR [rsi+r15*1+0x30]
  c19467:	jae    c19476 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b56>
  c19469:	mov    rax,QWORD PTR [rdx+0x28]
  c1946d:	shl    ecx,0x4
  c19470:	mov    rax,QWORD PTR [rax+rcx*1]
  c19474:	jmp    c1947a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9b5a>
  c19476:	add    rax,QWORD PTR [rdx+0x60]
  c1947a:	mov    rsi,QWORD PTR [rsp+0x28]
  c1947f:	mov    rcx,QWORD PTR [rsi+0x8]
  c19483:	mov    rdx,QWORD PTR [rsp+0x90]
  c1948b:	mov    QWORD PTR [rsp+0x120],rdx
  c19493:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c1949c:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c194a5:	cmp    rax,QWORD PTR [rsi+0x10]
  c194a9:	jae    c19635 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d15>
  c194af:	lea    rax,[rax+rax*2]
  c194b3:	lea    r15,[rcx+rax*8]
  c194b7:	mov    rdi,r15
  c194ba:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c194bf:	mov    rax,QWORD PTR [rsp+0x90]
  c194c7:	mov    QWORD PTR [r15+0x10],rax
  c194cb:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c194d4:	movdqu XMMWORD PTR [r15],xmm0
  c194d9:	mov    rax,QWORD PTR [rsp+0x1b0]
  c194e1:	mov    rsi,QWORD PTR [rax]
  c194e4:	cmp    r12,rsi
  c194e7:	jae    c1a119 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa7f9>
  c194ed:	mov    rax,QWORD PTR [rsp+0x1b8]
  c194f5:	mov    rax,QWORD PTR [rax]
  c194f8:	mov    rcx,QWORD PTR [rsp+0x20]
  c194fd:	inc    QWORD PTR [rax+rcx*1+0x58]
  c19502:	call   c25100 <_RNvNtCscdodAO9FK5_5alloc5boxed14box_new_uninit>
  c19507:	mov    r15,rax
  c1950a:	mov    rax,QWORD PTR [rsp+0x1b0]
  c19512:	mov    rsi,QWORD PTR [rax]
  c19515:	cmp    r12,rsi
  c19518:	jae    c1a12b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa80b>
  c1951e:	mov    rax,QWORD PTR [rsp+0x1b8]
  c19526:	mov    rax,QWORD PTR [rax]
  c19529:	mov    rcx,QWORD PTR [rsp+0x20]
  c1952e:	mov    eax,DWORD PTR [rax+rcx*1+0x70]
  c19532:	mov    rcx,QWORD PTR [rsp+0x1d8]
  c1953a:	movzx  ecx,BYTE PTR [rcx+0xc3]
  c19541:	mov    QWORD PTR [r15],0x0
  c19548:	movups xmm0,XMMWORD PTR [rsp+0x40]
  c1954d:	movups XMMWORD PTR [r15+0x20],xmm0
  c19552:	mov    rdx,QWORD PTR [rsp+0x50]
  c19557:	mov    QWORD PTR [r15+0x30],rdx
  c1955b:	mov    QWORD PTR [r15+0x38],0x0
  c19563:	mov    QWORD PTR [r15+0x40],0x8
  c1956b:	mov    QWORD PTR [r15+0x48],0x0
  c19573:	mov    rdx,QWORD PTR [rsp+0x4b0]
  c1957b:	mov    QWORD PTR [r15+0x50],rdx
  c1957f:	mov    QWORD PTR [r15+0x58],0x0
  c19587:	mov    QWORD PTR [r15+0x60],rcx
  c1958b:	mov    QWORD PTR [r15+0x68],0x0
  c19593:	mov    DWORD PTR [r15+0x70],eax
  c19597:	mov    BYTE PTR [r15+0x74],0x0
  c1959c:	mov    rax,QWORD PTR [rsp+0xe0]
  c195a4:	mov    QWORD PTR [rsp+0x148],rax
  c195ac:	movdqu xmm0,XMMWORD PTR [rsp+0xd0]
  c195b5:	movdqu XMMWORD PTR [rsp+0x138],xmm0
  c195be:	mov    rdi,QWORD PTR [rsp+0x660]
  c195c6:	mov    rax,QWORD PTR [rdi+0xb0]
  c195cd:	mov    QWORD PTR [rsp+0x120],0x1
  c195d9:	mov    QWORD PTR [rsp+0x128],r15
  c195e1:	mov    QWORD PTR [rsp+0x130],0x1
  c195ed:	mov    DWORD PTR [rsp+0x150],0xffffffff
  c195f8:	mov    QWORD PTR [rsp+0x110],r14
  c19600:	mov    QWORD PTR [rsp+0x118],rbx
  c19608:	mov    QWORD PTR [rsp+0x168],rax
  c19610:	lea    rsi,[rsp+0x110]
  c19618:	call   c49380 <_RNvMs0_NtCsbxgXiyEKxkX_6bsl_vm9schedulerNtB5_10AsyncState11insert_task>
  c1961d:	mov    rcx,QWORD PTR [rsp+0x10]
  c19622:	mov    DWORD PTR [rcx+0x8],0xe
  c19629:	mov    QWORD PTR [rcx+0x10],rax
  c1962d:	mov    BYTE PTR [rcx],0xff
  c19630:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c19635:	lea    rdi,[rsp+0x110]
  c1963d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c19642:	mov    rcx,QWORD PTR [rsp+0x10]
  c19647:	mov    BYTE PTR [rcx],0x1f
  c1964a:	lea    rax,[rip+0xffffffffff6ad2bb]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c19651:	mov    QWORD PTR [rcx+0x8],rax
  c19655:	mov    QWORD PTR [rcx+0x10],0x4f
  c1965d:	mov    rsi,QWORD PTR [rsp+0x40]
  c19662:	test   rsi,rsi
  c19665:	je     c1967b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9d5b>
  c19667:	mov    rdi,QWORD PTR [rsp+0x48]
  c1966c:	shl    rsi,0x4
  c19670:	mov    edx,0x8
  c19675:	call   QWORD PTR [rip+0x234385]        # e4da00 <_DYNAMIC+0x240>
  c1967b:	lea    rdi,[rsp+0xd0]
  c19683:	call   c0a040 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueEECsbxgXiyEKxkX_6bsl_vm>
  c19688:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1968d:	mov    QWORD PTR [rsp+0x118],rax
  c19695:	mov    QWORD PTR [rsp+0x120],0x40
  c196a1:	movdqu xmm0,XMMWORD PTR [rsp+0x130]
  c196aa:	mov    rdx,QWORD PTR [rsp+0x10]
  c196af:	movdqu XMMWORD PTR [rdx+0x20],xmm0
  c196b4:	mov    rcx,QWORD PTR [rsp+0x120]
  c196bc:	mov    QWORD PTR [rdx+0x10],rcx
  c196c0:	mov    rcx,QWORD PTR [rsp+0x128]
  c196c8:	mov    QWORD PTR [rdx+0x18],rcx
  c196cc:	mov    BYTE PTR [rdx],0x1f
  c196cf:	mov    QWORD PTR [rdx+0x8],rax
  c196d3:	jmp    c19945 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa025>
  c196d8:	cmp    al,0xff
  c196da:	je     c197fb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9edb>
  c196e0:	lea    rdi,[rsp+0x110]
  c196e8:	mov    rsi,rbx
  c196eb:	call   c25260 <_RNvXs8_NtCs54fMbAdz0qV_6bsl_rt5errorNtB5_7RtErrorNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c196f0:	movzx  eax,BYTE PTR [rsp+0x110]
  c196f8:	movups xmm0,XMMWORD PTR [rsp+0x111]
  c19700:	movaps XMMWORD PTR [rsp+0x80],xmm0
  c19708:	movups xmm0,XMMWORD PTR [rsp+0x120]
  c19710:	movups XMMWORD PTR [rsp+0x8f],xmm0
  c19718:	movups xmm0,XMMWORD PTR [rsp+0x130]
  c19720:	mov    rcx,QWORD PTR [rsp+0x10]
  c19725:	movups XMMWORD PTR [rcx+0x20],xmm0
  c19729:	movaps xmm0,XMMWORD PTR [rsp+0x80]
  c19731:	movaps XMMWORD PTR [rsp+0x40],xmm0
  c19736:	movups xmm0,XMMWORD PTR [rsp+0x8f]
  c1973e:	movups XMMWORD PTR [rsp+0x4f],xmm0
  c19743:	movups xmm0,XMMWORD PTR [rsp+0x4f]
  c19748:	movups XMMWORD PTR [rcx+0x10],xmm0
  c1974c:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c19752:	movdqu XMMWORD PTR [rcx+0x1],xmm0
  c19757:	mov    BYTE PTR [rcx],al
  c19759:	jmp    c19945 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa025>
  c1975e:	mov    rax,QWORD PTR [rsp+0x1b0]
  c19766:	mov    rsi,QWORD PTR [rax]
  c19769:	cmp    QWORD PTR [rsp+0x8],rsi
  c1976e:	jae    c1a161 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa841>
  c19774:	mov    rax,QWORD PTR [rsp+0x1b8]
  c1977c:	mov    rax,QWORD PTR [rax]
  c1977f:	mov    rcx,QWORD PTR [rsp+0x28]
  c19784:	mov    rsi,QWORD PTR [rcx+0x8]
  c19788:	mov    rdx,QWORD PTR [rcx+0x10]
  c1978c:	mov    rcx,QWORD PTR [rsp+0x20]
  c19791:	lea    rax,[rax+rcx*1+0x58]
  c19796:	lea    rdi,[rsp+0x110]
  c1979e:	mov    rcx,r15
  c197a1:	mov    r8,rbp
  c197a4:	push   rbx
  c197a5:	push   rax
  c197a6:	call   c0f560 <_RNvCsbxgXiyEKxkX_6bsl_vm24numeric_for_i64_overflow>
  c197ab:	add    rsp,0x10
  c197af:	cmp    BYTE PTR [rsp+0x110],0xff
  c197b7:	je     c1994a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa02a>
  c197bd:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c197c6:	movdqu xmm1,XMMWORD PTR [rsp+0x120]
  c197cf:	movups xmm2,XMMWORD PTR [rsp+0x130]
  c197d7:	mov    rax,QWORD PTR [rsp+0x10]
  c197dc:	movups XMMWORD PTR [rax+0x20],xmm2
  c197e0:	movdqu XMMWORD PTR [rax+0x10],xmm1
  c197e5:	movdqu XMMWORD PTR [rax],xmm0
  c197e9:	add    rsp,0x5f8
  c197f0:	pop    rbx
  c197f1:	pop    r12
  c197f3:	pop    r13
  c197f5:	pop    r14
  c197f7:	pop    r15
  c197f9:	pop    rbp
  c197fa:	ret
  c197fb:	add    rbx,0x8
  c197ff:	lea    rdi,[rsp+0x110]
  c19807:	mov    rsi,rbx
  c1980a:	call   c251c0 <_RNvXs4_NtCs54fMbAdz0qV_6bsl_rt5valueNtB5_8BslValueNtNtCs4NRVxsYgnAr_4core5clone5Clone5clone>
  c1980f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c19818:	movdqu XMMWORD PTR [rsp+0x87],xmm0
  c19821:	mov    rax,QWORD PTR [rsp+0x120]
  c19829:	movdqu XMMWORD PTR [rsp+0x47],xmm0
  c1982f:	movdqa XMMWORD PTR [rsp+0xd0],xmm0
  c19838:	mov    QWORD PTR [rsp+0xe0],rax
  c19840:	mov    rax,QWORD PTR [rsp+0x1b0]
  c19848:	mov    rsi,QWORD PTR [rax]
  c1984b:	cmp    QWORD PTR [rsp+0x8],rsi
  c19850:	jae    c1a173 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa853>
  c19856:	mov    rax,QWORD PTR [rsp+0x1b8]
  c1985e:	mov    rdx,QWORD PTR [rax]
  c19861:	mov    rsi,QWORD PTR [rsp+0x20]
  c19866:	lea    rcx,[rdx+rsi*1]
  c1986a:	mov    rax,r12
  c1986d:	sub    rax,QWORD PTR [rdx+rsi*1+0x30]
  c19872:	jae    c19882 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f62>
  c19874:	mov    rax,QWORD PTR [rcx+0x28]
  c19878:	shl    r12d,0x4
  c1987c:	mov    rax,QWORD PTR [rax+r12*1]
  c19880:	jmp    c19886 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9f66>
  c19882:	add    rax,QWORD PTR [rcx+0x60]
  c19886:	mov    rsi,QWORD PTR [rsp+0x28]
  c1988b:	mov    rcx,QWORD PTR [rsi+0x8]
  c1988f:	mov    rdx,QWORD PTR [rsp+0xe0]
  c19897:	mov    QWORD PTR [rsp+0x120],rdx
  c1989f:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c198a8:	movdqa XMMWORD PTR [rsp+0x110],xmm0
  c198b1:	cmp    rax,QWORD PTR [rsi+0x10]
  c198b5:	jae    c1991d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ffd>
  c198b7:	lea    rax,[rax+rax*2]
  c198bb:	lea    r15,[rcx+rax*8]
  c198bf:	mov    rdi,r15
  c198c2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c198c7:	mov    rax,QWORD PTR [rsp+0xe0]
  c198cf:	mov    QWORD PTR [r15+0x10],rax
  c198d3:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c198dc:	movdqu XMMWORD PTR [r15],xmm0
  c198e1:	mov    rax,QWORD PTR [rsp+0x1b0]
  c198e9:	mov    rsi,QWORD PTR [rax]
  c198ec:	cmp    QWORD PTR [rsp+0x8],rsi
  c198f1:	jae    c1a187 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa867>
  c198f7:	mov    rax,QWORD PTR [rsp+0x1b8]
  c198ff:	mov    rax,QWORD PTR [rax]
  c19902:	mov    rcx,QWORD PTR [rsp+0x20]
  c19907:	inc    QWORD PTR [rax+rcx*1+0x58]
  c1990c:	mov    rax,QWORD PTR [rsp+0x10]
  c19911:	mov    DWORD PTR [rax+0x8],0xd
  c19918:	mov    BYTE PTR [rax],0xff
  c1991b:	jmp    c19945 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa025>
  c1991d:	lea    rdi,[rsp+0x110]
  c19925:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1992a:	mov    rcx,QWORD PTR [rsp+0x10]
  c1992f:	mov    BYTE PTR [rcx],0x1f
  c19932:	lea    rax,[rip+0xffffffffff6acfd3]        # 2c690c <anon.c2b893ca1edaacc1e9ca389f72ce6453.17.llvm.4407857772816606588+0x589>
  c19939:	mov    QWORD PTR [rcx+0x8],rax
  c1993d:	mov    QWORD PTR [rcx+0x10],0x4f
  c19945:	jmp    c18803 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x8ee3>
  c1994a:	mov    rax,QWORD PTR [rsp+0x10]
  c1994f:	mov    DWORD PTR [rax+0x8],0xc
  c19956:	mov    BYTE PTR [rax],0xff
  c19959:	jmp    c197e9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0x9ec9>
  c1995e:	lea    rcx,[rip+0x21d383]        # e36ce8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.254.llvm.4407857772816606588>
  c19965:	mov    edx,0x3
  c1996a:	xor    edi,edi
  c1996c:	mov    rsi,r8
  c1996f:	call   QWORD PTR [rip+0x2341ab]        # e4db20 <_DYNAMIC+0x360>
  c19975:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1997a:	lea    rdx,[rip+0x21c30f]        # e35c90 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x90>
  c19981:	mov    rdi,r13
  c19984:	mov    rsi,QWORD PTR [rsp+0x30]
  c19989:	call   QWORD PTR [rip+0x234149]        # e4dad8 <_DYNAMIC+0x318>
  c1998f:	lea    rdx,[rip+0x21ccaa]        # e36640 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xa40>
  c19996:	mov    rdi,QWORD PTR [rsp+0x8]
  c1999b:	call   QWORD PTR [rip+0x234137]        # e4dad8 <_DYNAMIC+0x318>
  c199a1:	lea    rdx,[rip+0x21c2d0]        # e35c78 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x78>
  c199a8:	mov    rdi,QWORD PTR [rsp+0x8]
  c199ad:	xor    esi,esi
  c199af:	call   QWORD PTR [rip+0x234123]        # e4dad8 <_DYNAMIC+0x318>
  c199b5:	mov    rsi,QWORD PTR [rsp+0x120]
  c199bd:	call   QWORD PTR [rip+0x2340e5]        # e4daa8 <_DYNAMIC+0x2e8>
  c199c3:	mov    rsi,QWORD PTR [rsp+0x120]
  c199cb:	call   QWORD PTR [rip+0x2340d7]        # e4daa8 <_DYNAMIC+0x2e8>
  c199d1:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c199d6:	lea    rdx,[rip+0x21c89b]        # e36278 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x678>
  c199dd:	jmp    c199f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0d8>
  c199df:	lea    rdx,[rip+0x21c8da]        # e362c0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x6c0>
  c199e6:	jmp    c199f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0d8>
  c199e8:	lea    rdx,[rip+0x21c8a1]        # e36290 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x690>
  c199ef:	jmp    c199f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0d8>
  c199f1:	lea    rdx,[rip+0x21c8b0]        # e362a8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x6a8>
  c199f8:	mov    rdi,QWORD PTR [rsp+0x8]
  c199fd:	mov    rsi,r12
  c19a00:	call   QWORD PTR [rip+0x2340d2]        # e4dad8 <_DYNAMIC+0x318>
  c19a06:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19a0b:	lea    rdx,[rip+0x21c48e]        # e35ea0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x2a0>
  c19a12:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a17:	call   QWORD PTR [rip+0x2340bb]        # e4dad8 <_DYNAMIC+0x318>
  c19a1d:	lea    rdx,[rip+0x21c50c]        # e35f30 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x330>
  c19a24:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a29:	call   QWORD PTR [rip+0x2340a9]        # e4dad8 <_DYNAMIC+0x318>
  c19a2f:	lea    rdx,[rip+0x21ca6a]        # e364a0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x8a0>
  c19a36:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a3b:	call   QWORD PTR [rip+0x234097]        # e4dad8 <_DYNAMIC+0x318>
  c19a41:	lea    rdx,[rip+0x21c668]        # e360b0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x4b0>
  c19a48:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a4d:	call   QWORD PTR [rip+0x234085]        # e4dad8 <_DYNAMIC+0x318>
  c19a53:	lea    rdx,[rip+0x21c48e]        # e35ee8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x2e8>
  c19a5a:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a5f:	call   QWORD PTR [rip+0x234073]        # e4dad8 <_DYNAMIC+0x318>
  c19a65:	lea    rdx,[rip+0x21cac4]        # e36530 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x930>
  c19a6c:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a71:	call   QWORD PTR [rip+0x234061]        # e4dad8 <_DYNAMIC+0x318>
  c19a77:	lea    rdx,[rip+0x21ca6a]        # e364e8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x8e8>
  c19a7e:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a83:	call   QWORD PTR [rip+0x23404f]        # e4dad8 <_DYNAMIC+0x318>
  c19a89:	lea    rdx,[rip+0x21c218]        # e35ca8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xa8>
  c19a90:	mov    rdi,QWORD PTR [rsp+0x8]
  c19a95:	call   QWORD PTR [rip+0x23403d]        # e4dad8 <_DYNAMIC+0x318>
  c19a9b:	lea    rdx,[rip+0x21c69e]        # e36140 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x540>
  c19aa2:	mov    rdi,QWORD PTR [rsp+0x8]
  c19aa7:	call   QWORD PTR [rip+0x23402b]        # e4dad8 <_DYNAMIC+0x318>
  c19aad:	lea    rdx,[rip+0x21cac4]        # e36578 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x978>
  c19ab4:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ab9:	call   QWORD PTR [rip+0x234019]        # e4dad8 <_DYNAMIC+0x318>
  c19abf:	lea    rdx,[rip+0x21c07a]        # e35b40 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c19ac6:	mov    rdi,QWORD PTR [rsp+0x8]
  c19acb:	call   QWORD PTR [rip+0x234007]        # e4dad8 <_DYNAMIC+0x318>
  c19ad1:	lea    rdx,[rip+0x21c068]        # e35b40 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c19ad8:	mov    rdi,QWORD PTR [rsp+0x8]
  c19add:	call   QWORD PTR [rip+0x233ff5]        # e4dad8 <_DYNAMIC+0x318>
  c19ae3:	lea    rdx,[rip+0x21c296]        # e35d80 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x180>
  c19aea:	mov    rdi,QWORD PTR [rsp+0x8]
  c19aef:	call   QWORD PTR [rip+0x233fe3]        # e4dad8 <_DYNAMIC+0x318>
  c19af5:	lea    rdx,[rip+0x21cac4]        # e365c0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x9c0>
  c19afc:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b01:	call   QWORD PTR [rip+0x233fd1]        # e4dad8 <_DYNAMIC+0x318>
  c19b07:	lea    rdx,[rip+0x21c032]        # e35b40 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c19b0e:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b13:	call   QWORD PTR [rip+0x233fbf]        # e4dad8 <_DYNAMIC+0x318>
  c19b19:	lea    rdx,[rip+0x21c8c0]        # e363e0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x7e0>
  c19b20:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b25:	call   QWORD PTR [rip+0x233fad]        # e4dad8 <_DYNAMIC+0x318>
  c19b2b:	lea    rdx,[rip+0x21c45e]        # e35f90 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x390>
  c19b32:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b37:	call   QWORD PTR [rip+0x233f9b]        # e4dad8 <_DYNAMIC+0x318>
  c19b3d:	lea    rdx,[rip+0x21c524]        # e36068 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x468>
  c19b44:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b49:	call   QWORD PTR [rip+0x233f89]        # e4dad8 <_DYNAMIC+0x318>
  c19b4f:	lea    rdx,[rip+0x21c4fa]        # e36050 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x450>
  c19b56:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b5b:	call   QWORD PTR [rip+0x233f77]        # e4dad8 <_DYNAMIC+0x318>
  c19b61:	lea    rdx,[rip+0x21c650]        # e361b8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x5b8>
  c19b68:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b6d:	call   QWORD PTR [rip+0x233f65]        # e4dad8 <_DYNAMIC+0x318>
  c19b73:	lea    rdx,[rip+0x21c266]        # e35de0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x1e0>
  c19b7a:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b7f:	call   QWORD PTR [rip+0x233f53]        # e4dad8 <_DYNAMIC+0x318>
  c19b85:	lea    rdx,[rip+0x21bfb4]        # e35b40 <anon.abc756da4e8df57d913bbfd9c615ca8d.75.llvm.6049947941247669032+0x970>
  c19b8c:	mov    rdi,QWORD PTR [rsp+0x8]
  c19b91:	call   QWORD PTR [rip+0x233f41]        # e4dad8 <_DYNAMIC+0x318>
  c19b97:	lea    rdx,[rip+0x21c602]        # e361a0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x5a0>
  c19b9e:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ba3:	call   QWORD PTR [rip+0x233f2f]        # e4dad8 <_DYNAMIC+0x318>
  c19ba9:	lea    rdx,[rip+0x21c5d8]        # e36188 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x588>
  c19bb0:	mov    rdi,QWORD PTR [rsp+0x8]
  c19bb5:	call   QWORD PTR [rip+0x233f1d]        # e4dad8 <_DYNAMIC+0x318>
  c19bbb:	lea    rdx,[rip+0x21c536]        # e360f8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x4f8>
  c19bc2:	mov    rdi,QWORD PTR [rsp+0x8]
  c19bc7:	call   QWORD PTR [rip+0x233f0b]        # e4dad8 <_DYNAMIC+0x318>
  c19bcd:	lea    rdx,[rip+0x21c1dc]        # e35db0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x1b0>
  c19bd4:	mov    rdi,QWORD PTR [rsp+0x8]
  c19bd9:	call   QWORD PTR [rip+0x233ef9]        # e4dad8 <_DYNAMIC+0x318>
  c19bdf:	lea    rdx,[rip+0x21c85a]        # e36440 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x840>
  c19be6:	mov    rdi,QWORD PTR [rsp+0x8]
  c19beb:	call   QWORD PTR [rip+0x233ee7]        # e4dad8 <_DYNAMIC+0x318>
  c19bf1:	lea    rdx,[rip+0x21c908]        # e36500 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x900>
  c19bf8:	mov    rdi,QWORD PTR [rsp+0x8]
  c19bfd:	call   QWORD PTR [rip+0x233ed5]        # e4dad8 <_DYNAMIC+0x318>
  c19c03:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19c08:	lea    rdx,[rip+0x21c141]        # e35d50 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x150>
  c19c0f:	mov    rdi,QWORD PTR [rsp+0x8]
  c19c14:	call   QWORD PTR [rip+0x233ebe]        # e4dad8 <_DYNAMIC+0x318>
  c19c1a:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19c1f:	lea    rdx,[rip+0x21c21a]        # e35e40 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x240>
  c19c26:	mov    rdi,QWORD PTR [rsp+0x8]
  c19c2b:	call   QWORD PTR [rip+0x233ea7]        # e4dad8 <_DYNAMIC+0x318>
  c19c31:	lea    rdx,[rip+0x21c220]        # e35e58 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x258>
  c19c38:	mov    rdi,QWORD PTR [rsp+0x8]
  c19c3d:	call   QWORD PTR [rip+0x233e95]        # e4dad8 <_DYNAMIC+0x318>
  c19c43:	lea    rdx,[rip+0x21c98e]        # e365d8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x9d8>
  c19c4a:	mov    rdi,QWORD PTR [rsp+0x8]
  c19c4f:	call   QWORD PTR [rip+0x233e83]        # e4dad8 <_DYNAMIC+0x318>
  c19c55:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19c5a:	lea    rdx,[rip+0x21c05f]        # e35cc0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xc0>
  c19c61:	mov    rdi,QWORD PTR [rsp+0x8]
  c19c66:	call   QWORD PTR [rip+0x233e6c]        # e4dad8 <_DYNAMIC+0x318>
  c19c6c:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19c71:	lea    rdx,[rip+0x21c2d0]        # e35f48 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x348>
  c19c78:	mov    rdi,QWORD PTR [rsp+0x8]
  c19c7d:	call   QWORD PTR [rip+0x233e55]        # e4dad8 <_DYNAMIC+0x318>
  c19c83:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19c88:	lea    rdx,[rip+0x21c139]        # e35dc8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x1c8>
  c19c8f:	mov    rdi,QWORD PTR [rsp+0x8]
  c19c94:	call   QWORD PTR [rip+0x233e3e]        # e4dad8 <_DYNAMIC+0x318>
  c19c9a:	lea    rdx,[rip+0x21c307]        # e35fa8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x3a8>
  c19ca1:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ca6:	call   QWORD PTR [rip+0x233e2c]        # e4dad8 <_DYNAMIC+0x318>
  c19cac:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19cb1:	lea    rdx,[rip+0x21c140]        # e35df8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x1f8>
  c19cb8:	mov    rdi,QWORD PTR [rsp+0x8]
  c19cbd:	call   QWORD PTR [rip+0x233e15]        # e4dad8 <_DYNAMIC+0x318>
  c19cc3:	lea    rdx,[rip+0x21c146]        # e35e10 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x210>
  c19cca:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ccf:	call   QWORD PTR [rip+0x233e03]        # e4dad8 <_DYNAMIC+0x318>
  c19cd5:	lea    rdx,[rip+0x21c1ac]        # e35e88 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x288>
  c19cdc:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ce1:	call   QWORD PTR [rip+0x233df1]        # e4dad8 <_DYNAMIC+0x318>
  c19ce7:	lea    rdx,[rip+0x21c0aa]        # e35d98 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x198>
  c19cee:	mov    rdi,QWORD PTR [rsp+0x8]
  c19cf3:	call   QWORD PTR [rip+0x233ddf]        # e4dad8 <_DYNAMIC+0x318>
  c19cf9:	lea    rdx,[rip+0x21c020]        # e35d20 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x120>
  c19d00:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d05:	call   QWORD PTR [rip+0x233dcd]        # e4dad8 <_DYNAMIC+0x318>
  c19d0b:	lea    rdx,[rip+0x21c746]        # e36458 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x858>
  c19d12:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d17:	call   QWORD PTR [rip+0x233dbb]        # e4dad8 <_DYNAMIC+0x318>
  c19d1d:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19d22:	lea    rdx,[rip+0x21c6cf]        # e363f8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x7f8>
  c19d29:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d2e:	call   QWORD PTR [rip+0x233da4]        # e4dad8 <_DYNAMIC+0x318>
  c19d34:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19d39:	lea    rdx,[rip+0x21c0e8]        # e35e28 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x228>
  c19d40:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d45:	call   QWORD PTR [rip+0x233d8d]        # e4dad8 <_DYNAMIC+0x318>
  c19d4b:	lea    rdx,[rip+0x21c11e]        # e35e70 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x270>
  c19d52:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d57:	call   QWORD PTR [rip+0x233d7b]        # e4dad8 <_DYNAMIC+0x318>
  c19d5d:	lea    rdx,[rip+0x21c7e4]        # e36548 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x948>
  c19d64:	jmp    c19ebd <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa59d>
  c19d69:	lea    rdx,[rip+0x21c1f0]        # e35f60 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x360>
  c19d70:	jmp    c19ea6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa586>
  c19d75:	lea    rdx,[rip+0x21c184]        # e35f00 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x300>
  c19d7c:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d81:	call   QWORD PTR [rip+0x233d51]        # e4dad8 <_DYNAMIC+0x318>
  c19d87:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19d8c:	lea    rdx,[rip+0x21c125]        # e35eb8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x2b8>
  c19d93:	mov    rdi,QWORD PTR [rsp+0x8]
  c19d98:	call   QWORD PTR [rip+0x233d3a]        # e4dad8 <_DYNAMIC+0x318>
  c19d9e:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19da3:	lea    rdx,[rip+0x21bfbe]        # e35d68 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x168>
  c19daa:	mov    rdi,QWORD PTR [rsp+0x8]
  c19daf:	call   QWORD PTR [rip+0x233d23]        # e4dad8 <_DYNAMIC+0x318>
  c19db5:	lea    rdx,[rip+0x21c6b4]        # e36470 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x870>
  c19dbc:	jmp    c19f85 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa665>
  c19dc1:	lea    rdx,[rip+0x21c1f8]        # e35fc0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x3c0>
  c19dc8:	jmp    c19e66 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa546>
  c19dcd:	lea    rdx,[rip+0x21c7bc]        # e36590 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x990>
  c19dd4:	mov    rdi,QWORD PTR [rsp+0x8]
  c19dd9:	call   QWORD PTR [rip+0x233cf9]        # e4dad8 <_DYNAMIC+0x318>
  c19ddf:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19de4:	lea    rdx,[rip+0x21beed]        # e35cd8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xd8>
  c19deb:	mov    rdi,QWORD PTR [rsp+0x8]
  c19df0:	call   QWORD PTR [rip+0x233ce2]        # e4dad8 <_DYNAMIC+0x318>
  c19df6:	lea    rdx,[rip+0x21bef3]        # e35cf0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xf0>
  c19dfd:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e02:	call   QWORD PTR [rip+0x233cd0]        # e4dad8 <_DYNAMIC+0x318>
  c19e08:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19e0d:	lea    rdx,[rip+0x21c794]        # e365a8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x9a8>
  c19e14:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e19:	call   QWORD PTR [rip+0x233cb9]        # e4dad8 <_DYNAMIC+0x318>
  c19e1f:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19e24:	lea    rdx,[rip+0x21c0a5]        # e35ed0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x2d0>
  c19e2b:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e30:	call   QWORD PTR [rip+0x233ca2]        # e4dad8 <_DYNAMIC+0x318>
  c19e36:	lea    rdx,[rip+0x21c5d3]        # e36410 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x810>
  c19e3d:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e42:	call   QWORD PTR [rip+0x233c90]        # e4dad8 <_DYNAMIC+0x318>
  c19e48:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19e4d:	lea    rdx,[rip+0x21beb4]        # e35d08 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x108>
  c19e54:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e59:	call   QWORD PTR [rip+0x233c79]        # e4dad8 <_DYNAMIC+0x318>
  c19e5f:	lea    rdx,[rip+0x21c172]        # e35fd8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x3d8>
  c19e66:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e6b:	call   QWORD PTR [rip+0x233c67]        # e4dad8 <_DYNAMIC+0x318>
  c19e71:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19e76:	lea    rdx,[rip+0x21bebb]        # e35d38 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x138>
  c19e7d:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e82:	call   QWORD PTR [rip+0x233c50]        # e4dad8 <_DYNAMIC+0x318>
  c19e88:	lea    rdx,[rip+0x21c781]        # e36610 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xa10>
  c19e8f:	mov    rdi,QWORD PTR [rsp+0x8]
  c19e94:	call   QWORD PTR [rip+0x233c3e]        # e4dad8 <_DYNAMIC+0x318>
  c19e9a:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19e9f:	lea    rdx,[rip+0x21c0d2]        # e35f78 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x378>
  c19ea6:	mov    rdi,QWORD PTR [rsp+0x8]
  c19eab:	call   QWORD PTR [rip+0x233c27]        # e4dad8 <_DYNAMIC+0x318>
  c19eb1:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19eb6:	lea    rdx,[rip+0x21c6a3]        # e36560 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x960>
  c19ebd:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ec2:	call   QWORD PTR [rip+0x233c10]        # e4dad8 <_DYNAMIC+0x318>
  c19ec8:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19ecd:	lea    rdx,[rip+0x21c044]        # e35f18 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x318>
  c19ed4:	mov    rdi,QWORD PTR [rsp+0x8]
  c19ed9:	call   QWORD PTR [rip+0x233bf9]        # e4dad8 <_DYNAMIC+0x318>
  c19edf:	lea    rdx,[rip+0x21c5d2]        # e364b8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x8b8>
  c19ee6:	mov    rdi,QWORD PTR [rsp+0x8]
  c19eeb:	call   QWORD PTR [rip+0x233be7]        # e4dad8 <_DYNAMIC+0x318>
  c19ef1:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19ef6:	lea    rdx,[rip+0x21c10b]        # e36008 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x408>
  c19efd:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f02:	call   QWORD PTR [rip+0x233bd0]        # e4dad8 <_DYNAMIC+0x318>
  c19f08:	lea    rdx,[rip+0x21c0e1]        # e35ff0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x3f0>
  c19f0f:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f14:	call   QWORD PTR [rip+0x233bbe]        # e4dad8 <_DYNAMIC+0x318>
  c19f1a:	lea    rdx,[rip+0x21c0ff]        # e36020 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x420>
  c19f21:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f26:	call   QWORD PTR [rip+0x233bac]        # e4dad8 <_DYNAMIC+0x318>
  c19f2c:	lea    rdx,[rip+0x21c4f5]        # e36428 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x828>
  c19f33:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f38:	call   QWORD PTR [rip+0x233b9a]        # e4dad8 <_DYNAMIC+0x318>
  c19f3e:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19f43:	lea    rdx,[rip+0x21c2fe]        # e36248 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x648>
  c19f4a:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f4f:	call   QWORD PTR [rip+0x233b83]        # e4dad8 <_DYNAMIC+0x318>
  c19f55:	lea    rdx,[rip+0x21c0dc]        # e36038 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x438>
  c19f5c:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f61:	call   QWORD PTR [rip+0x233b71]        # e4dad8 <_DYNAMIC+0x318>
  c19f67:	lea    rdx,[rip+0x21c6ba]        # e36628 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0xa28>
  c19f6e:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f73:	call   QWORD PTR [rip+0x233b5f]        # e4dad8 <_DYNAMIC+0x318>
  c19f79:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19f7e:	lea    rdx,[rip+0x21c503]        # e36488 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x888>
  c19f85:	mov    rdi,QWORD PTR [rsp+0x8]
  c19f8a:	call   QWORD PTR [rip+0x233b48]        # e4dad8 <_DYNAMIC+0x318>
  c19f90:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19f95:	lea    rdx,[rip+0x21c534]        # e364d0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x8d0>
  c19f9c:	mov    rdi,QWORD PTR [rsp+0x8]
  c19fa1:	call   QWORD PTR [rip+0x233b31]        # e4dad8 <_DYNAMIC+0x318>
  c19fa7:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19fac:	lea    rdx,[rip+0x21c565]        # e36518 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x918>
  c19fb3:	mov    rdi,QWORD PTR [rsp+0x8]
  c19fb8:	call   QWORD PTR [rip+0x233b1a]        # e4dad8 <_DYNAMIC+0x318>
  c19fbe:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c19fc3:	lea    rdx,[rip+0x21c18e]        # e36158 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x558>
  c19fca:	jmp    c1a086 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa766>
  c19fcf:	lea    rdx,[rip+0x21c1fa]        # e361d0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x5d0>
  c19fd6:	mov    rdi,QWORD PTR [rsp+0x8]
  c19fdb:	call   QWORD PTR [rip+0x233af7]        # e4dad8 <_DYNAMIC+0x318>
  c19fe1:	lea    rdx,[rip+0x21c230]        # e36218 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x618>
  c19fe8:	mov    rdi,QWORD PTR [rsp+0x8]
  c19fed:	call   QWORD PTR [rip+0x233ae5]        # e4dad8 <_DYNAMIC+0x318>
  c19ff3:	lea    rdx,[rip+0x21c206]        # e36200 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x600>
  c19ffa:	mov    rdi,QWORD PTR [rsp+0x8]
  c19fff:	call   QWORD PTR [rip+0x233ad3]        # e4dad8 <_DYNAMIC+0x318>
  c1a005:	lea    rdx,[rip+0x21c08c]        # e36098 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x498>
  c1a00c:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a011:	call   QWORD PTR [rip+0x233ac1]        # e4dad8 <_DYNAMIC+0x318>
  c1a017:	lea    rdx,[rip+0x21c062]        # e36080 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x480>
  c1a01e:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a023:	call   QWORD PTR [rip+0x233aaf]        # e4dad8 <_DYNAMIC+0x318>
  c1a029:	lea    rdx,[rip+0x21c0b0]        # e360e0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x4e0>
  c1a030:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a035:	call   QWORD PTR [rip+0x233a9d]        # e4dad8 <_DYNAMIC+0x318>
  c1a03b:	lea    rdx,[rip+0x21c086]        # e360c8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x4c8>
  c1a042:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a047:	call   QWORD PTR [rip+0x233a8b]        # e4dad8 <_DYNAMIC+0x318>
  c1a04d:	lea    rdx,[rip+0x21c194]        # e361e8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x5e8>
  c1a054:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a059:	call   QWORD PTR [rip+0x233a79]        # e4dad8 <_DYNAMIC+0x318>
  c1a05f:	lea    rdx,[rip+0x21c0aa]        # e36110 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x510>
  c1a066:	jmp    c1a06f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa74f>
  c1a068:	lea    rdx,[rip+0x21c0b9]        # e36128 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x528>
  c1a06f:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a074:	call   QWORD PTR [rip+0x233a5e]        # e4dad8 <_DYNAMIC+0x318>
  c1a07a:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1a07f:	lea    rdx,[rip+0x21c0ea]        # e36170 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x570>
  c1a086:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a08b:	call   QWORD PTR [rip+0x233a47]        # e4dad8 <_DYNAMIC+0x318>
  c1a091:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1a096:	lea    rdx,[rip+0x21c1c3]        # e36260 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x660>
  c1a09d:	jmp    c199f8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa0d8>
  c1a0a2:	lea    rax,[rip+0x21c277]        # e36320 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x720>
  c1a0a9:	mov    QWORD PTR [rsp+0x1c0],rax
  c1a0b1:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a0b6:	mov    rdx,QWORD PTR [rsp+0x1c0]
  c1a0be:	call   QWORD PTR [rip+0x233a14]        # e4dad8 <_DYNAMIC+0x318>
  c1a0c4:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1a0c9:	lea    rdx,[rip+0x21c280]        # e36350 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x750>
  c1a0d0:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a0d5:	call   QWORD PTR [rip+0x2339fd]        # e4dad8 <_DYNAMIC+0x318>
  c1a0db:	lea    rdx,[rip+0x21c2e6]        # e363c8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x7c8>
  c1a0e2:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a0e7:	call   QWORD PTR [rip+0x2339eb]        # e4dad8 <_DYNAMIC+0x318>
  c1a0ed:	lea    rdx,[rip+0x21c1e4]        # e362d8 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x6d8>
  c1a0f4:	mov    rdi,r12
  c1a0f7:	call   QWORD PTR [rip+0x2339db]        # e4dad8 <_DYNAMIC+0x318>
  c1a0fd:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1a102:	lea    rdx,[rip+0x21c28f]        # e36398 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x798>
  c1a109:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a10e:	call   QWORD PTR [rip+0x2339c4]        # e4dad8 <_DYNAMIC+0x318>
  c1a114:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1a119:	lea    rdx,[rip+0x21c1d0]        # e362f0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x6f0>
  c1a120:	mov    rdi,r12
  c1a123:	call   QWORD PTR [rip+0x2339af]        # e4dad8 <_DYNAMIC+0x318>
  c1a129:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1a12b:	lea    rdx,[rip+0x21c1d6]        # e36308 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x708>
  c1a132:	mov    rdi,r12
  c1a135:	call   QWORD PTR [rip+0x23399d]        # e4dad8 <_DYNAMIC+0x318>
  c1a13b:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1a13d:	mov    edi,0x1
  c1a142:	mov    esi,0x45
  c1a147:	call   QWORD PTR [rip+0x23395b]        # e4daa8 <_DYNAMIC+0x2e8>
  c1a14d:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1a14f:	lea    rdx,[rip+0x21c25a]        # e363b0 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x7b0>
  c1a156:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a15b:	call   QWORD PTR [rip+0x233977]        # e4dad8 <_DYNAMIC+0x318>
  c1a161:	lea    rdx,[rip+0x21c0c8]        # e36230 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x630>
  c1a168:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a16d:	call   QWORD PTR [rip+0x233965]        # e4dad8 <_DYNAMIC+0x318>
  c1a173:	lea    rdx,[rip+0x21c1ee]        # e36368 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x768>
  c1a17a:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a17f:	call   QWORD PTR [rip+0x233953]        # e4dad8 <_DYNAMIC+0x318>
  c1a185:	jmp    c1a199 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa879>
  c1a187:	lea    rdx,[rip+0x21c1f2]        # e36380 <anon.c2b893ca1edaacc1e9ca389f72ce6453.28.llvm.4407857772816606588+0x780>
  c1a18e:	mov    rdi,QWORD PTR [rsp+0x8]
  c1a193:	call   QWORD PTR [rip+0x23393f]        # e4dad8 <_DYNAMIC+0x318>
  c1a199:	ud2
  c1a19b:	mov    rbx,rax
  c1a19e:	mov    rax,QWORD PTR [rsp+0xe0]
  c1a1a6:	mov    QWORD PTR [r15+0x10],rax
  c1a1aa:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1a1b3:	movdqu XMMWORD PTR [r15],xmm0
  c1a1b8:	jmp    c1a26c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa94c>
  c1a1bd:	jmp    c1a269 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa949>
  c1a1c2:	mov    rbx,rax
  c1a1c5:	lea    rdi,[rsp+0xd0]
  c1a1cd:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a1d2:	jmp    c1a26c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa94c>
  c1a1d7:	mov    rbx,rax
  c1a1da:	mov    rax,QWORD PTR [rsp+0x120]
  c1a1e2:	mov    QWORD PTR [r15+0x10],rax
  c1a1e6:	movaps xmm0,XMMWORD PTR [rsp+0x110]
  c1a1ee:	movups XMMWORD PTR [r15],xmm0
  c1a1f2:	mov    rdi,rbx
  c1a1f5:	call   d9b550 <_Unwind_Resume@plt>
  c1a1fa:	mov    rbx,rax
  c1a1fd:	mov    esi,0x78
  c1a202:	mov    edx,0x8
  c1a207:	mov    rdi,r15
  c1a20a:	call   QWORD PTR [rip+0x2337f0]        # e4da00 <_DYNAMIC+0x240>
  c1a210:	jmp    c1a58b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac6b>
  c1a215:	mov    rbx,rax
  c1a218:	mov    rax,QWORD PTR [rsp+0x90]
  c1a220:	mov    QWORD PTR [r15+0x10],rax
  c1a224:	movdqu xmm0,XMMWORD PTR [rsp+0x80]
  c1a22d:	movdqu XMMWORD PTR [r15],xmm0
  c1a232:	jmp    c1a58b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac6b>
  c1a237:	jmp    c1a313 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa9f3>
  c1a23c:	jmp    c1a31b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa9fb>
  c1a241:	jmp    c1a2a0 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa980>
  c1a243:	jmp    c1a298 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xa978>
  c1a245:	jmp    c1a7c3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaea3>
  c1a24a:	mov    rbx,rax
  c1a24d:	lea    rdi,[rsp+0x80]
  c1a255:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a25a:	jmp    c1a58b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac6b>
  c1a25f:	jmp    c1a588 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac68>
  c1a264:	jmp    c1a7d8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaeb8>
  c1a269:	mov    rbx,rax
  c1a26c:	lea    rdi,[rsp+0xf0]
  c1a274:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a279:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a27e:	jmp    c1a549 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac29>
  c1a283:	mov    rbx,rax
  c1a286:	mov    DWORD PTR [r12],0x4
  c1a28e:	mov    BYTE PTR [r12+0x4],r14b
  c1a293:	jmp    c1a69a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad7a>
  c1a298:	mov    rbx,rax
  c1a29b:	jmp    c1a65d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad3d>
  c1a2a0:	mov    rbx,rax
  c1a2a3:	jmp    c1a6a7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad87>
  c1a2a8:	jmp    c1a7bc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae9c>
  c1a2ad:	mov    rbx,rax
  c1a2b0:	mov    DWORD PTR [r14],0x4
  c1a2b7:	mov    BYTE PTR [r14+0x4],bpl
  c1a2bb:	jmp    c1a6bf <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad9f>
  c1a2c0:	mov    rbx,rax
  c1a2c3:	mov    rax,QWORD PTR [rsp+0x50]
  c1a2c8:	mov    QWORD PTR [r14+0x10],rax
  c1a2cc:	movdqa xmm0,XMMWORD PTR [rsp+0x40]
  c1a2d2:	movdqu XMMWORD PTR [r14],xmm0
  c1a2d7:	jmp    c1a611 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xacf1>
  c1a2dc:	mov    rbx,rax
  c1a2df:	mov    DWORD PTR [r12],0x4
  c1a2e7:	mov    BYTE PTR [r12+0x4],r14b
  c1a2ec:	jmp    c1a650 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad30>
  c1a2f1:	mov    rbx,rax
  c1a2f4:	mov    rax,QWORD PTR [rsp+0xe0]
  c1a2fc:	mov    QWORD PTR [r14+0x10],rax
  c1a300:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1a309:	movdqu XMMWORD PTR [r14],xmm0
  c1a30e:	jmp    c1a7db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaebb>
  c1a313:	mov    rbx,rax
  c1a316:	jmp    c1a6cc <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xadac>
  c1a31b:	mov    rbx,rax
  c1a31e:	jmp    c1a682 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad62>
  c1a323:	mov    rbx,rax
  c1a326:	mov    rax,QWORD PTR [rsp+0x100]
  c1a32e:	mov    QWORD PTR [r14+0x10],rax
  c1a332:	movdqa xmm0,XMMWORD PTR [rsp+0xf0]
  c1a33b:	movdqu XMMWORD PTR [r14],xmm0
  c1a340:	jmp    c1a904 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xafe4>
  c1a345:	jmp    c1a7a7 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae87>
  c1a34a:	mov    rbx,rax
  c1a34d:	mov    DWORD PTR [r15],0x4
  c1a354:	mov    BYTE PTR [r15+0x4],bpl
  c1a358:	jmp    c1a675 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xad55>
  c1a35d:	jmp    c1a797 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae77>
  c1a362:	mov    rbx,rax
  c1a365:	mov    rax,QWORD PTR [rsp+0x120]
  c1a36d:	mov    QWORD PTR [r14+0x10],rax
  c1a371:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c1a37a:	movdqu XMMWORD PTR [r14],xmm0
  c1a37f:	jmp    c1a86b <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf4b>
  c1a384:	jmp    c1a45f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab3f>
  c1a389:	mov    rbx,rax
  c1a38c:	mov    rax,QWORD PTR [rsp+0x120]
  c1a394:	mov    QWORD PTR [r14+0x10],rax
  c1a398:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c1a3a1:	movdqu XMMWORD PTR [r14],xmm0
  c1a3a6:	jmp    c1a880 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf60>
  c1a3ab:	jmp    c1a79f <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae7f>
  c1a3b0:	mov    rbx,rax
  c1a3b3:	mov    rax,QWORD PTR [rsp+0xe0]
  c1a3bb:	mov    QWORD PTR [r14+0x10],rax
  c1a3bf:	movdqa xmm0,XMMWORD PTR [rsp+0xd0]
  c1a3c8:	movdqu XMMWORD PTR [r14],xmm0
  c1a3cd:	jmp    c1a810 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaef0>
  c1a3d2:	mov    rbx,rax
  c1a3d5:	mov    rax,QWORD PTR [rsp+0x120]
  c1a3dd:	mov    QWORD PTR [r14+0x10],rax
  c1a3e1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
  c1a3ea:	movdqu XMMWORD PTR [r14],xmm0
  c1a3ef:	jmp    c1a84c <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf2c>
  c1a3f4:	jmp    c1a419 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaaf9>
  c1a3f6:	mov    rbx,rax
  c1a3f9:	mov    rax,QWORD PTR [rsp+0x510]
  c1a401:	mov    QWORD PTR [r14+0x10],rax
  c1a405:	movups xmm0,XMMWORD PTR [rsp+0x500]
  c1a40d:	movups XMMWORD PTR [r14],xmm0
  c1a411:	mov    rdi,rbx
  c1a414:	call   d9b550 <_Unwind_Resume@plt>
  c1a419:	mov    rbx,rax
  c1a41c:	mov    rax,QWORD PTR [rsp+0xe0]
  c1a424:	mov    QWORD PTR [r14+0x10],rax
  c1a428:	movaps xmm0,XMMWORD PTR [rsp+0xd0]
  c1a430:	movups XMMWORD PTR [r14],xmm0
  c1a434:	mov    rdi,rbx
  c1a437:	call   d9b550 <_Unwind_Resume@plt>
  c1a43c:	mov    rbx,rax
  c1a43f:	mov    rax,QWORD PTR [rsp+0x90]
  c1a447:	mov    QWORD PTR [r14+0x10],rax
  c1a44b:	movaps xmm0,XMMWORD PTR [rsp+0x80]
  c1a453:	movups XMMWORD PTR [r14],xmm0
  c1a457:	mov    rdi,rbx
  c1a45a:	call   d9b550 <_Unwind_Resume@plt>
  c1a45f:	mov    rbx,rax
  c1a462:	mov    rax,QWORD PTR [rsp+0x90]
  c1a46a:	mov    QWORD PTR [r14+0x10],rax
  c1a46e:	movups xmm0,XMMWORD PTR [rsp+0x80]
  c1a476:	movups XMMWORD PTR [r14],xmm0
  c1a47a:	mov    rdi,rbx
  c1a47d:	call   d9b550 <_Unwind_Resume@plt>
  c1a482:	jmp    c1a6fb <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaddb>
  c1a487:	jmp    c1a6e6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xadc6>
  c1a48c:	jmp    c1a490 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab70>
  c1a48e:	jmp    c1a490 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xab70>
  c1a490:	mov    rbx,rax
  c1a493:	mov    rax,QWORD PTR [rsp+0x120]
  c1a49b:	mov    QWORD PTR [r14+0x10],rax
  c1a49f:	movups xmm0,XMMWORD PTR [rsp+0x110]
  c1a4a7:	movups XMMWORD PTR [r14],xmm0
  c1a4ab:	mov    rdi,rbx
  c1a4ae:	call   d9b550 <_Unwind_Resume@plt>
  c1a4b3:	mov    rbx,rax
  c1a4b6:	lea    rdi,[rsp+0x110]
  c1a4be:	call   c0a360 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm5FrameEBD_>
  c1a4c3:	mov    rdi,rbx
  c1a4c6:	call   d9b550 <_Unwind_Resume@plt>
  c1a4cb:	jmp    c1a89e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf7e>
  c1a4d0:	jmp    c1a588 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac68>
  c1a4d5:	mov    rbx,rax
  c1a4d8:	mov    DWORD PTR [r15],0x2
  c1a4df:	jmp    c1a8a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf81>
  c1a4e4:	mov    rbx,rax
  c1a4e7:	cmp    BYTE PTR [rsp+0x80],0xff
  c1a4ef:	je     c1a7c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaea6>
  c1a4f5:	lea    rdi,[rsp+0x80]
  c1a4fd:	call   c0a8e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5error7RtErrorECsbxgXiyEKxkX_6bsl_vm.llvm.4407857772816606588>
  c1a502:	jmp    c1a7c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaea6>
  c1a507:	mov    rbx,rax
  c1a50a:	lea    rdi,[rsp+0x80]
  c1a512:	call   c099c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueNtNtB11_5error7RtErrorEECsbxgXiyEKxkX_6bsl_vm>
  c1a517:	jmp    c1a7db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaebb>
  c1a51c:	jmp    c1a7c3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaea3>
  c1a521:	jmp    c1a7c3 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaea3>
  c1a526:	mov    rbx,rax
  c1a529:	mov    rax,QWORD PTR [rsp+0x120]
  c1a531:	mov    QWORD PTR [r15+0x10],rax
  c1a535:	movups xmm0,XMMWORD PTR [rsp+0x110]
  c1a53d:	movups XMMWORD PTR [r15],xmm0
  c1a541:	mov    rdi,rbx
  c1a544:	call   d9b550 <_Unwind_Resume@plt>
  c1a549:	mov    rbx,rax
  c1a54c:	jmp    c1a55a <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac3a>
  c1a54e:	mov    rbx,rax
  c1a551:	test   bpl,bpl
  c1a554:	je     c1a7c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaea6>
  c1a55a:	lea    rdi,[rsp+0xd0]
  c1a562:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a567:	jmp    c1a7c6 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaea6>
  c1a56c:	jmp    c1a5b2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xac92>
  c1a56e:	mov    rbx,rax
  c1a571:	lea    rdi,[rsp+0xd0]
  c1a579:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a57e:	jmp    c1a7db <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaebb>
  c1a583:	jmp    c1a7d8 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaeb8>
  c1a588:	mov    rbx,rax
  c1a58b:	mov    rsi,QWORD PTR [rsp+0x40]
  c1a590:	test   rsi,rsi
  c1a593:	je     c1a8f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xafd2>
  c1a599:	mov    rdi,QWORD PTR [rsp+0x48]
  c1a59e:	shl    rsi,0x4
  c1a5a2:	mov    edx,0x8
  c1a5a7:	call   QWORD PTR [rip+0x233453]        # e4da00 <_DYNAMIC+0x240>
  c1a5ad:	jmp    c1a8f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xafd2>
  c1a5b2:	mov    rbx,rax
  c1a5b5:	lea    rdi,[rsp+0x80]
  c1a5bd:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a5c2:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a5c7:	jmp    c1a822 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf02>
  c1a5cc:	mov    rbx,rax
  c1a5cf:	lea    rdi,[rsp+0xf0]
  c1a5d7:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a5dc:	jmp    c1a904 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xafe4>
  c1a5e1:	mov    rbx,rax
  c1a5e4:	lea    rdi,[rsp+0x40]
  c1a5e9:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a5ee:	jmp    c1a611 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xacf1>
  c1a5f0:	jmp    c1a5f2 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xacd2>
  c1a5f2:	mov    rbx,rax
  c1a5f5:	lea    rdi,[rsp+0x110]
  c1a5fd:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a602:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a607:	jmp    c1a901 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xafe1>
  c1a60c:	jmp    c1a60e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xacee>
  c1a60e:	mov    rbx,rax
  c1a611:	lea    rdi,[rsp+0xd0]
  c1a619:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a61e:	jmp    c1a7aa <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xae8a>
  c1a623:	mov    rbx,rax
  c1a626:	lea    rdi,[rsp+0x80]
  c1a62e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a633:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a638:	mov    rbx,rax
  c1a63b:	lea    rdi,[rsp+0xd0]
  c1a643:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a648:	jmp    c1a810 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaef0>
  c1a64d:	mov    rbx,rax
  c1a650:	lea    rdi,[rsp+0x80]
  c1a658:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a65d:	lea    rdi,[rsp+0x40]
  c1a662:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a667:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a66c:	call   QWORD PTR [rip+0x2333ae]        # e4da20 <_DYNAMIC+0x260>
  c1a672:	mov    rbx,rax
  c1a675:	lea    rdi,[rsp+0x80]
  c1a67d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a682:	lea    rdi,[rsp+0x40]
  c1a687:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a68c:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a691:	call   QWORD PTR [rip+0x233389]        # e4da20 <_DYNAMIC+0x260>
  c1a697:	mov    rbx,rax
  c1a69a:	lea    rdi,[rsp+0x80]
  c1a6a2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a6a7:	lea    rdi,[rsp+0x40]
  c1a6ac:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a6b1:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a6b6:	call   QWORD PTR [rip+0x233364]        # e4da20 <_DYNAMIC+0x260>
  c1a6bc:	mov    rbx,rax
  c1a6bf:	lea    rdi,[rsp+0x80]
  c1a6c7:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a6cc:	lea    rdi,[rsp+0x40]
  c1a6d1:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a6d6:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a6db:	call   QWORD PTR [rip+0x23333f]        # e4da20 <_DYNAMIC+0x260>
  c1a6e1:	jmp    c1a87d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf5d>
  c1a6e6:	mov    rbx,rax
  c1a6e9:	lea    rdi,[rsp+0xd0]
  c1a6f1:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a6f6:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a6fb:	mov    rbx,rax
  c1a6fe:	lea    rdi,[rsp+0xd0]
  c1a706:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a70b:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a710:	jmp    c1a849 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf29>
  c1a715:	jmp    c1a80d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaeed>
  c1a71a:	mov    rbx,rax
  c1a71d:	lea    rdi,[rsp+0x80]
  c1a725:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a72a:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a72f:	jmp    c1a868 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf48>
  c1a734:	mov    rbx,rax
  c1a737:	lea    rdi,[rsp+0x80]
  c1a73f:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a744:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a749:	mov    rbx,rax
  c1a74c:	lea    rdi,[rsp+0x80]
  c1a754:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a759:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a75e:	mov    rbx,rax
  c1a761:	lea    rdi,[rsp+0x40]
  c1a766:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a76b:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a770:	mov    rbx,rax
  c1a773:	lea    rdi,[rsp+0x40]
  c1a778:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a77d:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a782:	mov    rbx,rax
  c1a785:	lea    rdi,[rsp+0x80]
  c1a78d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a792:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a797:	mov    rbx,rax
  c1a79a:	jmp    c1a859 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf39>
  c1a79f:	mov    rbx,rax
  c1a7a2:	jmp    c1a88d <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf6d>
  c1a7a7:	mov    rbx,rax
  c1a7aa:	lea    rdi,[rsp+0xf0]
  c1a7b2:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a7b7:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a7bc:	mov    rbx,rax
  c1a7bf:	jmp    c1a832 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf12>
  c1a7c1:	jmp    c1a841 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf21>
  c1a7c3:	mov    rbx,rax
  c1a7c6:	lea    rdi,[rsp+0xf0]
  c1a7ce:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a7d3:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a7d8:	mov    rbx,rax
  c1a7db:	lea    rdi,[rsp+0xf0]
  c1a7e3:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a7e8:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a7ed:	mov    rbx,rax
  c1a7f0:	lea    rdi,[rsp+0x598]
  c1a7f8:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a7fd:	jmp    c1a8a1 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf81>
  c1a802:	call   QWORD PTR [rip+0x233218]        # e4da20 <_DYNAMIC+0x260>
  c1a808:	jmp    c1a901 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xafe1>
  c1a80d:	mov    rbx,rax
  c1a810:	lea    rdi,[rsp+0x80]
  c1a818:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1a81d:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a822:	mov    rbx,rax
  c1a825:	lea    rdi,[rsp+0x80]
  c1a82d:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a832:	lea    rdi,[rsp+0x40]
  c1a837:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a83c:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a841:	mov    rbx,rax
  c1a844:	jmp    c1a911 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaff1>
  c1a849:	mov    rbx,rax
  c1a84c:	lea    rdi,[rsp+0x80]
  c1a854:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a859:	lea    rdi,[rsp+0x40]
  c1a85e:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a863:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a868:	mov    rbx,rax
  c1a86b:	lea    rdi,[rsp+0x80]
  c1a873:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a878:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a87d:	mov    rbx,rax
  c1a880:	lea    rdi,[rsp+0x80]
  c1a888:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a88d:	lea    rdi,[rsp+0x40]
  c1a892:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a897:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a89c:	jmp    c1a89e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaf7e>
  c1a89e:	mov    rbx,rax
  c1a8a1:	mov    rax,QWORD PTR [rsp+0x80]
  c1a8a9:	test   rax,rax
  c1a8ac:	je     c1a8c9 <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xafa9>
  c1a8ae:	mov    rdi,QWORD PTR [rsp+0x88]
  c1a8b6:	shl    rax,0x3
  c1a8ba:	lea    rsi,[rax+rax*2]
  c1a8be:	mov    edx,0x8
  c1a8c3:	call   QWORD PTR [rip+0x233137]        # e4da00 <_DYNAMIC+0x240>
  c1a8c9:	mov    rsi,QWORD PTR [rsp+0x40]
  c1a8ce:	test   rsi,rsi
  c1a8d1:	je     c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a8d3:	mov    rdi,QWORD PTR [rsp+0x48]
  c1a8d8:	shl    rsi,0x4
  c1a8dc:	mov    edx,0x8
  c1a8e1:	call   QWORD PTR [rip+0x233119]        # e4da00 <_DYNAMIC+0x240>
  c1a8e7:	mov    rdi,rbx
  c1a8ea:	call   d9b550 <_Unwind_Resume@plt>
  c1a8ef:	mov    rbx,rax
  c1a8f2:	lea    rdi,[rsp+0xd0]
  c1a8fa:	call   c0a040 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueEECsbxgXiyEKxkX_6bsl_vm>
  c1a8ff:	jmp    c1a91e <_RNvCsbxgXiyEKxkX_6bsl_vm4step+0xaffe>
  c1a901:	mov    rbx,rax
  c1a904:	lea    rdi,[rsp+0x80]
  c1a90c:	call   c0a3c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsbxgXiyEKxkX_6bsl_vm8CallArgsEBD_>
  c1a911:	lea    rdi,[rsp+0x358]
  c1a919:	call   c0abe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCs54fMbAdz0qV_6bsl_rt5value8BslValueECsbxgXiyEKxkX_6bsl_vm>
  c1a91e:	mov    rdi,rbx
  c1a921:	call   d9b550 <_Unwind_Resume@plt>
  c1a926:	call   QWORD PTR [rip+0x2330f4]        # e4da20 <_DYNAMIC+0x260>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
